# مرجع المعادلات السريع - الإصدار 2.0
## معادلات الحضور والغياب ورصيد الإجازات

---

## ورقة Daily_Attendance (الحضور اليومي)

### العمود C: اسم الموظف
```
=VLOOKUP(B2,Employees!A:B,2,FALSE)
```

### العمود F: ساعات العمل الفعلية
```
=IF(AND(D2<>"",E2<>""),(E2-D2)*24,0)
```

### العمود G: ساعات العمل المطلوبة
```
=VLOOKUP(B2,Employees!A:J,10,FALSE)
```

### العمود H: التأخير (بالدقائق)
```
=IF(D2>TIME(9,0,0),MAX(0,(D2-TIME(9,0,0))*24*60),0)
```
**ملاحظة:** يمكن تغيير TIME(9,0,0) إلى وقت بداية العمل الفعلي في شركتك

### العمود I: الانصراف المبكر (بالدقائق)
```
=IF(E2<TIME(17,0,0),MAX(0,(TIME(17,0,0)-E2)*24*60),0)
```
**ملاحظة:** يمكن تغيير TIME(17,0,0) إلى وقت نهاية العمل الفعلي في شركتك

---

## ورقة Leave_Balance (رصيد الإجازات)

### العمود B: اسم الموظف
```
=VLOOKUP(A2,Employees!A:B,2,FALSE)
```

### العمود D: الإجازات السنوية المستحقة
```
=VLOOKUP(A2,Employees!A:I,9,FALSE)
```

### العمود E: الإجازات السنوية المستخدمة
```
=COUNTIFS(Daily_Attendance!B:B,A2,Daily_Attendance!A:A,">="&DATE(C2,1,1),Daily_Attendance!A:A,"<="&DATE(C2,12,31),Daily_Attendance!K:K,"إجازة سنوية مدفوعة")
```

### العمود F: الرصيد المتبقي (إجازات سنوية)
```
=D2-E2
```

### العمود H: الإجازات المرضية المستخدمة
```
=COUNTIFS(Daily_Attendance!B:B,A2,Daily_Attendance!A:A,">="&DATE(C2,1,1),Daily_Attendance!A:A,"<="&DATE(C2,12,31),Daily_Attendance!K:K,"إجازة مرضية مدفوعة")
```

### العمود I: الرصيد المتبقي (إجازات مرضية)
```
=G2-H2
```

### العمود J: الإجازات الطارئة المستخدمة
```
=COUNTIFS(Daily_Attendance!B:B,A2,Daily_Attendance!A:A,">="&DATE(C2,1,1),Daily_Attendance!A:A,"<="&DATE(C2,12,31),Daily_Attendance!K:K,"إجازة طارئة مدفوعة")
```

### العمود K: الإجازات بدون راتب المستخدمة
```
=COUNTIFS(Daily_Attendance!B:B,A2,Daily_Attendance!A:A,">="&DATE(C2,1,1),Daily_Attendance!A:A,"<="&DATE(C2,12,31),Daily_Attendance!K:K,"إجازة بدون راتب")
```

### العمود L: إجمالي أيام الإجازة المستخدمة
```
=E2+H2+J2+K2
```

### العمود M: تاريخ آخر تحديث
```
=TODAY()
```

---

## ورقة Monthly_Performance (تحديثات جديدة)

### العمود N: معدل الحضور (%)
```
=COUNTIFS(Daily_Attendance!B:B,B2,Daily_Attendance!A:A,">="&DATE(LEFT(A2,4),RIGHT(A2,2),1),Daily_Attendance!A:A,"<"&DATE(LEFT(A2,4),RIGHT(A2,2)+1,1),Daily_Attendance!J:J,"حاضر")/NETWORKDAYS(DATE(LEFT(A2,4),RIGHT(A2,2),1),EOMONTH(DATE(LEFT(A2,4),RIGHT(A2,2),1),0))*100
```

### العمود O: إجمالي التأخير (دقيقة)
```
=SUMIFS(Daily_Attendance!H:H,Daily_Attendance!B:B,B2,Daily_Attendance!A:A,">="&DATE(LEFT(A2,4),RIGHT(A2,2),1),Daily_Attendance!A:A,"<"&DATE(LEFT(A2,4),RIGHT(A2,2)+1,1))
```

---

## ورقة Rewards_Calculator (تحديثات جديدة)

### العمود M: خصومات الغياب
```
=COUNTIFS(Daily_Attendance!B:B,B2,Daily_Attendance!A:A,">="&DATE(LEFT(A2,4),RIGHT(A2,2),1),Daily_Attendance!A:A,"<"&DATE(LEFT(A2,4),RIGHT(A2,2)+1,1),Daily_Attendance!K:K,"غياب بدون إذن")*(D2/26)
```
**شرح:** يُخصم راتب يوم كامل (الراتب الأساسي ÷ 26 يوم عمل) عن كل يوم غياب بدون إذن

### العمود N: خصومات المخالفات
```
=SUMIFS(Violations_Log!I:I,Violations_Log!B:B,B2,Violations_Log!A:A,">="&DATE(LEFT(A2,4),RIGHT(A2,2),1),Violations_Log!A:A,"<"&DATE(LEFT(A2,4),RIGHT(A2,2)+1,1))
```

### العمود O: إجمالي الخصومات
```
=M2+N2
```

### العمود P: صافي المكافآت/الخصومات
```
=L2-O2
```

### العمود Q: الراتب النهائي
```
=D2+P2
```

---

## معادلات متقدمة للتحليل

### 1. حساب عدد أيام الحضور الشهري لموظف
```
=COUNTIFS(Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31),Daily_Attendance!J:J,"حاضر")
```

### 2. حساب عدد أيام الغياب الشهري
```
=COUNTIFS(Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31),Daily_Attendance!J:J,"غائب")
```

### 3. حساب معدل الحضور لموظف معين
```
=COUNTIFS(Daily_Attendance!B:B,"EMP001",Daily_Attendance!J:J,"حاضر",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))/NETWORKDAYS(DATE(2025,10,1),DATE(2025,10,31))*100
```

### 4. حساب إجمالي ساعات التأخير الشهري
```
=SUMIFS(Daily_Attendance!H:H,Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))
```

### 5. حساب عدد مرات التأخير (أكثر من 0 دقيقة)
```
=COUNTIFS(Daily_Attendance!B:B,"EMP001",Daily_Attendance!H:H,">0",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))
```

### 6. حساب خصم التأخير التلقائي (إذا تجاوز 120 دقيقة شهرياً)
```
=IF(SUMIFS(Daily_Attendance!H:H,Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))>120,(800/26/8)*(SUMIFS(Daily_Attendance!H:H,Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))/60),0)
```
**شرح:** 
- 800 = الراتب الأساسي
- 26 = عدد أيام العمل الشهرية
- 8 = ساعات العمل اليومية
- 120 = الحد الأقصى المسموح (دقيقتان يومياً × 60 يوم عمل)

### 7. تحديد الموظفين بمعدل حضور أقل من 90%
```
=FILTER(Leave_Balance!A:B,(COUNTIFS(Daily_Attendance!B:B,Leave_Balance!A:A,Daily_Attendance!J:J,"حاضر")/NETWORKDAYS(DATE(2025,10,1),DATE(2025,10,31)))<0.9)
```

### 8. تحديد الموظفين بتأخير متكرر (أكثر من 3 مرات شهرياً)
```
=FILTER(Employees!A:B,COUNTIFS(Daily_Attendance!B:B,Employees!A:A,Daily_Attendance!H:H,">0",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))>3)
```

### 9. حساب متوسط ساعات العمل الفعلية لموظف
```
=AVERAGEIFS(Daily_Attendance!F:F,Daily_Attendance!B:B,"EMP001",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31),Daily_Attendance!J:J,"حاضر")
```

### 10. حساب معدل الحضور العام للشركة
```
=COUNTIFS(Daily_Attendance!J:J,"حاضر",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))/COUNTIFS(Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))*100
```

---

## معادلات Dashboard (لوحة المعلومات)

### معدل الحضور العام (%)
```
=COUNTIFS(Daily_Attendance!J:J,"حاضر",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))/COUNTIFS(Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))*100
```

### إجمالي ساعات التأخير
```
=SUMIFS(Daily_Attendance!H:H,Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))
```

### عدد حالات الغياب
```
=COUNTIFS(Daily_Attendance!J:J,"غائب",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))
```

### عدد الإجازات المستخدمة (جميع الأنواع)
```
=COUNTIFS(Daily_Attendance!J:J,"إجازة*",Daily_Attendance!A:A,">="&DATE(2025,10,1),Daily_Attendance!A:A,"<="&DATE(2025,10,31))
```

### أفضل 5 موظفين من حيث الحضور
```
=SORT(UNIQUE(FILTER(Daily_Attendance!B:C,Daily_Attendance!A:A>=DATE(2025,10,1),Daily_Attendance!A:A<=DATE(2025,10,31))),COUNTIFS(Daily_Attendance!B:B,Daily_Attendance!B:B,Daily_Attendance!J:J,"حاضر"),FALSE)
```

---

## نصائح مهمة

### 1. تنسيق الوقت
تأكد من تنسيق الأعمدة D و E في ورقة Daily_Attendance بتنسيق الوقت:
- حدد العمود
- تنسيق > رقم > وقت
- اختر التنسيق: HH:MM

### 2. تنسيق التاريخ
تأكد من تنسيق عمود التاريخ (A) بتنسيق التاريخ:
- حدد العمود
- تنسيق > رقم > تاريخ
- اختر التنسيق: YYYY-MM-DD

### 3. استخدام NETWORKDAYS
دالة NETWORKDAYS تحسب أيام العمل فقط (تستثني الجمعة والسبت تلقائياً):
```
=NETWORKDAYS(تاريخ_البداية, تاريخ_النهاية)
```

لاستثناء الإجازات الرسمية أيضاً:
```
=NETWORKDAYS(تاريخ_البداية, تاريخ_النهاية, نطاق_الإجازات_الرسمية)
```

### 4. استخدام EOMONTH
للحصول على آخر يوم في الشهر:
```
=EOMONTH(DATE(2025,10,1),0)
```
النتيجة: 2025-10-31

### 5. تحويل الشهر من نص إلى تاريخ
إذا كان الشهر بصيغة "2025-10":
```
تاريخ البداية: =DATE(LEFT(A2,4),RIGHT(A2,2),1)
تاريخ النهاية: =EOMONTH(DATE(LEFT(A2,4),RIGHT(A2,2),1),0)
```

---

## أمثلة عملية

### مثال 1: حساب الراتب النهائي لأحمد في أكتوبر 2025

**البيانات:**
- الراتب الأساسي: 800 ريال
- أيام الحضور: 20 يوم
- إجمالي التأخير: 95 دقيقة
- أيام الغياب بدون إذن: 0
- مكافأة العمل الإضافي: 34.13 ريال
- مكافأة الأفكار: 100 ريال

**الحساب:**
```
الراتب الأساسي: 800.00
+ العمل الإضافي: 34.13
+ الأفكار: 100.00
- خصومات الغياب: 0.00
- خصومات المخالفات: 0.00
= الراتب النهائي: 934.13 ريال
```

### مثال 2: حساب خصم التأخير لموظف تأخر 150 دقيقة في الشهر

**البيانات:**
- الراتب الأساسي: 800 ريال
- إجمالي التأخير: 150 دقيقة (2.5 ساعة)
- الحد المسموح: 120 دقيقة

**الحساب:**
```
أجر الساعة = 800 ÷ 26 ÷ 8 = 3.85 ريال/ساعة
التأخير الزائد = 150 - 120 = 30 دقيقة = 0.5 ساعة
الخصم = 0.5 × 3.85 = 1.92 ريال
```

**المعادلة:**
```
=IF(150>120,(800/26/8)*((150-120)/60),0)
```
النتيجة: 1.92 ريال

### مثال 3: حساب خصم الغياب بدون إذن

**البيانات:**
- الراتب الأساسي: 800 ريال
- أيام الغياب بدون إذن: 2 يوم

**الحساب:**
```
أجر اليوم = 800 ÷ 26 = 30.77 ريال/يوم
الخصم = 2 × 30.77 = 61.54 ريال
```

**المعادلة:**
```
=2*(800/26)
```
النتيجة: 61.54 ريال

---

## الخلاصة

هذا المرجع يحتوي على جميع المعادلات الأساسية والمتقدمة التي تحتاجها لإدارة نظام الحضور والغياب والمكافآت بشكل كامل.

**تذكر:**
- انسخ المعادلات كما هي
- استبدل "EMP001" برقم الموظف الفعلي أو استخدم مرجع الخلية
- استبدل DATE(2025,10,1) بتاريخ بداية الشهر الفعلي
- استبدل 800 بالراتب الأساسي الفعلي أو استخدم مرجع الخلية

**النظام جاهز للاستخدام!** 🚀

