---
last_updated: 2026-06-06T13:48:32Z
status: pending
---

# Project Context

## Project Overview

## Key Decisions
| Date | Decision | By | Rationale |
|------|----------|-----|-----------|

## Constraints


> This file was auto-generated and has not been fully adapted.
> For project details, refer to .wiki.md (may be outdated); current code is authoritative.
> You can trigger full adaptation via the frontend at any time.

