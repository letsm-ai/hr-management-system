# نظام إدارة الموارد البشرية (HR Management System)

نظام متكامل لإدارة الموارد البشرية يشمل إدارة الموظفين، الحضور، العقود، المكافآت، تقييم الأداء، وتكامل ClickUp.

## 🚀 المميزات

- **إدارة الموظفين**: إضافة وتعديل وحذف بيانات الموظفين
- **إدارة الحضور**: تتبع الحضور والانصراف والإجازات والعمل الإضافي
- **إدارة العقود**: عقود الموظفين وعقود العملاء مع تنبيهات الانتهاء
- **نظام المكافآت**: حساب المكافآت الشهرية بناءً على الأداء
- **تقييم الأداء**: تقييم شهري تلقائي (حضور + إنتاجية + جودة)
- **تكامل ClickUp**: مزامنة بيانات الإنتاجية من ClickUp
- **التقارير**: تقارير شاملة للرواتب والمكافآت والمخالفات
- **إدارة المستخدمين**: نظام صلاحيات متعدد الأدوار
- **لوحة تحكم**: إحصائيات ورسوم بيانية تفاعلية

## 📋 المتطلبات

- Docker & Docker Compose
- أو:
  - Node.js 20+
  - Python 3.11+
  - PostgreSQL 15+

## 🏗️ هيكل المشروع

```
app/
├── backend/                 # خادم FastAPI
│   ├── core/               # الإعدادات والمصادقة وقاعدة البيانات
│   ├── models/             # نماذج SQLAlchemy
│   ├── routers/            # مسارات API
│   ├── services/           # منطق الأعمال
│   ├── schemas/            # مخططات Pydantic
│   ├── alembic/            # ترحيل قاعدة البيانات
│   ├── Dockerfile          # حاوية Docker للخادم
│   └── requirements.txt    # اعتماديات Python
├── frontend/               # واجهة React
│   ├── src/
│   │   ├── components/     # مكونات UI
│   │   ├── pages/          # صفحات التطبيق
│   │   ├── lib/            # مكتبات مساعدة
│   │   └── contexts/       # سياقات React
│   ├── Dockerfile          # حاوية Docker للواجهة
│   ├── nginx.conf          # إعدادات Nginx
│   └── package.json        # اعتماديات Node.js
├── docker-compose.yml      # تنسيق Docker
├── .env.example            # نموذج متغيرات البيئة
└── README.md               # هذا الملف
```

## 🚀 التشغيل السريع (Docker)

### 1. استنساخ المشروع

```bash
git clone https://github.com/your-username/hr-system.git
cd hr-system
```

### 2. إعداد متغيرات البيئة

```bash
cp .env.example .env
# قم بتعديل .env وتغيير القيم الافتراضية
```

**⚠️ مهم**: غيّر القيم التالية في ملف `.env`:
- `POSTGRES_PASSWORD` - كلمة مرور قاعدة البيانات
- `JWT_SECRET_KEY` - مفتاح سري لتوقيع التوكنات

### 3. التشغيل

```bash
docker-compose up -d --build
```

### 4. الوصول

- **الواجهة**: http://localhost
- **API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

## 💻 التشغيل المحلي (بدون Docker)

### Backend

```bash
cd backend

# إنشاء بيئة افتراضية
python -m venv venv
source venv/bin/activate  # Linux/Mac
# أو: venv\Scripts\activate  # Windows

# تثبيت الاعتماديات
pip install -r requirements.txt

# إعداد متغيرات البيئة
export DATABASE_URL="postgresql+asyncpg://postgres:password@localhost:5432/hr_system"
export JWT_SECRET_KEY="your-secret-key"
export JWT_ALGORITHM="HS256"
export JWT_EXPIRE_MINUTES="1440"
export ADMIN_USER_ID="admin"
export ADMIN_USER_EMAIL="admin@example.com"

# تشغيل الخادم
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend

```bash
cd frontend

# تثبيت الاعتماديات
npm install -g pnpm
pnpm install

# التشغيل في وضع التطوير
pnpm run dev

# أو البناء للإنتاج
pnpm run build
```

## 🌐 النشر على VPS

### المتطلبات
- سيرفر VPS (Ubuntu 22.04+ مُوصى)
- Docker & Docker Compose مثبتان
- دومين (اختياري)

### خطوات النشر

#### 1. تجهيز السيرفر

```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# تثبيت Docker Compose
sudo apt install docker-compose-plugin -y

# إضافة المستخدم لمجموعة Docker
sudo usermod -aG docker $USER
newgrp docker
```

#### 2. رفع المشروع

```bash
# استنساخ من GitHub
git clone https://github.com/your-username/hr-system.git
cd hr-system

# إعداد البيئة
cp .env.example .env
nano .env  # تعديل القيم
```

#### 3. التشغيل

```bash
# بناء وتشغيل الحاويات
docker-compose up -d --build

# التحقق من الحالة
docker-compose ps
docker-compose logs -f
```

#### 4. إعداد SSL (اختياري - مع دومين)

```bash
# تثبيت Certbot
sudo apt install certbot python3-certbot-nginx -y

# الحصول على شهادة SSL
sudo certbot --nginx -d yourdomain.com
```

### إعداد Nginx كـ Reverse Proxy (بدون Docker للواجهة)

إذا أردت استخدام Nginx على السيرفر مباشرة:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        root /var/www/hr-system/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## 🔧 إدارة قاعدة البيانات

### ترحيل قاعدة البيانات (Alembic)

```bash
cd backend

# إنشاء ترحيل جديد
alembic revision --autogenerate -m "وصف التغيير"

# تطبيق الترحيلات
alembic upgrade head

# التراجع
alembic downgrade -1
```

### النسخ الاحتياطي

```bash
# نسخ احتياطي
docker exec hr_database pg_dump -U postgres hr_system > backup_$(date +%Y%m%d).sql

# استعادة
docker exec -i hr_database psql -U postgres hr_system < backup_file.sql
```

## 🔐 الأمان

- جميع كلمات المرور مشفرة
- JWT tokens مع انتهاء صلاحية قابل للتكوين
- CORS مُقيّد في بيئة الإنتاج
- Rate limiting على API endpoints
- SQL injection protection عبر SQLAlchemy ORM
- XSS protection عبر React DOM escaping

## 📊 API Documentation

بعد تشغيل الخادم، يمكنك الوصول إلى:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🤝 المساهمة

1. Fork المشروع
2. إنشاء فرع جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'إضافة ميزة جديدة'`)
4. Push للفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT.