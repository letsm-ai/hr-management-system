"""Unit tests for the notification service.

Tests cover all CRUD operations:
- create_notification
- get_notifications (all + unread_only)
- get_unread_count
- mark_as_read
- mark_all_as_read
- delete_notification

Uses an in-memory SQLite database so no external services are required.
"""

import pytest
import pytest_asyncio
from datetime import datetime
from unittest.mock import patch, AsyncMock

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

# ---------------------------------------------------------------------------
# SQLite-compatible schema (mirrors the PostgreSQL production table)
# ---------------------------------------------------------------------------
SQLITE_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id VARCHAR NOT NULL,
    employee_id INTEGER NOT NULL,
    type VARCHAR NOT NULL,
    title VARCHAR NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT 0,
    related_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

# A no-op async function that accepts any arguments (replaces ensure_table)
async def _noop_ensure_table(*args, **kwargs):
    pass


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def engine():
    """Create an in-memory async SQLite engine."""
    eng = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture
async def db_session(engine):
    """Provide a transactional database session for each test."""
    async with engine.begin() as conn:
        await conn.execute(text(SQLITE_CREATE_TABLE))

    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with session_factory() as session:
        yield session


# ---------------------------------------------------------------------------
# Auto-patch ensure_table for ALL tests in this module
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def patch_ensure_table():
    """Automatically patch ensure_table for every test so it doesn't run PostgreSQL DDL."""
    with patch(
        "services.notification_service.ensure_table",
        side_effect=_noop_ensure_table,
    ):
        yield


# ---------------------------------------------------------------------------
# Tests: create_notification
# ---------------------------------------------------------------------------
class TestCreateNotification:
    """Tests for the create_notification function."""

    @pytest.mark.asyncio
    async def test_create_basic(self, db_session: AsyncSession):
        """Should insert a notification with correct data types."""
        from services.notification_service import create_notification

        await create_notification(
            db=db_session,
            user_id="user-001",
            employee_id=42,
            notif_type="contract_expiry",
            title="عقد على وشك الانتهاء",
            message="العقد رقم 100 ينتهي خلال 30 يوم",
            related_id=100,
        )

        # Verify the row was persisted
        result = await db_session.execute(
            text("SELECT user_id, employee_id, type, title, message, is_read, related_id, created_at FROM notifications")
        )
        row = result.fetchone()
        assert row is not None

        user_id, employee_id, notif_type, title, message, is_read, related_id, created_at = row
        assert user_id == "user-001"
        assert employee_id == 42
        assert notif_type == "contract_expiry"
        assert title == "عقد على وشك الانتهاء"
        assert message == "العقد رقم 100 ينتهي خلال 30 يوم"
        assert related_id == 100
        # is_read should be False / 0
        assert is_read in (False, 0)
        # created_at must have been set
        assert created_at is not None

    @pytest.mark.asyncio
    async def test_create_without_related_id(self, db_session: AsyncSession):
        """Should allow related_id to be None."""
        from services.notification_service import create_notification

        await create_notification(
            db=db_session,
            user_id="user-002",
            employee_id=10,
            notif_type="leave_rejected",
            title="طلب إجازة مرفوض",
            message="تم رفض طلب الإجازة",
        )

        result = await db_session.execute(
            text("SELECT related_id FROM notifications WHERE user_id = 'user-002'")
        )
        row = result.fetchone()
        assert row is not None
        assert row[0] is None

    @pytest.mark.asyncio
    async def test_create_multiple(self, db_session: AsyncSession):
        """Should create multiple notifications for the same user."""
        from services.notification_service import create_notification

        for i in range(5):
            await create_notification(
                db=db_session,
                user_id="user-003",
                employee_id=i,
                notif_type="info",
                title=f"إشعار {i}",
                message=f"رسالة الإشعار رقم {i}",
            )

        result = await db_session.execute(
            text("SELECT COUNT(*) FROM notifications WHERE user_id = 'user-003'")
        )
        assert result.scalar() == 5


# ---------------------------------------------------------------------------
# Tests: get_notifications
# ---------------------------------------------------------------------------
class TestGetNotifications:
    """Tests for the get_notifications function."""

    async def _seed(self, db: AsyncSession, count: int = 3, user_id: str = "user-100"):
        """Insert test notifications directly."""
        from services.notification_service import create_notification

        for i in range(count):
            await create_notification(
                db=db,
                user_id=user_id,
                employee_id=i,
                notif_type="info",
                title=f"إشعار {i}",
                message=f"رسالة {i}",
                related_id=i * 10,
            )

    @pytest.mark.asyncio
    async def test_get_all(self, db_session: AsyncSession):
        """Should return all notifications for a user."""
        from services.notification_service import get_notifications

        await self._seed(db_session, count=3)
        items = await get_notifications(db_session, "user-100")

        assert len(items) == 3
        # Each item should be a dict with expected keys
        for item in items:
            assert "id" in item
            assert "user_id" in item
            assert "employee_id" in item
            assert "type" in item
            assert "title" in item
            assert "message" in item
            assert "is_read" in item
            assert "created_at" in item

    @pytest.mark.asyncio
    async def test_get_unread_only(self, db_session: AsyncSession):
        """Should filter to unread notifications when unread_only=True."""
        from services.notification_service import get_notifications, mark_as_read

        await self._seed(db_session, count=3)

        # Mark the first notification as read
        all_items = await get_notifications(db_session, "user-100")
        first_id = all_items[0]["id"]
        await mark_as_read(db_session, "user-100", first_id)

        unread = await get_notifications(db_session, "user-100", unread_only=True)
        assert len(unread) == 2

    @pytest.mark.asyncio
    async def test_get_with_limit(self, db_session: AsyncSession):
        """Should respect the limit parameter."""
        from services.notification_service import get_notifications

        await self._seed(db_session, count=10)
        items = await get_notifications(db_session, "user-100", limit=5)
        assert len(items) == 5

    @pytest.mark.asyncio
    async def test_get_empty(self, db_session: AsyncSession):
        """Should return empty list for a user with no notifications."""
        from services.notification_service import get_notifications

        items = await get_notifications(db_session, "non-existent-user")
        assert items == []

    @pytest.mark.asyncio
    async def test_user_isolation(self, db_session: AsyncSession):
        """Notifications for one user should not appear for another."""
        from services.notification_service import get_notifications

        await self._seed(db_session, count=3, user_id="user-A")
        await self._seed(db_session, count=2, user_id="user-B")

        items_a = await get_notifications(db_session, "user-A")
        items_b = await get_notifications(db_session, "user-B")

        assert len(items_a) == 3
        assert len(items_b) == 2


# ---------------------------------------------------------------------------
# Tests: get_unread_count
# ---------------------------------------------------------------------------
class TestGetUnreadCount:
    """Tests for the get_unread_count function."""

    @pytest.mark.asyncio
    async def test_initial_count(self, db_session: AsyncSession):
        """All new notifications should be unread."""
        from services.notification_service import create_notification, get_unread_count

        for i in range(4):
            await create_notification(
                db=db_session, user_id="user-200", employee_id=i,
                notif_type="info", title=f"t{i}", message=f"m{i}",
            )
        count = await get_unread_count(db_session, "user-200")
        assert count == 4

    @pytest.mark.asyncio
    async def test_count_after_read(self, db_session: AsyncSession):
        """Count should decrease after marking as read."""
        from services.notification_service import (
            create_notification, get_notifications, get_unread_count, mark_as_read,
        )

        await create_notification(
            db=db_session, user_id="user-201", employee_id=1,
            notif_type="info", title="t", message="m",
        )
        await create_notification(
            db=db_session, user_id="user-201", employee_id=2,
            notif_type="info", title="t2", message="m2",
        )

        items = await get_notifications(db_session, "user-201")
        await mark_as_read(db_session, "user-201", items[0]["id"])
        count = await get_unread_count(db_session, "user-201")
        assert count == 1

    @pytest.mark.asyncio
    async def test_count_zero_for_unknown_user(self, db_session: AsyncSession):
        """Should return 0 for a user with no notifications."""
        from services.notification_service import get_unread_count

        count = await get_unread_count(db_session, "ghost-user")
        assert count == 0


# ---------------------------------------------------------------------------
# Tests: mark_as_read
# ---------------------------------------------------------------------------
class TestMarkAsRead:
    """Tests for the mark_as_read function."""

    @pytest.mark.asyncio
    async def test_mark_single(self, db_session: AsyncSession):
        """Should mark exactly one notification as read."""
        from services.notification_service import (
            create_notification, get_notifications, mark_as_read,
        )

        await create_notification(
            db=db_session, user_id="user-300", employee_id=1,
            notif_type="alert", title="تنبيه", message="رسالة تنبيه",
        )
        await create_notification(
            db=db_session, user_id="user-300", employee_id=2,
            notif_type="alert", title="تنبيه 2", message="رسالة تنبيه 2",
        )

        items = await get_notifications(db_session, "user-300")
        target_id = items[0]["id"]
        await mark_as_read(db_session, "user-300", target_id)

        updated = await get_notifications(db_session, "user-300")
        read_items = [i for i in updated if i["is_read"] in (True, 1)]
        unread_items = [i for i in updated if i["is_read"] in (False, 0)]
        assert len(read_items) == 1
        assert len(unread_items) == 1

    @pytest.mark.asyncio
    async def test_mark_wrong_user(self, db_session: AsyncSession):
        """Marking with wrong user_id should not affect the notification."""
        from services.notification_service import (
            create_notification, get_notifications, mark_as_read,
        )

        await create_notification(
            db=db_session, user_id="user-301", employee_id=1,
            notif_type="info", title="t", message="m",
        )
        items = await get_notifications(db_session, "user-301")
        target_id = items[0]["id"]

        # Try marking with a different user
        await mark_as_read(db_session, "wrong-user", target_id)

        items_after = await get_notifications(db_session, "user-301")
        assert items_after[0]["is_read"] in (False, 0)


# ---------------------------------------------------------------------------
# Tests: mark_all_as_read
# ---------------------------------------------------------------------------
class TestMarkAllAsRead:
    """Tests for the mark_all_as_read function."""

    @pytest.mark.asyncio
    async def test_mark_all(self, db_session: AsyncSession):
        """Should mark all notifications as read for a user."""
        from services.notification_service import (
            create_notification, get_unread_count, mark_all_as_read,
        )

        for i in range(5):
            await create_notification(
                db=db_session, user_id="user-400", employee_id=i,
                notif_type="info", title=f"t{i}", message=f"m{i}",
            )

        await mark_all_as_read(db_session, "user-400")
        count = await get_unread_count(db_session, "user-400")
        assert count == 0

    @pytest.mark.asyncio
    async def test_mark_all_does_not_affect_other_users(self, db_session: AsyncSession):
        """mark_all_as_read for user A should not affect user B."""
        from services.notification_service import (
            create_notification, get_unread_count, mark_all_as_read,
        )

        await create_notification(
            db=db_session, user_id="user-A", employee_id=1,
            notif_type="info", title="t", message="m",
        )
        await create_notification(
            db=db_session, user_id="user-B", employee_id=2,
            notif_type="info", title="t", message="m",
        )

        await mark_all_as_read(db_session, "user-A")

        count_a = await get_unread_count(db_session, "user-A")
        count_b = await get_unread_count(db_session, "user-B")
        assert count_a == 0
        assert count_b == 1


# ---------------------------------------------------------------------------
# Tests: delete_notification
# ---------------------------------------------------------------------------
class TestDeleteNotification:
    """Tests for the delete_notification function."""

    @pytest.mark.asyncio
    async def test_delete_existing(self, db_session: AsyncSession):
        """Should delete a notification by id."""
        from services.notification_service import (
            create_notification, delete_notification, get_notifications,
        )

        await create_notification(
            db=db_session, user_id="user-500", employee_id=1,
            notif_type="info", title="حذف", message="سيتم حذف هذا الإشعار",
        )
        items = await get_notifications(db_session, "user-500")
        assert len(items) == 1
        target_id = items[0]["id"]

        await delete_notification(db_session, "user-500", target_id)

        items_after = await get_notifications(db_session, "user-500")
        assert len(items_after) == 0

    @pytest.mark.asyncio
    async def test_delete_wrong_user(self, db_session: AsyncSession):
        """Deleting with wrong user_id should not remove the notification."""
        from services.notification_service import (
            create_notification, delete_notification, get_notifications,
        )

        await create_notification(
            db=db_session, user_id="user-501", employee_id=1,
            notif_type="info", title="t", message="m",
        )
        items = await get_notifications(db_session, "user-501")
        target_id = items[0]["id"]

        await delete_notification(db_session, "wrong-user", target_id)

        items_after = await get_notifications(db_session, "user-501")
        assert len(items_after) == 1

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, db_session: AsyncSession):
        """Deleting a non-existent notification should not raise an error."""
        from services.notification_service import delete_notification

        # Should not raise
        await delete_notification(db_session, "user-502", 99999)


# ---------------------------------------------------------------------------
# Tests: data type correctness (regression for the strftime bug)
# ---------------------------------------------------------------------------
class TestDataTypes:
    """Verify that correct Python types are passed to the database."""

    @pytest.mark.asyncio
    async def test_created_at_is_datetime(self, db_session: AsyncSession):
        """created_at parameter must be a datetime object, not a string.

        This is a regression test for the bug where datetime.now().strftime()
        was used, causing asyncpg to reject the string value for a TIMESTAMP column.
        """
        from services.notification_service import create_notification

        # This should NOT raise any type errors
        await create_notification(
            db=db_session,
            user_id="user-type-check",
            employee_id=1,
            notif_type="test",
            title="اختبار نوع البيانات",
            message="التحقق من أن created_at هو كائن datetime",
        )

        result = await db_session.execute(
            text("SELECT created_at FROM notifications WHERE user_id = 'user-type-check'")
        )
        row = result.fetchone()
        assert row is not None
        # The value should have been inserted successfully
        assert row[0] is not None

    @pytest.mark.asyncio
    async def test_created_at_param_type_in_code(self):
        """Verify that the source code passes datetime.now() not strftime()."""
        import inspect
        from services.notification_service import create_notification

        source = inspect.getsource(create_notification)
        # Must NOT contain strftime (the old bug)
        assert "strftime" not in source, "create_notification should not use strftime for created_at"
        # Must contain datetime.now()
        assert "datetime.now()" in source, "create_notification should use datetime.now() directly"

    @pytest.mark.asyncio
    async def test_notification_response_format(self, db_session: AsyncSession):
        """get_notifications should return properly formatted dicts."""
        from services.notification_service import create_notification, get_notifications

        await create_notification(
            db=db_session,
            user_id="user-format",
            employee_id=7,
            notif_type="contract_expiry",
            title="تنسيق الاستجابة",
            message="التحقق من تنسيق البيانات المرجعة",
            related_id=42,
        )
        items = await get_notifications(db_session, "user-format")

        assert len(items) == 1
        item = items[0]

        # Check types
        assert isinstance(item["id"], int)
        assert isinstance(item["user_id"], str)
        assert isinstance(item["employee_id"], int)
        assert isinstance(item["type"], str)
        assert isinstance(item["title"], str)
        assert isinstance(item["message"], str)
        assert item["is_read"] in (True, False, 0, 1)
        assert isinstance(item["related_id"], int)
        # created_at should be an ISO format string or None
        assert item["created_at"] is None or isinstance(item["created_at"], str)