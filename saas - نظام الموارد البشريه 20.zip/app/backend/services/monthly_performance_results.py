import logging
from typing import Any, Dict, List, Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.monthly_performance_results import Monthly_performance_results

logger = logging.getLogger(__name__)


class Monthly_performance_resultsService:
    """Service layer for Monthly_performance_results operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Monthly_performance_results]:
        """Create a new monthly performance result"""
        try:
            obj = Monthly_performance_results(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created monthly_performance_results with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating monthly_performance_results: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Monthly_performance_results]:
        """Get by ID"""
        query = select(Monthly_performance_results).where(Monthly_performance_results.id == obj_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_by_employee_month(self, employee_id: int, month: str) -> Optional[Monthly_performance_results]:
        """Get result for a specific employee and month"""
        query = select(Monthly_performance_results).where(
            Monthly_performance_results.employee_id == employee_id,
            Monthly_performance_results.month == month,
        )
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_list(
        self,
        skip: int = 0,
        limit: int = 20,
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list"""
        query = select(Monthly_performance_results)
        count_query = select(func.count(Monthly_performance_results.id))

        if query_dict:
            for field, value in query_dict.items():
                if hasattr(Monthly_performance_results, field):
                    query = query.where(getattr(Monthly_performance_results, field) == value)
                    count_query = count_query.where(getattr(Monthly_performance_results, field) == value)

        count_result = await self.db.execute(count_query)
        total = count_result.scalar()

        if sort:
            if sort.startswith("-"):
                field_name = sort[1:]
                if hasattr(Monthly_performance_results, field_name):
                    query = query.order_by(getattr(Monthly_performance_results, field_name).desc())
            else:
                if hasattr(Monthly_performance_results, sort):
                    query = query.order_by(getattr(Monthly_performance_results, sort))
        else:
            query = query.order_by(Monthly_performance_results.id.desc())

        result = await self.db.execute(query.offset(skip).limit(limit))
        items = result.scalars().all()

        return {"items": items, "total": total, "skip": skip, "limit": limit}

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Monthly_performance_results]:
        """Update monthly performance result"""
        obj = await self.get_by_id(obj_id)
        if not obj:
            return None
        for key, value in update_data.items():
            if hasattr(obj, key):
                setattr(obj, key, value)
        await self.db.commit()
        await self.db.refresh(obj)
        return obj

    async def delete(self, obj_id: int) -> bool:
        """Delete monthly performance result"""
        obj = await self.get_by_id(obj_id)
        if not obj:
            return False
        await self.db.delete(obj)
        await self.db.commit()
        return True