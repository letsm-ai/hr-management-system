import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func, text
from sqlalchemy.ext.asyncio import AsyncSession

from models.attendance_records import Attendance_records

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Attendance_recordsService:
    """Service layer for Attendance_records operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Attendance_records]:
        """Create a new attendance_records with auto-retry on sequence conflict"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                obj = Attendance_records(**data)
                self.db.add(obj)
                await self.db.commit()
                await self.db.refresh(obj)
                logger.info(f"Created attendance_records with id: {obj.id}")
                return obj
            except Exception as e:
                await self.db.rollback()
                error_str = str(e)
                # Check if this is a duplicate key / sequence conflict error
                if "UniqueViolationError" in error_str or "duplicate key" in error_str:
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"Sequence conflict on attempt {attempt + 1}, resetting sequence and retrying..."
                        )
                        try:
                            await self.db.execute(
                                text(
                                    "SELECT setval("
                                    "pg_get_serial_sequence('attendance_records', 'id'), "
                                    "COALESCE((SELECT MAX(id) FROM attendance_records), 0) + 1, "
                                    "false)"
                                )
                            )
                            await self.db.commit()
                            logger.info("Sequence reset successfully, retrying insert...")
                            continue
                        except Exception as seq_err:
                            logger.error(f"Failed to reset sequence: {seq_err}")
                            await self.db.rollback()
                    # Final attempt failed
                    logger.error(f"Error creating attendance_records after {max_retries} attempts: {error_str}")
                    raise
                else:
                    logger.error(f"Error creating attendance_records: {error_str}")
                    raise
        return None

    async def find_by_employee_and_date(self, employee_id: int, date: str) -> Optional[Attendance_records]:
        """Find attendance record by employee_id and date (for upsert logic)"""
        try:
            query = select(Attendance_records).where(
                Attendance_records.employee_id == employee_id,
                Attendance_records.date == date,
            )
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error finding attendance_records for employee {employee_id} on {date}: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Attendance_records]:
        """Get attendance_records by ID"""
        try:
            query = select(Attendance_records).where(Attendance_records.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching attendance_records {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of attendance_recordss"""
        try:
            query = select(Attendance_records)
            count_query = select(func.count(Attendance_records.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Attendance_records, field):
                        query = query.where(getattr(Attendance_records, field) == value)
                        count_query = count_query.where(getattr(Attendance_records, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Attendance_records, field_name):
                        query = query.order_by(getattr(Attendance_records, field_name).desc())
                else:
                    if hasattr(Attendance_records, sort):
                        query = query.order_by(getattr(Attendance_records, sort))
            else:
                query = query.order_by(Attendance_records.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching attendance_records list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Attendance_records]:
        """Update attendance_records"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Attendance_records {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated attendance_records {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating attendance_records {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete attendance_records"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Attendance_records {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted attendance_records {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting attendance_records {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Attendance_records]:
        """Get attendance_records by any field"""
        try:
            if not hasattr(Attendance_records, field_name):
                raise ValueError(f"Field {field_name} does not exist on Attendance_records")
            result = await self.db.execute(
                select(Attendance_records).where(getattr(Attendance_records, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching attendance_records by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Attendance_records]:
        """Get list of attendance_recordss filtered by field"""
        try:
            if not hasattr(Attendance_records, field_name):
                raise ValueError(f"Field {field_name} does not exist on Attendance_records")
            result = await self.db.execute(
                select(Attendance_records)
                .where(getattr(Attendance_records, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Attendance_records.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching attendance_recordss by {field_name}: {str(e)}")
            raise