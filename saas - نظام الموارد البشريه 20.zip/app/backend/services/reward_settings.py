import logging
from typing import Any, Dict, List, Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.reward_settings import Reward_settings

logger = logging.getLogger(__name__)


class Reward_settingsService:
    """Service layer for Reward_settings operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_or_create_default(self) -> Reward_settings:
        """Get the single settings row, or create one with defaults."""
        query = select(Reward_settings).limit(1)
        result = await self.db.execute(query)
        obj = result.scalar_one_or_none()
        if obj:
            return obj
        # Create default row
        obj = Reward_settings(
            attendance_weight=0.30,
            productivity_weight=0.45,
            quality_weight=0.25,
            excellent_threshold=0.85,
            excellent_reward_percent=15.00,
            good_threshold=0.70,
            good_reward_percent=10.00,
            fair_threshold=0.55,
            fair_reward_percent=5.00,
            working_days_per_month=30,
            late_minor_threshold_minutes=15,
            absent_annual_leave_points=100,
            absent_approved_points=50,
            absent_unapproved_points=0,
        )
        self.db.add(obj)
        await self.db.commit()
        await self.db.refresh(obj)
        logger.info("Created default reward_settings row")
        return obj

    async def update_settings(self, update_data: Dict[str, Any]) -> Reward_settings:
        """Update the reward settings."""
        obj = await self.get_or_create_default()
        for key, value in update_data.items():
            if hasattr(obj, key) and key != "id":
                setattr(obj, key, value)
        await self.db.commit()
        await self.db.refresh(obj)
        logger.info("Updated reward_settings")
        return obj

    async def create(self, data: Dict[str, Any]) -> Optional[Reward_settings]:
        """Create a new reward_settings"""
        try:
            obj = Reward_settings(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating reward_settings: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Reward_settings]:
        """Get reward_settings by ID"""
        query = select(Reward_settings).where(Reward_settings.id == obj_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_list(
        self,
        skip: int = 0,
        limit: int = 20,
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list"""
        query = select(Reward_settings)
        count_query = select(func.count(Reward_settings.id))

        if query_dict:
            for field, value in query_dict.items():
                if hasattr(Reward_settings, field):
                    query = query.where(getattr(Reward_settings, field) == value)
                    count_query = count_query.where(getattr(Reward_settings, field) == value)

        count_result = await self.db.execute(count_query)
        total = count_result.scalar()

        if sort:
            if sort.startswith("-"):
                field_name = sort[1:]
                if hasattr(Reward_settings, field_name):
                    query = query.order_by(getattr(Reward_settings, field_name).desc())
            else:
                if hasattr(Reward_settings, sort):
                    query = query.order_by(getattr(Reward_settings, sort))
        else:
            query = query.order_by(Reward_settings.id.desc())

        result = await self.db.execute(query.offset(skip).limit(limit))
        items = result.scalars().all()

        return {"items": items, "total": total, "skip": skip, "limit": limit}

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Reward_settings]:
        """Update reward_settings"""
        obj = await self.get_by_id(obj_id)
        if not obj:
            return None
        for key, value in update_data.items():
            if hasattr(obj, key):
                setattr(obj, key, value)
        await self.db.commit()
        await self.db.refresh(obj)
        return obj

    async def delete(self, obj_id: int) -> bool:
        """Delete reward_settings"""
        obj = await self.get_by_id(obj_id)
        if not obj:
            return False
        await self.db.delete(obj)
        await self.db.commit()
        return True