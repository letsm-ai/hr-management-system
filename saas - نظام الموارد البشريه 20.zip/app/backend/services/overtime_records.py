import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.overtime_records import Overtime_records

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Overtime_recordsService:
    """Service layer for Overtime_records operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Overtime_records]:
        """Create a new overtime_records"""
        try:
            obj = Overtime_records(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created overtime_records with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating overtime_records: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Overtime_records]:
        """Get overtime_records by ID"""
        try:
            query = select(Overtime_records).where(Overtime_records.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching overtime_records {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of overtime_recordss"""
        try:
            query = select(Overtime_records)
            count_query = select(func.count(Overtime_records.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Overtime_records, field):
                        query = query.where(getattr(Overtime_records, field) == value)
                        count_query = count_query.where(getattr(Overtime_records, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Overtime_records, field_name):
                        query = query.order_by(getattr(Overtime_records, field_name).desc())
                else:
                    if hasattr(Overtime_records, sort):
                        query = query.order_by(getattr(Overtime_records, sort))
            else:
                query = query.order_by(Overtime_records.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching overtime_records list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Overtime_records]:
        """Update overtime_records"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Overtime_records {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated overtime_records {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating overtime_records {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete overtime_records"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Overtime_records {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted overtime_records {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting overtime_records {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Overtime_records]:
        """Get overtime_records by any field"""
        try:
            if not hasattr(Overtime_records, field_name):
                raise ValueError(f"Field {field_name} does not exist on Overtime_records")
            result = await self.db.execute(
                select(Overtime_records).where(getattr(Overtime_records, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching overtime_records by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Overtime_records]:
        """Get list of overtime_recordss filtered by field"""
        try:
            if not hasattr(Overtime_records, field_name):
                raise ValueError(f"Field {field_name} does not exist on Overtime_records")
            result = await self.db.execute(
                select(Overtime_records)
                .where(getattr(Overtime_records, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Overtime_records.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching overtime_recordss by {field_name}: {str(e)}")
            raise