import logging
import os
import time

from core.database import db_manager
from sqlalchemy import text

logger = logging.getLogger(__name__)


async def check_database_health() -> bool:
    """Check if database is healthy"""
    start_time = time.time()
    logger.debug("[DB_OP] Starting database health check")
    try:
        if not db_manager.async_session_maker:
            return False

        async with db_manager.async_session_maker() as session:
            await session.execute(text("SELECT 1"))
            logger.debug(f"[DB_OP] Database health check completed in {time.time() - start_time:.4f}s - healthy: True")
            return True
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        logger.debug(f"[DB_OP] Database health check failed in {time.time() - start_time:.4f}s - healthy: False")
        return False


async def _run_migrations():
    """Run any pending schema migrations."""
    try:
        async with db_manager.async_session_maker() as session:
            # Migration: Change evaluated_by and approved_by from INTEGER to VARCHAR(255)
            # Check if the column type needs changing
            result = await session.execute(text(
                "SELECT data_type FROM information_schema.columns "
                "WHERE table_name = 'monthly_performance_results' AND column_name = 'evaluated_by'"
            ))
            row = result.fetchone()
            if row and row[0] == 'integer':
                logger.info("🔧 Migrating evaluated_by column from INTEGER to VARCHAR(255)...")
                await session.execute(text(
                    "ALTER TABLE monthly_performance_results "
                    "ALTER COLUMN evaluated_by TYPE VARCHAR(255) USING evaluated_by::VARCHAR"
                ))
                await session.commit()
                logger.info("🔧 evaluated_by column migrated successfully")

            result = await session.execute(text(
                "SELECT data_type FROM information_schema.columns "
                "WHERE table_name = 'monthly_performance_results' AND column_name = 'approved_by'"
            ))
            row = result.fetchone()
            if row and row[0] == 'integer':
                logger.info("🔧 Migrating approved_by column from INTEGER to VARCHAR(255)...")
                await session.execute(text(
                    "ALTER TABLE monthly_performance_results "
                    "ALTER COLUMN approved_by TYPE VARCHAR(255) USING approved_by::VARCHAR"
                ))
                await session.commit()
                logger.info("🔧 approved_by column migrated successfully")
    except Exception as e:
        logger.warning(f"Migration check skipped or failed (non-critical): {e}")


async def _fix_sequences():
    """Fix auto-increment sequences for all tables to avoid duplicate key errors.
    This resets each sequence to MAX(id) + 1 so new inserts don't collide with existing rows."""
    tables_to_fix = [
        "attendance_records",
        "employees",
        "overtime_records",
        "violations",
        "contracts",
        "client_contracts",
        "performance_records",
        "ideas",
        "leave_balances",
    ]
    try:
        async with db_manager.session() as session:
            for table in tables_to_fix:
                try:
                    # Check if table exists
                    result = await session.execute(
                        text(f"SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = '{table}')")
                    )
                    exists = result.scalar()
                    if not exists:
                        continue
                    # Reset sequence to max(id) + 1
                    await session.execute(
                        text(f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), COALESCE((SELECT MAX(id) FROM {table}), 0) + 1, false)")
                    )
                except Exception as e:
                    logger.warning(f"Could not fix sequence for {table}: {e}")
            await session.commit()
            logger.info("🔧 Auto-increment sequences fixed successfully")
    except Exception as e:
        logger.warning(f"Sequence fix skipped (non-critical): {e}")


async def initialize_database():
    """Initialize database and create tables"""
    if "MGX_IGNORE_INIT_DB" in os.environ:
        logger.info("Ignore creating tables")
        return
    start_time = time.time()
    logger.debug("[DB_OP] Starting database initialization")
    try:
        logger.info("🔧 Starting database initialization...")
        await db_manager.init_db()
        logger.info("🔧 Database connection initialized, now creating tables if tables not exist...")
        await db_manager.create_tables()
        logger.info("🔧 Table creation completed")
        await _run_migrations()
        await _fix_sequences()
        logger.info("Database initialized successfully")
        logger.debug(f"[DB_OP] Database initialization completed in {time.time() - start_time:.4f}s")
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise


async def close_database():
    """Close database connections"""
    start_time = time.time()
    logger.debug("[DB_OP] Starting database close")
    try:
        await db_manager.close_db()
        logger.info("Database connections closed")
        logger.debug(f"[DB_OP] Database close completed in {time.time() - start_time:.4f}s")
    except Exception as e:
        logger.error(f"Error closing database: {e}")
        logger.debug(f"[DB_OP] Database close failed in {time.time() - start_time:.4f}s")
