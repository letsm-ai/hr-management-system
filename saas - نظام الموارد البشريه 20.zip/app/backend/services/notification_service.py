"""Notification service for managing employee notifications"""
import logging
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

logger = logging.getLogger(__name__)

# Ensure notifications table exists
CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR NOT NULL,
    employee_id INTEGER NOT NULL,
    type VARCHAR NOT NULL,
    title VARCHAR NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    related_id INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);
"""


async def ensure_table(db: AsyncSession):
    """Create notifications table if it doesn't exist"""
    try:
        await db.execute(text(CREATE_TABLE_SQL))
        await db.commit()
    except Exception as e:
        logger.warning(f"Table creation warning (may already exist): {e}")
        await db.rollback()


async def get_notifications(db: AsyncSession, user_id: str, unread_only: bool = False, limit: int = 50):
    """Get notifications for a user"""
    await ensure_table(db)
    query = "SELECT id, user_id, employee_id, type, title, message, is_read, related_id, created_at FROM notifications WHERE user_id = :user_id"
    if unread_only:
        query += " AND is_read = FALSE"
    query += " ORDER BY created_at DESC LIMIT :limit"
    result = await db.execute(text(query), {"user_id": user_id, "limit": limit})
    rows = result.fetchall()
    return [
        {
            "id": r[0], "user_id": r[1], "employee_id": r[2], "type": r[3],
            "title": r[4], "message": r[5], "is_read": r[6], "related_id": r[7],
            "created_at": (r[8].isoformat() if hasattr(r[8], "isoformat") else r[8]) if r[8] else None,
        }
        for r in rows
    ]


async def get_unread_count(db: AsyncSession, user_id: str) -> int:
    """Get unread notification count"""
    await ensure_table(db)
    result = await db.execute(
        text("SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND is_read = FALSE"),
        {"user_id": user_id}
    )
    return result.scalar() or 0


async def create_notification(
    db: AsyncSession, user_id: str, employee_id: int,
    notif_type: str, title: str, message: str, related_id: int = None
):
    """Create a new notification"""
    await ensure_table(db)
    now = datetime.now()
    await db.execute(
        text("""
            INSERT INTO notifications (user_id, employee_id, type, title, message, is_read, related_id, created_at)
            VALUES (:user_id, :employee_id, :type, :title, :message, FALSE, :related_id, :created_at)
        """),
        {
            "user_id": user_id, "employee_id": employee_id,
            "type": notif_type, "title": title, "message": message,
            "related_id": related_id, "created_at": now,
        }
    )
    await db.commit()


async def mark_as_read(db: AsyncSession, user_id: str, notification_id: int):
    """Mark a notification as read"""
    await db.execute(
        text("UPDATE notifications SET is_read = TRUE WHERE id = :id AND user_id = :user_id"),
        {"id": notification_id, "user_id": user_id}
    )
    await db.commit()


async def mark_all_as_read(db: AsyncSession, user_id: str):
    """Mark all notifications as read for a user"""
    await db.execute(
        text("UPDATE notifications SET is_read = TRUE WHERE user_id = :user_id AND is_read = FALSE"),
        {"user_id": user_id}
    )
    await db.commit()


async def delete_notification(db: AsyncSession, user_id: str, notification_id: int):
    """Delete a notification"""
    await db.execute(
        text("DELETE FROM notifications WHERE id = :id AND user_id = :user_id"),
        {"id": notification_id, "user_id": user_id}
    )
    await db.commit()