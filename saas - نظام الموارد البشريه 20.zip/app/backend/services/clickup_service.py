"""ClickUp API Integration Service - Fetches task data for KPI tracking.

Includes retry logic and robust error handling for network issues.
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Optional
import httpx

logger = logging.getLogger(__name__)

CLICKUP_API_BASE = "https://api.clickup.com/api/v2"

# Timeout configuration (seconds)
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
TOTAL_TIMEOUT = 45

# Retry configuration
MAX_RETRIES = 2
RETRY_DELAY = 1.0


def _get_token() -> str:
    token = os.environ.get("CLICKUP_API_TOKEN", "")
    if not token or not token.strip():
        raise ValueError(
            "لم يتم إدخال توكن ClickUp بعد. يرجى إدخال التوكن في إعدادات ClickUp أولاً."
        )
    return token.strip()


def _headers(token: Optional[str] = None) -> dict:
    t = token or _get_token()
    # Ensure token is not empty after resolution
    if not t or not t.strip():
        raise ValueError(
            "لم يتم إدخال توكن ClickUp بعد. يرجى إدخال التوكن في إعدادات ClickUp أولاً."
        )
    return {
        "Authorization": t.strip(),
        "Content-Type": "application/json",
    }


def _get_timeout() -> httpx.Timeout:
    """Get configured timeout for ClickUp API requests."""
    return httpx.Timeout(
        connect=CONNECT_TIMEOUT,
        read=READ_TIMEOUT,
        write=READ_TIMEOUT,
        pool=CONNECT_TIMEOUT,
    )


async def _request_with_retry(
    method: str,
    url: str,
    headers: dict,
    params: Optional[dict] = None,
    max_retries: int = MAX_RETRIES,
    timeout: Optional[httpx.Timeout] = None,
) -> httpx.Response:
    """Make an HTTP request with retry logic for transient failures.
    
    Retries on:
    - Network connection errors
    - Timeout errors
    - 5xx server errors from ClickUp
    
    Does NOT retry on:
    - 401/403 (auth errors)
    - 4xx client errors
    """
    import asyncio
    
    _timeout = timeout or _get_timeout()
    last_error = None
    
    for attempt in range(max_retries + 1):
        try:
            async with httpx.AsyncClient(timeout=_timeout) as http_client:
                resp = await http_client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                )
                
                # Don't retry on auth errors
                if resp.status_code in (401, 403):
                    return resp
                
                # Retry on server errors
                if resp.status_code >= 500 and attempt < max_retries:
                    logger.warning(
                        f"ClickUp API returned {resp.status_code} on attempt {attempt + 1}/{max_retries + 1}, retrying..."
                    )
                    await asyncio.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                
                return resp
                
        except (httpx.TimeoutException, httpx.ConnectError, httpx.ReadTimeout) as e:
            last_error = e
            if attempt < max_retries:
                logger.warning(
                    f"ClickUp API request failed on attempt {attempt + 1}/{max_retries + 1}: {type(e).__name__}: {e}. Retrying..."
                )
                await asyncio.sleep(RETRY_DELAY * (attempt + 1))
            else:
                logger.error(
                    f"ClickUp API request failed after {max_retries + 1} attempts: {type(e).__name__}: {e}"
                )
    
    # All retries exhausted
    if isinstance(last_error, httpx.TimeoutException):
        raise ValueError(
            "انتهت مهلة الاتصال بـ ClickUp بعد عدة محاولات. يرجى المحاولة مرة أخرى لاحقاً."
        )
    elif isinstance(last_error, httpx.ConnectError):
        raise ValueError(
            "فشل الاتصال بخادم ClickUp بعد عدة محاولات. تحقق من اتصال الإنترنت."
        )
    else:
        raise ValueError(
            f"فشل الاتصال بـ ClickUp: {str(last_error)}"
        )


async def test_connection(api_token: str) -> dict:
    """Test ClickUp API connection with a given token.

    Returns:
        dict with keys: success (bool), workspaces (list), error (str optional)
    """
    if not api_token or not api_token.strip():
        return {
            "success": False,
            "error": "يرجى إدخال التوكن أولاً. حقل التوكن فارغ.",
        }

    token = api_token.strip()
    logger.info(f"Testing ClickUp connection with token (length: {len(token)}, prefix: {token[:5]}...)")

    try:
        resp = await _request_with_retry(
            method="GET",
            url=f"{CLICKUP_API_BASE}/team",
            headers={"Authorization": token, "Content-Type": "application/json"},
            max_retries=2,
        )
        
        if resp.status_code == 200:
            data = resp.json()
            teams = data.get("teams", [])
            # Also set the env var for future use
            os.environ["CLICKUP_API_TOKEN"] = token
            logger.info(f"ClickUp connection successful: found {len(teams)} workspace(s)")
            return {
                "success": True,
                "workspaces": [
                    {"id": str(t["id"]), "name": t.get("name", "")}
                    for t in teams
                ],
            }
        elif resp.status_code == 401:
            logger.warning("ClickUp connection test: 401 Unauthorized")
            return {
                "success": False,
                "error": "التوكن غير صالح أو منتهي الصلاحية. يرجى التأكد من صحة التوكن من حساب ClickUp.",
            }
        elif resp.status_code == 403:
            logger.warning("ClickUp connection test: 403 Forbidden")
            return {
                "success": False,
                "error": "التوكن لا يملك صلاحيات كافية. يرجى إنشاء توكن جديد من إعدادات ClickUp.",
            }
        else:
            body = resp.text[:200]
            logger.error(f"ClickUp connection test: HTTP {resp.status_code}: {body}")
            return {
                "success": False,
                "error": f"خطأ من ClickUp (HTTP {resp.status_code}): {body}",
            }
    except ValueError as e:
        # From _request_with_retry
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"ClickUp connection test failed: {e}", exc_info=True)
        return {"success": False, "error": f"خطأ غير متوقع: {str(e)}"}


async def get_teams(token: Optional[str] = None) -> list[dict]:
    """Get all workspaces (teams) the token has access to.
    
    Args:
        token: Optional API token. If provided, uses this directly instead of env var.
    """
    headers = _headers(token)
    resp = await _request_with_retry(
        method="GET",
        url=f"{CLICKUP_API_BASE}/team",
        headers=headers,
    )
    if resp.status_code == 401:
        raise ValueError(
            "التوكن غير صالح أو منتهي الصلاحية. "
            "يرجى تحديث التوكن في إعدادات ClickUp."
        )
    resp.raise_for_status()
    data = resp.json()
    return data.get("teams", [])


async def get_spaces(team_id: str, token: Optional[str] = None) -> list[dict]:
    """Get all spaces in a workspace."""
    headers = _headers(token)
    resp = await _request_with_retry(
        method="GET",
        url=f"{CLICKUP_API_BASE}/team/{team_id}/space",
        headers=headers,
        params={"archived": "false"},
    )
    if resp.status_code == 401:
        raise ValueError(
            "التوكن غير صالح أو منتهي الصلاحية. "
            "يرجى تحديث التوكن في إعدادات ClickUp."
        )
    resp.raise_for_status()
    data = resp.json()
    return data.get("spaces", [])


async def get_team_members(team_id: str, token: Optional[str] = None) -> list[dict]:
    """Get all members of a workspace."""
    teams = await get_teams(token=token)
    for team in teams:
        if str(team.get("id")) == str(team_id):
            members = team.get("members", [])
            return [
                {
                    "id": str(m.get("user", {}).get("id", "")),
                    "username": m.get("user", {}).get("username", ""),
                    "email": m.get("user", {}).get("email", ""),
                    "profilePicture": m.get("user", {}).get("profilePicture", ""),
                }
                for m in members
            ]
    return []


async def get_folders(space_id: str, token: Optional[str] = None) -> list[dict]:
    """Get all folders in a space."""
    headers = _headers(token)
    resp = await _request_with_retry(
        method="GET",
        url=f"{CLICKUP_API_BASE}/space/{space_id}/folder",
        headers=headers,
        params={"archived": "false"},
    )
    if resp.status_code == 401:
        raise ValueError(
            "التوكن غير صالح أو منتهي الصلاحية. "
            "يرجى تحديث التوكن في إعدادات ClickUp."
        )
    resp.raise_for_status()
    data = resp.json()
    return data.get("folders", [])


async def get_lists_in_folder(folder_id: str, token: Optional[str] = None) -> list[dict]:
    """Get all lists in a folder."""
    headers = _headers(token)
    resp = await _request_with_retry(
        method="GET",
        url=f"{CLICKUP_API_BASE}/folder/{folder_id}/list",
        headers=headers,
        params={"archived": "false"},
    )
    if resp.status_code == 401:
        raise ValueError(
            "التوكن غير صالح أو منتهي الصلاحية. "
            "يرجى تحديث التوكن في إعدادات ClickUp."
        )
    resp.raise_for_status()
    data = resp.json()
    return data.get("lists", [])


async def get_folderless_lists(space_id: str, token: Optional[str] = None) -> list[dict]:
    """Get lists not in any folder."""
    headers = _headers(token)
    resp = await _request_with_retry(
        method="GET",
        url=f"{CLICKUP_API_BASE}/space/{space_id}/list",
        headers=headers,
        params={"archived": "false"},
    )
    if resp.status_code == 401:
        raise ValueError(
            "التوكن غير صالح أو منتهي الصلاحية. "
            "يرجى تحديث التوكن في إعدادات ClickUp."
        )
    resp.raise_for_status()
    data = resp.json()
    return data.get("lists", [])


async def get_all_lists_in_space(space_id: str, token: Optional[str] = None) -> list[dict]:
    """Get all lists in a space (from folders + folderless)."""
    all_lists = []
    folders = await get_folders(space_id, token=token)
    for folder in folders:
        lists = await get_lists_in_folder(str(folder["id"]), token=token)
        all_lists.extend(lists)
    folderless = await get_folderless_lists(space_id, token=token)
    all_lists.extend(folderless)
    return all_lists


async def get_tasks_for_team(
    team_id: str,
    assignee_ids: Optional[list[str]] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    include_closed: bool = True,
    token: Optional[str] = None,
) -> list[dict]:
    """Fetch tasks from a ClickUp workspace filtered by assignees and date range."""
    params: dict = {
        "page": 0,
        "include_closed": str(include_closed).lower(),
        "subtasks": "true",
        "order_by": "updated",
    }

    if assignee_ids:
        params["assignees[]"] = assignee_ids

    if date_from:
        dt_from = datetime.strptime(date_from, "%Y-%m-%d")
        params["date_updated_gt"] = str(int(dt_from.timestamp() * 1000))

    if date_to:
        dt_to = datetime.strptime(date_to, "%Y-%m-%d") + timedelta(days=1)
        params["date_updated_lt"] = str(int(dt_to.timestamp() * 1000))

    all_tasks = []
    page = 0
    max_pages = 10
    headers = _headers(token)

    # Use longer timeout for task fetching (can be large)
    task_timeout = httpx.Timeout(
        connect=CONNECT_TIMEOUT,
        read=60,
        write=30,
        pool=CONNECT_TIMEOUT,
    )

    while page < max_pages:
        params["page"] = page
        resp = await _request_with_retry(
            method="GET",
            url=f"{CLICKUP_API_BASE}/team/{team_id}/task",
            headers=headers,
            params=params,
            timeout=task_timeout,
        )
        if resp.status_code == 401:
            raise ValueError(
                "التوكن غير صالح أو منتهي الصلاحية. "
                "يرجى تحديث التوكن في إعدادات ClickUp."
            )
        resp.raise_for_status()
        data = resp.json()
        tasks = data.get("tasks", [])
        if not tasks:
            break
        all_tasks.extend(tasks)
        if len(tasks) < 100:
            break
        page += 1

    logger.debug(f"Fetched {len(all_tasks)} tasks from ClickUp team {team_id} (pages: {page + 1})")
    return all_tasks


def compute_member_stats(tasks: list[dict], member_id: str) -> dict:
    """Compute task statistics for a specific ClickUp member."""
    member_tasks = []
    for task in tasks:
        assignee_ids = [str(a.get("id", "")) for a in task.get("assignees", [])]
        if member_id in assignee_ids:
            member_tasks.append(task)

    total = len(member_tasks)
    completed = 0
    in_progress = 0

    for task in member_tasks:
        status = task.get("status", {})
        status_type = status.get("type", "").lower() if isinstance(status, dict) else ""
        status_name = status.get("status", "").lower() if isinstance(status, dict) else ""

        if status_type == "closed" or status_name in [
            "closed", "complete", "done", "مكتمل", "مغلق", "منجز"
        ]:
            completed += 1
        elif status_type == "active" or status_name in [
            "in progress", "قيد التنفيذ", "جاري العمل"
        ]:
            in_progress += 1

    completion_rate = round((completed / total) * 100) if total > 0 else 0

    return {
        "total_tasks": total,
        "completed_tasks": completed,
        "in_progress_tasks": in_progress,
        "completion_rate": completion_rate,
    }


async def get_workspace_summary(
    team_id: str,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    token: Optional[str] = None,
) -> dict:
    """Get a summary of all members' task stats in a workspace."""
    members = await get_team_members(team_id, token=token)
    all_member_ids = [m["id"] for m in members]

    tasks = await get_tasks_for_team(
        team_id=team_id,
        assignee_ids=all_member_ids,
        date_from=date_from,
        date_to=date_to,
        include_closed=True,
        token=token,
    )

    member_stats = []
    total_tasks = 0
    total_completed = 0

    for member in members:
        stats = compute_member_stats(tasks, member["id"])
        member_stats.append({
            "clickup_id": member["id"],
            "username": member["username"],
            "email": member["email"],
            "total_tasks": stats["total_tasks"],
            "completed_tasks": stats["completed_tasks"],
            "in_progress_tasks": stats["in_progress_tasks"],
            "completion_rate": stats["completion_rate"],
        })
        total_tasks += stats["total_tasks"]
        total_completed += stats["completed_tasks"]

    return {
        "members": member_stats,
        "total_tasks": total_tasks,
        "total_completed": total_completed,
    }