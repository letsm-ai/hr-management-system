import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.ideas import Ideas

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class IdeasService:
    """Service layer for Ideas operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Ideas]:
        """Create a new ideas"""
        try:
            obj = Ideas(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created ideas with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating ideas: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Ideas]:
        """Get ideas by ID"""
        try:
            query = select(Ideas).where(Ideas.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching ideas {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of ideass"""
        try:
            query = select(Ideas)
            count_query = select(func.count(Ideas.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Ideas, field):
                        query = query.where(getattr(Ideas, field) == value)
                        count_query = count_query.where(getattr(Ideas, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Ideas, field_name):
                        query = query.order_by(getattr(Ideas, field_name).desc())
                else:
                    if hasattr(Ideas, sort):
                        query = query.order_by(getattr(Ideas, sort))
            else:
                query = query.order_by(Ideas.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching ideas list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Ideas]:
        """Update ideas"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Ideas {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated ideas {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating ideas {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete ideas"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Ideas {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted ideas {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting ideas {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Ideas]:
        """Get ideas by any field"""
        try:
            if not hasattr(Ideas, field_name):
                raise ValueError(f"Field {field_name} does not exist on Ideas")
            result = await self.db.execute(
                select(Ideas).where(getattr(Ideas, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching ideas by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Ideas]:
        """Get list of ideass filtered by field"""
        try:
            if not hasattr(Ideas, field_name):
                raise ValueError(f"Field {field_name} does not exist on Ideas")
            result = await self.db.execute(
                select(Ideas)
                .where(getattr(Ideas, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Ideas.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching ideass by {field_name}: {str(e)}")
            raise