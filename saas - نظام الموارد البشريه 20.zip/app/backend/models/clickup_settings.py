from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text


class Clickup_settings(Base):
    __tablename__ = "clickup_settings"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    api_token = Column(String, nullable=True)
    workspace_id = Column(String, nullable=True)
    workspace_name = Column(String, nullable=True)
    is_active = Column(Boolean, nullable=True)
    last_sync_at = Column(DateTime(timezone=True), nullable=True)
    auto_sync_enabled = Column(Boolean, nullable=True)
    auto_sync_frequency = Column(String, nullable=True)
    auto_sync_day = Column(Integer, nullable=True)
    auto_sync_hour = Column(Integer, nullable=True)
    last_auto_sync_at = Column(DateTime(timezone=True), nullable=True)
    next_auto_sync_at = Column(DateTime(timezone=True), nullable=True)
    auto_sync_notify = Column(Boolean, nullable=True)
    member_mapping = Column(Text, nullable=True)  # JSON: { clickup_id: employee_id }
    user_id = Column(String, nullable=True)