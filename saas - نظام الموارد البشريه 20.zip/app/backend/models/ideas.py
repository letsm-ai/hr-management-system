from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Ideas(Base):
    __tablename__ = "ideas"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    month = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    status = Column(String, nullable=True)
    classification = Column(String, nullable=True)
    expected_impact = Column(String, nullable=True)
    submission_date = Column(String, nullable=True)
    decision_date = Column(String, nullable=True)
    revenue_generated = Column(Float, nullable=True)
    notes = Column(String, nullable=True)