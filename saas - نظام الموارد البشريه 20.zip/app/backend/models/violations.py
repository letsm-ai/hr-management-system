from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Violations(Base):
    __tablename__ = "violations"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    date = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    violation_type = Column(String, nullable=True)
    details = Column(String, nullable=True)
    severity = Column(String, nullable=True)
    is_repeated = Column(String, nullable=True)
    penalty = Column(String, nullable=True)
    deduction_amount = Column(Float, nullable=True)
    deduction_days = Column(Float, nullable=True)
    notification_date = Column(String, nullable=True)
    grievance_status = Column(String, nullable=True)
    notes = Column(String, nullable=True)