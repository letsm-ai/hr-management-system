from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Overtime_records(Base):
    __tablename__ = "overtime_records"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    date = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    day_type = Column(String, nullable=True)
    overtime_hours = Column(Float, nullable=True)
    compensation_method = Column(String, nullable=True)
    approved = Column(String, nullable=True)