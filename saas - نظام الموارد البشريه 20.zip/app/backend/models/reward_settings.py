from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, func


class Reward_settings(Base):
    __tablename__ = "reward_settings"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    attendance_weight = Column(Float, nullable=False, default=0.30)
    productivity_weight = Column(Float, nullable=False, default=0.45)
    quality_weight = Column(Float, nullable=False, default=0.25)
    excellent_threshold = Column(Float, nullable=False, default=0.85)
    excellent_reward_percent = Column(Float, nullable=False, default=15.00)
    good_threshold = Column(Float, nullable=False, default=0.70)
    good_reward_percent = Column(Float, nullable=False, default=10.00)
    fair_threshold = Column(Float, nullable=False, default=0.55)
    fair_reward_percent = Column(Float, nullable=False, default=5.00)
    working_days_per_month = Column(Integer, nullable=False, default=30)
    late_minor_threshold_minutes = Column(Integer, nullable=False, default=15)
    absent_annual_leave_points = Column(Integer, nullable=False, default=100)
    absent_approved_points = Column(Integer, nullable=False, default=50)
    absent_unapproved_points = Column(Integer, nullable=False, default=0)
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=func.now())