from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Attendance_records(Base):
    __tablename__ = "attendance_records"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    date = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    check_in = Column(String, nullable=True)
    check_out = Column(String, nullable=True)
    actual_hours = Column(Float, nullable=True)
    required_hours = Column(Float, nullable=True)
    tardiness = Column(Integer, nullable=True)
    early_departure = Column(Integer, nullable=True)
    day_status = Column(String, nullable=False)
    absence_type = Column(String, nullable=True)
    notes = Column(String, nullable=True)
    approved = Column(String, nullable=True)