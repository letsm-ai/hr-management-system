from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Clickup_sync_logs(Base):
    __tablename__ = "clickup_sync_logs"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    month = Column(String, nullable=True)
    sync_type = Column(String, nullable=True)
    status = Column(String, nullable=True)
    synced_count = Column(Integer, nullable=True)
    skipped_count = Column(Integer, nullable=True)
    failed_count = Column(Integer, nullable=True)
    workspace_name = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    user_id = Column(String, nullable=True)