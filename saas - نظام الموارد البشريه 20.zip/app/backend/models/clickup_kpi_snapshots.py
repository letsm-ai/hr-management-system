from core.database import Base
from sqlalchemy import Column, Integer, String


class Clickup_kpi_snapshots(Base):
    __tablename__ = "clickup_kpi_snapshots"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    employee_id = Column(Integer, nullable=False)
    month = Column(String, nullable=False)
    clickup_user_id = Column(String, nullable=True)
    total_tasks = Column(Integer, nullable=True)
    completed_tasks = Column(Integer, nullable=True)
    completion_rate = Column(Integer, nullable=True)
    on_time_tasks = Column(Integer, nullable=True)
    late_tasks = Column(Integer, nullable=True)
    on_time_rate = Column(Integer, nullable=True)
    overdue_tasks = Column(Integer, nullable=True)
    total_time_spent_ms = Column(Integer, nullable=True)
    average_completion_days = Column(Integer, nullable=True)
    user_id = Column(String, nullable=True)