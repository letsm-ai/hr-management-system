from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Performance_kpis(Base):
    __tablename__ = "performance_kpis"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    employee_id = Column(Integer, nullable=False)
    month = Column(String, nullable=False)
    tasks_target = Column(Integer, nullable=False)
    tasks_completed = Column(Integer, nullable=False)
    achievement_rate = Column(Float, nullable=True)
    kpi_bonus = Column(Float, nullable=True)
    quality_score = Column(Integer, nullable=True)
    timeliness_score = Column(Integer, nullable=True)
    collaboration_score = Column(Integer, nullable=True)
    innovation_score = Column(Integer, nullable=True)
    overall_rating = Column(String, nullable=True)
    manager_notes = Column(String, nullable=True)
    employee_goals = Column(String, nullable=True)