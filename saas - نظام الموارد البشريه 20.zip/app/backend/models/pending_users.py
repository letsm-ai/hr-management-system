from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Pending_users(Base):
    __tablename__ = "pending_users"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    email = Column(String, nullable=True)
    name = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)