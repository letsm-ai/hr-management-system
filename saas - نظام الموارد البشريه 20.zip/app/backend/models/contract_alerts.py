from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Contract_alerts(Base):
    __tablename__ = "contract_alerts"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    contract_id = Column(Integer, nullable=False)
    client_name = Column(String, nullable=False)
    alert_type = Column(String, nullable=False)
    days_remaining = Column(Integer, nullable=False)
    contract_end_date = Column(String, nullable=False)
    is_read = Column(Boolean, nullable=True)
    is_dismissed = Column(Boolean, nullable=True)
    sent_at = Column(String, nullable=True)
    read_at = Column(String, nullable=True)