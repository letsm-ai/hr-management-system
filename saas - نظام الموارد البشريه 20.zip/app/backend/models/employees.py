from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Employees(Base):
    __tablename__ = "employees"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    emp_code = Column(String, nullable=True)
    full_name = Column(String, nullable=True)
    department = Column(String, nullable=True)
    job_title = Column(String, nullable=True)
    hire_date = Column(String, nullable=True)
    basic_salary = Column(Float, nullable=True)
    email = Column(String, nullable=True)
    status = Column(String, nullable=True)
    annual_leave_balance = Column(Integer, nullable=True)
    daily_work_hours = Column(Integer, nullable=True)
    clickup_id = Column(String, nullable=True)
    clickup_email = Column(String, nullable=True)