from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Incentive_records(Base):
    __tablename__ = "incentive_records"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    contract_id = Column(Integer, nullable=True)
    month = Column(String, nullable=False)
    incentive_type = Column(String, nullable=False)
    base_amount = Column(Integer, nullable=False)
    performance_multiplier = Column(Float, nullable=True)
    final_amount = Column(Integer, nullable=False)
    status = Column(String, nullable=False)
    calculation_details = Column(String, nullable=True)
    approved_by = Column(String, nullable=True)
    paid_at = Column(String, nullable=True)
    created_at = Column(String, nullable=True)