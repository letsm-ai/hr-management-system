from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Contracts(Base):
    __tablename__ = "contracts"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    contract_type = Column(String, nullable=True)
    job_title = Column(String, nullable=True)
    department = Column(String, nullable=True)
    start_date = Column(String, nullable=True)
    end_date = Column(String, nullable=True)
    basic_salary = Column(Float, nullable=True)
    housing_allowance = Column(Float, nullable=True)
    transport_allowance = Column(Float, nullable=True)
    food_allowance = Column(Float, nullable=True)
    other_allowances = Column(Float, nullable=True)
    total_salary = Column(Float, nullable=True)
    working_hours = Column(Integer, nullable=True)
    annual_leave_days = Column(Integer, nullable=True)
    probation_period = Column(Integer, nullable=True)
    notice_period = Column(Integer, nullable=True)
    status = Column(String, nullable=True)
    notes = Column(String, nullable=True)
    signed_date = Column(String, nullable=True)
    termination_date = Column(String, nullable=True)
    termination_reason = Column(String, nullable=True)