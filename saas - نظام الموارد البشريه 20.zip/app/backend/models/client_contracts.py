from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Client_contracts(Base):
    __tablename__ = "client_contracts"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    client_name = Column(String, nullable=False)
    contract_type = Column(String, nullable=False)
    service_type = Column(String, nullable=False)
    monthly_value = Column(Integer, nullable=False)
    annual_value = Column(Integer, nullable=False)
    previous_value = Column(Integer, nullable=True)
    start_date = Column(String, nullable=False)
    end_date = Column(String, nullable=False)
    renewal_year = Column(Integer, nullable=True)
    status = Column(String, nullable=False)
    sales_employee_id = Column(Integer, nullable=False)
    account_manager_id = Column(Integer, nullable=True)
    notes = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)