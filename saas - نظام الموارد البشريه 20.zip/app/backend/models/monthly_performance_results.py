from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String, Text, UniqueConstraint, func


class Monthly_performance_results(Base):
    __tablename__ = "monthly_performance_results"
    __table_args__ = (
        UniqueConstraint("employee_id", "month", name="uq_employee_month"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    employee_id = Column(Integer, nullable=False, index=True)
    month = Column(String(7), nullable=False)  # e.g. "2026-04"
    attendance_score = Column(Float, nullable=True)
    attendance_details = Column(Text, nullable=True)  # JSON
    productivity_score = Column(Float, nullable=True)
    tasks_assigned = Column(Integer, nullable=True)
    tasks_completed = Column(Integer, nullable=True)
    tasks_on_time = Column(Integer, nullable=True)
    points_target = Column(Integer, nullable=True)
    points_achieved = Column(Integer, nullable=True)
    productivity_details = Column(Text, nullable=True)  # JSON
    quality_score = Column(Float, nullable=True)
    quality_output = Column(Integer, nullable=True)  # 1-10
    quality_initiative = Column(Integer, nullable=True)  # 1-10
    quality_teamwork = Column(Integer, nullable=True)  # 1-10
    quality_client_satisfaction = Column(Integer, nullable=True)  # 1-10
    quality_notes = Column(Text, nullable=True)
    evaluated_by = Column(String(255), nullable=True)
    final_score = Column(Float, nullable=True)
    grade = Column(String(50), nullable=True)  # ممتاز/جيد جداً/جيد/يحتاج تحسين
    reward_percent = Column(Float, nullable=True)
    reward_amount = Column(Float, nullable=True)
    status = Column(String(20), nullable=False, default="draft")  # draft/pending_approval/approved/paid
    approved_by = Column(String(255), nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())