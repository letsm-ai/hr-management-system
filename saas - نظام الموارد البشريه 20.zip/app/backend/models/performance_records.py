from core.database import Base
from sqlalchemy import Column, Integer, String


class Performance_records(Base):
    __tablename__ = "performance_records"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    month = Column(String, nullable=False)
    employee_id = Column(Integer, nullable=False)
    work_quality = Column(Integer, nullable=True)
    punctuality = Column(Integer, nullable=True)
    customer_satisfaction = Column(Integer, nullable=True)
    teamwork = Column(Integer, nullable=True)
    initiative = Column(Integer, nullable=True)
    self_development = Column(Integer, nullable=True)