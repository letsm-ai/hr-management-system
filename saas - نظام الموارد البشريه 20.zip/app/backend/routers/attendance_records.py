import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.attendance_records import Attendance_recordsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/attendance_records", tags=["attendance_records"])


# ---------- Pydantic Schemas ----------
class Attendance_recordsData(BaseModel):
    """Entity data schema (for create/update)"""
    date: str
    employee_id: int
    check_in: str = None
    check_out: str = None
    actual_hours: float = None
    required_hours: float = None
    tardiness: int = None
    early_departure: int = None
    day_status: str
    absence_type: str = None
    notes: str = None
    approved: str = None


class Attendance_recordsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    date: Optional[str] = None
    employee_id: Optional[int] = None
    check_in: Optional[str] = None
    check_out: Optional[str] = None
    actual_hours: Optional[float] = None
    required_hours: Optional[float] = None
    tardiness: Optional[int] = None
    early_departure: Optional[int] = None
    day_status: Optional[str] = None
    absence_type: Optional[str] = None
    notes: Optional[str] = None
    approved: Optional[str] = None


class Attendance_recordsResponse(BaseModel):
    """Entity response schema"""
    id: int
    date: str
    employee_id: int
    check_in: Optional[str] = None
    check_out: Optional[str] = None
    actual_hours: Optional[float] = None
    required_hours: Optional[float] = None
    tardiness: Optional[int] = None
    early_departure: Optional[int] = None
    day_status: str
    absence_type: Optional[str] = None
    notes: Optional[str] = None
    approved: Optional[str] = None

    class Config:
        from_attributes = True


class Attendance_recordsListResponse(BaseModel):
    """List response schema"""
    items: List[Attendance_recordsResponse]
    total: int
    skip: int
    limit: int


class Attendance_recordsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Attendance_recordsData]


class Attendance_recordsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Attendance_recordsUpdateData


class Attendance_recordsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Attendance_recordsBatchUpdateItem]


class Attendance_recordsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Attendance_recordsListResponse)
async def query_attendance_recordss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query attendance_recordss with filtering, sorting, and pagination"""
    logger.debug(f"Querying attendance_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Attendance_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} attendance_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying attendance_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Attendance_recordsListResponse)
async def query_attendance_recordss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query attendance_recordss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying attendance_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Attendance_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} attendance_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying attendance_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Attendance_recordsResponse)
async def get_attendance_records(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single attendance_records by ID"""
    logger.debug(f"Fetching attendance_records with id: {id}, fields={fields}")
    
    service = Attendance_recordsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Attendance_records with id {id} not found")
            raise HTTPException(status_code=404, detail="Attendance_records not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching attendance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Attendance_recordsResponse, status_code=201)
async def create_attendance_records(
    data: Attendance_recordsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new attendance_records (upsert: updates if employee_id+date already exists)"""
    logger.debug(f"Creating new attendance_records with data: {data}")
    
    service = Attendance_recordsService(db)
    try:
        # Check for existing record with same employee_id + date (upsert logic)
        existing = await service.find_by_employee_and_date(data.employee_id, data.date)
        if existing:
            # Update existing record instead of creating duplicate
            update_dict = {k: v for k, v in data.model_dump().items() if k not in ('employee_id', 'date')}
            result = await service.update(existing.id, update_dict)
            if not result:
                raise HTTPException(status_code=400, detail="Failed to update existing attendance_records")
            logger.info(f"Attendance_records upserted (updated existing id: {result.id})")
            return result

        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create attendance_records")
        
        logger.info(f"Attendance_records created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating attendance_records: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating attendance_records: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Attendance_recordsResponse], status_code=201)
async def create_attendance_recordss_batch(
    request: Attendance_recordsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple attendance_recordss in a single request (upsert: updates if employee_id+date already exists)"""
    logger.debug(f"Batch creating {len(request.items)} attendance_recordss")
    
    service = Attendance_recordsService(db)
    results = []
    
    try:
        for item_data in request.items:
            data_dict = item_data.model_dump()
            # Upsert logic: check for existing record
            existing = await service.find_by_employee_and_date(
                data_dict['employee_id'], data_dict['date']
            )
            if existing:
                update_dict = {k: v for k, v in data_dict.items() if k not in ('employee_id', 'date')}
                result = await service.update(existing.id, update_dict)
            else:
                result = await service.create(data_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch upserted {len(results)} attendance_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Attendance_recordsResponse])
async def update_attendance_recordss_batch(
    request: Attendance_recordsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple attendance_recordss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} attendance_recordss")
    
    service = Attendance_recordsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} attendance_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Attendance_recordsResponse)
async def update_attendance_records(
    id: int,
    data: Attendance_recordsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing attendance_records"""
    logger.debug(f"Updating attendance_records {id} with data: {data}")

    service = Attendance_recordsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Attendance_records with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Attendance_records not found")
        
        logger.info(f"Attendance_records {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating attendance_records {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating attendance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_attendance_recordss_batch(
    request: Attendance_recordsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple attendance_recordss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} attendance_recordss")
    
    service = Attendance_recordsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} attendance_recordss successfully")
        return {"message": f"Successfully deleted {deleted_count} attendance_recordss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_attendance_records(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single attendance_records by ID"""
    logger.debug(f"Deleting attendance_records with id: {id}")
    
    service = Attendance_recordsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Attendance_records with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Attendance_records not found")
        
        logger.info(f"Attendance_records {id} deleted successfully")
        return {"message": "Attendance_records deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting attendance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.post("/fix-sequence")
async def fix_attendance_records_sequence(
    db: AsyncSession = Depends(get_db),
):
    """Reset the attendance_records ID sequence to avoid duplicate key errors"""
    try:
        result = await db.execute(
            text(
                "SELECT setval("
                "pg_get_serial_sequence('attendance_records', 'id'), "
                "COALESCE((SELECT MAX(id) FROM attendance_records), 0) + 1, "
                "false)"
            )
        )
        new_val = result.scalar()
        await db.commit()
        logger.info(f"Attendance_records sequence reset to {new_val}")
        return {"message": f"Sequence reset successfully to {new_val}", "new_value": new_val}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error resetting sequence: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to reset sequence: {str(e)}")
