import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.incentive_records import Incentive_recordsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/incentive_records", tags=["incentive_records"])


# ---------- Pydantic Schemas ----------
class Incentive_recordsData(BaseModel):
    """Entity data schema (for create/update)"""
    employee_id: int
    contract_id: int = None
    month: str
    incentive_type: str
    base_amount: int
    performance_multiplier: float = None
    final_amount: int
    status: str
    calculation_details: str = None
    approved_by: str = None
    paid_at: str = None
    created_at: str = None


class Incentive_recordsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    employee_id: Optional[int] = None
    contract_id: Optional[int] = None
    month: Optional[str] = None
    incentive_type: Optional[str] = None
    base_amount: Optional[int] = None
    performance_multiplier: Optional[float] = None
    final_amount: Optional[int] = None
    status: Optional[str] = None
    calculation_details: Optional[str] = None
    approved_by: Optional[str] = None
    paid_at: Optional[str] = None
    created_at: Optional[str] = None


class Incentive_recordsResponse(BaseModel):
    """Entity response schema"""
    id: int
    user_id: str
    employee_id: int
    contract_id: Optional[int] = None
    month: str
    incentive_type: str
    base_amount: int
    performance_multiplier: Optional[float] = None
    final_amount: int
    status: str
    calculation_details: Optional[str] = None
    approved_by: Optional[str] = None
    paid_at: Optional[str] = None
    created_at: Optional[str] = None

    class Config:
        from_attributes = True


class Incentive_recordsListResponse(BaseModel):
    """List response schema"""
    items: List[Incentive_recordsResponse]
    total: int
    skip: int
    limit: int


class Incentive_recordsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Incentive_recordsData]


class Incentive_recordsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Incentive_recordsUpdateData


class Incentive_recordsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Incentive_recordsBatchUpdateItem]


class Incentive_recordsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Incentive_recordsListResponse)
async def query_incentive_recordss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query incentive_recordss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying incentive_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Incentive_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} incentive_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying incentive_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Incentive_recordsListResponse)
async def query_incentive_recordss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query incentive_recordss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying incentive_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Incentive_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} incentive_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying incentive_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Incentive_recordsResponse)
async def get_incentive_records(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single incentive_records by ID (user can only see their own records)"""
    logger.debug(f"Fetching incentive_records with id: {id}, fields={fields}")
    
    service = Incentive_recordsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Incentive_records with id {id} not found")
            raise HTTPException(status_code=404, detail="Incentive_records not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching incentive_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Incentive_recordsResponse, status_code=201)
async def create_incentive_records(
    data: Incentive_recordsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new incentive_records"""
    logger.debug(f"Creating new incentive_records with data: {data}")
    
    service = Incentive_recordsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create incentive_records")
        
        logger.info(f"Incentive_records created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating incentive_records: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating incentive_records: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Incentive_recordsResponse], status_code=201)
async def create_incentive_recordss_batch(
    request: Incentive_recordsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple incentive_recordss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} incentive_recordss")
    
    service = Incentive_recordsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} incentive_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Incentive_recordsResponse])
async def update_incentive_recordss_batch(
    request: Incentive_recordsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple incentive_recordss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} incentive_recordss")
    
    service = Incentive_recordsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} incentive_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Incentive_recordsResponse)
async def update_incentive_records(
    id: int,
    data: Incentive_recordsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing incentive_records (requires ownership)"""
    logger.debug(f"Updating incentive_records {id} with data: {data}")

    service = Incentive_recordsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Incentive_records with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Incentive_records not found")
        
        logger.info(f"Incentive_records {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating incentive_records {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating incentive_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_incentive_recordss_batch(
    request: Incentive_recordsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple incentive_recordss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} incentive_recordss")
    
    service = Incentive_recordsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} incentive_recordss successfully")
        return {"message": f"Successfully deleted {deleted_count} incentive_recordss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_incentive_records(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single incentive_records by ID (requires ownership)"""
    logger.debug(f"Deleting incentive_records with id: {id}")
    
    service = Incentive_recordsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Incentive_records with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Incentive_records not found")
        
        logger.info(f"Incentive_records {id} deleted successfully")
        return {"message": "Incentive_records deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting incentive_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")