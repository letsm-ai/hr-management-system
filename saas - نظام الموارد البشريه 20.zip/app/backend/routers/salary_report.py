"""
Monthly Salary Report Router
Parses attendance XLS files from biometric devices and generates comprehensive
salary reports with deductions based on tardiness and absences.
"""
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, time

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/salary-report", tags=["salary-report"])

# ============ CONSTANTS ============
WORK_DAYS_PER_MONTH = 22
DAILY_WORK_MINUTES = 480
WORK_START_HOUR = 8
WORK_START_MINUTE = 30
SALARY_DIVISOR = 30  # Daily salary = basic / 30

# Weekend days (Friday=4, Saturday=5 in Python's weekday())
WEEKEND_DAYS = {4, 5}  # Friday, Saturday


# ============ MODELS ============

class DailyRecord(BaseModel):
    day: int
    date: str
    weekday: str
    status: str  # "present" | "single_punch" | "absent"
    check_in: Optional[str] = None
    check_out: Optional[str] = None
    work_hours: Optional[float] = None
    tardiness_minutes: int = 0


class EmployeeReport(BaseModel):
    employee_name: str
    employee_id: str
    department: str
    basic_salary: float
    overtime_amount: float
    daily_salary: float
    total_attendance_days: int  # includes single punch days
    full_punch_days: int  # days with both in and out
    single_punch_days: int
    absence_days: int
    total_work_hours: float
    tardiness_count: int
    total_tardiness_minutes: int
    tardiness_deduction_days: float
    total_deduction_days: float
    deduction_amount: float
    final_salary: float
    daily_records: List[DailyRecord]
    single_punch_records: List[DailyRecord]
    absence_records: List[DailyRecord]
    tardiness_records: List[DailyRecord]
    on_paid_leave: bool = False


class SalaryReportResponse(BaseModel):
    success: bool
    message: str
    month: str
    year: int
    employees: List[EmployeeReport]
    total_basic_salaries: float
    total_overtime: float
    total_deductions: float
    total_final_salaries: float


class NoteInput(BaseModel):
    report_month: str  # e.g. "2026-03"
    employee_id: str
    date: str
    note_type: str  # "single_punch" | "absence" | "tardiness"
    note: str


class NotesResponse(BaseModel):
    success: bool
    notes: Dict[str, str]  # key: "emp_id|date|type" -> note text


# ============ HELPER FUNCTIONS ============

def _safe_float(val) -> float:
    if isinstance(val, (int, float)):
        return float(val)
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return 0.0


def _safe_int(val) -> int:
    if isinstance(val, (int, float)):
        return int(val)
    try:
        return int(float(str(val).strip()))
    except (ValueError, TypeError):
        return 0


def _parse_time(time_str: str) -> Optional[time]:
    """Parse time string like '8:30' or '08:30' to time object."""
    if not time_str or not time_str.strip():
        return None
    time_str = time_str.strip()
    try:
        parts = time_str.split(":")
        if len(parts) >= 2:
            h = int(parts[0])
            m = int(parts[1])
            if 0 <= h <= 23 and 0 <= m <= 59:
                return time(h, m)
    except (ValueError, TypeError):
        pass
    return None


def _calculate_tardiness(check_in_time: time) -> int:
    """Calculate tardiness in minutes from 8:30 start."""
    work_start = time(WORK_START_HOUR, WORK_START_MINUTE)
    if check_in_time <= work_start:
        return 0
    in_minutes = check_in_time.hour * 60 + check_in_time.minute
    start_minutes = work_start.hour * 60 + work_start.minute
    return in_minutes - start_minutes


def _calculate_work_hours(check_in_time: time, check_out_time: time) -> float:
    """Calculate work hours between check-in and check-out."""
    in_minutes = check_in_time.hour * 60 + check_in_time.minute
    out_minutes = check_out_time.hour * 60 + check_out_time.minute
    diff = out_minutes - in_minutes
    if diff <= 0:
        return 0.0
    return round(diff / 60.0, 2)


def _get_weekday_arabic(weekday_int: int) -> str:
    """Convert Python weekday (0=Mon) to Arabic day name."""
    days = {
        0: "الإثنين",
        1: "الثلاثاء",
        2: "الأربعاء",
        3: "الخميس",
        4: "الجمعة",
        5: "السبت",
        6: "الأحد",
    }
    return days.get(weekday_int, "")


def _is_weekend(date_obj: datetime) -> bool:
    """Check if date is Friday or Saturday (Omani weekend)."""
    return date_obj.weekday() in WEEKEND_DAYS


def parse_attendance_xls(file_content: bytes) -> List[Dict[str, Any]]:
    """
    Parse XLS attendance file and return raw employee data.
    Reuses the proven parser from attendance_import.py.
    """
    import xlrd

    wb = xlrd.open_workbook(file_contents=file_content)
    employees_raw = []

    employee_col_offsets = [0, 11, 22]

    for sheet_idx in range(wb.nsheets):
        sheet = wb.sheet_by_index(sheet_idx)

        block_starts = []
        for row_idx in range(sheet.nrows):
            val = str(sheet.cell_value(row_idx, 0)).strip()
            if val == "Dept":
                block_starts.append(row_idx)

        for block_idx, block_start in enumerate(block_starts):
            if block_idx + 1 < len(block_starts):
                block_end = block_starts[block_idx + 1]
            else:
                block_end = sheet.nrows

            for offset in employee_col_offsets:
                try:
                    dept = str(sheet.cell_value(block_start, offset + 1)).strip()
                    name = str(sheet.cell_value(block_start, offset + 7)).strip()

                    if not name or name.lower() == "name":
                        continue

                    date_range = str(sheet.cell_value(block_start + 1, offset + 1)).strip()
                    emp_id = str(sheet.cell_value(block_start + 1, offset + 7)).strip()

                    if emp_id.lower() == "id":
                        continue

                    try:
                        emp_id = str(int(float(emp_id)))
                    except (ValueError, TypeError):
                        pass

                    # Daily records start at block_start+9
                    daily_start = block_start + 9
                    daily_records = []
                    for row_idx in range(daily_start, block_end):
                        day_num = str(sheet.cell_value(row_idx, offset + 0)).strip()
                        if not day_num:
                            continue
                        try:
                            day_int = int(float(day_num))
                        except (ValueError, TypeError):
                            continue
                        if day_int < 1 or day_int > 31:
                            continue

                        week_day = str(sheet.cell_value(row_idx, offset + 1)).strip()
                        first_on = str(sheet.cell_value(row_idx, offset + 2)).strip()
                        first_off = str(sheet.cell_value(row_idx, offset + 3)).strip()

                        daily_records.append({
                            "day": day_int,
                            "weekday": week_day,
                            "first_in": first_on,
                            "first_out": first_off,
                        })

                    employees_raw.append({
                        "name": name,
                        "employee_id": emp_id,
                        "department": dept,
                        "date_range": date_range,
                        "daily_records": daily_records,
                    })

                except Exception as e:
                    logger.warning(f"Error parsing employee at block {block_start}, offset {offset}: {e}")
                    continue

    return employees_raw


def compute_salary_report(
    employees_raw: List[Dict[str, Any]],
    salary_data: Dict[str, Dict[str, float]],
    year: int,
    month: int,
    paid_leave_employees: List[str],
) -> List[EmployeeReport]:
    """
    Compute salary report for all employees based on attendance data and rules.
    """
    import calendar

    reports = []
    _, days_in_month = calendar.monthrange(year, month)

    for emp_raw in employees_raw:
        emp_id = emp_raw["employee_id"]
        emp_name = emp_raw["name"]
        department = emp_raw["department"]

        # Get salary data
        emp_salary = salary_data.get(emp_id, {})
        basic_salary = emp_salary.get("basic_salary", 0.0)
        overtime_amount = emp_salary.get("overtime", 0.0)
        daily_salary = basic_salary / SALARY_DIVISOR if basic_salary > 0 else 0.0

        on_paid_leave = emp_id in paid_leave_employees

        # Build a map of daily records from XLS
        xls_records: Dict[int, Dict] = {}
        for rec in emp_raw["daily_records"]:
            xls_records[rec["day"]] = rec

        # Process all work days in the month
        all_daily_records: List[DailyRecord] = []
        single_punch_records: List[DailyRecord] = []
        absence_records: List[DailyRecord] = []
        tardiness_records: List[DailyRecord] = []

        full_punch_days = 0
        single_punch_days = 0
        absence_days = 0
        total_work_hours = 0.0
        tardiness_count = 0
        total_tardiness_minutes = 0

        for day in range(1, days_in_month + 1):
            try:
                date_obj = datetime(year, month, day)
            except ValueError:
                continue

            # Skip weekends
            if _is_weekend(date_obj):
                continue

            date_str = f"{year}-{month:02d}-{day:02d}"
            weekday_name = _get_weekday_arabic(date_obj.weekday())

            xls_rec = xls_records.get(day)
            check_in_str = xls_rec.get("first_in", "") if xls_rec else ""
            check_out_str = xls_rec.get("first_out", "") if xls_rec else ""

            has_in = bool(check_in_str and check_in_str.strip())
            has_out = bool(check_out_str and check_out_str.strip())

            # Classify the day
            if has_in and has_out:
                status = "present"
                full_punch_days += 1

                in_time = _parse_time(check_in_str)
                out_time = _parse_time(check_out_str)

                work_hours = 0.0
                tard_mins = 0

                if in_time and out_time:
                    work_hours = _calculate_work_hours(in_time, out_time)
                    total_work_hours += work_hours
                    tard_mins = _calculate_tardiness(in_time)
                    if tard_mins > 0:
                        tardiness_count += 1
                        total_tardiness_minutes += tard_mins

                record = DailyRecord(
                    day=day,
                    date=date_str,
                    weekday=weekday_name,
                    status="present",
                    check_in=check_in_str,
                    check_out=check_out_str,
                    work_hours=work_hours,
                    tardiness_minutes=tard_mins,
                )
                all_daily_records.append(record)

                if tard_mins > 0:
                    tardiness_records.append(record)

            elif has_in or has_out:
                status = "single_punch"
                single_punch_days += 1

                record = DailyRecord(
                    day=day,
                    date=date_str,
                    weekday=weekday_name,
                    status="single_punch",
                    check_in=check_in_str if has_in else None,
                    check_out=check_out_str if has_out else None,
                    work_hours=None,
                    tardiness_minutes=0,
                )
                all_daily_records.append(record)
                single_punch_records.append(record)

            else:
                status = "absent"
                absence_days += 1

                record = DailyRecord(
                    day=day,
                    date=date_str,
                    weekday=weekday_name,
                    status="absent",
                    check_in=None,
                    check_out=None,
                    work_hours=None,
                    tardiness_minutes=0,
                )
                all_daily_records.append(record)
                absence_records.append(record)

        # Calculate deductions
        total_attendance_days = full_punch_days + single_punch_days
        # Absence deduction: 22 - total attendance (single punch counts as present)
        absence_deduction_days = max(0, WORK_DAYS_PER_MONTH - total_attendance_days)
        # Tardiness deduction in days
        tardiness_deduction_days = round(total_tardiness_minutes / DAILY_WORK_MINUTES, 4)
        # Total deduction days
        total_deduction_days = absence_deduction_days + tardiness_deduction_days

        # If on paid leave, no deductions for absence
        if on_paid_leave:
            absence_deduction_days = 0
            total_deduction_days = tardiness_deduction_days

        deduction_amount = round(total_deduction_days * daily_salary, 3)
        final_salary = round(basic_salary + overtime_amount - deduction_amount, 3)

        reports.append(EmployeeReport(
            employee_name=emp_name,
            employee_id=emp_id,
            department=department,
            basic_salary=basic_salary,
            overtime_amount=overtime_amount,
            daily_salary=round(daily_salary, 3),
            total_attendance_days=total_attendance_days,
            full_punch_days=full_punch_days,
            single_punch_days=single_punch_days,
            absence_days=absence_deduction_days,
            total_work_hours=round(total_work_hours, 2),
            tardiness_count=tardiness_count,
            total_tardiness_minutes=total_tardiness_minutes,
            tardiness_deduction_days=round(tardiness_deduction_days, 4),
            total_deduction_days=round(total_deduction_days, 4),
            deduction_amount=deduction_amount,
            final_salary=final_salary,
            daily_records=all_daily_records,
            single_punch_records=single_punch_records,
            absence_records=absence_records,
            tardiness_records=tardiness_records,
            on_paid_leave=on_paid_leave,
        ))

    # Sort by final salary descending
    reports.sort(key=lambda r: r.final_salary, reverse=True)
    return reports


# ============ ENDPOINTS ============


class SaveReportInput(BaseModel):
    month: str  # e.g. "2026-03"
    year: int
    report_data: Dict[str, Any]  # Full report JSON


@router.post("/save")
async def save_salary_report(
    payload: SaveReportInput,
    db: AsyncSession = Depends(get_db),
):
    """Save/update a salary report in the database for persistence."""
    try:
        # Create table if not exists
        create_sql = text("""
            CREATE TABLE IF NOT EXISTS salary_reports (
                id SERIAL PRIMARY KEY,
                report_month VARCHAR(10) NOT NULL UNIQUE,
                year INTEGER NOT NULL,
                report_data JSONB NOT NULL,
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW()
            )
        """)
        await db.execute(create_sql)

        # Upsert report
        upsert_sql = text("""
            INSERT INTO salary_reports (report_month, year, report_data, updated_at)
            VALUES (:report_month, :year, CAST(:report_data AS jsonb), NOW())
            ON CONFLICT (report_month)
            DO UPDATE SET report_data = CAST(:report_data AS jsonb), year = :year, updated_at = NOW()
        """)
        import json as json_mod
        await db.execute(upsert_sql, {
            "report_month": payload.month,
            "year": payload.year,
            "report_data": json_mod.dumps(payload.report_data, ensure_ascii=False),
        })
        await db.commit()

        return {"success": True, "message": "تم حفظ التقرير بنجاح"}

    except Exception as e:
        await db.rollback()
        logger.error(f"Error saving salary report: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في حفظ التقرير: {str(e)}")


@router.get("/load/{report_month}")
async def load_salary_report(
    report_month: str,
    db: AsyncSession = Depends(get_db),
):
    """Load a saved salary report for a specific month."""
    try:
        # Check if table exists
        check_sql = text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = 'salary_reports'
            )
        """)
        result = await db.execute(check_sql)
        exists = result.scalar()

        if not exists:
            return {"success": False, "message": "لا يوجد تقرير محفوظ", "report": None}

        query = text("""
            SELECT report_data, updated_at FROM salary_reports
            WHERE report_month = :report_month
        """)
        result = await db.execute(query, {"report_month": report_month})
        row = result.fetchone()

        if not row:
            return {"success": False, "message": "لا يوجد تقرير محفوظ لهذا الشهر", "report": None}

        return {
            "success": True,
            "message": "تم تحميل التقرير",
            "report": row[0],
            "updated_at": str(row[1]) if row[1] else None,
        }

    except Exception as e:
        logger.error(f"Error loading salary report: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في تحميل التقرير: {str(e)}")


@router.post("/generate", response_model=SalaryReportResponse)
async def generate_salary_report(
    file: UploadFile = File(...),
    month: Optional[int] = None,
    year: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
):
    """
    Upload attendance XLS file and generate comprehensive salary report.
    Month/year are auto-detected from the file if not provided.
    """
    if not file.filename or not file.filename.lower().endswith(('.xls', '.xlsx')):
        raise HTTPException(status_code=400, detail="يرجى رفع ملف بصيغة XLS أو XLSX")

    try:
        content = await file.read()
        employees_raw = parse_attendance_xls(content)

        if not employees_raw:
            raise HTTPException(
                status_code=400,
                detail="لم يتم العثور على بيانات موظفين في الملف",
            )

        # Auto-detect month/year from first employee's date_range
        if not month or not year:
            date_range = employees_raw[0].get("date_range", "")
            if date_range:
                parts = date_range.split("-")[0].strip().split("/")
                if len(parts) >= 2:
                    year = year or int(parts[0])
                    month = month or int(parts[1])
            if not month or not year:
                now = datetime.now()
                year = year or now.year
                month = month or now.month

        # Fetch salary data from employees table
        salary_query = text(
            "SELECT emp_code, basic_salary FROM employees"
        )
        result = await db.execute(salary_query)
        rows = result.fetchall()

        salary_data: Dict[str, Dict[str, float]] = {}
        for row in rows:
            emp_code = str(row[0]).strip()
            basic = _safe_float(row[1])
            salary_data[emp_code] = {"basic_salary": basic, "overtime": 0.0}

        # Fetch overtime data for the month
        month_str = f"{year}-{month:02d}"
        overtime_query = text(
            "SELECT employee_id, SUM(overtime_hours) as total_hours "
            "FROM overtime_records "
            "WHERE date LIKE :month_prefix "
            "GROUP BY employee_id"
        )
        ot_result = await db.execute(overtime_query, {"month_prefix": f"{month_str}%"})
        ot_rows = ot_result.fetchall()

        for row in ot_rows:
            emp_id_str = str(row[0])
            # Find matching employee in salary_data
            if emp_id_str in salary_data:
                # Overtime amount: hours * (daily_salary / 8) * 1.5 (standard overtime rate)
                basic = salary_data[emp_id_str]["basic_salary"]
                hourly_rate = (basic / SALARY_DIVISOR) / 8
                salary_data[emp_id_str]["overtime"] = round(_safe_float(row[1]) * hourly_rate * 1.5, 3)

        # Check for paid leave employees (placeholder - can be extended)
        paid_leave_employees: List[str] = []

        # Compute the report
        reports = compute_salary_report(
            employees_raw=employees_raw,
            salary_data=salary_data,
            year=year,
            month=month,
            paid_leave_employees=paid_leave_employees,
        )

        # Calculate totals
        total_basic = sum(r.basic_salary for r in reports)
        total_overtime = sum(r.overtime_amount for r in reports)
        total_deductions = sum(r.deduction_amount for r in reports)
        total_final = sum(r.final_salary for r in reports)

        return SalaryReportResponse(
            success=True,
            message=f"تم إنشاء تقرير الرواتب لشهر {month}/{year} - {len(reports)} موظف",
            month=f"{year}-{month:02d}",
            year=year,
            employees=reports,
            total_basic_salaries=round(total_basic, 3),
            total_overtime=round(total_overtime, 3),
            total_deductions=round(total_deductions, 3),
            total_final_salaries=round(total_final, 3),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating salary report: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في إنشاء التقرير: {str(e)}")


@router.post("/notes")
async def save_note(
    note_input: NoteInput,
    db: AsyncSession = Depends(get_db),
):
    """Save a note for a specific employee/date/type combination."""
    try:
        # Create table if not exists
        create_sql = text("""
            CREATE TABLE IF NOT EXISTS salary_report_notes (
                id SERIAL PRIMARY KEY,
                report_month VARCHAR(10) NOT NULL,
                employee_id VARCHAR(50) NOT NULL,
                date VARCHAR(20) NOT NULL,
                note_type VARCHAR(20) NOT NULL,
                note TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW(),
                UNIQUE(report_month, employee_id, date, note_type)
            )
        """)
        await db.execute(create_sql)

        # Upsert note
        upsert_sql = text("""
            INSERT INTO salary_report_notes (report_month, employee_id, date, note_type, note, updated_at)
            VALUES (:report_month, :employee_id, :date, :note_type, :note, NOW())
            ON CONFLICT (report_month, employee_id, date, note_type)
            DO UPDATE SET note = :note, updated_at = NOW()
        """)
        await db.execute(upsert_sql, {
            "report_month": note_input.report_month,
            "employee_id": note_input.employee_id,
            "date": note_input.date,
            "note_type": note_input.note_type,
            "note": note_input.note,
        })
        await db.commit()

        return {"success": True, "message": "تم حفظ الملاحظة"}

    except Exception as e:
        logger.error(f"Error saving note: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في حفظ الملاحظة: {str(e)}")


@router.get("/notes/{report_month}", response_model=NotesResponse)
async def get_notes(
    report_month: str,
    db: AsyncSession = Depends(get_db),
):
    """Get all notes for a specific month."""
    try:
        # Check if table exists
        check_sql = text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'salary_report_notes'
            )
        """)
        result = await db.execute(check_sql)
        exists = result.scalar()

        if not exists:
            return NotesResponse(success=True, notes={})

        query = text("""
            SELECT employee_id, date, note_type, note
            FROM salary_report_notes
            WHERE report_month = :report_month
        """)
        result = await db.execute(query, {"report_month": report_month})
        rows = result.fetchall()

        notes: Dict[str, str] = {}
        for row in rows:
            key = f"{row[0]}|{row[1]}|{row[2]}"
            notes[key] = row[3]

        return NotesResponse(success=True, notes=notes)

    except Exception as e:
        logger.error(f"Error fetching notes: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في جلب الملاحظات: {str(e)}")