import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.performance_records import Performance_recordsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/performance_records", tags=["performance_records"])


# ---------- Pydantic Schemas ----------
class Performance_recordsData(BaseModel):
    """Entity data schema (for create/update)"""
    month: str
    employee_id: int
    work_quality: int = None
    punctuality: int = None
    customer_satisfaction: int = None
    teamwork: int = None
    initiative: int = None
    self_development: int = None


class Performance_recordsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    month: Optional[str] = None
    employee_id: Optional[int] = None
    work_quality: Optional[int] = None
    punctuality: Optional[int] = None
    customer_satisfaction: Optional[int] = None
    teamwork: Optional[int] = None
    initiative: Optional[int] = None
    self_development: Optional[int] = None


class Performance_recordsResponse(BaseModel):
    """Entity response schema"""
    id: int
    month: str
    employee_id: int
    work_quality: Optional[int] = None
    punctuality: Optional[int] = None
    customer_satisfaction: Optional[int] = None
    teamwork: Optional[int] = None
    initiative: Optional[int] = None
    self_development: Optional[int] = None

    class Config:
        from_attributes = True


class Performance_recordsListResponse(BaseModel):
    """List response schema"""
    items: List[Performance_recordsResponse]
    total: int
    skip: int
    limit: int


class Performance_recordsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Performance_recordsData]


class Performance_recordsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Performance_recordsUpdateData


class Performance_recordsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Performance_recordsBatchUpdateItem]


class Performance_recordsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Performance_recordsListResponse)
async def query_performance_recordss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query performance_recordss with filtering, sorting, and pagination"""
    logger.debug(f"Querying performance_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Performance_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} performance_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying performance_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Performance_recordsListResponse)
async def query_performance_recordss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query performance_recordss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying performance_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Performance_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} performance_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying performance_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Performance_recordsResponse)
async def get_performance_records(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single performance_records by ID"""
    logger.debug(f"Fetching performance_records with id: {id}, fields={fields}")
    
    service = Performance_recordsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Performance_records with id {id} not found")
            raise HTTPException(status_code=404, detail="Performance_records not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching performance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Performance_recordsResponse, status_code=201)
async def create_performance_records(
    data: Performance_recordsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new performance_records"""
    logger.debug(f"Creating new performance_records with data: {data}")
    
    service = Performance_recordsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create performance_records")
        
        logger.info(f"Performance_records created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating performance_records: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating performance_records: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Performance_recordsResponse], status_code=201)
async def create_performance_recordss_batch(
    request: Performance_recordsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple performance_recordss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} performance_recordss")
    
    service = Performance_recordsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} performance_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Performance_recordsResponse])
async def update_performance_recordss_batch(
    request: Performance_recordsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple performance_recordss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} performance_recordss")
    
    service = Performance_recordsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} performance_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Performance_recordsResponse)
async def update_performance_records(
    id: int,
    data: Performance_recordsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing performance_records"""
    logger.debug(f"Updating performance_records {id} with data: {data}")

    service = Performance_recordsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Performance_records with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Performance_records not found")
        
        logger.info(f"Performance_records {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating performance_records {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating performance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_performance_recordss_batch(
    request: Performance_recordsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple performance_recordss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} performance_recordss")
    
    service = Performance_recordsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} performance_recordss successfully")
        return {"message": f"Successfully deleted {deleted_count} performance_recordss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_performance_records(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single performance_records by ID"""
    logger.debug(f"Deleting performance_records with id: {id}")
    
    service = Performance_recordsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Performance_records with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Performance_records not found")
        
        logger.info(f"Performance_records {id} deleted successfully")
        return {"message": "Performance_records deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting performance_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")