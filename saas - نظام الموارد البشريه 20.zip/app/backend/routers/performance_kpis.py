import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.performance_kpis import Performance_kpisService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/performance_kpis", tags=["performance_kpis"])


# ---------- Pydantic Schemas ----------
class Performance_kpisData(BaseModel):
    """Entity data schema (for create/update)"""
    employee_id: int
    month: str
    tasks_target: int
    tasks_completed: int
    achievement_rate: float = None
    kpi_bonus: float = None
    quality_score: int = None
    timeliness_score: int = None
    collaboration_score: int = None
    innovation_score: int = None
    overall_rating: str = None
    manager_notes: str = None
    employee_goals: str = None


class Performance_kpisUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    employee_id: Optional[int] = None
    month: Optional[str] = None
    tasks_target: Optional[int] = None
    tasks_completed: Optional[int] = None
    achievement_rate: Optional[float] = None
    kpi_bonus: Optional[float] = None
    quality_score: Optional[int] = None
    timeliness_score: Optional[int] = None
    collaboration_score: Optional[int] = None
    innovation_score: Optional[int] = None
    overall_rating: Optional[str] = None
    manager_notes: Optional[str] = None
    employee_goals: Optional[str] = None


class Performance_kpisResponse(BaseModel):
    """Entity response schema"""
    id: int
    employee_id: int
    month: str
    tasks_target: int
    tasks_completed: int
    achievement_rate: Optional[float] = None
    kpi_bonus: Optional[float] = None
    quality_score: Optional[int] = None
    timeliness_score: Optional[int] = None
    collaboration_score: Optional[int] = None
    innovation_score: Optional[int] = None
    overall_rating: Optional[str] = None
    manager_notes: Optional[str] = None
    employee_goals: Optional[str] = None

    class Config:
        from_attributes = True


class Performance_kpisListResponse(BaseModel):
    """List response schema"""
    items: List[Performance_kpisResponse]
    total: int
    skip: int
    limit: int


class Performance_kpisBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Performance_kpisData]


class Performance_kpisBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Performance_kpisUpdateData


class Performance_kpisBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Performance_kpisBatchUpdateItem]


class Performance_kpisBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Performance_kpisListResponse)
async def query_performance_kpiss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query performance_kpiss with filtering, sorting, and pagination"""
    logger.debug(f"Querying performance_kpiss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Performance_kpisService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} performance_kpiss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying performance_kpiss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Performance_kpisListResponse)
async def query_performance_kpiss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query performance_kpiss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying performance_kpiss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Performance_kpisService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} performance_kpiss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying performance_kpiss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Performance_kpisResponse)
async def get_performance_kpis(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single performance_kpis by ID"""
    logger.debug(f"Fetching performance_kpis with id: {id}, fields={fields}")
    
    service = Performance_kpisService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Performance_kpis with id {id} not found")
            raise HTTPException(status_code=404, detail="Performance_kpis not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching performance_kpis {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Performance_kpisResponse, status_code=201)
async def create_performance_kpis(
    data: Performance_kpisData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new performance_kpis"""
    logger.debug(f"Creating new performance_kpis with data: {data}")
    
    service = Performance_kpisService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create performance_kpis")
        
        logger.info(f"Performance_kpis created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating performance_kpis: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating performance_kpis: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Performance_kpisResponse], status_code=201)
async def create_performance_kpiss_batch(
    request: Performance_kpisBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple performance_kpiss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} performance_kpiss")
    
    service = Performance_kpisService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} performance_kpiss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Performance_kpisResponse])
async def update_performance_kpiss_batch(
    request: Performance_kpisBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple performance_kpiss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} performance_kpiss")
    
    service = Performance_kpisService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} performance_kpiss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Performance_kpisResponse)
async def update_performance_kpis(
    id: int,
    data: Performance_kpisUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing performance_kpis"""
    logger.debug(f"Updating performance_kpis {id} with data: {data}")

    service = Performance_kpisService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Performance_kpis with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Performance_kpis not found")
        
        logger.info(f"Performance_kpis {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating performance_kpis {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating performance_kpis {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_performance_kpiss_batch(
    request: Performance_kpisBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple performance_kpiss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} performance_kpiss")
    
    service = Performance_kpisService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} performance_kpiss successfully")
        return {"message": f"Successfully deleted {deleted_count} performance_kpiss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_performance_kpis(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single performance_kpis by ID"""
    logger.debug(f"Deleting performance_kpis with id: {id}")
    
    service = Performance_kpisService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Performance_kpis with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Performance_kpis not found")
        
        logger.info(f"Performance_kpis {id} deleted successfully")
        return {"message": "Performance_kpis deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting performance_kpis {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")