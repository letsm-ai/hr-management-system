import json
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.reward_settings import Reward_settingsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/reward_settings", tags=["reward_settings"])


# ---------- Pydantic Schemas ----------
class RewardSettingsData(BaseModel):
    attendance_weight: float = 0.30
    productivity_weight: float = 0.45
    quality_weight: float = 0.25
    excellent_threshold: float = 0.85
    excellent_reward_percent: float = 15.00
    good_threshold: float = 0.70
    good_reward_percent: float = 10.00
    fair_threshold: float = 0.55
    fair_reward_percent: float = 5.00
    working_days_per_month: int = 30
    late_minor_threshold_minutes: int = 15
    absent_annual_leave_points: int = 100
    absent_approved_points: int = 50
    absent_unapproved_points: int = 0


class RewardSettingsUpdateData(BaseModel):
    attendance_weight: Optional[float] = None
    productivity_weight: Optional[float] = None
    quality_weight: Optional[float] = None
    excellent_threshold: Optional[float] = None
    excellent_reward_percent: Optional[float] = None
    good_threshold: Optional[float] = None
    good_reward_percent: Optional[float] = None
    fair_threshold: Optional[float] = None
    fair_reward_percent: Optional[float] = None
    working_days_per_month: Optional[int] = None
    late_minor_threshold_minutes: Optional[int] = None
    absent_annual_leave_points: Optional[int] = None
    absent_approved_points: Optional[int] = None
    absent_unapproved_points: Optional[int] = None


class RewardSettingsResponse(BaseModel):
    id: int
    attendance_weight: float
    productivity_weight: float
    quality_weight: float
    excellent_threshold: float
    excellent_reward_percent: float
    good_threshold: float
    good_reward_percent: float
    fair_threshold: float
    fair_reward_percent: float
    working_days_per_month: int
    late_minor_threshold_minutes: int
    absent_annual_leave_points: int
    absent_approved_points: int
    absent_unapproved_points: int
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class RewardSettingsListResponse(BaseModel):
    items: List[RewardSettingsResponse]
    total: int
    skip: int
    limit: int


# ---------- Routes ----------
@router.get("/current", response_model=RewardSettingsResponse)
async def get_current_settings(db: AsyncSession = Depends(get_db)):
    """Get the current reward settings (creates default if not exists)"""
    service = Reward_settingsService(db)
    try:
        result = await service.get_or_create_default()
        return result
    except Exception as e:
        logger.error(f"Error fetching reward settings: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.put("/current", response_model=RewardSettingsResponse)
async def update_current_settings(
    data: RewardSettingsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update the current reward settings"""
    service = Reward_settingsService(db)
    try:
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update_settings(update_dict)
        return result
    except Exception as e:
        logger.error(f"Error updating reward settings: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("", response_model=RewardSettingsListResponse)
async def query_reward_settings(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field"),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=2000),
    db: AsyncSession = Depends(get_db),
):
    """Query reward_settings with filtering, sorting, and pagination"""
    service = Reward_settingsService(db)
    try:
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        result = await service.get_list(skip=skip, limit=limit, query_dict=query_dict, sort=sort)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying reward_settings: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=RewardSettingsResponse)
async def get_reward_settings(id: int, db: AsyncSession = Depends(get_db)):
    """Get a single reward_settings by ID"""
    service = Reward_settingsService(db)
    result = await service.get_by_id(id)
    if not result:
        raise HTTPException(status_code=404, detail="Reward_settings not found")
    return result


@router.post("", response_model=RewardSettingsResponse, status_code=201)
async def create_reward_settings(data: RewardSettingsData, db: AsyncSession = Depends(get_db)):
    """Create a new reward_settings"""
    service = Reward_settingsService(db)
    try:
        result = await service.create(data.model_dump())
        return result
    except Exception as e:
        logger.error(f"Error creating reward_settings: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.put("/{id}", response_model=RewardSettingsResponse)
async def update_reward_settings(
    id: int,
    data: RewardSettingsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing reward_settings"""
    service = Reward_settingsService(db)
    update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
    result = await service.update(id, update_dict)
    if not result:
        raise HTTPException(status_code=404, detail="Reward_settings not found")
    return result


@router.delete("/{id}")
async def delete_reward_settings(id: int, db: AsyncSession = Depends(get_db)):
    """Delete a single reward_settings by ID"""
    service = Reward_settingsService(db)
    success = await service.delete(id)
    if not success:
        raise HTTPException(status_code=404, detail="Reward_settings not found")
    return {"message": "Reward_settings deleted successfully", "id": id}