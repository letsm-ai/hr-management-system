import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.client_contracts import Client_contractsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/client_contracts", tags=["client_contracts"])


# ---------- Pydantic Schemas ----------
class Client_contractsData(BaseModel):
    """Entity data schema (for create/update)"""
    client_name: str
    contract_type: str
    service_type: str
    monthly_value: int
    annual_value: int
    previous_value: Optional[int] = None
    start_date: str
    end_date: str
    renewal_year: Optional[int] = None
    status: str
    sales_employee_id: int
    account_manager_id: Optional[int] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Client_contractsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    client_name: Optional[str] = None
    contract_type: Optional[str] = None
    service_type: Optional[str] = None
    monthly_value: Optional[int] = None
    annual_value: Optional[int] = None
    previous_value: Optional[int] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    renewal_year: Optional[int] = None
    status: Optional[str] = None
    sales_employee_id: Optional[int] = None
    account_manager_id: Optional[int] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Client_contractsResponse(BaseModel):
    """Entity response schema"""
    id: int
    user_id: str
    client_name: str
    contract_type: str
    service_type: str
    monthly_value: int
    annual_value: int
    previous_value: Optional[int] = None
    start_date: str
    end_date: str
    renewal_year: Optional[int] = None
    status: str
    sales_employee_id: int
    account_manager_id: Optional[int] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Client_contractsListResponse(BaseModel):
    """List response schema"""
    items: List[Client_contractsResponse]
    total: int
    skip: int
    limit: int


class Client_contractsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Client_contractsData]


class Client_contractsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Client_contractsUpdateData


class Client_contractsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Client_contractsBatchUpdateItem]


class Client_contractsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Client_contractsListResponse)
async def query_client_contractss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query client_contractss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying client_contractss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Client_contractsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} client_contractss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying client_contractss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Client_contractsListResponse)
async def query_client_contractss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query client_contractss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying client_contractss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Client_contractsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} client_contractss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying client_contractss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Client_contractsResponse)
async def get_client_contracts(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single client_contracts by ID (user can only see their own records)"""
    logger.debug(f"Fetching client_contracts with id: {id}, fields={fields}")
    
    service = Client_contractsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Client_contracts with id {id} not found")
            raise HTTPException(status_code=404, detail="Client_contracts not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching client_contracts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Client_contractsResponse, status_code=201)
async def create_client_contracts(
    data: Client_contractsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new client_contracts"""
    logger.debug(f"Creating new client_contracts with data: {data}")
    
    service = Client_contractsService(db)
    try:
        create_data = data.model_dump()
        # Set timestamps for new records
        now = datetime.now()
        create_data['created_at'] = now
        create_data['updated_at'] = now
        result = await service.create(create_data, user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create client_contracts")
        
        logger.info(f"Client_contracts created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating client_contracts: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating client_contracts: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Client_contractsResponse], status_code=201)
async def create_client_contractss_batch(
    request: Client_contractsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple client_contractss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} client_contractss")
    
    service = Client_contractsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} client_contractss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Client_contractsResponse])
async def update_client_contractss_batch(
    request: Client_contractsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple client_contractss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} client_contractss")
    
    service = Client_contractsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} client_contractss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Client_contractsResponse)
async def update_client_contracts(
    id: int,
    data: Client_contractsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing client_contracts (requires ownership)"""
    logger.debug(f"Updating client_contracts {id} with data: {data}")

    service = Client_contractsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Client_contracts with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Client_contracts not found")
        
        logger.info(f"Client_contracts {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating client_contracts {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating client_contracts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_client_contractss_batch(
    request: Client_contractsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple client_contractss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} client_contractss")
    
    service = Client_contractsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} client_contractss successfully")
        return {"message": f"Successfully deleted {deleted_count} client_contractss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_client_contracts(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single client_contracts by ID (requires ownership)"""
    logger.debug(f"Deleting client_contracts with id: {id}")
    
    service = Client_contractsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Client_contracts with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Client_contracts not found")
        
        logger.info(f"Client_contracts {id} deleted successfully")
        return {"message": "Client_contracts deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting client_contracts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")