import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.overtime_records import Overtime_recordsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/overtime_records", tags=["overtime_records"])


# ---------- Pydantic Schemas ----------
class Overtime_recordsData(BaseModel):
    """Entity data schema (for create/update)"""
    date: str
    employee_id: int
    day_type: str = None
    overtime_hours: float = None
    compensation_method: str = None
    approved: str = None


class Overtime_recordsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    date: Optional[str] = None
    employee_id: Optional[int] = None
    day_type: Optional[str] = None
    overtime_hours: Optional[float] = None
    compensation_method: Optional[str] = None
    approved: Optional[str] = None


class Overtime_recordsResponse(BaseModel):
    """Entity response schema"""
    id: int
    date: str
    employee_id: int
    day_type: Optional[str] = None
    overtime_hours: Optional[float] = None
    compensation_method: Optional[str] = None
    approved: Optional[str] = None

    class Config:
        from_attributes = True


class Overtime_recordsListResponse(BaseModel):
    """List response schema"""
    items: List[Overtime_recordsResponse]
    total: int
    skip: int
    limit: int


class Overtime_recordsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Overtime_recordsData]


class Overtime_recordsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Overtime_recordsUpdateData


class Overtime_recordsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Overtime_recordsBatchUpdateItem]


class Overtime_recordsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Overtime_recordsListResponse)
async def query_overtime_recordss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query overtime_recordss with filtering, sorting, and pagination"""
    logger.debug(f"Querying overtime_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Overtime_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} overtime_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying overtime_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Overtime_recordsListResponse)
async def query_overtime_recordss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query overtime_recordss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying overtime_recordss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Overtime_recordsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} overtime_recordss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying overtime_recordss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Overtime_recordsResponse)
async def get_overtime_records(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single overtime_records by ID"""
    logger.debug(f"Fetching overtime_records with id: {id}, fields={fields}")
    
    service = Overtime_recordsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Overtime_records with id {id} not found")
            raise HTTPException(status_code=404, detail="Overtime_records not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching overtime_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Overtime_recordsResponse, status_code=201)
async def create_overtime_records(
    data: Overtime_recordsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new overtime_records"""
    logger.debug(f"Creating new overtime_records with data: {data}")
    
    service = Overtime_recordsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create overtime_records")
        
        logger.info(f"Overtime_records created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating overtime_records: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating overtime_records: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Overtime_recordsResponse], status_code=201)
async def create_overtime_recordss_batch(
    request: Overtime_recordsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple overtime_recordss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} overtime_recordss")
    
    service = Overtime_recordsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} overtime_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Overtime_recordsResponse])
async def update_overtime_recordss_batch(
    request: Overtime_recordsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple overtime_recordss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} overtime_recordss")
    
    service = Overtime_recordsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} overtime_recordss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Overtime_recordsResponse)
async def update_overtime_records(
    id: int,
    data: Overtime_recordsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing overtime_records"""
    logger.debug(f"Updating overtime_records {id} with data: {data}")

    service = Overtime_recordsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Overtime_records with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Overtime_records not found")
        
        logger.info(f"Overtime_records {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating overtime_records {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating overtime_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_overtime_recordss_batch(
    request: Overtime_recordsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple overtime_recordss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} overtime_recordss")
    
    service = Overtime_recordsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} overtime_recordss successfully")
        return {"message": f"Successfully deleted {deleted_count} overtime_recordss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_overtime_records(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single overtime_records by ID"""
    logger.debug(f"Deleting overtime_records with id: {id}")
    
    service = Overtime_recordsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Overtime_records with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Overtime_records not found")
        
        logger.info(f"Overtime_records {id} deleted successfully")
        return {"message": "Overtime_records deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting overtime_records {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")