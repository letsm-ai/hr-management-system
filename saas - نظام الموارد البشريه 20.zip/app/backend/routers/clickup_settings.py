import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.clickup_settings import Clickup_settingsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/clickup_settings", tags=["clickup_settings"])


# ---------- Pydantic Schemas ----------
class Clickup_settingsData(BaseModel):
    """Entity data schema (for create/update)"""
    workspace_id: str = None
    workspace_name: str = None
    is_active: bool = None
    last_sync_at: Optional[datetime] = None
    auto_sync_enabled: bool = None
    auto_sync_frequency: str = None
    auto_sync_day: int = None
    auto_sync_hour: int = None
    last_auto_sync_at: Optional[datetime] = None
    next_auto_sync_at: Optional[datetime] = None
    auto_sync_notify: bool = None


class Clickup_settingsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    workspace_id: Optional[str] = None
    workspace_name: Optional[str] = None
    is_active: Optional[bool] = None
    last_sync_at: Optional[datetime] = None
    auto_sync_enabled: Optional[bool] = None
    auto_sync_frequency: Optional[str] = None
    auto_sync_day: Optional[int] = None
    auto_sync_hour: Optional[int] = None
    last_auto_sync_at: Optional[datetime] = None
    next_auto_sync_at: Optional[datetime] = None
    auto_sync_notify: Optional[bool] = None


class Clickup_settingsResponse(BaseModel):
    """Entity response schema"""
    id: int
    workspace_id: Optional[str] = None
    workspace_name: Optional[str] = None
    is_active: Optional[bool] = None
    last_sync_at: Optional[datetime] = None
    auto_sync_enabled: Optional[bool] = None
    auto_sync_frequency: Optional[str] = None
    auto_sync_day: Optional[int] = None
    auto_sync_hour: Optional[int] = None
    last_auto_sync_at: Optional[datetime] = None
    next_auto_sync_at: Optional[datetime] = None
    auto_sync_notify: Optional[bool] = None
    user_id: Optional[str] = None

    class Config:
        from_attributes = True


class Clickup_settingsListResponse(BaseModel):
    """List response schema"""
    items: List[Clickup_settingsResponse]
    total: int
    skip: int
    limit: int


class Clickup_settingsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Clickup_settingsData]


class Clickup_settingsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Clickup_settingsUpdateData


class Clickup_settingsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Clickup_settingsBatchUpdateItem]


class Clickup_settingsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Clickup_settingsListResponse)
async def query_clickup_settingss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query clickup_settingss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying clickup_settingss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Clickup_settingsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} clickup_settingss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying clickup_settingss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Clickup_settingsListResponse)
async def query_clickup_settingss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query clickup_settingss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying clickup_settingss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Clickup_settingsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} clickup_settingss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying clickup_settingss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Clickup_settingsResponse)
async def get_clickup_settings(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single clickup_settings by ID (user can only see their own records)"""
    logger.debug(f"Fetching clickup_settings with id: {id}, fields={fields}")
    
    service = Clickup_settingsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Clickup_settings with id {id} not found")
            raise HTTPException(status_code=404, detail="Clickup_settings not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching clickup_settings {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Clickup_settingsResponse, status_code=201)
async def create_clickup_settings(
    data: Clickup_settingsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new clickup_settings"""
    logger.debug(f"Creating new clickup_settings with data: {data}")
    
    service = Clickup_settingsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create clickup_settings")
        
        logger.info(f"Clickup_settings created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating clickup_settings: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating clickup_settings: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Clickup_settingsResponse], status_code=201)
async def create_clickup_settingss_batch(
    request: Clickup_settingsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple clickup_settingss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} clickup_settingss")
    
    service = Clickup_settingsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} clickup_settingss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Clickup_settingsResponse])
async def update_clickup_settingss_batch(
    request: Clickup_settingsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple clickup_settingss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} clickup_settingss")
    
    service = Clickup_settingsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} clickup_settingss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Clickup_settingsResponse)
async def update_clickup_settings(
    id: int,
    data: Clickup_settingsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing clickup_settings (requires ownership)"""
    logger.debug(f"Updating clickup_settings {id} with data: {data}")

    service = Clickup_settingsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Clickup_settings with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Clickup_settings not found")
        
        logger.info(f"Clickup_settings {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating clickup_settings {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating clickup_settings {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_clickup_settingss_batch(
    request: Clickup_settingsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple clickup_settingss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} clickup_settingss")
    
    service = Clickup_settingsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} clickup_settingss successfully")
        return {"message": f"Successfully deleted {deleted_count} clickup_settingss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_clickup_settings(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single clickup_settings by ID (requires ownership)"""
    logger.debug(f"Deleting clickup_settings with id: {id}")
    
    service = Clickup_settingsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Clickup_settings with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Clickup_settings not found")
        
        logger.info(f"Clickup_settings {id} deleted successfully")
        return {"message": "Clickup_settings deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting clickup_settings {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")