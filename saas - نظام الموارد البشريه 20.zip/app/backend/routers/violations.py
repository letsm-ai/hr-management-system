import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.violations import ViolationsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/violations", tags=["violations"])


# ---------- Pydantic Schemas ----------
class ViolationsData(BaseModel):
    """Entity data schema (for create/update)"""
    date: str
    employee_id: int
    violation_type: str = None
    details: str = None
    severity: str = None
    is_repeated: str = None
    penalty: str = None
    deduction_amount: float = None
    deduction_days: float = None
    notification_date: str = None
    grievance_status: str = None
    notes: str = None


class ViolationsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    date: Optional[str] = None
    employee_id: Optional[int] = None
    violation_type: Optional[str] = None
    details: Optional[str] = None
    severity: Optional[str] = None
    is_repeated: Optional[str] = None
    penalty: Optional[str] = None
    deduction_amount: Optional[float] = None
    deduction_days: Optional[float] = None
    notification_date: Optional[str] = None
    grievance_status: Optional[str] = None
    notes: Optional[str] = None


class ViolationsResponse(BaseModel):
    """Entity response schema"""
    id: int
    date: str
    employee_id: int
    violation_type: Optional[str] = None
    details: Optional[str] = None
    severity: Optional[str] = None
    is_repeated: Optional[str] = None
    penalty: Optional[str] = None
    deduction_amount: Optional[float] = None
    deduction_days: Optional[float] = None
    notification_date: Optional[str] = None
    grievance_status: Optional[str] = None
    notes: Optional[str] = None

    class Config:
        from_attributes = True


class ViolationsListResponse(BaseModel):
    """List response schema"""
    items: List[ViolationsResponse]
    total: int
    skip: int
    limit: int


class ViolationsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[ViolationsData]


class ViolationsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: ViolationsUpdateData


class ViolationsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[ViolationsBatchUpdateItem]


class ViolationsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=ViolationsListResponse)
async def query_violationss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query violationss with filtering, sorting, and pagination"""
    logger.debug(f"Querying violationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = ViolationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} violationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying violationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=ViolationsListResponse)
async def query_violationss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query violationss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying violationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = ViolationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} violationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying violationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=ViolationsResponse)
async def get_violations(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single violations by ID"""
    logger.debug(f"Fetching violations with id: {id}, fields={fields}")
    
    service = ViolationsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Violations with id {id} not found")
            raise HTTPException(status_code=404, detail="Violations not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching violations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=ViolationsResponse, status_code=201)
async def create_violations(
    data: ViolationsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new violations"""
    logger.debug(f"Creating new violations with data: {data}")
    
    service = ViolationsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create violations")
        
        logger.info(f"Violations created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating violations: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating violations: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[ViolationsResponse], status_code=201)
async def create_violationss_batch(
    request: ViolationsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple violationss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} violationss")
    
    service = ViolationsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} violationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[ViolationsResponse])
async def update_violationss_batch(
    request: ViolationsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple violationss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} violationss")
    
    service = ViolationsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} violationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=ViolationsResponse)
async def update_violations(
    id: int,
    data: ViolationsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing violations"""
    logger.debug(f"Updating violations {id} with data: {data}")

    service = ViolationsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Violations with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Violations not found")
        
        logger.info(f"Violations {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating violations {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating violations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_violationss_batch(
    request: ViolationsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple violationss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} violationss")
    
    service = ViolationsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} violationss successfully")
        return {"message": f"Successfully deleted {deleted_count} violationss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_violations(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single violations by ID"""
    logger.debug(f"Deleting violations with id: {id}")
    
    service = ViolationsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Violations with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Violations not found")
        
        logger.info(f"Violations {id} deleted successfully")
        return {"message": "Violations deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting violations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")