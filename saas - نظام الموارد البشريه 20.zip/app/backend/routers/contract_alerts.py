import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.contract_alerts import Contract_alertsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/contract_alerts", tags=["contract_alerts"])


# ---------- Pydantic Schemas ----------
class Contract_alertsData(BaseModel):
    """Entity data schema (for create/update)"""
    contract_id: int
    client_name: str
    alert_type: str
    days_remaining: int
    contract_end_date: str
    is_read: bool = None
    is_dismissed: bool = None
    sent_at: str = None
    read_at: str = None


class Contract_alertsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    contract_id: Optional[int] = None
    client_name: Optional[str] = None
    alert_type: Optional[str] = None
    days_remaining: Optional[int] = None
    contract_end_date: Optional[str] = None
    is_read: Optional[bool] = None
    is_dismissed: Optional[bool] = None
    sent_at: Optional[str] = None
    read_at: Optional[str] = None


class Contract_alertsResponse(BaseModel):
    """Entity response schema"""
    id: int
    user_id: str
    contract_id: int
    client_name: str
    alert_type: str
    days_remaining: int
    contract_end_date: str
    is_read: Optional[bool] = None
    is_dismissed: Optional[bool] = None
    sent_at: Optional[str] = None
    read_at: Optional[str] = None

    class Config:
        from_attributes = True


class Contract_alertsListResponse(BaseModel):
    """List response schema"""
    items: List[Contract_alertsResponse]
    total: int
    skip: int
    limit: int


class Contract_alertsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Contract_alertsData]


class Contract_alertsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Contract_alertsUpdateData


class Contract_alertsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Contract_alertsBatchUpdateItem]


class Contract_alertsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Contract_alertsListResponse)
async def query_contract_alertss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query contract_alertss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying contract_alertss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Contract_alertsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} contract_alertss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying contract_alertss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Contract_alertsListResponse)
async def query_contract_alertss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query contract_alertss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying contract_alertss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Contract_alertsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} contract_alertss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying contract_alertss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Contract_alertsResponse)
async def get_contract_alerts(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single contract_alerts by ID (user can only see their own records)"""
    logger.debug(f"Fetching contract_alerts with id: {id}, fields={fields}")
    
    service = Contract_alertsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Contract_alerts with id {id} not found")
            raise HTTPException(status_code=404, detail="Contract_alerts not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching contract_alerts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Contract_alertsResponse, status_code=201)
async def create_contract_alerts(
    data: Contract_alertsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new contract_alerts"""
    logger.debug(f"Creating new contract_alerts with data: {data}")
    
    service = Contract_alertsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create contract_alerts")
        
        logger.info(f"Contract_alerts created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating contract_alerts: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating contract_alerts: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Contract_alertsResponse], status_code=201)
async def create_contract_alertss_batch(
    request: Contract_alertsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple contract_alertss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} contract_alertss")
    
    service = Contract_alertsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} contract_alertss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Contract_alertsResponse])
async def update_contract_alertss_batch(
    request: Contract_alertsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple contract_alertss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} contract_alertss")
    
    service = Contract_alertsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} contract_alertss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Contract_alertsResponse)
async def update_contract_alerts(
    id: int,
    data: Contract_alertsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing contract_alerts (requires ownership)"""
    logger.debug(f"Updating contract_alerts {id} with data: {data}")

    service = Contract_alertsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Contract_alerts with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Contract_alerts not found")
        
        logger.info(f"Contract_alerts {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating contract_alerts {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating contract_alerts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_contract_alertss_batch(
    request: Contract_alertsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple contract_alertss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} contract_alertss")
    
    service = Contract_alertsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} contract_alertss successfully")
        return {"message": f"Successfully deleted {deleted_count} contract_alertss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_contract_alerts(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single contract_alerts by ID (requires ownership)"""
    logger.debug(f"Deleting contract_alerts with id: {id}")
    
    service = Contract_alertsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Contract_alerts with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Contract_alerts not found")
        
        logger.info(f"Contract_alerts {id} deleted successfully")
        return {"message": "Contract_alerts deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting contract_alerts {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")