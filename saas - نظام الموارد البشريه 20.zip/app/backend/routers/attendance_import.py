"""
XLS Attendance Import Router
Parses attendance card reports (XLS format) from biometric devices
and imports the data into the attendance_records table.
"""
import logging
from typing import List, Optional
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/attendance", tags=["attendance-import"])


class EmployeeAttendanceSummary(BaseModel):
    """Summary data extracted from XLS for one employee"""
    name: str
    employee_id: str
    department: str
    date_range: str
    absent_days: float
    casual_days: float
    on_business_days: float
    attendance_days: float
    overtime_normal: str
    overtime_special: str
    late_times: int
    late_mins: int
    leave_early_times: int
    leave_early_mins: int
    daily_records: List[dict]


class ImportResult(BaseModel):
    """Result of the import operation"""
    success: bool
    message: str
    employees: List[EmployeeAttendanceSummary]
    total_records_imported: int = 0


def _safe_float(val) -> float:
    """Safely convert a value to float."""
    if isinstance(val, (int, float)):
        return float(val)
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return 0.0


def _safe_int(val) -> int:
    """Safely convert a value to int."""
    if isinstance(val, (int, float)):
        return int(val)
    try:
        return int(float(str(val).strip()))
    except (ValueError, TypeError):
        return 0


def parse_xls_file(file_content: bytes) -> List[EmployeeAttendanceSummary]:
    """
    Parse the XLS attendance card report and extract employee data.

    File structure: Each sheet contains multiple vertical blocks of 3 employees
    side by side. Blocks are identified by rows where col 0 == "Dept".

    Per block (relative to block_start_row):
    - block_start+0: Dept label + value, Name label + value
    - block_start+1: Date label + range, ID label + value
    - block_start+2-3: Summary headers
    - block_start+4: Summary values
    - block_start+9+: Daily records

    Column layout per employee within a block:
    - Employee 1: cols 0-9
    - Employee 2: cols 11-20
    - Employee 3: cols 22-31
    """
    import xlrd

    wb = xlrd.open_workbook(file_contents=file_content)
    employees = []

    # Column offsets for the 3 side-by-side employees
    employee_col_offsets = [0, 11, 22]

    for sheet_idx in range(wb.nsheets):
        sheet = wb.sheet_by_index(sheet_idx)

        # Find all block start rows (where col 0 == "Dept")
        block_starts = []
        for row_idx in range(sheet.nrows):
            val = str(sheet.cell_value(row_idx, 0)).strip()
            if val == "Dept":
                block_starts.append(row_idx)

        for block_idx, block_start in enumerate(block_starts):
            # Determine the end of this block
            if block_idx + 1 < len(block_starts):
                block_end = block_starts[block_idx + 1]
            else:
                block_end = sheet.nrows

            for offset in employee_col_offsets:
                try:
                    # block_start+0: Dept value at offset+1, Name value at offset+7
                    dept = str(sheet.cell_value(block_start, offset + 1)).strip()
                    name = str(sheet.cell_value(block_start, offset + 7)).strip()

                    if not name or name.lower() == "name":
                        continue

                    # block_start+1: Date range at offset+1, ID at offset+7
                    date_range = str(sheet.cell_value(block_start + 1, offset + 1)).strip()
                    emp_id = str(sheet.cell_value(block_start + 1, offset + 7)).strip()

                    # Skip if ID is the header text
                    if emp_id.lower() == "id":
                        continue

                    # Try to convert ID to clean string
                    try:
                        emp_id = str(int(float(emp_id)))
                    except (ValueError, TypeError):
                        pass

                    # block_start+4: Summary values
                    summary_row = block_start + 4
                    absent_days = _safe_float(sheet.cell_value(summary_row, offset + 0))
                    casual_days = _safe_float(sheet.cell_value(summary_row, offset + 1))
                    on_business = _safe_float(sheet.cell_value(summary_row, offset + 2))
                    attendance_days = _safe_float(sheet.cell_value(summary_row, offset + 3))

                    # Overtime: Normal (col offset+4), Special (col offset+5)
                    overtime_normal = str(sheet.cell_value(summary_row, offset + 4)).strip() or "0:00"
                    overtime_special = str(sheet.cell_value(summary_row, offset + 5)).strip() or "0:00"

                    # Late: times (col offset+6), mins (col offset+7)
                    late_times = _safe_int(sheet.cell_value(summary_row, offset + 6))
                    late_mins = _safe_int(sheet.cell_value(summary_row, offset + 7))

                    # Leave early: times (col offset+8), mins (col offset+9)
                    leave_early_times = _safe_int(sheet.cell_value(summary_row, offset + 8))
                    leave_early_mins = _safe_int(sheet.cell_value(summary_row, offset + 9))

                    # Daily records start at block_start+9
                    daily_start = block_start + 9
                    daily_records = []
                    for row_idx in range(daily_start, block_end):
                        day_num = str(sheet.cell_value(row_idx, offset + 0)).strip()
                        if not day_num:
                            continue
                        # Convert float day numbers
                        try:
                            day_int = int(float(day_num))
                            day_num = str(day_int)
                        except (ValueError, TypeError):
                            continue

                        # Validate reasonable day number (1-31)
                        if day_int < 1 or day_int > 31:
                            continue

                        week_day = str(sheet.cell_value(row_idx, offset + 1)).strip()

                        # First shift: On (col+2), Off (col+3)
                        first_on = str(sheet.cell_value(row_idx, offset + 2)).strip()
                        first_off = str(sheet.cell_value(row_idx, offset + 3)).strip()

                        # Second shift: On (col+4), Off (col+5)
                        second_on = str(sheet.cell_value(row_idx, offset + 4)).strip()
                        second_off = str(sheet.cell_value(row_idx, offset + 5)).strip()

                        # Third shift: On (col+6), Off (col+7)
                        third_on = str(sheet.cell_value(row_idx, offset + 6)).strip()
                        third_off = str(sheet.cell_value(row_idx, offset + 7)).strip()

                        # Overtime: In (col+8), Out (col+9)
                        over_in = str(sheet.cell_value(row_idx, offset + 8)).strip()
                        over_out = str(sheet.cell_value(row_idx, offset + 9)).strip()

                        record = {
                            "day": day_num,
                            "weekday": week_day,
                            "first_in": first_on,
                            "first_out": first_off,
                            "second_in": second_on,
                            "second_out": second_off,
                            "third_in": third_on,
                            "third_out": third_off,
                            "overtime_in": over_in,
                            "overtime_out": over_out,
                        }
                        daily_records.append(record)

                    employee = EmployeeAttendanceSummary(
                        name=name,
                        employee_id=emp_id,
                        department=dept,
                        date_range=date_range,
                        absent_days=absent_days,
                        casual_days=casual_days,
                        on_business_days=on_business,
                        attendance_days=attendance_days,
                        overtime_normal=overtime_normal,
                        overtime_special=overtime_special,
                        late_times=late_times,
                        late_mins=late_mins,
                        leave_early_times=leave_early_times,
                        leave_early_mins=leave_early_mins,
                        daily_records=daily_records,
                    )
                    employees.append(employee)

                except Exception as e:
                    logger.warning(
                        f"Error parsing employee at sheet {sheet_idx}, "
                        f"block row {block_start}, offset {offset}: {e}"
                    )
                    continue

    return employees


@router.post("/import-xls", response_model=ImportResult)
async def import_xls(file: UploadFile = File(...)):
    """
    Import attendance data from XLS biometric device report.
    Parses the file and returns extracted data for confirmation.
    """
    if not file.filename or not file.filename.lower().endswith(('.xls', '.xlsx')):
        raise HTTPException(status_code=400, detail="يرجى رفع ملف بصيغة XLS أو XLSX")

    try:
        content = await file.read()
        employees = parse_xls_file(content)

        if not employees:
            raise HTTPException(
                status_code=400,
                detail="لم يتم العثور على بيانات موظفين في الملف",
            )

        return ImportResult(
            success=True,
            message=f"تم استخراج بيانات {len(employees)} موظف بنجاح",
            employees=employees,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error parsing XLS file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في قراءة الملف: {str(e)}")


@router.post("/confirm-import", response_model=ImportResult)
async def confirm_import(
    employees: List[EmployeeAttendanceSummary],
    db: AsyncSession = Depends(get_db),
):
    """
    Confirm and save the imported attendance data to the database.
    """
    total_imported = 0

    try:
        for emp in employees:
            # Parse date range to get year and month
            # Format: "2026/03/01-2026/03/31"
            year_month = ""
            if emp.date_range:
                parts = emp.date_range.split("-")
                if parts:
                    date_parts = parts[0].strip().split("/")
                    if len(date_parts) >= 2:
                        year_month = f"{date_parts[0]}-{date_parts[1]}"

            for record in emp.daily_records:
                day = record.get("day", "")
                if not day:
                    continue

                # Build date string
                if year_month:
                    date_str = f"{year_month}-{day.zfill(2)}"
                else:
                    date_str = day

                # Determine check-in and check-out
                check_in = record.get("first_in", "")
                check_out = (
                    record.get("first_out", "")
                    or record.get("second_out", "")
                    or record.get("third_out", "")
                )

                # Determine day status
                if check_in:
                    day_status = "حاضر"
                else:
                    day_status = "غائب"

                # Calculate actual hours if both check_in and check_out exist
                actual_hours = None
                if check_in and check_out:
                    try:
                        t_in = datetime.strptime(check_in, "%H:%M")
                        t_out = datetime.strptime(check_out, "%H:%M")
                        diff = (t_out - t_in).total_seconds() / 3600
                        if diff > 0:
                            actual_hours = round(diff, 2)
                    except (ValueError, TypeError):
                        pass

                # Check if record already exists for this employee+date
                emp_id_int = int(emp.employee_id) if emp.employee_id.isdigit() else 0
                check_sql = text(
                    "SELECT id FROM attendance_records "
                    "WHERE employee_id = :emp_id AND date = :date_str "
                    "LIMIT 1"
                )
                result = await db.execute(check_sql, {
                    "emp_id": emp_id_int,
                    "date_str": date_str,
                })
                existing = result.fetchone()

                if existing:
                    # Update existing record
                    update_sql = text(
                        "UPDATE attendance_records "
                        "SET check_in = :check_in, check_out = :check_out, "
                        "actual_hours = :actual_hours, day_status = :day_status "
                        "WHERE id = :id"
                    )
                    await db.execute(update_sql, {
                        "check_in": check_in or None,
                        "check_out": check_out or None,
                        "actual_hours": actual_hours,
                        "day_status": day_status,
                        "id": existing[0],
                    })
                else:
                    # Insert new record
                    insert_sql = text(
                        "INSERT INTO attendance_records "
                        "(employee_id, date, check_in, check_out, actual_hours, day_status) "
                        "VALUES (:emp_id, :date_str, :check_in, :check_out, "
                        ":actual_hours, :day_status)"
                    )
                    await db.execute(insert_sql, {
                        "emp_id": emp_id_int,
                        "date_str": date_str,
                        "check_in": check_in or None,
                        "check_out": check_out or None,
                        "actual_hours": actual_hours,
                        "day_status": day_status,
                    })

                total_imported += 1

        await db.commit()

        return ImportResult(
            success=True,
            message=f"تم حفظ {total_imported} سجل حضور بنجاح",
            employees=employees,
            total_records_imported=total_imported,
        )

    except Exception as e:
        logger.error(f"Error saving attendance data: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في حفظ البيانات: {str(e)}")