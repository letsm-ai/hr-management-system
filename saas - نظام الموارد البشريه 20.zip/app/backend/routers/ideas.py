import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.ideas import IdeasService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/ideas", tags=["ideas"])


# ---------- Pydantic Schemas ----------
class IdeasData(BaseModel):
    """Entity data schema (for create/update)"""
    month: str
    employee_id: int
    title: str
    status: str = None
    classification: str = None
    expected_impact: str = None
    submission_date: str = None
    decision_date: str = None
    revenue_generated: float = None
    notes: str = None


class IdeasUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    month: Optional[str] = None
    employee_id: Optional[int] = None
    title: Optional[str] = None
    status: Optional[str] = None
    classification: Optional[str] = None
    expected_impact: Optional[str] = None
    submission_date: Optional[str] = None
    decision_date: Optional[str] = None
    revenue_generated: Optional[float] = None
    notes: Optional[str] = None


class IdeasResponse(BaseModel):
    """Entity response schema"""
    id: int
    month: str
    employee_id: int
    title: str
    status: Optional[str] = None
    classification: Optional[str] = None
    expected_impact: Optional[str] = None
    submission_date: Optional[str] = None
    decision_date: Optional[str] = None
    revenue_generated: Optional[float] = None
    notes: Optional[str] = None

    class Config:
        from_attributes = True


class IdeasListResponse(BaseModel):
    """List response schema"""
    items: List[IdeasResponse]
    total: int
    skip: int
    limit: int


class IdeasBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[IdeasData]


class IdeasBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: IdeasUpdateData


class IdeasBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[IdeasBatchUpdateItem]


class IdeasBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=IdeasListResponse)
async def query_ideass(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query ideass with filtering, sorting, and pagination"""
    logger.debug(f"Querying ideass: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = IdeasService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} ideass")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying ideass: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=IdeasListResponse)
async def query_ideass_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query ideass with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying ideass: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = IdeasService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} ideass")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying ideass: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=IdeasResponse)
async def get_ideas(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single ideas by ID"""
    logger.debug(f"Fetching ideas with id: {id}, fields={fields}")
    
    service = IdeasService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Ideas with id {id} not found")
            raise HTTPException(status_code=404, detail="Ideas not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching ideas {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=IdeasResponse, status_code=201)
async def create_ideas(
    data: IdeasData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new ideas"""
    logger.debug(f"Creating new ideas with data: {data}")
    
    service = IdeasService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create ideas")
        
        logger.info(f"Ideas created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating ideas: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating ideas: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[IdeasResponse], status_code=201)
async def create_ideass_batch(
    request: IdeasBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple ideass in a single request"""
    logger.debug(f"Batch creating {len(request.items)} ideass")
    
    service = IdeasService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} ideass successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[IdeasResponse])
async def update_ideass_batch(
    request: IdeasBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple ideass in a single request"""
    logger.debug(f"Batch updating {len(request.items)} ideass")
    
    service = IdeasService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} ideass successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=IdeasResponse)
async def update_ideas(
    id: int,
    data: IdeasUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing ideas"""
    logger.debug(f"Updating ideas {id} with data: {data}")

    service = IdeasService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Ideas with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Ideas not found")
        
        logger.info(f"Ideas {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating ideas {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating ideas {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_ideass_batch(
    request: IdeasBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple ideass by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} ideass")
    
    service = IdeasService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} ideass successfully")
        return {"message": f"Successfully deleted {deleted_count} ideass", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_ideas(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single ideas by ID"""
    logger.debug(f"Deleting ideas with id: {id}")
    
    service = IdeasService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Ideas with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Ideas not found")
        
        logger.info(f"Ideas {id} deleted successfully")
        return {"message": "Ideas deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting ideas {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")