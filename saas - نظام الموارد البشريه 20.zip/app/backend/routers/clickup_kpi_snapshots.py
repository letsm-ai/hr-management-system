import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.clickup_kpi_snapshots import Clickup_kpi_snapshotsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/clickup_kpi_snapshots", tags=["clickup_kpi_snapshots"])


# ---------- Pydantic Schemas ----------
class Clickup_kpi_snapshotsData(BaseModel):
    """Entity data schema (for create/update)"""
    employee_id: int
    month: str
    clickup_user_id: str = None
    total_tasks: int = None
    completed_tasks: int = None
    completion_rate: int = None
    on_time_tasks: int = None
    late_tasks: int = None
    on_time_rate: int = None
    overdue_tasks: int = None
    total_time_spent_ms: int = None
    average_completion_days: int = None


class Clickup_kpi_snapshotsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    employee_id: Optional[int] = None
    month: Optional[str] = None
    clickup_user_id: Optional[str] = None
    total_tasks: Optional[int] = None
    completed_tasks: Optional[int] = None
    completion_rate: Optional[int] = None
    on_time_tasks: Optional[int] = None
    late_tasks: Optional[int] = None
    on_time_rate: Optional[int] = None
    overdue_tasks: Optional[int] = None
    total_time_spent_ms: Optional[int] = None
    average_completion_days: Optional[int] = None


class Clickup_kpi_snapshotsResponse(BaseModel):
    """Entity response schema"""
    id: int
    employee_id: int
    month: str
    clickup_user_id: Optional[str] = None
    total_tasks: Optional[int] = None
    completed_tasks: Optional[int] = None
    completion_rate: Optional[int] = None
    on_time_tasks: Optional[int] = None
    late_tasks: Optional[int] = None
    on_time_rate: Optional[int] = None
    overdue_tasks: Optional[int] = None
    total_time_spent_ms: Optional[int] = None
    average_completion_days: Optional[int] = None
    user_id: Optional[str] = None

    class Config:
        from_attributes = True


class Clickup_kpi_snapshotsListResponse(BaseModel):
    """List response schema"""
    items: List[Clickup_kpi_snapshotsResponse]
    total: int
    skip: int
    limit: int


class Clickup_kpi_snapshotsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Clickup_kpi_snapshotsData]


class Clickup_kpi_snapshotsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Clickup_kpi_snapshotsUpdateData


class Clickup_kpi_snapshotsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Clickup_kpi_snapshotsBatchUpdateItem]


class Clickup_kpi_snapshotsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Clickup_kpi_snapshotsListResponse)
async def query_clickup_kpi_snapshotss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query clickup_kpi_snapshotss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying clickup_kpi_snapshotss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Clickup_kpi_snapshotsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} clickup_kpi_snapshotss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying clickup_kpi_snapshotss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Clickup_kpi_snapshotsListResponse)
async def query_clickup_kpi_snapshotss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query clickup_kpi_snapshotss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying clickup_kpi_snapshotss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Clickup_kpi_snapshotsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} clickup_kpi_snapshotss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying clickup_kpi_snapshotss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Clickup_kpi_snapshotsResponse)
async def get_clickup_kpi_snapshots(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single clickup_kpi_snapshots by ID (user can only see their own records)"""
    logger.debug(f"Fetching clickup_kpi_snapshots with id: {id}, fields={fields}")
    
    service = Clickup_kpi_snapshotsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Clickup_kpi_snapshots with id {id} not found")
            raise HTTPException(status_code=404, detail="Clickup_kpi_snapshots not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching clickup_kpi_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Clickup_kpi_snapshotsResponse, status_code=201)
async def create_clickup_kpi_snapshots(
    data: Clickup_kpi_snapshotsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new clickup_kpi_snapshots"""
    logger.debug(f"Creating new clickup_kpi_snapshots with data: {data}")
    
    service = Clickup_kpi_snapshotsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create clickup_kpi_snapshots")
        
        logger.info(f"Clickup_kpi_snapshots created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating clickup_kpi_snapshots: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating clickup_kpi_snapshots: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Clickup_kpi_snapshotsResponse], status_code=201)
async def create_clickup_kpi_snapshotss_batch(
    request: Clickup_kpi_snapshotsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple clickup_kpi_snapshotss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} clickup_kpi_snapshotss")
    
    service = Clickup_kpi_snapshotsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} clickup_kpi_snapshotss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Clickup_kpi_snapshotsResponse])
async def update_clickup_kpi_snapshotss_batch(
    request: Clickup_kpi_snapshotsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple clickup_kpi_snapshotss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} clickup_kpi_snapshotss")
    
    service = Clickup_kpi_snapshotsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} clickup_kpi_snapshotss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Clickup_kpi_snapshotsResponse)
async def update_clickup_kpi_snapshots(
    id: int,
    data: Clickup_kpi_snapshotsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing clickup_kpi_snapshots (requires ownership)"""
    logger.debug(f"Updating clickup_kpi_snapshots {id} with data: {data}")

    service = Clickup_kpi_snapshotsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Clickup_kpi_snapshots with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Clickup_kpi_snapshots not found")
        
        logger.info(f"Clickup_kpi_snapshots {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating clickup_kpi_snapshots {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating clickup_kpi_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_clickup_kpi_snapshotss_batch(
    request: Clickup_kpi_snapshotsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple clickup_kpi_snapshotss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} clickup_kpi_snapshotss")
    
    service = Clickup_kpi_snapshotsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} clickup_kpi_snapshotss successfully")
        return {"message": f"Successfully deleted {deleted_count} clickup_kpi_snapshotss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_clickup_kpi_snapshots(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single clickup_kpi_snapshots by ID (requires ownership)"""
    logger.debug(f"Deleting clickup_kpi_snapshots with id: {id}")
    
    service = Clickup_kpi_snapshotsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Clickup_kpi_snapshots with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Clickup_kpi_snapshots not found")
        
        logger.info(f"Clickup_kpi_snapshots {id} deleted successfully")
        return {"message": "Clickup_kpi_snapshots deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting clickup_kpi_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")