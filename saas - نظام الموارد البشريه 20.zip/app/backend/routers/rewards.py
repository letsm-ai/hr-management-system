"""Unified Rewards System - Phase 2 & 3 APIs.

Provides:
- POST /api/v1/rewards/compute-attendance: Compute attendance scores from existing records
- POST /api/v1/rewards/sync-clickup: Sync ClickUp data and compute productivity scores
- GET /api/v1/rewards/readiness: Check data readiness for a given month
- POST /api/v1/rewards/evaluate: Submit quality evaluation for an employee
- POST /api/v1/rewards/calculate: Calculate final rewards for a month
- POST /api/v1/rewards/approve: Approve rewards for employees
- GET /api/v1/rewards/results: Get monthly results with employee details
"""

import json
import logging
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user
from models.attendance_records import Attendance_records
from models.employees import Employees
from models.monthly_performance_results import Monthly_performance_results
from models.notifications import Notifications
from models.reward_settings import Reward_settings
from schemas.auth import UserResponse
from services.monthly_performance_results import Monthly_performance_resultsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/rewards", tags=["rewards"])


# ---------- Pydantic Schemas ----------

class ComputeAttendanceRequest(BaseModel):
    month: str  # e.g. "2026-04"


class SyncClickUpRequest(BaseModel):
    month: str  # e.g. "2026-04"


class EvaluateRequest(BaseModel):
    employee_id: int
    month: str
    quality_output: int  # 1-10
    quality_initiative: int  # 1-10
    quality_teamwork: int  # 1-10
    quality_client_satisfaction: int  # 1-10
    quality_notes: Optional[str] = None


class CalculateRequest(BaseModel):
    month: str


class ApproveRequest(BaseModel):
    month: str
    employee_ids: Optional[List[int]] = None
    all: Optional[bool] = False


class ReadinessResponse(BaseModel):
    attendance_ready: bool
    productivity_ready: bool
    quality_ready: bool
    employees_evaluated: int
    employees_total: int


# ---------- Helper: Load reward settings ----------

async def _get_reward_settings(db: AsyncSession) -> dict:
    """Load reward settings from DB, return defaults if none exist."""
    result = await db.execute(select(Reward_settings).limit(1))
    settings = result.scalar_one_or_none()
    if settings:
        return {
            "working_days_per_month": settings.working_days_per_month,
            "late_minor_threshold_minutes": settings.late_minor_threshold_minutes,
            "absent_annual_leave_points": settings.absent_annual_leave_points,
            "absent_approved_points": settings.absent_approved_points,
            "absent_unapproved_points": settings.absent_unapproved_points,
            "attendance_weight": settings.attendance_weight,
            "productivity_weight": settings.productivity_weight,
            "quality_weight": settings.quality_weight,
            "excellent_threshold": settings.excellent_threshold,
            "excellent_reward_percent": settings.excellent_reward_percent,
            "good_threshold": settings.good_threshold,
            "good_reward_percent": settings.good_reward_percent,
            "fair_threshold": settings.fair_threshold,
            "fair_reward_percent": settings.fair_reward_percent,
        }
    return {
        "working_days_per_month": 22,
        "late_minor_threshold_minutes": 15,
        "absent_annual_leave_points": 50,
        "absent_approved_points": 50,
        "absent_unapproved_points": 0,
        "attendance_weight": 0.30,
        "productivity_weight": 0.45,
        "quality_weight": 0.25,
        "excellent_threshold": 0.85,
        "excellent_reward_percent": 15.0,
        "good_threshold": 0.70,
        "good_reward_percent": 10.0,
        "fair_threshold": 0.55,
        "fair_reward_percent": 5.0,
    }


# ---------- Helper: Compute attendance score for one employee ----------

def _compute_day_score(record: dict, late_threshold: int) -> dict:
    """Compute score for a single day attendance record."""
    check_in = record.get("check_in") or ""
    check_out = record.get("check_out") or ""
    day_status = (record.get("day_status") or "").strip().lower()
    absence_type = (record.get("absence_type") or "").strip().lower()
    tardiness = record.get("tardiness") or 0

    result = {
        "date": record.get("date", ""),
        "clock_in": check_in,
        "clock_out": check_out,
    }

    # Check if absent
    if day_status in ("غائب", "absent", "غياب"):
        if absence_type in ("إجازة سنوية", "annual_leave", "annual", "إجازة", "مدفوعة", "paid_leave"):
            result["status"] = "absent_approved"
            result["score"] = 50
        elif absence_type in ("بإذن", "approved", "إذن", "طارئ", "emergency", "مرضية", "sick"):
            result["status"] = "absent_approved"
            result["score"] = 50
        else:
            result["status"] = "absent_unapproved"
            result["score"] = 0
        return result

    # Check if only single punch
    has_in = bool(check_in and check_in.strip() and check_in.strip() != "-")
    has_out = bool(check_out and check_out.strip() and check_out.strip() != "-")

    if (has_in and not has_out) or (has_out and not has_in):
        result["status"] = "single_punch"
        result["score"] = 80
        return result

    if not has_in and not has_out:
        if day_status in ("عطلة", "holiday", "weekend", "إجازة رسمية"):
            result["status"] = "absent_approved"
            result["score"] = 50
        else:
            result["status"] = "absent_unapproved"
            result["score"] = 0
        return result

    # Both punches present - check tardiness
    if tardiness > late_threshold:
        result["status"] = "present_late_major"
        result["score"] = 75
        result["late_minutes"] = tardiness
    elif tardiness > 0:
        result["status"] = "present_late_minor"
        result["score"] = 90
        result["late_minutes"] = tardiness
    else:
        try:
            if check_in and ":" in check_in:
                time_parts = check_in.strip().split(":")
                hour = int(time_parts[0])
                minute = int(time_parts[1])
                total_minutes = hour * 60 + minute
                threshold_minutes = 8 * 60 + 30
                if total_minutes > threshold_minutes:
                    late_mins = total_minutes - threshold_minutes
                    if late_mins > late_threshold:
                        result["status"] = "present_late_major"
                        result["score"] = 75
                        result["late_minutes"] = late_mins
                    elif late_mins > 0:
                        result["status"] = "present_late_minor"
                        result["score"] = 90
                        result["late_minutes"] = late_mins
                    else:
                        result["status"] = "present_no_late"
                        result["score"] = 100
                else:
                    result["status"] = "present_no_late"
                    result["score"] = 100
            else:
                result["status"] = "present_no_late"
                result["score"] = 100
        except (ValueError, IndexError):
            result["status"] = "present_no_late"
            result["score"] = 100

    return result


# ---------- Endpoint: Compute Attendance Scores ----------

@router.post("/compute-attendance")
async def compute_attendance_scores(
    data: ComputeAttendanceRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Compute attendance scores for all employees for a given month."""
    month = data.month

    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    settings = await _get_reward_settings(db)
    working_days = settings["working_days_per_month"]
    late_threshold = settings["late_minor_threshold_minutes"]

    query = select(Attendance_records).where(
        Attendance_records.date.like(month + "%")
    )
    result = await db.execute(query)
    all_records = result.scalars().all()

    if not all_records:
        return {
            "success": True,
            "month": month,
            "employees_processed": 0,
            "results": [],
            "message": "No attendance records found for this month",
        }

    employee_records: dict = {}
    for rec in all_records:
        eid = rec.employee_id
        if eid not in employee_records:
            employee_records[eid] = []
        employee_records[eid].append({
            "date": rec.date,
            "check_in": rec.check_in,
            "check_out": rec.check_out,
            "day_status": rec.day_status,
            "absence_type": rec.absence_type,
            "tardiness": rec.tardiness,
        })

    service = Monthly_performance_resultsService(db)
    results_summary = []

    for employee_id, records in employee_records.items():
        day_details = []
        total_score = 0

        for rec in records:
            day_result = _compute_day_score(rec, late_threshold)
            day_details.append(day_result)
            total_score += day_result["score"]

        attendance_score = round(total_score / (working_days * 100), 4) if working_days > 0 else 0.0
        attendance_score = min(attendance_score, 1.0)

        existing = await service.get_by_employee_month(employee_id, month)
        attendance_details_json = json.dumps(day_details, ensure_ascii=False)

        if existing:
            await service.update(existing.id, {
                "attendance_score": attendance_score,
                "attendance_details": attendance_details_json,
            })
        else:
            await service.create({
                "employee_id": employee_id,
                "month": month,
                "attendance_score": attendance_score,
                "attendance_details": attendance_details_json,
                "status": "draft",
            })

        results_summary.append({
            "employee_id": employee_id,
            "days_counted": len(day_details),
            "attendance_score": attendance_score,
        })

    return {
        "success": True,
        "month": month,
        "employees_processed": len(results_summary),
        "results": results_summary,
    }


# ---------- Endpoint: Sync ClickUp & Compute Productivity ----------

@router.post("/sync-clickup")
async def sync_clickup_productivity(
    data: SyncClickUpRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Sync ClickUp tasks for a given month and compute productivity scores."""
    month = data.month

    try:
        dt = datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    year = dt.year
    month_num = dt.month
    date_from = "%d-%02d-01" % (year, month_num)
    if month_num == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month_num + 1, 1)
    from datetime import timedelta
    last_day = next_month - timedelta(days=1)
    date_to = last_day.strftime("%Y-%m-%d")

    from routers.clickup import _load_settings, _load_member_mapping
    from services.clickup_service import get_tasks_for_team

    settings = await _load_settings(db)
    if not settings.get("api_token"):
        raise HTTPException(
            status_code=400,
            detail="ClickUp API token not configured. Please set it in ClickUp Settings."
        )

    workspace_id = settings.get("default_workspace_id")
    if not workspace_id:
        raise HTTPException(
            status_code=400,
            detail="No default workspace configured. Please set it in ClickUp Settings."
        )

    member_mapping = await _load_member_mapping(db)
    api_token = settings.get("api_token", "").strip()

    # If no member mapping exists, try to auto-match by name/email
    if not member_mapping:
        logger.info("No member mapping found, attempting auto-match...")
        from services.clickup_service import get_team_members
        try:
            clickup_members = await get_team_members(workspace_id, token=api_token)
        except Exception as e:
            logger.error("Failed to fetch ClickUp members for auto-match: %s", e)
            raise HTTPException(
                status_code=400,
                detail="لا يوجد ربط بين أعضاء ClickUp والموظفين. يرجى إعداد الربط في إعدادات ClickUp أو التأكد من اتصال ClickUp."
            )

        # Get all employees
        emp_result = await db.execute(select(Employees).where(Employees.status != "مستقيل"))
        all_employees = emp_result.scalars().all()

        # Try to match by email or name similarity
        auto_mapping = {}
        for cm in clickup_members:
            cm_email = (cm.get("email") or "").lower().strip()
            cm_username = (cm.get("username") or "").lower().strip()
            cm_id = str(cm.get("id", ""))

            for emp in all_employees:
                emp_name = (emp.full_name or "").lower().strip()
                emp_email = (emp.email or "").lower().strip()
                emp_clickup_email = (emp.clickup_email or "").lower().strip()

                # Match by clickup_email first (most specific)
                if cm_email and emp_clickup_email and cm_email == emp_clickup_email:
                    auto_mapping[cm_id] = str(emp.id)
                    break
                # Match by regular email
                elif cm_email and emp_email and cm_email == emp_email:
                    auto_mapping[cm_id] = str(emp.id)
                    break
                # Match by username contains name or vice versa
                elif cm_username and emp_name and (cm_username in emp_name or emp_name in cm_username):
                    auto_mapping[cm_id] = str(emp.id)
                    break
                elif cm_email and emp_name:
                    # Try matching email prefix to name
                    email_prefix = cm_email.split("@")[0].replace(".", " ").replace("_", " ").lower()
                    if email_prefix in emp_name or emp_name in email_prefix:
                        auto_mapping[cm_id] = str(emp.id)
                        break

        if not auto_mapping:
            raise HTTPException(
                status_code=400,
                detail="لم يتم العثور على تطابق بين أعضاء ClickUp والموظفين. يرجى إعداد ربط الأعضاء يدوياً في إعدادات ClickUp."
            )

        # Save the auto-mapping for future use
        from routers.clickup import _save_member_mapping_to_db
        await _save_member_mapping_to_db(db, auto_mapping)
        member_mapping = auto_mapping
        logger.info("Auto-matched %d ClickUp members to employees", len(auto_mapping))

    try:
        all_tasks = await get_tasks_for_team(
            team_id=workspace_id,
            date_from=date_from,
            date_to=date_to,
            include_closed=True,
            token=api_token,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Failed to fetch ClickUp tasks: %s", e)
        raise HTTPException(status_code=500, detail="Failed to fetch ClickUp tasks: " + str(e))

    service = Monthly_performance_resultsService(db)
    results_summary = []

    for clickup_member_id, employee_id_str in member_mapping.items():
        try:
            employee_id = int(employee_id_str)
        except (ValueError, TypeError):
            continue

        member_tasks = []
        for task in all_tasks:
            assignee_ids = [str(a.get("id", "")) for a in task.get("assignees", [])]
            if clickup_member_id in assignee_ids:
                task_due = task.get("due_date")
                task_created = task.get("date_created")

                in_range = False
                if task_due:
                    try:
                        due_dt = datetime.fromtimestamp(int(task_due) / 1000)
                        if due_dt.strftime("%Y-%m") == month:
                            in_range = True
                    except (ValueError, TypeError):
                        pass
                if not in_range and task_created:
                    try:
                        created_dt = datetime.fromtimestamp(int(task_created) / 1000)
                        if created_dt.strftime("%Y-%m") == month:
                            in_range = True
                    except (ValueError, TypeError):
                        pass
                if not in_range:
                    task_updated = task.get("date_updated")
                    if task_updated:
                        try:
                            updated_dt = datetime.fromtimestamp(int(task_updated) / 1000)
                            if updated_dt.strftime("%Y-%m") == month:
                                in_range = True
                        except (ValueError, TypeError):
                            pass

                if in_range:
                    member_tasks.append(task)

        tasks_assigned = len(member_tasks)
        tasks_completed = 0
        tasks_on_time = 0
        points_target = 0
        points_achieved = 0
        task_details = []

        for task in member_tasks:
            task_status = task.get("status", {})
            status_type = task_status.get("type", "").lower() if isinstance(task_status, dict) else ""
            status_name = task_status.get("status", "").lower() if isinstance(task_status, dict) else ""

            is_completed = status_type == "closed" or status_name in [
                "closed", "complete", "done", "مكتمل", "مغلق", "منجز"
            ]

            task_points = 0
            custom_fields = task.get("custom_fields", [])
            for cf in custom_fields:
                cf_name = (cf.get("name") or "").lower()
                if "story" in cf_name or "point" in cf_name:
                    try:
                        task_points = float(cf.get("value") or 0)
                    except (ValueError, TypeError):
                        task_points = 0
                    break

            if task_points == 0:
                time_est = task.get("time_estimate")
                if time_est:
                    try:
                        task_points = round(int(time_est) / 3600000, 1)
                    except (ValueError, TypeError):
                        task_points = 0

            points_target += task_points

            on_time = False
            completed_date_str = None
            if is_completed:
                tasks_completed += 1
                points_achieved += task_points

                task_due = task.get("due_date")
                date_closed = task.get("date_closed") or task.get("date_done")

                if task_due and date_closed:
                    try:
                        due_ts = int(task_due)
                        closed_ts = int(date_closed)
                        if closed_ts <= due_ts:
                            on_time = True
                            tasks_on_time += 1
                    except (ValueError, TypeError):
                        pass
                elif task_due and not date_closed:
                    on_time = True
                    tasks_on_time += 1

                if date_closed:
                    try:
                        completed_date_str = datetime.fromtimestamp(int(date_closed) / 1000).strftime("%Y-%m-%d")
                    except (ValueError, TypeError):
                        pass

            due_date_str = None
            if task.get("due_date"):
                try:
                    due_date_str = datetime.fromtimestamp(int(task["due_date"]) / 1000).strftime("%Y-%m-%d")
                except (ValueError, TypeError):
                    pass

            task_details.append({
                "task_id": task.get("id", ""),
                "task_name": task.get("name", ""),
                "points": task_points,
                "status": "completed" if is_completed else "in_progress",
                "due_date": due_date_str,
                "completed_date": completed_date_str,
                "on_time": on_time,
            })

        completion_rate = (tasks_completed / tasks_assigned) if tasks_assigned > 0 else 0
        timeliness_rate = (tasks_on_time / tasks_completed) if tasks_completed > 0 else 0

        if points_target > 0:
            points_rate = points_achieved / points_target
        else:
            points_rate = 1.0

        productivity_score = round(
            (completion_rate * 0.50) + (timeliness_rate * 0.30) + (points_rate * 0.20),
            4
        )

        existing = await service.get_by_employee_month(employee_id, month)
        productivity_details_json = json.dumps(task_details, ensure_ascii=False)

        update_data = {
            "productivity_score": productivity_score,
            "tasks_assigned": tasks_assigned,
            "tasks_completed": tasks_completed,
            "tasks_on_time": tasks_on_time,
            "points_target": int(points_target),
            "points_achieved": int(points_achieved),
            "productivity_details": productivity_details_json,
        }

        if existing:
            await service.update(existing.id, update_data)
        else:
            create_data = {
                "employee_id": employee_id,
                "month": month,
                "status": "draft",
                **update_data,
            }
            await service.create(create_data)

        results_summary.append({
            "employee_id": employee_id,
            "clickup_member_id": clickup_member_id,
            "tasks_assigned": tasks_assigned,
            "tasks_completed": tasks_completed,
            "tasks_on_time": tasks_on_time,
            "productivity_score": productivity_score,
        })

    from routers.clickup import _add_sync_record
    await _add_sync_record(
        db,
        month=month,
        sync_type="productivity_sync",
        status="success",
        synced_count=len(results_summary),
        skipped_count=0,
        failed_count=0,
        workspace_name=settings.get("default_workspace_name", ""),
    )

    return {
        "success": True,
        "month": month,
        "employees_processed": len(results_summary),
        "results": results_summary,
    }


# ---------- Endpoint: Readiness Check ----------

@router.get("/readiness", response_model=ReadinessResponse)
async def check_readiness(
    month: str = Query(..., description="Month in YYYY-MM format"),
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Check data readiness for reward calculation for a given month."""
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    emp_count_result = await db.execute(select(func.count(Employees.id)))
    employees_total = emp_count_result.scalar() or 0

    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month
    )
    result = await db.execute(query)
    results = result.scalars().all()

    attendance_ready = False
    productivity_ready = False
    quality_ready = False
    employees_evaluated = 0

    if results:
        att_count = sum(1 for r in results if r.attendance_score is not None)
        attendance_ready = att_count > 0

        prod_count = sum(1 for r in results if r.productivity_score is not None)
        productivity_ready = prod_count > 0

        qual_count = sum(1 for r in results if r.quality_score is not None)
        quality_ready = qual_count > 0

        employees_evaluated = sum(
            1 for r in results
            if r.attendance_score is not None
            and r.productivity_score is not None
            and r.quality_score is not None
        )

    return ReadinessResponse(
        attendance_ready=attendance_ready,
        productivity_ready=productivity_ready,
        quality_ready=quality_ready,
        employees_evaluated=employees_evaluated,
        employees_total=employees_total,
    )


# ---------- Endpoint: Quality Evaluation ----------

@router.post("/evaluate")
async def evaluate_employee(
    data: EvaluateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Submit quality evaluation for an employee for a given month."""
    month = data.month

    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    # Validate scores are 1-10
    for field_name, value in [
        ("quality_output", data.quality_output),
        ("quality_initiative", data.quality_initiative),
        ("quality_teamwork", data.quality_teamwork),
        ("quality_client_satisfaction", data.quality_client_satisfaction),
    ]:
        if value < 1 or value > 10:
            raise HTTPException(
                status_code=400,
                detail=field_name + " must be between 1 and 10"
            )

    # Verify employee exists
    emp_result = await db.execute(
        select(Employees).where(Employees.id == data.employee_id)
    )
    employee = emp_result.scalar_one_or_none()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    # Calculate quality_score
    quality_score = round(
        (
            (data.quality_output * 0.35)
            + (data.quality_initiative * 0.25)
            + (data.quality_teamwork * 0.20)
            + (data.quality_client_satisfaction * 0.20)
        ) / 10.0,
        4,
    )

    service = Monthly_performance_resultsService(db)
    existing = await service.get_by_employee_month(data.employee_id, month)

    update_data = {
        "quality_score": quality_score,
        "quality_output": data.quality_output,
        "quality_initiative": data.quality_initiative,
        "quality_teamwork": data.quality_teamwork,
        "quality_client_satisfaction": data.quality_client_satisfaction,
        "quality_notes": data.quality_notes,
        "evaluated_by": current_user.id,
    }

    if existing:
        await service.update(existing.id, update_data)
    else:
        create_data = {
            "employee_id": data.employee_id,
            "month": month,
            "status": "draft",
            **update_data,
        }
        await service.create(create_data)

    return {
        "success": True,
        "employee_id": data.employee_id,
        "month": month,
        "quality_score": quality_score,
        "quality_output": data.quality_output,
        "quality_initiative": data.quality_initiative,
        "quality_teamwork": data.quality_teamwork,
        "quality_client_satisfaction": data.quality_client_satisfaction,
    }


# ---------- Endpoint: Calculate Final Rewards ----------

@router.post("/calculate")
async def calculate_rewards(
    data: CalculateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Calculate final rewards for all employees for a given month."""
    month = data.month

    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    settings = await _get_reward_settings(db)
    attendance_weight = settings["attendance_weight"]
    productivity_weight = settings["productivity_weight"]
    quality_weight = settings["quality_weight"]
    excellent_threshold = settings["excellent_threshold"]
    excellent_reward_percent = settings["excellent_reward_percent"]
    good_threshold = settings["good_threshold"]
    good_reward_percent = settings["good_reward_percent"]
    fair_threshold = settings["fair_threshold"]
    fair_reward_percent = settings["fair_reward_percent"]

    # Get all performance results for this month
    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month
    )
    result = await db.execute(query)
    all_results = result.scalars().all()

    if not all_results:
        raise HTTPException(
            status_code=404,
            detail="No performance records found for month " + month
        )

    service = Monthly_performance_resultsService(db)
    calculated = []
    skipped = []
    total_rewards = 0.0

    for record in all_results:
        # Skip if any score is missing
        if (
            record.attendance_score is None
            or record.productivity_score is None
            or record.quality_score is None
        ):
            skipped.append({
                "employee_id": record.employee_id,
                "reason": "missing_scores",
                "attendance": record.attendance_score is not None,
                "productivity": record.productivity_score is not None,
                "quality": record.quality_score is not None,
            })
            continue

        # Calculate final score
        final_score = round(
            (record.attendance_score * attendance_weight)
            + (record.productivity_score * productivity_weight)
            + (record.quality_score * quality_weight),
            4,
        )

        # Determine grade and reward percent
        if final_score >= excellent_threshold:
            grade = "ممتاز"
            reward_percent = excellent_reward_percent
        elif final_score >= good_threshold:
            grade = "جيد جداً"
            reward_percent = good_reward_percent
        elif final_score >= fair_threshold:
            grade = "جيد"
            reward_percent = fair_reward_percent
        else:
            grade = "يحتاج تحسين"
            reward_percent = 0.0

        # Get employee salary
        emp_result = await db.execute(
            select(Employees).where(Employees.id == record.employee_id)
        )
        employee = emp_result.scalar_one_or_none()
        salary = employee.basic_salary if employee and employee.basic_salary else 0.0
        reward_amount = round(salary * (reward_percent / 100.0), 2)
        total_rewards += reward_amount

        # Update record
        await service.update(record.id, {
            "final_score": final_score,
            "grade": grade,
            "reward_percent": reward_percent,
            "reward_amount": reward_amount,
            "status": "pending_approval",
        })

        calculated.append({
            "employee_id": record.employee_id,
            "final_score": final_score,
            "grade": grade,
            "reward_percent": reward_percent,
            "reward_amount": reward_amount,
        })

    return {
        "success": True,
        "month": month,
        "calculated_count": len(calculated),
        "skipped_count": len(skipped),
        "total_rewards": round(total_rewards, 2),
        "calculated": calculated,
        "skipped": skipped,
    }


# ---------- Endpoint: Approve Rewards ----------

@router.post("/approve")
async def approve_rewards(
    data: ApproveRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Approve rewards for employees for a given month."""
    month = data.month

    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    # Build query
    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month,
        Monthly_performance_results.status == "pending_approval",
    )

    if not data.all and data.employee_ids:
        query = query.where(
            Monthly_performance_results.employee_id.in_(data.employee_ids)
        )

    result = await db.execute(query)
    records = result.scalars().all()

    if not records:
        raise HTTPException(
            status_code=404,
            detail="No pending approval records found for the specified criteria"
        )

    now = datetime.now(timezone.utc)
    approved_count = 0

    for record in records:
        record.status = "approved"
        record.approved_by = current_user.id
        record.approved_at = now
        approved_count += 1

        # Send notification to employee
        try:
            # Get employee info for notification
            emp_result = await db.execute(
                select(Employees).where(Employees.id == record.employee_id)
            )
            employee = emp_result.scalar_one_or_none()
            if employee:
                notification = Notifications(
                    user_id=str(record.employee_id),
                    employee_id=record.employee_id,
                    type="reward_approved",
                    title="تم اعتماد مكافأتك",
                    message="تم اعتماد مكافأتك لشهر " + month + " بمبلغ " + str(record.reward_amount or 0) + " ر.ع. التصنيف: " + (record.grade or ""),
                    is_read=False,
                    related_id=record.id,
                    created_at=now,
                )
                db.add(notification)
        except Exception as e:
            logger.warning("Failed to create notification for employee %s: %s", record.employee_id, e)

    await db.commit()

    return {
        "success": True,
        "month": month,
        "approved_count": approved_count,
    }


# ---------- Endpoint: Get Monthly Results ----------

@router.get("/results")
async def get_monthly_results(
    month: str = Query(..., description="Month in YYYY-MM format"),
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get all monthly performance results with employee details for a given month."""
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    # Get all results for this month
    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month
    )
    result = await db.execute(query)
    records = result.scalars().all()

    # Get all employees
    emp_result = await db.execute(select(Employees))
    employees = {e.id: e for e in emp_result.scalars().all()}

    results_list = []
    for record in records:
        emp = employees.get(record.employee_id)
        results_list.append({
            "id": record.id,
            "employee_id": record.employee_id,
            "employee_name": emp.full_name if emp else "غير معروف",
            "department": emp.department if emp else "",
            "salary": emp.basic_salary if emp else 0,
            "attendance_score": record.attendance_score,
            "productivity_score": record.productivity_score,
            "quality_score": record.quality_score,
            "quality_output": record.quality_output,
            "quality_initiative": record.quality_initiative,
            "quality_teamwork": record.quality_teamwork,
            "quality_client_satisfaction": record.quality_client_satisfaction,
            "quality_notes": record.quality_notes,
            "final_score": record.final_score,
            "grade": record.grade,
            "reward_percent": record.reward_percent,
            "reward_amount": record.reward_amount,
            "status": record.status,
            "attendance_details": record.attendance_details,
            "productivity_details": record.productivity_details,
            "tasks_assigned": record.tasks_assigned,
            "tasks_completed": record.tasks_completed,
            "tasks_on_time": record.tasks_on_time,
            "evaluated_by": record.evaluated_by,
            "approved_by": record.approved_by,
            "approved_at": record.approved_at.isoformat() if record.approved_at else None,
        })

    # Sort by final_score descending (None values at end)
    results_list.sort(
        key=lambda x: x["final_score"] if x["final_score"] is not None else -1,
        reverse=True,
    )

    return {
        "month": month,
        "results": results_list,
        "total_count": len(results_list),
    }


# ---------- Endpoint: Auto-Compute Scores ----------

@router.post("/auto-compute")
async def auto_compute_scores(
    data: ComputeAttendanceRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Auto-compute attendance scores from attendance records for a given month.
    
    This is called automatically when the evaluation page loads to ensure
    attendance scores are always up-to-date. Productivity scores require
    ClickUp sync which is triggered separately.
    """
    month = data.month

    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    settings = await _get_reward_settings(db)
    working_days = settings["working_days_per_month"]
    late_threshold = settings["late_minor_threshold_minutes"]

    # Get attendance records for the month
    query = select(Attendance_records).where(
        Attendance_records.date.like(month + "%")
    )
    result = await db.execute(query)
    all_records = result.scalars().all()

    if not all_records:
        return {
            "success": True,
            "month": month,
            "employees_processed": 0,
            "message": "No attendance records found for this month",
        }

    # Group by employee
    employee_records: dict = {}
    for rec in all_records:
        eid = rec.employee_id
        if eid not in employee_records:
            employee_records[eid] = []
        employee_records[eid].append({
            "date": rec.date,
            "check_in": rec.check_in,
            "check_out": rec.check_out,
            "day_status": rec.day_status,
            "absence_type": rec.absence_type,
            "tardiness": rec.tardiness,
        })

    service = Monthly_performance_resultsService(db)
    processed = 0

    for employee_id, records in employee_records.items():
        day_details = []
        total_score = 0

        for rec in records:
            day_result = _compute_day_score(rec, late_threshold)
            day_details.append(day_result)
            total_score += day_result["score"]

        attendance_score = round(total_score / (working_days * 100), 4) if working_days > 0 else 0.0
        attendance_score = min(attendance_score, 1.0)

        existing = await service.get_by_employee_month(employee_id, month)
        attendance_details_json = json.dumps(day_details, ensure_ascii=False)

        if existing:
            await service.update(existing.id, {
                "attendance_score": attendance_score,
                "attendance_details": attendance_details_json,
            })
        else:
            await service.create({
                "employee_id": employee_id,
                "month": month,
                "attendance_score": attendance_score,
                "attendance_details": attendance_details_json,
                "status": "draft",
            })
        processed += 1

    # Now also auto-calculate final scores for employees that have all 3 scores
    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month
    )
    result = await db.execute(query)
    all_results = result.scalars().all()

    attendance_weight = settings["attendance_weight"]
    productivity_weight = settings["productivity_weight"]
    quality_weight = settings["quality_weight"]
    excellent_threshold = settings["excellent_threshold"]
    excellent_reward_percent = settings["excellent_reward_percent"]
    good_threshold = settings["good_threshold"]
    good_reward_percent = settings["good_reward_percent"]
    fair_threshold = settings["fair_threshold"]
    fair_reward_percent = settings["fair_reward_percent"]

    for record in all_results:
        if (
            record.attendance_score is not None
            and record.productivity_score is not None
            and record.quality_score is not None
        ):
            final_score = round(
                (record.attendance_score * attendance_weight)
                + (record.productivity_score * productivity_weight)
                + (record.quality_score * quality_weight),
                4,
            )

            if final_score >= excellent_threshold:
                grade = "ممتاز"
            elif final_score >= good_threshold:
                grade = "جيد جداً"
            elif final_score >= fair_threshold:
                grade = "جيد"
            else:
                grade = "يحتاج تحسين"

            await service.update(record.id, {
                "final_score": final_score,
                "grade": grade,
            })

    return {
        "success": True,
        "month": month,
        "employees_processed": processed,
    }


# ---------- Endpoint: Get Employees for Evaluation ----------

@router.get("/employees-evaluation-status")
async def get_employees_evaluation_status(
    month: str = Query(..., description="Month in YYYY-MM format"),
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get all employees with their evaluation status for a given month."""
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid month format. Use YYYY-MM")

    # Get all employees
    emp_result = await db.execute(select(Employees).where(Employees.status != "مستقيل"))
    employees = emp_result.scalars().all()

    # Get existing evaluations for this month
    query = select(Monthly_performance_results).where(
        Monthly_performance_results.month == month
    )
    result = await db.execute(query)
    evaluations = {r.employee_id: r for r in result.scalars().all()}

    employees_list = []
    for emp in employees:
        eval_record = evaluations.get(emp.id)
        is_evaluated = eval_record is not None and eval_record.quality_score is not None
        employees_list.append({
            "id": emp.id,
            "full_name": emp.full_name,
            "department": emp.department,
            "job_title": emp.job_title,
            "is_evaluated": is_evaluated,
            "attendance_score": eval_record.attendance_score if eval_record else None,
            "productivity_score": eval_record.productivity_score if eval_record else None,
            "tasks_assigned": eval_record.tasks_assigned if eval_record else None,
            "tasks_completed": eval_record.tasks_completed if eval_record else None,
            "quality_score": eval_record.quality_score if eval_record else None,
            "quality_output": eval_record.quality_output if eval_record else None,
            "quality_initiative": eval_record.quality_initiative if eval_record else None,
            "quality_teamwork": eval_record.quality_teamwork if eval_record else None,
            "quality_client_satisfaction": eval_record.quality_client_satisfaction if eval_record else None,
            "quality_notes": eval_record.quality_notes if eval_record else None,
            "final_score": eval_record.final_score if eval_record else None,
            "grade": eval_record.grade if eval_record else None,
        })

    evaluated_count = sum(1 for e in employees_list if e["is_evaluated"])

    # Also include settings weights for frontend display
    settings = await _get_reward_settings(db)

    return {
        "month": month,
        "employees": employees_list,
        "total": len(employees_list),
        "evaluated": evaluated_count,
        "pending": len(employees_list) - evaluated_count,
        "weights": {
            "attendance": settings["attendance_weight"],
            "productivity": settings["productivity_weight"],
            "quality": settings["quality_weight"],
        },
    }