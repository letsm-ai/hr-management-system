import logging
import re
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Set
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from dateutil import parser as dateparser

from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/data-sync", tags=["data-sync"])

# Tables to export/import (order matters for foreign key dependencies)
SYNC_TABLES = [
    "employees",
    "performance_records",
    "attendance_records",
    "violations",
    "overtime_records",
    "performance_kpis",
    "incentive_settings",
    "incentive_records",
    "client_contracts",
    "contract_alerts",
    "contracts",
    "notifications",
    "clickup_settings",
    "clickup_kpi_snapshots",
    "clickup_sync_logs",
]

# All allowed tables (SYNC_TABLES + auth tables)
ALLOWED_TABLES = set(SYNC_TABLES + ["users", "user_roles", "pending_users"])

# Valid SQL identifier pattern
_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

# Static query to check if a table exists
_TABLE_EXISTS_QUERY = text(
    "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = :t)"
)

# All queries below are fully static string literals with no dynamic construction.
# Each table has its own pre-written queries to avoid any string concatenation.
_SELECT_ALL_QUERIES: Dict[str, Any] = {
    "employees": text('SELECT * FROM "employees" ORDER BY id'),
    "performance_records": text('SELECT * FROM "performance_records" ORDER BY id'),
    "attendance_records": text('SELECT * FROM "attendance_records" ORDER BY id'),
    "violations": text('SELECT * FROM "violations" ORDER BY id'),
    "overtime_records": text('SELECT * FROM "overtime_records" ORDER BY id'),
    "performance_kpis": text('SELECT * FROM "performance_kpis" ORDER BY id'),
    "incentive_settings": text('SELECT * FROM "incentive_settings" ORDER BY id'),
    "incentive_records": text('SELECT * FROM "incentive_records" ORDER BY id'),
    "client_contracts": text('SELECT * FROM "client_contracts" ORDER BY id'),
    "contract_alerts": text('SELECT * FROM "contract_alerts" ORDER BY id'),
    "contracts": text('SELECT * FROM "contracts" ORDER BY id'),
    "notifications": text('SELECT * FROM "notifications" ORDER BY id'),
    "clickup_settings": text('SELECT * FROM "clickup_settings" ORDER BY id'),
    "clickup_kpi_snapshots": text('SELECT * FROM "clickup_kpi_snapshots" ORDER BY id'),
    "clickup_sync_logs": text('SELECT * FROM "clickup_sync_logs" ORDER BY id'),
    "users": text('SELECT * FROM "users" ORDER BY id'),
    "user_roles": text('SELECT * FROM "user_roles" ORDER BY id'),
    "pending_users": text('SELECT * FROM "pending_users" ORDER BY id'),
}

_SELECT_COUNT_QUERIES: Dict[str, Any] = {
    "employees": text('SELECT COUNT(*) FROM "employees"'),
    "performance_records": text('SELECT COUNT(*) FROM "performance_records"'),
    "attendance_records": text('SELECT COUNT(*) FROM "attendance_records"'),
    "violations": text('SELECT COUNT(*) FROM "violations"'),
    "overtime_records": text('SELECT COUNT(*) FROM "overtime_records"'),
    "performance_kpis": text('SELECT COUNT(*) FROM "performance_kpis"'),
    "incentive_settings": text('SELECT COUNT(*) FROM "incentive_settings"'),
    "incentive_records": text('SELECT COUNT(*) FROM "incentive_records"'),
    "client_contracts": text('SELECT COUNT(*) FROM "client_contracts"'),
    "contract_alerts": text('SELECT COUNT(*) FROM "contract_alerts"'),
    "contracts": text('SELECT COUNT(*) FROM "contracts"'),
    "notifications": text('SELECT COUNT(*) FROM "notifications"'),
    "clickup_settings": text('SELECT COUNT(*) FROM "clickup_settings"'),
    "clickup_kpi_snapshots": text('SELECT COUNT(*) FROM "clickup_kpi_snapshots"'),
    "clickup_sync_logs": text('SELECT COUNT(*) FROM "clickup_sync_logs"'),
    "users": text('SELECT COUNT(*) FROM "users"'),
    "user_roles": text('SELECT COUNT(*) FROM "user_roles"'),
    "pending_users": text('SELECT COUNT(*) FROM "pending_users"'),
}

_SELECT_ID_QUERIES: Dict[str, Any] = {
    "employees": text('SELECT id FROM "employees"'),
    "performance_records": text('SELECT id FROM "performance_records"'),
    "attendance_records": text('SELECT id FROM "attendance_records"'),
    "violations": text('SELECT id FROM "violations"'),
    "overtime_records": text('SELECT id FROM "overtime_records"'),
    "performance_kpis": text('SELECT id FROM "performance_kpis"'),
    "incentive_settings": text('SELECT id FROM "incentive_settings"'),
    "incentive_records": text('SELECT id FROM "incentive_records"'),
    "client_contracts": text('SELECT id FROM "client_contracts"'),
    "contract_alerts": text('SELECT id FROM "contract_alerts"'),
    "contracts": text('SELECT id FROM "contracts"'),
    "notifications": text('SELECT id FROM "notifications"'),
    "clickup_settings": text('SELECT id FROM "clickup_settings"'),
    "clickup_kpi_snapshots": text('SELECT id FROM "clickup_kpi_snapshots"'),
    "clickup_sync_logs": text('SELECT id FROM "clickup_sync_logs"'),
    "users": text('SELECT id FROM "users"'),
    "user_roles": text('SELECT id FROM "user_roles"'),
    "pending_users": text('SELECT id FROM "pending_users"'),
}

_DELETE_QUERIES: Dict[str, Any] = {
    "employees": text('DELETE FROM "employees"'),
    "performance_records": text('DELETE FROM "performance_records"'),
    "attendance_records": text('DELETE FROM "attendance_records"'),
    "violations": text('DELETE FROM "violations"'),
    "overtime_records": text('DELETE FROM "overtime_records"'),
    "performance_kpis": text('DELETE FROM "performance_kpis"'),
    "incentive_settings": text('DELETE FROM "incentive_settings"'),
    "incentive_records": text('DELETE FROM "incentive_records"'),
    "client_contracts": text('DELETE FROM "client_contracts"'),
    "contract_alerts": text('DELETE FROM "contract_alerts"'),
    "contracts": text('DELETE FROM "contracts"'),
    "notifications": text('DELETE FROM "notifications"'),
    "clickup_settings": text('DELETE FROM "clickup_settings"'),
    "clickup_kpi_snapshots": text('DELETE FROM "clickup_kpi_snapshots"'),
    "clickup_sync_logs": text('DELETE FROM "clickup_sync_logs"'),
    "users": text('DELETE FROM "users"'),
    "user_roles": text('DELETE FROM "user_roles"'),
    "pending_users": text('DELETE FROM "pending_users"'),
}


def _validate_identifier(name: str, kind: str = "identifier") -> str:
    """Validate that a name is a safe SQL identifier (letters, digits, underscores only)."""
    if not _IDENTIFIER_RE.match(name):
        raise ValueError("Invalid " + kind + ": " + repr(name))
    return name


def _validate_table_name(table_name: str) -> str:
    """Validate table name is in the allowed list and is a safe identifier."""
    if table_name not in ALLOWED_TABLES:
        raise ValueError("Table not allowed: " + repr(table_name))
    return _validate_identifier(table_name, "table name")


def _get_select_all_query(table_name: str):
    """Get static SELECT * query for a validated table."""
    _validate_table_name(table_name)
    return _SELECT_ALL_QUERIES[table_name]


def _get_select_count_query(table_name: str):
    """Get static SELECT COUNT(*) query for a validated table."""
    _validate_table_name(table_name)
    return _SELECT_COUNT_QUERIES[table_name]


def _get_select_id_query(table_name: str):
    """Get static SELECT id query for a validated table."""
    _validate_table_name(table_name)
    return _SELECT_ID_QUERIES[table_name]


def _get_delete_query(table_name: str):
    """Get static DELETE query for a validated table."""
    _validate_table_name(table_name)
    return _DELETE_QUERIES[table_name]


def serialize_value(val: Any) -> Any:
    """Serialize a value for JSON export."""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, bytes):
        return val.decode("utf-8", errors="replace")
    return val


async def _get_timestamp_columns(db: AsyncSession, table_name: str) -> Set[str]:
    """Get the set of timestamp columns for a given table."""
    result = await db.execute(text(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_name = :tbl AND table_schema = 'public' "
        "AND data_type IN ('timestamp with time zone', 'timestamp without time zone')"
    ), {"tbl": table_name})
    return {row[0] for row in result.fetchall()}


def _convert_row_timestamps(row: Dict[str, Any], timestamp_cols: Set[str]) -> Dict[str, Any]:
    """Convert string timestamp values to Python datetime objects for asyncpg compatibility."""
    converted = {}
    for k, v in row.items():
        if k in timestamp_cols and v is not None and isinstance(v, str):
            try:
                converted[k] = dateparser.parse(v)
            except (ValueError, TypeError):
                converted[k] = v
        else:
            converted[k] = v
    return converted


async def check_admin(current_user: UserResponse, db: AsyncSession) -> bool:
    """Check if the current user is an admin."""
    result = await db.execute(
        text("SELECT role FROM user_roles WHERE user_id = :uid"),
        {"uid": current_user.id},
    )
    row = result.fetchone()
    return row is not None and row[0] == "admin"


@router.get("/export")
async def export_all_data(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Export all system data as JSON (admin only)."""
    try:
        if not await check_admin(current_user, db):
            raise HTTPException(status_code=403, detail="Only admins can export data")

        export_data: Dict[str, Any] = {
            "exported_at": datetime.now().isoformat(),
            "exported_by": current_user.id,
            "tables": {},
        }

        for table_name in SYNC_TABLES:
            try:
                _validate_table_name(table_name)

                # Check if table exists using parameterized query
                check = await db.execute(_TABLE_EXISTS_QUERY, {"t": table_name})
                exists = check.scalar()
                if not exists:
                    continue

                # Use static pre-built query (no dynamic SQL)
                result = await db.execute(_get_select_all_query(table_name))
                rows = result.fetchall()
                keys = list(result.keys())

                table_data = []
                for row in rows:
                    row_dict = {}
                    for i, key in enumerate(keys):
                        row_dict[key] = serialize_value(row[i])
                    table_data.append(row_dict)

                export_data["tables"][table_name] = {
                    "count": len(table_data),
                    "columns": keys,
                    "rows": table_data,
                }
            except ValueError as ve:
                logger.warning("Skipping table %s: %s", table_name, ve)
                continue
            except Exception as e:
                logger.warning("Skipping table %s: %s", table_name, e)
                continue

        # Also export users and user_roles
        for table_name in ["users", "user_roles", "pending_users"]:
            try:
                _validate_table_name(table_name)
                result = await db.execute(_get_select_all_query(table_name))
                rows = result.fetchall()
                keys = list(result.keys())
                table_data = []
                for row in rows:
                    row_dict = {}
                    for i, key in enumerate(keys):
                        row_dict[key] = serialize_value(row[i])
                    table_data.append(row_dict)
                export_data["tables"][table_name] = {
                    "count": len(table_data),
                    "columns": keys,
                    "rows": table_data,
                }
            except Exception as e:
                logger.warning("Skipping table %s: %s", table_name, e)

        return export_data
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error exporting data: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/summary")
async def export_summary(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a summary of all data counts (admin only)."""
    try:
        if not await check_admin(current_user, db):
            raise HTTPException(status_code=403, detail="Only admins can view data summary")

        summary = {}
        all_tables = SYNC_TABLES + ["users", "user_roles", "pending_users"]
        for table_name in all_tables:
            try:
                _validate_table_name(table_name)
                result = await db.execute(_get_select_count_query(table_name))
                count = result.scalar()
                summary[table_name] = count or 0
            except Exception:
                summary[table_name] = -1  # table doesn't exist or error

        return {"summary": summary}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error getting summary: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


class ImportRequest(BaseModel):
    tables: Dict[str, Any]
    mode: str = "replace"  # "replace" = clear and insert, "merge" = upsert


@router.post("/import/preview")
async def preview_import(
    data: ImportRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Preview import differences without applying changes (admin only).
    Returns per-table counts of new, updated, and deleted records."""
    try:
        if not await check_admin(current_user, db):
            raise HTTPException(status_code=403, detail="Only admins can preview import")

        preview: Dict[str, Any] = {}
        all_tables = SYNC_TABLES + ["users", "user_roles"]

        for table_name in all_tables:
            table_info = data.tables.get(table_name)

            # Get current IDs from database
            current_ids: set = set()
            current_count = 0
            try:
                _validate_table_name(table_name)

                check = await db.execute(_TABLE_EXISTS_QUERY, {"t": table_name})
                exists = check.scalar()
                if exists:
                    result = await db.execute(_get_select_id_query(table_name))
                    current_ids = {row[0] for row in result.fetchall()}
                    current_count = len(current_ids)
            except Exception:
                current_count = 0

            if table_info is None:
                # Table not in import file
                if current_count > 0 and data.mode == "replace":
                    preview[table_name] = {
                        "current_count": current_count,
                        "import_count": 0,
                        "new_count": 0,
                        "updated_count": 0,
                        "deleted_count": current_count,
                        "unchanged_count": 0,
                        "status": "not_in_file",
                    }
                continue

            import_rows = table_info.get("rows", [])
            import_ids = set()
            for row in import_rows:
                rid = row.get("id")
                if rid is not None:
                    import_ids.add(rid)

            import_count = len(import_rows)
            new_ids = import_ids - current_ids
            existing_ids = import_ids & current_ids
            deleted_ids = current_ids - import_ids if data.mode == "replace" else set()

            preview[table_name] = {
                "current_count": current_count,
                "import_count": import_count,
                "new_count": len(new_ids),
                "updated_count": len(existing_ids),
                "deleted_count": len(deleted_ids),
                "unchanged_count": current_count - len(existing_ids) - len(deleted_ids)
                if data.mode == "merge"
                else 0,
                "status": "ready",
            }

        # Calculate totals
        total_new = sum(t.get("new_count", 0) for t in preview.values())
        total_updated = sum(t.get("updated_count", 0) for t in preview.values())
        total_deleted = sum(t.get("deleted_count", 0) for t in preview.values())

        return {
            "preview": preview,
            "totals": {
                "new": total_new,
                "updated": total_updated,
                "deleted": total_deleted,
                "tables_affected": len([t for t in preview.values() if t.get("status") == "ready"]),
            },
            "mode": data.mode,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error previewing import: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


def _build_insert_sql(table_name: str, columns: list, mode: str) -> str:
    """Build a safe INSERT SQL statement with validated identifiers.

    Security: table_name is validated against ALLOWED_TABLES whitelist.
    All column names are validated against _IDENTIFIER_RE regex.
    The SQL is assembled using join() on validated literals only.
    """
    safe_table = _validate_table_name(table_name)
    safe_columns = [_validate_identifier(c, "column name") for c in columns]

    # Build column list: "col1", "col2", ...
    quoted_cols = []
    for c in safe_columns:
        quoted_cols.append('"' + c + '"')
    col_str = ", ".join(quoted_cols)

    # Build parameter list: :col1, :col2, ...
    param_refs = []
    for c in safe_columns:
        param_refs.append(":" + c)
    val_str = ", ".join(param_refs)

    # Build the base INSERT clause
    insert_clause = 'INSERT INTO "' + safe_table + '" (' + col_str + ") VALUES (" + val_str + ")"

    if mode == "merge":
        # Build ON CONFLICT update clause
        update_parts = []
        for c in safe_columns:
            if c != "id":
                update_parts.append('"' + c + '" = EXCLUDED."' + c + '"')
        update_str = ", ".join(update_parts)
        return insert_clause + " ON CONFLICT (id) DO UPDATE SET " + update_str
    else:
        return insert_clause


@router.post("/import")
async def import_data(
    data: ImportRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Import data from JSON (admin only). Mode: 'replace' clears existing data first, 'merge' upserts."""
    try:
        if not await check_admin(current_user, db):
            raise HTTPException(status_code=403, detail="Only admins can import data")

        results = {}
        import_order = SYNC_TABLES + ["users", "user_roles"]

        # Cache timestamp columns per table to avoid repeated queries
        ts_cols_cache: Dict[str, Set[str]] = {}

        for table_name in import_order:
            if table_name not in data.tables:
                continue

            table_info = data.tables[table_name]
            rows = table_info.get("rows", [])
            if not rows:
                results[table_name] = {"status": "skipped", "reason": "no rows"}
                continue

            try:
                _validate_table_name(table_name)

                # Get timestamp columns for this table
                if table_name not in ts_cols_cache:
                    ts_cols_cache[table_name] = await _get_timestamp_columns(db, table_name)

                if data.mode == "replace":
                    # Clear existing data using static pre-built query
                    await db.execute(_get_delete_query(table_name))

                # Insert rows
                inserted = 0
                for row in rows:
                    # Convert timestamp strings to datetime objects
                    converted_row = _convert_row_timestamps(row, ts_cols_cache[table_name])
                    columns = [k for k in converted_row.keys() if converted_row[k] is not None]
                    if not columns:
                        continue

                    sql = _build_insert_sql(table_name, columns, data.mode)
                    await db.execute(text(sql), {k: converted_row[k] for k in columns})
                    inserted += 1

                await db.commit()
                results[table_name] = {"status": "success", "imported": inserted}
            except ValueError as ve:
                await db.rollback()
                logger.error("Validation error importing %s: %s", table_name, ve)
                results[table_name] = {"status": "error", "error": str(ve)}
            except Exception as e:
                await db.rollback()
                logger.error("Error importing %s: %s", table_name, e)
                results[table_name] = {"status": "error", "error": str(e)}

        return {"results": results}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error importing data: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/import/employees")
async def import_employees_only(
    data: ImportRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Import only employees data (admin only)."""
    try:
        if not await check_admin(current_user, db):
            raise HTTPException(status_code=403, detail="Only admins can import data")

        if "employees" not in data.tables:
            raise HTTPException(status_code=400, detail="No employees data provided")

        rows = data.tables["employees"].get("rows", [])
        if not rows:
            raise HTTPException(status_code=400, detail="No employee rows to import")

        # Get timestamp columns for employees table
        ts_cols = await _get_timestamp_columns(db, "employees")

        if data.mode == "replace":
            await db.execute(_get_delete_query("employees"))

        inserted = 0
        for row in rows:
            converted_row = _convert_row_timestamps(row, ts_cols)
            columns = [k for k in converted_row.keys() if converted_row[k] is not None]
            if not columns:
                continue

            sql = _build_insert_sql("employees", columns, data.mode)
            await db.execute(text(sql), {k: converted_row[k] for k in columns})
            inserted += 1

        await db.commit()
        return {"status": "success", "imported": inserted}
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Error importing employees: %s", e)
        raise HTTPException(status_code=500, detail=str(e))