"""ClickUp Integration API Routes - Settings, Dashboard, Sync History.

All persistent data is stored in the database (clickup_settings, clickup_sync_logs)
instead of the filesystem to support read-only deployment environments.
"""

import json
import logging
import os
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user
from models.clickup_settings import Clickup_settings
from models.clickup_sync_logs import Clickup_sync_logs
from schemas.auth import UserResponse
from services.clickup_service import (
    get_teams,
    get_team_members,
    get_workspace_summary,
    get_spaces as get_clickup_spaces,
    test_connection,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/clickup", tags=["clickup"])


# ============ DB-BASED HELPERS ============


async def _load_settings_from_db(db: AsyncSession) -> dict:
    """Load ClickUp settings from database.
    
    NOTE: We intentionally do NOT fall back to env var for the token.
    The env var is only used as a transient cache within a single process lifetime.
    The DB is the single source of truth for token persistence.
    """
    result = await db.execute(select(Clickup_settings).limit(1))
    row = result.scalar_one_or_none()

    defaults = {
        "api_token": "",
        "default_workspace_id": "",
        "default_workspace_name": "",
        "auto_sync_enabled": False,
        "sync_frequency": "monthly",
        "sync_day": 1,
        "sync_hour": 9,
    }

    if row:
        settings = {
            "id": row.id,
            "api_token": row.api_token or "",
            "default_workspace_id": row.workspace_id or "",
            "default_workspace_name": row.workspace_name or "",
            "auto_sync_enabled": row.auto_sync_enabled or False,
            "sync_frequency": row.auto_sync_frequency or "monthly",
            "sync_day": row.auto_sync_day or 1,
            "sync_hour": row.auto_sync_hour or 9,
        }
    else:
        settings = defaults

    # Sync env var from DB token (for services that still use _get_token())
    if settings.get("api_token"):
        os.environ["CLICKUP_API_TOKEN"] = settings["api_token"]
    
    logger.debug(f"Loaded ClickUp settings from DB: token={'present' if settings.get('api_token') else 'empty'}, workspace={settings.get('default_workspace_id', '')}")

    return settings


async def _save_settings_to_db(db: AsyncSession, settings: dict, user_id: str = ""):
    """Save ClickUp settings to database (upsert)."""
    result = await db.execute(select(Clickup_settings).limit(1))
    row = result.scalar_one_or_none()

    if row:
        row.api_token = settings.get("api_token", "")
        row.workspace_id = settings.get("default_workspace_id", "")
        row.workspace_name = settings.get("default_workspace_name", "")
        row.auto_sync_enabled = settings.get("auto_sync_enabled", False)
        row.auto_sync_frequency = settings.get("sync_frequency", "monthly")
        row.auto_sync_day = settings.get("sync_day", 1)
        row.auto_sync_hour = settings.get("sync_hour", 9)
        row.is_active = True
        if user_id and not row.user_id:
            row.user_id = user_id
    else:
        row = Clickup_settings(
            api_token=settings.get("api_token", ""),
            workspace_id=settings.get("default_workspace_id", ""),
            workspace_name=settings.get("default_workspace_name", ""),
            auto_sync_enabled=settings.get("auto_sync_enabled", False),
            auto_sync_frequency=settings.get("sync_frequency", "monthly"),
            auto_sync_day=settings.get("sync_day", 1),
            auto_sync_hour=settings.get("sync_hour", 9),
            is_active=True,
            user_id=user_id or None,
        )
        db.add(row)

    await db.commit()

    # Update env var
    if settings.get("api_token"):
        os.environ["CLICKUP_API_TOKEN"] = settings["api_token"]

    logger.info(f"ClickUp settings saved to DB (token={'present' if settings.get('api_token') else 'empty'}, workspace={settings.get('default_workspace_id', '')})")


async def _load_sync_history_from_db(db: AsyncSession) -> list:
    """Load sync history from database."""
    result = await db.execute(
        select(Clickup_sync_logs).order_by(Clickup_sync_logs.id.desc()).limit(50)
    )
    rows = result.scalars().all()
    return [
        {
            "id": r.id,
            "month": r.month or "",
            "sync_type": r.sync_type or "",
            "status": r.status or "",
            "synced_count": r.synced_count or 0,
            "skipped_count": r.skipped_count or 0,
            "failed_count": r.failed_count or 0,
            "workspace_name": r.workspace_name or "",
            "created_at": r.created_at.strftime("%Y-%m-%d %H:%M") if r.created_at else "",
        }
        for r in rows
    ]


async def _add_sync_record_to_db(
    db: AsyncSession,
    month: str,
    sync_type: str,
    status: str,
    synced_count: int,
    skipped_count: int,
    failed_count: int,
    workspace_name: str = "",
) -> dict:
    """Add a sync record to database."""
    record = Clickup_sync_logs(
        month=month,
        sync_type=sync_type,
        status=status,
        synced_count=synced_count,
        skipped_count=skipped_count,
        failed_count=failed_count,
        workspace_name=workspace_name,
        created_at=datetime.now(),
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return {
        "id": record.id,
        "month": month,
        "sync_type": sync_type,
        "status": status,
        "synced_count": synced_count,
        "skipped_count": skipped_count,
        "failed_count": failed_count,
        "workspace_name": workspace_name,
        "created_at": record.created_at.strftime("%Y-%m-%d %H:%M") if record.created_at else "",
    }


async def _load_member_mapping_from_db(db: AsyncSession) -> dict:
    """Load ClickUp member-to-employee mapping from database."""
    result = await db.execute(select(Clickup_settings).limit(1))
    row = result.scalar_one_or_none()
    if row and row.member_mapping:
        try:
            return json.loads(row.member_mapping)
        except (json.JSONDecodeError, TypeError):
            return {}
    return {}


async def _save_member_mapping_to_db(db: AsyncSession, mapping: dict):
    """Save ClickUp member-to-employee mapping to database."""
    result = await db.execute(select(Clickup_settings).limit(1))
    row = result.scalar_one_or_none()
    mapping_json = json.dumps(mapping, ensure_ascii=False)

    if row:
        row.member_mapping = mapping_json
    else:
        row = Clickup_settings(
            member_mapping=mapping_json,
            is_active=True,
        )
        db.add(row)

    await db.commit()


# ============ PUBLIC HELPER FUNCTIONS (used by rewards router) ============


async def _load_settings(db: AsyncSession) -> dict:
    """Public helper: load settings from DB. Used by rewards router."""
    return await _load_settings_from_db(db)


async def _load_member_mapping(db: AsyncSession) -> dict:
    """Public helper: load member mapping from DB. Used by rewards router."""
    return await _load_member_mapping_from_db(db)


async def _add_sync_record(
    db: AsyncSession,
    month: str,
    sync_type: str,
    status: str,
    synced_count: int,
    skipped_count: int,
    failed_count: int,
    workspace_name: str = "",
) -> dict:
    """Public helper: add sync record to DB. Used by rewards router."""
    return await _add_sync_record_to_db(
        db, month, sync_type, status, synced_count, skipped_count, failed_count, workspace_name
    )


# ============ SETTINGS ENDPOINTS ============


class ClickUpSettingsModel(BaseModel):
    api_token: str = ""
    default_workspace_id: str = ""
    default_workspace_name: str = ""
    auto_sync_enabled: bool = False
    sync_frequency: str = "monthly"
    sync_day: int = 1
    sync_hour: int = 9


class TestConnectionRequest(BaseModel):
    api_token: str


class WorkspaceSummaryRequest(BaseModel):
    team_id: str
    date_from: Optional[str] = None
    date_to: Optional[str] = None


class TriggerSyncRequest(BaseModel):
    workspace_id: str
    month: str


class RecordSyncRequest(BaseModel):
    """Request body for recording a sync operation."""
    month: str = ""
    sync_type: str = "manual"
    status: str = "success"
    synced_count: int = 0
    skipped_count: int = 0
    failed_count: int = 0


@router.get("/settings")
async def get_settings(
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get ClickUp integration settings."""
    logger.debug(f"Loading ClickUp settings for user {current_user.id}")
    settings = await _load_settings_from_db(db)
    # Remove internal id field
    settings.pop("id", None)
    return settings


@router.post("/settings")
async def save_settings(
    data: ClickUpSettingsModel,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Save ClickUp integration settings."""
    try:
        settings = data.model_dump()
        logger.info(f"Saving ClickUp settings: token={'present' if settings.get('api_token') else 'empty'}, workspace_id={settings.get('default_workspace_id', '')}")
        await _save_settings_to_db(db, settings, user_id=str(current_user.id))
        return {"status": "ok", "message": "Settings saved successfully"}
    except Exception as e:
        logger.error(f"Failed to save ClickUp settings: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/test_connection")
async def test_clickup_connection(
    data: TestConnectionRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Test ClickUp API connection with a given token.
    
    On successful connection, the token is automatically saved to the database
    to ensure persistence across backend restarts.
    """
    logger.info(f"Testing ClickUp connection (token length: {len(data.api_token)})")
    try:
        result = await test_connection(data.api_token)
        
        # On successful connection, persist the token to DB immediately
        if result.get("success"):
            logger.info("ClickUp connection successful - persisting token to DB")
            try:
                # Load existing settings and update token
                existing = await _load_settings_from_db(db)
                existing["api_token"] = data.api_token.strip()
                # If workspaces returned, auto-set first workspace if none selected
                workspaces = result.get("workspaces", [])
                if workspaces and not existing.get("default_workspace_id"):
                    existing["default_workspace_id"] = workspaces[0]["id"]
                    existing["default_workspace_name"] = workspaces[0]["name"]
                await _save_settings_to_db(db, existing, user_id=str(current_user.id))
                logger.info("Token persisted to DB successfully")
            except Exception as save_err:
                logger.error(f"Failed to persist token to DB after successful test: {save_err}", exc_info=True)
                # Don't fail the test_connection response - token is still in env var
        else:
            logger.warning(f"ClickUp connection test failed: {result.get('error', 'unknown')}")
        
        return result
    except Exception as e:
        logger.error(f"ClickUp connection test error: {e}", exc_info=True)
        return {"success": False, "error": f"خطأ في اختبار الاتصال: {str(e)}"}


# ============ WORKSPACE ENDPOINTS ============


@router.get("/workspaces")
async def list_workspaces(
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """List all ClickUp workspaces accessible by the configured token."""
    try:
        settings = await _load_settings_from_db(db)
        token = settings.get("api_token", "")
        if not token or not token.strip():
            logger.warning("ClickUp workspaces requested but no token configured in DB")
            # Return empty workspaces with a flag instead of error
            # This allows the frontend to handle "not configured" gracefully
            raise HTTPException(
                status_code=400,
                detail="TOKEN_NOT_CONFIGURED"
            )
        logger.info(f"Fetching ClickUp workspaces with token (length: {len(token)}, prefix: {token[:5]}...)")
        teams = await get_teams(token=token)
        logger.info(f"Successfully fetched {len(teams)} ClickUp workspace(s)")
        return {
            "workspaces": [
                {"id": str(t["id"]), "name": t.get("name", "")}
                for t in teams
            ]
        }
    except ValueError as e:
        error_msg = str(e)
        logger.error(f"ClickUp workspaces ValueError: {error_msg}")
        # Differentiate between token-not-set and token-invalid errors
        if "لم يتم إدخال" in error_msg:
            raise HTTPException(status_code=400, detail="TOKEN_NOT_CONFIGURED")
        raise HTTPException(status_code=401, detail=error_msg)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"ClickUp workspaces error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"فشل في جلب بيانات ClickUp: {str(e)}"
        )


@router.get("/spaces")
async def list_spaces(
    team_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """List all spaces in a ClickUp workspace."""
    try:
        settings = await _load_settings_from_db(db)
        if not settings.get("api_token") or not settings["api_token"].strip():
            raise HTTPException(
                status_code=400,
                detail="يرجى إدخال توكن ClickUp أولاً في صفحة الإعدادات. التوكن غير محفوظ حالياً."
            )
        token = settings["api_token"].strip()
        spaces = await get_clickup_spaces(team_id, token=token)
        return {
            "spaces": [
                {"id": str(s["id"]), "name": s.get("name", "")}
                for s in spaces
            ]
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"ClickUp spaces error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch ClickUp spaces: {str(e)}"
        )


@router.get("/members")
async def list_members(
    team_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """List all members of a ClickUp workspace."""
    try:
        settings = await _load_settings_from_db(db)
        if not settings.get("api_token") or not settings["api_token"].strip():
            raise HTTPException(
                status_code=400,
                detail="يرجى إدخال توكن ClickUp أولاً في صفحة الإعدادات. التوكن غير محفوظ حالياً."
            )
        token = settings["api_token"].strip()
        members = await get_team_members(team_id, token=token)
        return {"members": members}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"ClickUp members error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch ClickUp members: {str(e)}"
        )


@router.post("/summary")
async def workspace_summary(
    data: WorkspaceSummaryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get task completion summary for all members in a workspace."""
    try:
        settings = await _load_settings_from_db(db)
        if not settings.get("api_token") or not settings["api_token"].strip():
            raise HTTPException(
                status_code=400,
                detail="يرجى إدخال توكن ClickUp أولاً في صفحة الإعدادات. التوكن غير محفوظ حالياً."
            )
        token = settings["api_token"].strip()
        logger.info(f"Fetching ClickUp summary for team {data.team_id} ({data.date_from} to {data.date_to})")
        summary = await get_workspace_summary(
            team_id=data.team_id,
            date_from=data.date_from,
            date_to=data.date_to,
            token=token,
        )
        logger.info(f"ClickUp summary: {len(summary.get('members', []))} members, {summary.get('total_tasks', 0)} tasks")
        return summary
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"ClickUp summary error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"فشل في جلب بيانات ClickUp: {str(e)}"
        )


# ============ SYNC HISTORY ENDPOINTS ============


@router.get("/sync_history")
async def get_sync_history(
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get ClickUp sync history."""
    history = await _load_sync_history_from_db(db)
    return {"items": history}


@router.post("/record_sync")
async def record_sync(
    data: RecordSyncRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Record a sync operation in history."""
    logger.info(f"Recording sync: month={data.month}, type={data.sync_type}, status={data.status}, synced={data.synced_count}")
    settings = await _load_settings_from_db(db)
    record = await _add_sync_record_to_db(
        db,
        month=data.month,
        sync_type=data.sync_type,
        status=data.status,
        synced_count=data.synced_count,
        skipped_count=data.skipped_count,
        failed_count=data.failed_count,
        workspace_name=settings.get("default_workspace_name", ""),
    )
    return {"status": "ok", "record": record}


@router.post("/trigger_sync")
async def trigger_sync(
    data: TriggerSyncRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Trigger a manual sync operation."""
    try:
        settings = await _load_settings_from_db(db)
        return {
            "success": True,
            "message": f"Sync triggered for workspace {data.workspace_id}, month {data.month}",
            "workspace_name": settings.get("default_workspace_name", ""),
        }
    except Exception as e:
        logger.error(f"Failed to trigger sync: {e}")
        return {"success": False, "message": str(e)}


# ============ MEMBER MAPPING ENDPOINTS ============


class MemberMappingModel(BaseModel):
    mapping: dict[str, str]  # { clickup_member_id: employee_id }


@router.get("/member_mapping")
async def get_member_mapping(
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Get saved ClickUp member-to-employee mapping."""
    mapping = await _load_member_mapping_from_db(db)
    return {"mapping": mapping}


@router.post("/member_mapping")
async def save_member_mapping(
    data: MemberMappingModel,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Save ClickUp member-to-employee mapping (merges with existing)."""
    try:
        existing = await _load_member_mapping_from_db(db)
        # Merge: new values override existing
        existing.update(data.mapping)
        # Remove entries with empty values
        existing = {k: v for k, v in existing.items() if v}
        await _save_member_mapping_to_db(db, existing)
        logger.info(f"Member mapping saved: {len(existing)} entries")
        return {"status": "ok", "message": "Mapping saved successfully", "count": len(existing)}
    except Exception as e:
        logger.error(f"Failed to save member mapping: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/member_mapping/{clickup_id}")
async def delete_member_mapping(
    clickup_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user),
):
    """Remove a specific member mapping."""
    try:
        existing = await _load_member_mapping_from_db(db)
        if clickup_id in existing:
            del existing[clickup_id]
            await _save_member_mapping_to_db(db, existing)
        return {"status": "ok"}
    except Exception as e:
        logger.error(f"Failed to delete member mapping: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))