"""Notification API routes"""
import logging
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse
from services.notification_service import (
    get_notifications, get_unread_count, create_notification,
    mark_as_read, mark_all_as_read, delete_notification,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


class NotificationCreate(BaseModel):
    employee_id: int
    type: str
    title: str
    message: str
    related_id: Optional[int] = None
    target_user_id: Optional[str] = None  # For admin creating notifications for employees


class NotificationResponse(BaseModel):
    id: int
    user_id: str
    employee_id: int
    type: str
    title: str
    message: str
    is_read: bool
    related_id: Optional[int] = None
    created_at: Optional[str] = None


class UnreadCountResponse(BaseModel):
    count: int


@router.get("/list")
async def list_notifications(
    unread_only: bool = False,
    limit: int = 50,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get notifications for the current user"""
    try:
        notifications = await get_notifications(db, current_user.id, unread_only, limit)
        return {"items": notifications}
    except Exception as e:
        logger.error(f"Error fetching notifications: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/unread_count")
async def unread_notification_count(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get unread notification count"""
    try:
        count = await get_unread_count(db, current_user.id)
        return {"count": count}
    except Exception as e:
        logger.error(f"Error getting unread count: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/create")
async def create_new_notification(
    data: NotificationCreate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a notification (admin use - for notifying employees)"""
    try:
        target_uid = data.target_user_id or current_user.id
        await create_notification(
            db, target_uid, data.employee_id,
            data.type, data.title, data.message, data.related_id
        )
        return {"status": "ok", "message": "Notification created"}
    except Exception as e:
        logger.error(f"Error creating notification: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/read/{notification_id}")
async def read_notification(
    notification_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Mark a notification as read"""
    try:
        await mark_as_read(db, current_user.id, notification_id)
        return {"status": "ok"}
    except Exception as e:
        logger.error(f"Error marking notification as read: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/read_all")
async def read_all_notifications(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Mark all notifications as read"""
    try:
        await mark_all_as_read(db, current_user.id)
        return {"status": "ok"}
    except Exception as e:
        logger.error(f"Error marking all as read: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{notification_id}")
async def remove_notification(
    notification_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a notification"""
    try:
        await delete_notification(db, current_user.id, notification_id)
        return {"status": "ok"}
    except Exception as e:
        logger.error(f"Error deleting notification: {e}")
        raise HTTPException(status_code=500, detail=str(e))