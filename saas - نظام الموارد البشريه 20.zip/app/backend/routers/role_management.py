import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, delete as sa_delete, text

from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse
from models.user_roles import User_roles
from models.pending_users import Pending_users

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/roles", tags=["roles"])


class RoleCheckResponse(BaseModel):
    has_role: bool
    role: Optional[str] = None
    employee_id: Optional[int] = None
    is_first_user: bool = False


class AssignRoleRequest(BaseModel):
    target_user_id: str
    role: str  # "admin" or "employee"
    employee_id: Optional[int] = None


class UserRoleResponse(BaseModel):
    id: int
    user_id: str
    role: str
    employee_id: Optional[int] = None
    email: Optional[str] = None
    name: Optional[str] = None


class AllUserRolesResponse(BaseModel):
    items: List[UserRoleResponse]


class PendingUserResponse(BaseModel):
    id: int
    user_id: str
    email: Optional[str] = None
    name: Optional[str] = None
    created_at: Optional[str] = None


class PendingUsersListResponse(BaseModel):
    items: List[PendingUserResponse]


@router.get("/check", response_model=RoleCheckResponse)
async def check_my_role(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Check the current user's role. If no users exist, auto-assign as admin."""
    try:
        # Check if user already has a role
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == current_user.id)
        )
        user_role = result.scalars().first()

        if user_role:
            # Remove from pending if exists
            await db.execute(
                sa_delete(Pending_users).where(Pending_users.user_id == current_user.id)
            )
            await db.commit()
            return RoleCheckResponse(
                has_role=True,
                role=user_role.role,
                employee_id=user_role.employee_id,
                is_first_user=False,
            )

        # Check if there are any users at all
        count_result = await db.execute(select(func.count(User_roles.id)))
        total_users = count_result.scalar() or 0

        if total_users == 0:
            # First user - auto-assign as admin
            new_role = User_roles(
                user_id=current_user.id,
                role="admin",
                employee_id=None,
                created_at=datetime.now(),
            )
            db.add(new_role)
            await db.commit()
            await db.refresh(new_role)
            return RoleCheckResponse(
                has_role=True,
                role="admin",
                employee_id=None,
                is_first_user=True,
            )

        # User exists but has no role assigned - save as pending
        existing_pending = await db.execute(
            select(Pending_users).where(Pending_users.user_id == current_user.id)
        )
        if not existing_pending.scalars().first():
            pending = Pending_users(
                user_id=current_user.id,
                email=getattr(current_user, 'email', None) or '',
                name=getattr(current_user, 'name', None) or getattr(current_user, 'username', None) or '',
                created_at=datetime.now(),
            )
            db.add(pending)
            await db.commit()

        return RoleCheckResponse(
            has_role=False,
            role=None,
            employee_id=None,
            is_first_user=False,
        )
    except Exception as e:
        logger.error(f"Error checking role: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/pending", response_model=PendingUsersListResponse)
async def get_pending_users(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get all pending users who logged in but have no role (admin only)."""
    try:
        # Check if current user is admin
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == current_user.id)
        )
        admin_role = result.scalars().first()
        if not admin_role or admin_role.role != "admin":
            raise HTTPException(status_code=403, detail="Only admins can view pending users")

        result = await db.execute(select(Pending_users))
        pending = result.scalars().all()
        items = [
            PendingUserResponse(
                id=p.id,
                user_id=p.user_id,
                email=p.email or '',
                name=p.name or '',
                created_at=str(p.created_at) if p.created_at else '',
            )
            for p in pending
        ]
        return PendingUsersListResponse(items=items)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching pending users: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/assign", response_model=UserRoleResponse)
async def assign_role(
    data: AssignRoleRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Assign a role to a user (admin only)."""
    try:
        # Check if current user is admin
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == current_user.id)
        )
        admin_role = result.scalars().first()
        if not admin_role or admin_role.role != "admin":
            raise HTTPException(status_code=403, detail="Only admins can assign roles")

        if data.role not in ("admin", "employee"):
            raise HTTPException(status_code=400, detail="Role must be 'admin' or 'employee'")

        # Check if target user already has a role
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == data.target_user_id)
        )
        existing = result.scalars().first()

        if existing:
            existing.role = data.role
            existing.employee_id = data.employee_id
            await db.commit()
            await db.refresh(existing)
            role_resp = UserRoleResponse(
                id=existing.id,
                user_id=existing.user_id,
                role=existing.role,
                employee_id=existing.employee_id,
            )
        else:
            new_role = User_roles(
                user_id=data.target_user_id,
                role=data.role,
                employee_id=data.employee_id,
                created_at=datetime.now(),
            )
            db.add(new_role)
            await db.commit()
            await db.refresh(new_role)
            role_resp = UserRoleResponse(
                id=new_role.id,
                user_id=new_role.user_id,
                role=new_role.role,
                employee_id=new_role.employee_id,
            )

        # Remove from pending users
        await db.execute(
            sa_delete(Pending_users).where(Pending_users.user_id == data.target_user_id)
        )
        await db.commit()

        return role_resp
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error assigning role: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/all", response_model=AllUserRolesResponse)
async def get_all_roles(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get all user roles with user info (admin only)."""
    try:
        # Check if current user is admin
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == current_user.id)
        )
        admin_role = result.scalars().first()
        if not admin_role or admin_role.role != "admin":
            raise HTTPException(status_code=403, detail="Only admins can view all roles")

        # Join user_roles with users table to get name and email
        result = await db.execute(
            text("""
                SELECT ur.id, ur.user_id, ur.role, ur.employee_id, u.email, u.name
                FROM user_roles ur
                LEFT JOIN users u ON CAST(ur.user_id AS TEXT) = CAST(u.id AS TEXT)
                ORDER BY ur.id
            """)
        )
        rows = result.fetchall()
        items = [
            UserRoleResponse(
                id=row[0],
                user_id=row[1],
                role=row[2],
                employee_id=row[3],
                email=row[4] or '',
                name=row[5] or '',
            )
            for row in rows
        ]
        return AllUserRolesResponse(items=items)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching roles: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{role_id}")
async def delete_role(
    role_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a user role (admin only)."""
    try:
        # Check if current user is admin
        result = await db.execute(
            select(User_roles).where(User_roles.user_id == current_user.id)
        )
        admin_role = result.scalars().first()
        if not admin_role or admin_role.role != "admin":
            raise HTTPException(status_code=403, detail="Only admins can delete roles")

        result = await db.execute(
            select(User_roles).where(User_roles.id == role_id)
        )
        role_to_delete = result.scalars().first()
        if not role_to_delete:
            raise HTTPException(status_code=404, detail="Role not found")

        # Prevent deleting own admin role
        if role_to_delete.user_id == current_user.id:
            raise HTTPException(status_code=400, detail="Cannot delete your own role")

        await db.delete(role_to_delete)
        await db.commit()
        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting role: {e}")
        raise HTTPException(status_code=500, detail=str(e))