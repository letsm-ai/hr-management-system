import json
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.monthly_performance_results import Monthly_performance_resultsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/monthly_performance_results", tags=["monthly_performance_results"])


# ---------- Pydantic Schemas ----------
class MonthlyPerformanceData(BaseModel):
    employee_id: int
    month: str
    attendance_score: Optional[float] = None
    attendance_details: Optional[str] = None
    productivity_score: Optional[float] = None
    tasks_assigned: Optional[int] = None
    tasks_completed: Optional[int] = None
    tasks_on_time: Optional[int] = None
    points_target: Optional[int] = None
    points_achieved: Optional[int] = None
    productivity_details: Optional[str] = None
    quality_score: Optional[float] = None
    quality_output: Optional[int] = None
    quality_initiative: Optional[int] = None
    quality_teamwork: Optional[int] = None
    quality_client_satisfaction: Optional[int] = None
    quality_notes: Optional[str] = None
    evaluated_by: Optional[int] = None
    final_score: Optional[float] = None
    grade: Optional[str] = None
    reward_percent: Optional[float] = None
    reward_amount: Optional[float] = None
    status: str = "draft"
    approved_by: Optional[int] = None
    approved_at: Optional[str] = None


class MonthlyPerformanceUpdateData(BaseModel):
    employee_id: Optional[int] = None
    month: Optional[str] = None
    attendance_score: Optional[float] = None
    attendance_details: Optional[str] = None
    productivity_score: Optional[float] = None
    tasks_assigned: Optional[int] = None
    tasks_completed: Optional[int] = None
    tasks_on_time: Optional[int] = None
    points_target: Optional[int] = None
    points_achieved: Optional[int] = None
    productivity_details: Optional[str] = None
    quality_score: Optional[float] = None
    quality_output: Optional[int] = None
    quality_initiative: Optional[int] = None
    quality_teamwork: Optional[int] = None
    quality_client_satisfaction: Optional[int] = None
    quality_notes: Optional[str] = None
    evaluated_by: Optional[int] = None
    final_score: Optional[float] = None
    grade: Optional[str] = None
    reward_percent: Optional[float] = None
    reward_amount: Optional[float] = None
    status: Optional[str] = None
    approved_by: Optional[int] = None
    approved_at: Optional[str] = None


class MonthlyPerformanceResponse(BaseModel):
    id: int
    employee_id: int
    month: str
    attendance_score: Optional[float] = None
    attendance_details: Optional[str] = None
    productivity_score: Optional[float] = None
    tasks_assigned: Optional[int] = None
    tasks_completed: Optional[int] = None
    tasks_on_time: Optional[int] = None
    points_target: Optional[int] = None
    points_achieved: Optional[int] = None
    productivity_details: Optional[str] = None
    quality_score: Optional[float] = None
    quality_output: Optional[int] = None
    quality_initiative: Optional[int] = None
    quality_teamwork: Optional[int] = None
    quality_client_satisfaction: Optional[int] = None
    quality_notes: Optional[str] = None
    evaluated_by: Optional[int] = None
    final_score: Optional[float] = None
    grade: Optional[str] = None
    reward_percent: Optional[float] = None
    reward_amount: Optional[float] = None
    status: str = "draft"
    approved_by: Optional[int] = None
    approved_at: Optional[str] = None
    created_at: Optional[str] = None

    class Config:
        from_attributes = True


class MonthlyPerformanceListResponse(BaseModel):
    items: List[MonthlyPerformanceResponse]
    total: int
    skip: int
    limit: int


# ---------- Routes ----------
@router.get("", response_model=MonthlyPerformanceListResponse)
async def query_monthly_performance(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field"),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=2000),
    db: AsyncSession = Depends(get_db),
):
    """Query monthly performance results"""
    service = Monthly_performance_resultsService(db)
    try:
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        result = await service.get_list(skip=skip, limit=limit, query_dict=query_dict, sort=sort)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying monthly_performance_results: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=MonthlyPerformanceListResponse)
async def query_monthly_performance_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=2000),
    db: AsyncSession = Depends(get_db),
):
    """Query all monthly performance results without user limitation"""
    service = Monthly_performance_resultsService(db)
    try:
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        result = await service.get_list(skip=skip, limit=limit, query_dict=query_dict, sort=sort)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying monthly_performance_results: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=MonthlyPerformanceResponse)
async def get_monthly_performance(id: int, db: AsyncSession = Depends(get_db)):
    """Get a single monthly performance result by ID"""
    service = Monthly_performance_resultsService(db)
    result = await service.get_by_id(id)
    if not result:
        raise HTTPException(status_code=404, detail="Monthly performance result not found")
    return result


@router.post("", response_model=MonthlyPerformanceResponse, status_code=201)
async def create_monthly_performance(data: MonthlyPerformanceData, db: AsyncSession = Depends(get_db)):
    """Create a new monthly performance result"""
    service = Monthly_performance_resultsService(db)
    try:
        result = await service.create(data.model_dump())
        return result
    except Exception as e:
        logger.error(f"Error creating monthly_performance_results: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.put("/{id}", response_model=MonthlyPerformanceResponse)
async def update_monthly_performance(
    id: int,
    data: MonthlyPerformanceUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing monthly performance result"""
    service = Monthly_performance_resultsService(db)
    update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
    result = await service.update(id, update_dict)
    if not result:
        raise HTTPException(status_code=404, detail="Monthly performance result not found")
    return result


@router.delete("/{id}")
async def delete_monthly_performance(id: int, db: AsyncSession = Depends(get_db)):
    """Delete a single monthly performance result by ID"""
    service = Monthly_performance_resultsService(db)
    success = await service.delete(id)
    if not success:
        raise HTTPException(status_code=404, detail="Monthly performance result not found")
    return {"message": "Monthly performance result deleted successfully", "id": id}