from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

router = APIRouter(prefix="/api/v1/fix", tags=["fix"])

@router.post("/contracts_user_id")
async def fix_contracts_user_id(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Fix null user_id in contracts table by setting them to current user's id"""
    await db.execute(
        text("UPDATE contracts SET user_id = :uid WHERE user_id IS NULL OR user_id = ''"),
        {"uid": current_user.id}
    )
    await db.commit()
    return {"status": "ok", "message": "Fixed null user_id values in contracts table"}