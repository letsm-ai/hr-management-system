# Contract & Incentive System - Development Plan

## Files to Create/Modify
1. `src/lib/incentive-api.ts` - API layer for client_contracts, incentive_records, incentive_settings, revenue calculations
2. `src/pages/ClientContracts.tsx` - Contract management (4 tabs: all, add, expiring, stats)
3. `src/pages/IncentiveCalculation.tsx` - Incentive calculation (3 tabs: calculate, history, settings)
4. `src/pages/RevenueDashboard.tsx` - Revenue dashboard with charts and stats
5. `src/pages/IncentiveReport.tsx` - Monthly incentive report with expandable details
6. Update `src/components/RoleRouter.tsx` - Add 4 new routes
7. Update `src/pages/Index.tsx` - Add 4 nav items to sidebar

## Key Business Logic (all amounts in baisa, display in OMR)
- New contract commission: 5% (≤500 OMR), 4% (501-2000), 3% (>2000) of annual value
- Renewal bonus: 3% (yr1), 4% (yr2), 5% (yr3+) of annual value
- Upsell bonus: (new - old) × 12 × 7%
- Monthly pool: 500 OMR (≤15k), 1000 OMR (15k-25k), 1500 OMR (>25k)
- Performance multiplier: 0.70 to 1.30 based on weighted score
- Max cap: 8% of monthly revenue