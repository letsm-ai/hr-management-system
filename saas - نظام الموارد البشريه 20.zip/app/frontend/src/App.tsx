import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/lib/auth-context';
import { HRDataProvider } from '@/lib/hr-data-context';
import { RoleProvider } from '@/lib/role-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import RoleRouter from '@/components/RoleRouter';
import AuthCallback from './pages/AuthCallback';

const queryClient = new QueryClient();

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthProvider>
          <RoleProvider>
            <HRDataProvider>
              <BrowserRouter>
                <Routes>
                  <Route path="/auth/callback" element={<AuthCallback />} />
                  <Route path="/*" element={<RoleRouter />} />
                </Routes>
              </BrowserRouter>
            </HRDataProvider>
          </RoleProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;