import { Routes, Route } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import { useRole } from '@/lib/role-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { LogIn, Loader2 } from 'lucide-react';

// Admin pages
import Index from '@/pages/Index';
import Employees from '@/pages/Employees';
import Attendance from '@/pages/Attendance';
import LeaveBalance from '@/pages/LeaveBalance';
import Performance from '@/pages/Performance';
import Overtime from '@/pages/Overtime';
import Rewards from '@/pages/Rewards';
import UserManagement from '@/pages/UserManagement';
import Contracts from '@/pages/Contracts';

import ClickUpIntegration from '@/pages/ClickUpIntegration';
import RequestsManagement from '@/pages/RequestsManagement';
import ClientContracts from '@/pages/ClientContracts';
import IncentiveCalculation from '@/pages/IncentiveCalculation';
import RevenueDashboard from '@/pages/RevenueDashboard';
import IncentiveReport from '@/pages/IncentiveReport';
import DataSync from '@/pages/DataSync';
import RewardSettings from '@/pages/RewardSettings';
import MonthlyRewards from '@/pages/MonthlyRewards';
import MonthlyEvaluation from '@/pages/MonthlyEvaluation';
import NotFound from '@/pages/NotFound';

// Merged pages
import AttendanceManagement from '@/pages/AttendanceManagement';
import ContractsManagement from '@/pages/ContractsManagement';
import EvaluationSync from '@/pages/EvaluationSync';
import FinancialOutputs from '@/pages/FinancialOutputs';

// Employee pages
import EmployeeDashboard from '@/pages/EmployeeDashboard';

// Pending page
import PendingApproval from '@/pages/PendingApproval';

export default function RoleRouter() {
  const { user, loading: authLoading, login } = useAuth();
  const { role, loading: roleLoading, isAdmin, isEmployee } = useRole();

  // Loading state
  if (authLoading || (user && roleLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin mx-auto text-blue-600 mb-4" />
          <p className="text-gray-500">جاري تحميل النظام...</p>
        </div>
      </div>
    );
  }

  // Not logged in
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
        <Card className="w-full max-w-md shadow-xl">
          <CardContent className="p-8 text-center space-y-6">
            <div className="bg-blue-600 text-white rounded-full h-20 w-20 flex items-center justify-center mx-auto text-2xl font-bold">
              HR
            </div>
            <h1 className="text-2xl font-bold">نظام إدارة الموارد البشرية</h1>
            <p className="text-gray-500">سجّل دخولك للوصول إلى النظام</p>
            <Button onClick={login} size="lg" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              <LogIn className="h-5 w-5 ml-2" />
              تسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Logged in but no role assigned
  if (!role) {
    return <PendingApproval />;
  }

  // Employee view
  if (isEmployee) {
    return (
      <Routes>
        <Route path="/" element={<EmployeeDashboard />} />
        <Route path="*" element={<EmployeeDashboard />} />
      </Routes>
    );
  }

  // Admin view - full access
  if (isAdmin) {
    return (
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/employees" element={<Employees />} />

        {/* Merged pages */}
        <Route path="/attendance-management" element={<AttendanceManagement />} />
        <Route path="/contracts-management" element={<ContractsManagement />} />
        <Route path="/evaluation-sync" element={<EvaluationSync />} />
        <Route path="/financial-outputs" element={<FinancialOutputs />} />

        {/* Standalone pages */}
        <Route path="/clickup" element={<ClickUpIntegration />} />
        <Route path="/requests" element={<RequestsManagement />} />
        <Route path="/revenue-dashboard" element={<RevenueDashboard />} />
        <Route path="/user-management" element={<UserManagement />} />
        <Route path="/data-sync" element={<DataSync />} />

        {/* Legacy routes - redirect to new pages */}
        <Route path="/attendance" element={<AttendanceManagement />} />
        <Route path="/leave-balance" element={<AttendanceManagement />} />
        <Route path="/overtime" element={<AttendanceManagement />} />
        <Route path="/contracts" element={<ContractsManagement />} />
        <Route path="/client-contracts" element={<ContractsManagement />} />
        <Route path="/performance" element={<EvaluationSync />} />
        <Route path="/performance-management" element={<EvaluationSync />} />
        <Route path="/monthly-evaluation" element={<EvaluationSync />} />
        <Route path="/rewards" element={<FinancialOutputs />} />
        <Route path="/rewards-management" element={<FinancialOutputs />} />
        <Route path="/reward-settings" element={<EvaluationSync />} />
        <Route path="/incentive-calculation" element={<FinancialOutputs />} />
        <Route path="/incentive-report" element={<FinancialOutputs />} />
        <Route path="/monthly-rewards" element={<FinancialOutputs />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    );
  }

  return <NotFound />;
}