import { useEffect, useState, useRef } from 'react';
import { Bell, BellRing, Check, CheckCheck, X, AlertTriangle, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  ContractAlert,
  fetchContractAlerts,
  markAlertAsRead,
  dismissAlert,
  markAllAlertsAsRead,
  ALERT_TYPE_LABELS,
  ALERT_TYPE_COLORS,
} from '@/lib/incentive-api';

function getAlertIcon(alertType: string) {
  switch (alertType) {
    case '7_days':
      return <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />;
    case '15_days':
      return <Clock className="w-4 h-4 text-amber-500 shrink-0" />;
    case '30_days':
      return <Calendar className="w-4 h-4 text-blue-500 shrink-0" />;
    case 'expired':
      return <X className="w-4 h-4 text-gray-500 shrink-0" />;
    default:
      return <Bell className="w-4 h-4 text-gray-400 shrink-0" />;
  }
}

function timeAgo(dateStr: string): string {
  if (!dateStr) return '';
  const now = new Date();
  const date = new Date(dateStr.replace(' ', 'T'));
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return 'الآن';
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `منذ ${diffDays} يوم`;
  return dateStr.split(' ')[0];
}

export default function ContractAlertsBell() {
  const [alerts, setAlerts] = useState<ContractAlert[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const visibleAlerts = alerts.filter((a) => !a.isDismissed);
  const unreadCount = visibleAlerts.filter((a) => !a.isRead).length;

  useEffect(() => {
    loadAlerts();
    const interval = setInterval(loadAlerts, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  async function loadAlerts() {
    const data = await fetchContractAlerts();
    setAlerts(data);
  }

  async function handleMarkRead(id: string) {
    await markAlertAsRead(id);
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, isRead: true } : a)));
  }

  async function handleDismiss(id: string) {
    await dismissAlert(id);
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, isDismissed: true, isRead: true } : a)));
  }

  async function handleMarkAllRead() {
    setLoading(true);
    await markAllAlertsAsRead(visibleAlerts);
    setAlerts((prev) => prev.map((a) => ({ ...a, isRead: true })));
    setLoading(false);
  }

  return (
    <div className="relative" ref={dropdownRef} dir="rtl">
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        onClick={() => setOpen(!open)}
      >
        {unreadCount > 0 ? (
          <BellRing className="w-5 h-5 text-amber-600 animate-pulse" />
        ) : (
          <Bell className="w-5 h-5 text-gray-500" />
        )}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -left-1 bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute left-0 top-full mt-2 w-[380px] bg-white rounded-xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-l from-[#1E3A5F] to-[#2C5282] text-white">
            <div className="flex items-center gap-2">
              <BellRing className="w-4 h-4" />
              <span className="font-semibold text-sm">تنبيهات العقود</span>
              {unreadCount > 0 && (
                <Badge className="bg-white/20 text-white text-[10px] px-1.5">{unreadCount} جديد</Badge>
              )}
            </div>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-white/80 hover:text-white hover:bg-white/10 text-xs h-7 px-2"
                onClick={handleMarkAllRead}
                disabled={loading}
              >
                <CheckCheck className="w-3.5 h-3.5 ml-1" />
                قراءة الكل
              </Button>
            )}
          </div>

          {/* Alerts List */}
          <ScrollArea className="max-h-[400px]">
            {visibleAlerts.length === 0 ? (
              <div className="py-12 text-center text-gray-400">
                <Bell className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">لا توجد تنبيهات</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {visibleAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer ${
                      !alert.isRead ? 'bg-blue-50/50' : ''
                    }`}
                    onClick={() => !alert.isRead && handleMarkRead(alert.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">{getAlertIcon(alert.alertType)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm text-gray-900 truncate">
                            {alert.clientName}
                          </span>
                          <Badge className={`text-[10px] px-1.5 py-0 ${ALERT_TYPE_COLORS[alert.alertType] || 'bg-gray-100 text-gray-600'}`}>
                            {ALERT_TYPE_LABELS[alert.alertType] || alert.alertType}
                          </Badge>
                          {!alert.isRead && (
                            <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-gray-600">
                          {alert.alertType === 'expired'
                            ? `انتهى العقد بتاريخ ${alert.contractEndDate}`
                            : `ينتهي العقد بعد ${alert.daysRemaining} يوم — ${alert.contractEndDate}`
                          }
                        </p>
                        <p className="text-[10px] text-gray-400 mt-1">{timeAgo(alert.sentAt)}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 shrink-0 text-gray-300 hover:text-red-400"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDismiss(alert.id);
                        }}
                      >
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Footer */}
          {visibleAlerts.length > 0 && (
            <div className="px-4 py-2 border-t bg-gray-50 text-center">
              <p className="text-[10px] text-gray-400">
                يتم فحص العقود تلقائياً عند فتح صفحة العقود
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}