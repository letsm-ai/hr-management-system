import { Component, ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Application error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
          <Card className="w-full max-w-md shadow-xl">
            <CardContent className="p-8 text-center space-y-6">
              <AlertTriangle className="h-16 w-16 text-amber-500 mx-auto" />
              <h1 className="text-xl font-bold text-gray-800">حدث خطأ غير متوقع</h1>
              <p className="text-gray-500">يرجى إعادة تحميل الصفحة</p>
              <Button
                onClick={() => window.location.reload()}
                size="lg"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                إعادة تحميل
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}