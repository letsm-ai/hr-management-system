// ClickUp Integration API - Frontend helpers
import { apiGet, apiPost, apiDelete } from './api-client';

export interface ClickUpSettings {
  api_token: string;
  default_workspace_id: string;
  default_workspace_name: string;
  auto_sync_enabled: boolean;
  sync_frequency: 'weekly' | 'biweekly' | 'monthly';
  sync_day: number;
  sync_hour: number;
  auto_sync_notify?: boolean;
  last_sync_at?: string;
  last_auto_sync_at?: string;
  next_auto_sync_at?: string;
}

export interface ClickUpSpace {
  id: string;
  name: string;
}

export interface SyncHistoryRecord {
  id: number;
  month: string;
  sync_type: 'manual' | 'auto';
  status: 'success' | 'partial' | 'failed';
  synced_count: number;
  skipped_count: number;
  failed_count: number;
  created_at: string;
  workspace_name: string;
}

// ============ SETTINGS API ============

export async function fetchClickUpSettings(): Promise<ClickUpSettings | null> {
  try {
    const res = await apiGet('/api/v1/clickup/settings');
    return res?.data || null;
  } catch (e) {
    console.error('Failed to fetch ClickUp settings:', e);
    return null;
  }
}

export async function saveClickUpSettings(settings: ClickUpSettings): Promise<boolean> {
  try {
    await apiPost('/api/v1/clickup/settings', settings);
    return true;
  } catch (e) {
    console.error('Failed to save ClickUp settings:', e);
    return false;
  }
}

export async function testClickUpConnection(token: string): Promise<{
  success: boolean;
  workspaces?: { id: string; name: string }[];
  error?: string;
}> {
  try {
    const res = await apiPost('/api/v1/clickup/test_connection', { api_token: token });
    return res?.data || { success: false, error: 'لم يتم استلام رد من الخادم' };
  } catch (e: any) {
    console.error('Failed to test ClickUp connection:', e);
    const errorMsg = e?.data?.detail || e?.message || 'فشل الاتصال بالخادم';
    return { success: false, error: errorMsg };
  }
}

// ============ SPACES API ============

export async function fetchClickUpSpaces(workspaceId: string): Promise<ClickUpSpace[]> {
  try {
    const res = await apiGet('/api/v1/clickup/spaces', { team_id: workspaceId });
    return res?.data?.spaces || [];
  } catch (e) {
    console.error('Failed to fetch ClickUp spaces:', e);
    return [];
  }
}

// ============ SYNC HISTORY API ============

export async function fetchClickUpSyncHistory(): Promise<SyncHistoryRecord[]> {
  try {
    const res = await apiGet('/api/v1/clickup/sync_history');
    return res?.data?.items || [];
  } catch (e) {
    console.error('Failed to fetch sync history:', e);
    return [];
  }
}

export async function recordSyncOperation(params: {
  month: string;
  sync_type: string;
  status: string;
  synced_count: number;
  skipped_count: number;
  failed_count: number;
}): Promise<boolean> {
  try {
    await apiPost('/api/v1/clickup/record_sync', params);
    return true;
  } catch (e) {
    console.error('Failed to record sync:', e);
    return false;
  }
}

export async function triggerManualSync(
  workspaceId: string,
  month: string,
): Promise<{ success: boolean; message?: string }> {
  try {
    const res = await apiPost('/api/v1/clickup/trigger_sync', { workspace_id: workspaceId, month });
    return res?.data || { success: false };
  } catch (e) {
    console.error('Failed to trigger manual sync:', e);
    return { success: false };
  }
}

// ============ MEMBER MAPPING API ============

export async function fetchMemberMapping(): Promise<Record<string, string>> {
  try {
    const res = await apiGet('/api/v1/clickup/member_mapping');
    return res?.data?.mapping || {};
  } catch (e) {
    console.error('Failed to fetch member mapping:', e);
    return {};
  }
}

export async function saveMemberMapping(mapping: Record<string, string>): Promise<boolean> {
  try {
    await apiPost('/api/v1/clickup/member_mapping', { mapping });
    return true;
  } catch (e) {
    console.error('Failed to save member mapping:', e);
    return false;
  }
}

export async function deleteMemberMapping(clickupId: string): Promise<boolean> {
  try {
    await apiDelete(`/api/v1/clickup/member_mapping/${clickupId}`);
    return true;
  } catch (e) {
    console.error('Failed to delete member mapping:', e);
    return false;
  }
}