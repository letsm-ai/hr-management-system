// Incentive System - API Layer using Atoms Cloud Web SDK
import { entities } from './entity-api';
import type {
  Employee, AttendanceRecord, IdeaRecord, OvertimeRecord, ViolationRecord,
  PerformanceKpiRecord,
} from './hr-api';
import {
  getMonthlyAttendanceStats,
  createNotification,
} from './hr-api';

// ============ TYPE DEFINITIONS ============

export interface DbClientContract {
  id: number;
  user_id: string;
  client_name: string;
  contract_type: string;
  service_type: string;
  monthly_value: number;
  annual_value: number;
  previous_value: number | null;
  start_date: string;
  end_date: string;
  renewal_year: number | null;
  status: string;
  sales_employee_id: number;
  account_manager_id: number | null;
  notes: string | null;
  created_at: string | null;  // ISO datetime string from backend
  updated_at: string | null;  // ISO datetime string from backend
}

export interface ClientContract {
  id: string;
  clientName: string;
  contractType: string;
  serviceType: string;
  monthlyValue: number;
  annualValue: number;
  previousValue: number;
  startDate: string;
  endDate: string;
  renewalYear: number;
  status: string;
  salesEmployeeId: string;
  accountManagerId: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface DbIncentiveRecord {
  id: number;
  user_id: string;
  employee_id: number;
  contract_id: number | null;
  month: string;
  incentive_type: string;
  base_amount: number;
  performance_multiplier: number;
  final_amount: number;
  status: string;
  calculation_details: string | null;
  approved_by: string | null;
  paid_at: string | null;
  created_at: string | null;
}

export interface IncentiveRecord {
  id: string;
  employeeId: string;
  contractId: string;
  month: string;
  incentiveType: string;
  baseAmount: number;
  performanceMultiplier: number;
  finalAmount: number;
  status: string;
  calculationDetails: string;
  approvedBy: string;
  paidAt: string;
  createdAt: string;
}

export interface DbIncentiveSetting {
  id: number;
  setting_key: string;
  setting_value: string;
  description: string | null;
  updated_at: string | null;
}

export interface IncentiveSetting {
  id: string;
  settingKey: string;
  settingValue: string;
  description: string;
  updatedAt: string;
}

// ============ MAPPERS ============

function mapDbClientContract(db: DbClientContract): ClientContract {
  return {
    id: String(db.id),
    clientName: db.client_name || '',
    contractType: db.contract_type || 'new',
    serviceType: db.service_type || '',
    monthlyValue: db.monthly_value || 0,
    annualValue: db.annual_value || 0,
    previousValue: db.previous_value || 0,
    startDate: db.start_date || '',
    endDate: db.end_date || '',
    renewalYear: db.renewal_year || 0,
    status: db.status || 'active',
    salesEmployeeId: String(db.sales_employee_id || 0),
    accountManagerId: String(db.account_manager_id || 0),
    notes: db.notes || '',
    createdAt: db.created_at || '',
    updatedAt: db.updated_at || '',
  };
}

function mapDbIncentiveRecord(db: DbIncentiveRecord): IncentiveRecord {
  return {
    id: String(db.id),
    employeeId: String(db.employee_id),
    contractId: String(db.contract_id || 0),
    month: db.month || '',
    incentiveType: db.incentive_type || '',
    baseAmount: db.base_amount || 0,
    performanceMultiplier: db.performance_multiplier || 1,
    finalAmount: db.final_amount || 0,
    status: db.status || 'calculated',
    calculationDetails: db.calculation_details || '',
    approvedBy: db.approved_by || '',
    paidAt: db.paid_at || '',
    createdAt: db.created_at || '',
  };
}

function mapDbIncentiveSetting(db: DbIncentiveSetting): IncentiveSetting {
  return {
    id: String(db.id),
    settingKey: db.setting_key || '',
    settingValue: db.setting_value || '',
    description: db.description || '',
    updatedAt: db.updated_at || '',
  };
}

// ============ CLIENT CONTRACTS API ============

export async function fetchClientContracts(): Promise<ClientContract[]> {
  try {
    const res = await entities.client_contracts.query({ query: {}, limit: 500 });
    const items = res?.data?.items || [];
    return items.map(mapDbClientContract);
  } catch (e) {
    console.error('Failed to fetch client contracts:', e);
    return [];
  }
}

export async function fetchAllClientContracts(): Promise<ClientContract[]> {
  try {
    // Try queryAll first (returns all users' data for create_only=true entities)
    const res = await entities.client_contracts.queryAll({ query: {}, limit: 500 });
    const allItems = res?.data?.items || [];
    
    // Also fetch current user's contracts to ensure newly created ones are included
    const userRes = await entities.client_contracts.query({ query: {}, limit: 500 });
    const userItems = userRes?.data?.items || [];
    
    // Merge and deduplicate by id
    const allMap = new Map<number, DbClientContract>();
    for (const item of allItems) {
      allMap.set(item.id, item);
    }
    for (const item of userItems) {
      allMap.set(item.id, item);
    }
    
    return Array.from(allMap.values()).map(mapDbClientContract);
  } catch (e) {
    console.error('Failed to fetch all client contracts:', e);
    // Fallback to user's own contracts
    try {
      const res = await entities.client_contracts.query({ query: {}, limit: 500 });
      const items = res?.data?.items || [];
      return items.map(mapDbClientContract);
    } catch (e2) {
      console.error('Fallback fetch also failed:', e2);
      return [];
    }
  }
}

export async function createClientContract(record: Omit<ClientContract, 'id' | 'createdAt' | 'updatedAt'>): Promise<ClientContract | null> {
  try {
    const res = await entities.client_contracts.create({
      data: {
        client_name: record.clientName,
        contract_type: record.contractType,
        service_type: record.serviceType,
        monthly_value: record.monthlyValue,
        annual_value: record.annualValue || record.monthlyValue * 12,
        previous_value: record.previousValue || 0,
        start_date: record.startDate,
        end_date: record.endDate,
        renewal_year: record.renewalYear || 0,
        status: record.status || 'active',
        sales_employee_id: Number(record.salesEmployeeId),
        account_manager_id: record.accountManagerId ? Number(record.accountManagerId) : null,
        notes: record.notes || '',
      },
    });
    return res?.data ? mapDbClientContract(res.data) : null;
  } catch (e) {
    console.error('Failed to create client contract:', e);
    return null;
  }
}

export async function updateClientContract(id: string, updates: Partial<ClientContract>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.clientName !== undefined) data.client_name = updates.clientName;
    if (updates.contractType !== undefined) data.contract_type = updates.contractType;
    if (updates.serviceType !== undefined) data.service_type = updates.serviceType;
    if (updates.monthlyValue !== undefined) data.monthly_value = updates.monthlyValue;
    if (updates.annualValue !== undefined) data.annual_value = updates.annualValue;
    if (updates.previousValue !== undefined) data.previous_value = updates.previousValue;
    if (updates.startDate !== undefined) data.start_date = updates.startDate;
    if (updates.endDate !== undefined) data.end_date = updates.endDate;
    if (updates.renewalYear !== undefined) data.renewal_year = updates.renewalYear;
    if (updates.status !== undefined) data.status = updates.status;
    if (updates.salesEmployeeId !== undefined) data.sales_employee_id = Number(updates.salesEmployeeId);
    if (updates.accountManagerId !== undefined) data.account_manager_id = updates.accountManagerId ? Number(updates.accountManagerId) : null;
    if (updates.notes !== undefined) data.notes = updates.notes;
    await entities.client_contracts.update({ id, data });
  } catch (e) {
    console.error('Failed to update client contract:', e);
  }
}

export async function deleteClientContract(id: string): Promise<void> {
  try {
    await entities.client_contracts.delete({ id });
  } catch (e) {
    console.error('Failed to delete client contract:', e);
  }
}

// ============ INCENTIVE RECORDS API ============

export async function fetchIncentiveRecords(): Promise<IncentiveRecord[]> {
  try {
    const res = await entities.incentive_records.query({ query: {}, limit: 500 });
    const items = res?.data?.items || [];
    return items.map(mapDbIncentiveRecord);
  } catch (e) {
    console.error('Failed to fetch incentive records:', e);
    return [];
  }
}

export async function createIncentiveRecord(record: Omit<IncentiveRecord, 'id' | 'createdAt'>): Promise<IncentiveRecord | null> {
  try {
    const res = await entities.incentive_records.create({
      data: {
        employee_id: Number(record.employeeId),
        contract_id: record.contractId ? Number(record.contractId) : null,
        month: record.month,
        incentive_type: record.incentiveType,
        base_amount: record.baseAmount,
        performance_multiplier: record.performanceMultiplier,
        final_amount: record.finalAmount,
        status: record.status || 'calculated',
        calculation_details: record.calculationDetails || '',
        approved_by: record.approvedBy || null,
        paid_at: record.paidAt || null,
      },
    });
    return res?.data ? mapDbIncentiveRecord(res.data) : null;
  } catch (e) {
    console.error('Failed to create incentive record:', e);
    return null;
  }
}

export async function updateIncentiveRecord(id: string, updates: Partial<IncentiveRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.status !== undefined) data.status = updates.status;
    if (updates.approvedBy !== undefined) data.approved_by = updates.approvedBy;
    if (updates.paidAt !== undefined) data.paid_at = updates.paidAt;
    if (updates.finalAmount !== undefined) data.final_amount = updates.finalAmount;
    if (updates.performanceMultiplier !== undefined) data.performance_multiplier = updates.performanceMultiplier;
    await entities.incentive_records.update({ id, data });
  } catch (e) {
    console.error('Failed to update incentive record:', e);
  }
}

export async function deleteIncentiveRecord(id: string): Promise<void> {
  try {
    await entities.incentive_records.delete({ id });
  } catch (e) {
    console.error('Failed to delete incentive record:', e);
  }
}

// ============ INCENTIVE SETTINGS API ============

export async function fetchIncentiveSettings(): Promise<IncentiveSetting[]> {
  try {
    const res = await entities.incentive_settings.query({ query: {}, limit: 50 });
    const items = res?.data?.items || [];
    return items.map(mapDbIncentiveSetting);
  } catch (e) {
    console.error('Failed to fetch incentive settings:', e);
    return [];
  }
}

export async function updateIncentiveSetting(id: string, value: string): Promise<void> {
  try {
    await entities.incentive_settings.update({
      id,
      data: { setting_value: value },
    });
  } catch (e) {
    console.error('Failed to update incentive setting:', e);
  }
}

// ============ HELPER: Get setting by key ============

export function getSettingByKey(settings: IncentiveSetting[], key: string): string {
  const s = settings.find((s) => s.settingKey === key);
  return s?.settingValue || '';
}

export function parseSettingJSON<T>(settings: IncentiveSetting[], key: string, fallback: T): T {
  try {
    const val = getSettingByKey(settings, key);
    return val ? JSON.parse(val) : fallback;
  } catch {
    return fallback;
  }
}

// ============ CURRENCY HELPERS ============

export function baisaToOmr(baisa: number): number {
  return baisa / 1000;
}

export function omrToBaisa(omr: number): number {
  return Math.round(omr * 1000);
}

export function formatOMR(baisa: number): string {
  return `${(baisa / 1000).toFixed(3)} ر.ع`;
}

// ============ CONTRACT TYPE LABELS ============

export const CONTRACT_TYPE_LABELS: Record<string, string> = {
  new: 'عقد جديد',
  renewal: 'تجديد',
  upsell: 'زيادة قيمة',
};

export const CONTRACT_STATUS_LABELS: Record<string, string> = {
  active: 'نشط',
  expired: 'منتهي',
  cancelled: 'ملغي',
  pending_renewal: 'بانتظار التجديد',
};

export const INCENTIVE_TYPE_LABELS: Record<string, string> = {
  new_contract: 'عقد جديد',
  renewal: 'تجديد',
  upsell: 'زيادة قيمة',
  monthly_pool: 'صندوق شهري',
  team_bonus: 'مكافأة فريق',
};

export const INCENTIVE_STATUS_LABELS: Record<string, string> = {
  calculated: 'محسوبة',
  approved: 'معتمدة',
  paid: 'مصروفة',
  cancelled: 'ملغاة',
};

export const SERVICE_TYPES = [
  'إدارة حسابات التواصل الاجتماعي',
  'تصميم جرافيك',
  'تصوير فوتوغرافي وفيديو',
  'برمجة وتطوير مواقع',
  'حملات إعلانية رقمية',
  'إنتاج محتوى',
  'استشارات تسويقية',
  'باقة شاملة',
  'أخرى',
];

// ============ CALCULATION ENGINE ============

interface NewContractTier {
  min: number;
  max: number | null;
  rate: number;
}

interface RenewalRates {
  year1: number;
  year2: number;
  year3plus: number;
}

interface MonthlyPoolTier {
  min: number;
  max: number | null;
  amount: number;
}

interface PerformanceWeights {
  attendance: number;
  kpi: number;
  clickup: number;
  ideas: number;
  violations: number;
}

interface PerformanceMultipliers {
  excellent: number;
  good: number;
  average: number;
  below: number;
  poor: number;
}

// م3 — New contract commission
export function calcNewContractBonus(annualValueBaisa: number, tiers: NewContractTier[]): number {
  const annualOMR = annualValueBaisa / 1000;
  for (const tier of tiers) {
    const minOMR = tier.min / 1000;
    const maxOMR = tier.max ? tier.max / 1000 : Infinity;
    if (annualOMR >= minOMR && annualOMR <= maxOMR) {
      return Math.round(annualValueBaisa * tier.rate);
    }
  }
  // fallback to last tier
  if (tiers.length > 0) {
    return Math.round(annualValueBaisa * tiers[tiers.length - 1].rate);
  }
  return 0;
}

// م4 — Renewal bonus
export function calcRenewalBonus(annualValueBaisa: number, renewalYear: number, rates: RenewalRates): number {
  let rate = rates.year1;
  if (renewalYear === 2) rate = rates.year2;
  else if (renewalYear >= 3) rate = rates.year3plus;
  return Math.round(annualValueBaisa * rate);
}

// م5 — Upsell bonus
export function calcUpsellBonus(newMonthlyBaisa: number, oldMonthlyBaisa: number, upsellRate: number): number {
  const diff = newMonthlyBaisa - oldMonthlyBaisa;
  if (diff <= 0) return 0;
  return Math.round(diff * 12 * upsellRate);
}

// م6 — Monthly pool amount
export function calcMonthlyPoolAmount(monthlyRevenueBaisa: number, tiers: MonthlyPoolTier[]): number {
  for (const tier of tiers) {
    const min = tier.min;
    const max = tier.max ?? Infinity;
    if (monthlyRevenueBaisa >= min && monthlyRevenueBaisa <= max) {
      return tier.amount;
    }
  }
  if (tiers.length > 0) return tiers[tiers.length - 1].amount;
  return 500000;
}

// م9 — Performance score
export function calcPerformanceScore(
  attendanceRate: number,
  kpiScore: number,
  clickupRate: number,
  ideasScore: number,
  disciplineScore: number,
  weights: PerformanceWeights
): number {
  return (
    attendanceRate * weights.attendance +
    kpiScore * weights.kpi +
    clickupRate * weights.clickup +
    ideasScore * weights.ideas +
    disciplineScore * weights.violations
  );
}

// م10 — Performance multiplier
export function getPerformanceMultiplier(score: number, multipliers: PerformanceMultipliers): { label: string; multiplier: number } {
  if (score >= 90) return { label: 'ممتاز', multiplier: multipliers.excellent };
  if (score >= 75) return { label: 'جيد', multiplier: multipliers.good };
  if (score >= 60) return { label: 'متوسط', multiplier: multipliers.average };
  if (score >= 45) return { label: 'أقل من المتوسط', multiplier: multipliers.below };
  return { label: 'ضعيف', multiplier: multipliers.poor };
}

// Full incentive calculation for a month
export interface EmployeeIncentiveResult {
  employeeId: string;
  employeeName: string;
  jobTitle: string;
  newContractBonus: number;
  renewalBonus: number;
  upsellBonus: number;
  poolShare: number;
  totalContractBonus: number;
  performanceScore: number;
  performanceLabel: string;
  performanceMultiplier: number;
  finalAmount: number;
  adjustedAmount: number;
  contractDetails: { contractId: string; clientName: string; type: string; value: number; rate: number; amount: number }[];
  performanceDetails: {
    attendanceScore: number;
    kpiScore: number;
    clickupScore: number;
    ideasScore: number;
    disciplineScore: number;
  };
}

export interface IncentiveCalculationResult {
  employees: EmployeeIncentiveResult[];
  summary: {
    totalIncentives: number;
    monthlyCap: number;
    isCapApplied: boolean;
    poolAmount: number;
    eligibleCount: number;
    monthlyRevenue: number;
  };
}

export function calculateMonthlyIncentives(
  month: string,
  contracts: ClientContract[],
  employees: Employee[],
  attendance: AttendanceRecord[],
  kpis: PerformanceKpiRecord[],
  ideas: IdeaRecord[],
  violations: ViolationRecord[],
  overtime: OvertimeRecord[],
  settings: IncentiveSetting[],
  clickupData?: Record<string, number>,
): IncentiveCalculationResult {
  // Parse settings
  const newContractTiers = parseSettingJSON<NewContractTier[]>(settings, 'new_contract_tiers', [
    { min: 0, max: 500000, rate: 0.05 },
    { min: 500001, max: 2000000, rate: 0.04 },
    { min: 2000001, max: null, rate: 0.03 },
  ]);
  const renewalRates = parseSettingJSON<RenewalRates>(settings, 'renewal_rates', { year1: 0.03, year2: 0.04, year3plus: 0.05 });
  const upsellRate = parseFloat(getSettingByKey(settings, 'upsell_rate') || '0.07');
  const poolTiers = parseSettingJSON<MonthlyPoolTier[]>(settings, 'monthly_pool_tiers', [
    { min: 0, max: 15000000, amount: 500000 },
    { min: 15000001, max: 25000000, amount: 1000000 },
    { min: 25000001, max: null, amount: 1500000 },
  ]);
  const maxCap = parseFloat(getSettingByKey(settings, 'max_incentive_cap') || '0.08');
  const perfWeights = parseSettingJSON<PerformanceWeights>(settings, 'performance_weights', {
    attendance: 0.20, kpi: 0.25, clickup: 0.30, ideas: 0.10, violations: 0.15,
  });
  const perfMultipliers = parseSettingJSON<PerformanceMultipliers>(settings, 'performance_multipliers', {
    excellent: 1.30, good: 1.15, average: 1.00, below: 0.85, poor: 0.70,
  });
  const eligibilityMonths = parseInt(getSettingByKey(settings, 'eligibility_min_months') || '3');

  // Active employees
  const activeEmployees = employees.filter((e) => e.status === 'نشط');

  // م7 — Monthly revenue from active contracts
  const activeContracts = contracts.filter((c) => c.status === 'active');
  const monthlyRevenue = activeContracts.reduce((sum, c) => sum + c.monthlyValue, 0);

  // م6 — Pool amount
  const poolAmount = calcMonthlyPoolAmount(monthlyRevenue, poolTiers);

  // Contracts created in this month
  const [yearStr, monthStr] = month.split('-');
  const monthStart = `${yearStr}-${monthStr}-01`;
  const nextMonth = parseInt(monthStr) === 12
    ? `${parseInt(yearStr) + 1}-01-01`
    : `${yearStr}-${String(parseInt(monthStr) + 1).padStart(2, '0')}-01`;

  const monthContracts = contracts.filter((c) => {
    return c.startDate >= monthStart && c.startDate < nextMonth;
  });

  // Eligible employees (min months)
  const eligibleEmployees = activeEmployees.filter((emp) => {
    if (!emp.hireDate) return false;
    const hire = new Date(emp.hireDate);
    const monthDate = new Date(`${month}-01`);
    const diffMs = monthDate.getTime() - hire.getTime();
    const diffMonths = diffMs / (1000 * 60 * 60 * 24 * 30);
    return diffMonths >= eligibilityMonths;
  });

  const eligibleCount = eligibleEmployees.length;
  const poolSharePerEmployee = eligibleCount > 0 ? Math.round(poolAmount / eligibleCount) : 0;

  // Calculate per employee
  const results: EmployeeIncentiveResult[] = activeEmployees.map((emp) => {
    const isEligible = eligibleEmployees.some((e) => e.id === emp.id);

    // Contract bonuses
    let newContractBonus = 0;
    let renewalBonus = 0;
    let upsellBonus = 0;
    const contractDetails: EmployeeIncentiveResult['contractDetails'] = [];

    const empContracts = monthContracts.filter((c) => c.salesEmployeeId === emp.id);
    for (const c of empContracts) {
      if (c.contractType === 'new') {
        const bonus = calcNewContractBonus(c.annualValue, newContractTiers);
        newContractBonus += bonus;
        const tier = newContractTiers.find((t) => {
          const av = c.annualValue;
          return av >= t.min && av <= (t.max ?? Infinity);
        });
        contractDetails.push({
          contractId: c.id,
          clientName: c.clientName,
          type: 'new',
          value: c.annualValue,
          rate: tier?.rate || 0,
          amount: bonus,
        });
      } else if (c.contractType === 'renewal') {
        const bonus = calcRenewalBonus(c.annualValue, c.renewalYear, renewalRates);
        renewalBonus += bonus;
        let rate = renewalRates.year1;
        if (c.renewalYear === 2) rate = renewalRates.year2;
        else if (c.renewalYear >= 3) rate = renewalRates.year3plus;
        contractDetails.push({
          contractId: c.id,
          clientName: c.clientName,
          type: 'renewal',
          value: c.annualValue,
          rate,
          amount: bonus,
        });
      } else if (c.contractType === 'upsell') {
        const bonus = calcUpsellBonus(c.monthlyValue, c.previousValue, upsellRate);
        upsellBonus += bonus;
        contractDetails.push({
          contractId: c.id,
          clientName: c.clientName,
          type: 'upsell',
          value: (c.monthlyValue - c.previousValue) * 12,
          rate: upsellRate,
          amount: bonus,
        });
      }
    }

    const totalContractBonus = newContractBonus + renewalBonus + upsellBonus;
    const poolShare = isEligible ? poolSharePerEmployee : 0;

    // Performance score
    const attStats = getMonthlyAttendanceStats(emp.id, month, attendance);
    const attendanceScore = attStats.attendanceRate;

    const empKpis = kpis.filter((k) => k.employeeId === emp.id && k.month === month);
    const kpiScore = empKpis.length > 0
      ? empKpis.reduce((sum, k) => sum + k.achievementRate, 0) / empKpis.length
      : 0;

    const clickupScore = clickupData?.[emp.id] ?? 0;

    const empIdeas = ideas.filter((i) => i.employeeId === emp.id && i.month === month);
    const totalIdeas = empIdeas.length;
    const acceptedIdeas = empIdeas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length;
    const ideasScore = totalIdeas > 0 ? (acceptedIdeas / totalIdeas) * 100 : 0;

    const empViolations = violations.filter((v) => {
      const d = new Date(v.date);
      const [y, m] = month.split('-').map(Number);
      return v.employeeId === emp.id && d.getFullYear() === y && d.getMonth() + 1 === m;
    });
    const disciplineScore = Math.max(0, 100 - empViolations.length * 10);

    const perfScore = calcPerformanceScore(attendanceScore, kpiScore, clickupScore, ideasScore, disciplineScore, perfWeights);
    const { label: perfLabel, multiplier: perfMult } = getPerformanceMultiplier(perfScore, perfMultipliers);

    // م11 — Final amount
    const finalAmount = Math.round((totalContractBonus + poolShare) * perfMult);

    return {
      employeeId: emp.id,
      employeeName: emp.fullName,
      jobTitle: emp.jobTitle,
      newContractBonus,
      renewalBonus,
      upsellBonus,
      poolShare,
      totalContractBonus,
      performanceScore: Math.round(perfScore * 10) / 10,
      performanceLabel: perfLabel,
      performanceMultiplier: perfMult,
      finalAmount,
      adjustedAmount: finalAmount,
      contractDetails,
      performanceDetails: {
        attendanceScore: Math.round(attendanceScore * 10) / 10,
        kpiScore: Math.round(kpiScore * 10) / 10,
        clickupScore: Math.round(clickupScore * 10) / 10,
        ideasScore: Math.round(ideasScore * 10) / 10,
        disciplineScore,
      },
    };
  });

  // م12 & م13 — Apply cap
  const totalIncentives = results.reduce((sum, r) => sum + r.finalAmount, 0);
  const monthlyCap = Math.round(monthlyRevenue * maxCap);
  let isCapApplied = false;

  if (totalIncentives > monthlyCap && monthlyCap > 0) {
    isCapApplied = true;
    for (const r of results) {
      r.adjustedAmount = totalIncentives > 0
        ? Math.round((r.finalAmount / totalIncentives) * monthlyCap)
        : 0;
    }
  }

  return {
    employees: results.filter((r) => r.adjustedAmount > 0 || r.totalContractBonus > 0 || r.poolShare > 0),
    summary: {
      totalIncentives: isCapApplied ? monthlyCap : totalIncentives,
      monthlyCap,
      isCapApplied,
      poolAmount,
      eligibleCount,
      monthlyRevenue,
    },
  };
}

// ============ CONTRACT ALERTS API ============

export interface DbContractAlert {
  id: number;
  user_id: string;
  contract_id: number;
  client_name: string;
  alert_type: string;
  days_remaining: number;
  contract_end_date: string;
  is_read: boolean;
  is_dismissed: boolean;
  sent_at: string | null;
  read_at: string | null;
}

export interface ContractAlert {
  id: string;
  contractId: string;
  clientName: string;
  alertType: string;
  daysRemaining: number;
  contractEndDate: string;
  isRead: boolean;
  isDismissed: boolean;
  sentAt: string;
  readAt: string;
}

function mapDbContractAlert(db: DbContractAlert): ContractAlert {
  return {
    id: String(db.id),
    contractId: String(db.contract_id),
    clientName: db.client_name || '',
    alertType: db.alert_type || '',
    daysRemaining: db.days_remaining ?? 0,
    contractEndDate: db.contract_end_date || '',
    isRead: db.is_read ?? false,
    isDismissed: db.is_dismissed ?? false,
    sentAt: db.sent_at || '',
    readAt: db.read_at || '',
  };
}

export const ALERT_TYPE_LABELS: Record<string, string> = {
  '30_days': 'قبل 30 يوم',
  '15_days': 'قبل 15 يوم',
  '7_days': 'قبل 7 أيام',
  'expired': 'منتهي',
};

export const ALERT_TYPE_COLORS: Record<string, string> = {
  '30_days': 'bg-blue-100 text-blue-700 border-blue-200',
  '15_days': 'bg-amber-100 text-amber-700 border-amber-200',
  '7_days': 'bg-red-100 text-red-700 border-red-200',
  'expired': 'bg-gray-200 text-gray-700 border-gray-300',
};

export async function fetchContractAlerts(): Promise<ContractAlert[]> {
  try {
    const res = await entities.contract_alerts.query({ query: {}, sort: '-id', limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbContractAlert);
  } catch (e) {
    console.error('Failed to fetch contract alerts:', e);
    return [];
  }
}

export async function createContractAlert(alert: Omit<ContractAlert, 'id' | 'sentAt' | 'readAt'>): Promise<ContractAlert | null> {
  try {
    const now = new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0];
    const res = await entities.contract_alerts.create({
      data: {
        contract_id: Number(alert.contractId),
        client_name: alert.clientName,
        alert_type: alert.alertType,
        days_remaining: alert.daysRemaining,
        contract_end_date: alert.contractEndDate,
        is_read: false,
        is_dismissed: false,
        sent_at: now,
      },
    });

    // Also create a unified notification for contract expiry
    try {
      const alertTypeLabels: Record<string, string> = {
        '7_days': 'ينتهي خلال 7 أيام',
        '15_days': 'ينتهي خلال 15 يوم',
        '30_days': 'ينتهي خلال 30 يوم',
        'expired': 'منتهي الصلاحية',
      };
      const title = `تنبيه عقد: ${alert.clientName}`;
      const message = `عقد العميل "${alert.clientName}" ${alertTypeLabels[alert.alertType] || alert.alertType} - تاريخ الانتهاء: ${alert.contractEndDate}`;
      await createNotification(0, 'contract_expiry', title, message, Number(alert.contractId));
    } catch (notifErr) {
      console.warn('Failed to create unified notification for contract alert:', notifErr);
    }

    return res?.data ? mapDbContractAlert(res.data) : null;
  } catch (e) {
    console.error('Failed to create contract alert:', e);
    return null;
  }
}

export async function markAlertAsRead(id: string): Promise<void> {
  try {
    const now = new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0];
    await entities.contract_alerts.update({
      id,
      data: { is_read: true, read_at: now },
    });
  } catch (e) {
    console.error('Failed to mark alert as read:', e);
  }
}

export async function dismissAlert(id: string): Promise<void> {
  try {
    await entities.contract_alerts.update({
      id,
      data: { is_dismissed: true, is_read: true },
    });
  } catch (e) {
    console.error('Failed to dismiss alert:', e);
  }
}

export async function markAllAlertsAsRead(alerts: ContractAlert[]): Promise<void> {
  const unread = alerts.filter((a) => !a.isRead);
  for (const a of unread) {
    await markAlertAsRead(a.id);
  }
}

/**
 * Generate alerts for contracts approaching expiration.
 * Checks existing alerts to avoid duplicates.
 */
export async function generateContractAlerts(contracts: ClientContract[]): Promise<number> {
  const existingAlerts = await fetchContractAlerts();
  const now = new Date();
  let createdCount = 0;

  const activeContracts = contracts.filter((c) => c.status === 'active' || c.status === 'pending_renewal');

  for (const contract of activeContracts) {
    const endDate = new Date(contract.endDate);
    const diffMs = endDate.getTime() - now.getTime();
    const daysRemaining = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    const thresholds = [
      { type: '7_days', min: 0, max: 7 },
      { type: '15_days', min: 8, max: 15 },
      { type: '30_days', min: 16, max: 30 },
    ];

    // Check if contract is expired
    if (daysRemaining < 0) {
      const exists = existingAlerts.some(
        (a) => a.contractId === contract.id && a.alertType === 'expired'
      );
      if (!exists) {
        await createContractAlert({
          contractId: contract.id,
          clientName: contract.clientName,
          alertType: 'expired',
          daysRemaining: 0,
          contractEndDate: contract.endDate,
          isRead: false,
          isDismissed: false,
        });
        createdCount++;
      }
      continue;
    }

    for (const threshold of thresholds) {
      if (daysRemaining >= threshold.min && daysRemaining <= threshold.max) {
        const exists = existingAlerts.some(
          (a) => a.contractId === contract.id && a.alertType === threshold.type
        );
        if (!exists) {
          await createContractAlert({
            contractId: contract.id,
            clientName: contract.clientName,
            alertType: threshold.type,
            daysRemaining,
            contractEndDate: contract.endDate,
            isRead: false,
            isDismissed: false,
          });
          createdCount++;
        }
        break;
      }
    }
  }

  return createdCount;
}

// ============ REVENUE HELPERS ============

export function getContractStats(contracts: ClientContract[]) {
  const now = new Date();
  const activeContracts = contracts.filter((c) => c.status === 'active');
  const monthlyRevenue = activeContracts.reduce((sum, c) => sum + c.monthlyValue, 0);
  const annualRevenue = activeContracts.reduce((sum, c) => sum + c.annualValue, 0);

  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const newThisMonth = contracts.filter((c) => c.contractType === 'new' && c.startDate.startsWith(currentMonth)).length;
  const renewalsThisMonth = contracts.filter((c) => c.contractType === 'renewal' && c.startDate.startsWith(currentMonth)).length;

  const in30Days = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const expiringSoon = contracts.filter((c) => {
    if (c.status !== 'active') return false;
    const end = new Date(c.endDate);
    return end >= now && end <= in30Days;
  }).length;

  return {
    activeCount: activeContracts.length,
    monthlyRevenue,
    annualRevenue,
    newThisMonth,
    renewalsThisMonth,
    expiringSoon,
  };
}

export function getExpiringContracts(contracts: ClientContract[], days: number): (ClientContract & { daysRemaining: number })[] {
  const now = new Date();
  const futureDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
  return contracts
    .filter((c) => {
      if (c.status !== 'active' && c.status !== 'pending_renewal') return false;
      const end = new Date(c.endDate);
      return end >= now && end <= futureDate;
    })
    .map((c) => ({
      ...c,
      daysRemaining: Math.ceil((new Date(c.endDate).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)),
    }))
    .sort((a, b) => a.daysRemaining - b.daysRemaining);
}

export function getMonthlyRevenueTrend(contracts: ClientContract[], months: number = 12) {
  const now = new Date();
  const result: { month: string; revenue: number }[] = [];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const monthStart = new Date(d.getFullYear(), d.getMonth(), 1);
    const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0);

    const activeInMonth = contracts.filter((c) => {
      if (c.status === 'cancelled') return false;
      const start = new Date(c.startDate);
      const end = new Date(c.endDate);
      return start <= monthEnd && end >= monthStart;
    });

    const revenue = activeInMonth.reduce((sum, c) => sum + c.monthlyValue, 0);
    result.push({ month: monthStr, revenue });
  }

  return result;
}

export function getRevenueByServiceType(contracts: ClientContract[]) {
  const active = contracts.filter((c) => c.status === 'active');
  const grouped: Record<string, { totalRevenue: number; contractCount: number }> = {};

  for (const c of active) {
    if (!grouped[c.serviceType]) {
      grouped[c.serviceType] = { totalRevenue: 0, contractCount: 0 };
    }
    grouped[c.serviceType].totalRevenue += c.annualValue;
    grouped[c.serviceType].contractCount += 1;
  }

  return Object.entries(grouped).map(([serviceType, data]) => ({
    serviceType,
    ...data,
  })).sort((a, b) => b.totalRevenue - a.totalRevenue);
}

export function getContractTrend(contracts: ClientContract[], months: number = 12) {
  const now = new Date();
  const result: { month: string; newContracts: number; renewals: number; upsells: number }[] = [];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

    const monthContracts = contracts.filter((c) => c.startDate.startsWith(monthStr));
    result.push({
      month: monthStr,
      newContracts: monthContracts.filter((c) => c.contractType === 'new').length,
      renewals: monthContracts.filter((c) => c.contractType === 'renewal').length,
      upsells: monthContracts.filter((c) => c.contractType === 'upsell').length,
    });
  }

  return result;
}

export function getTopClients(contracts: ClientContract[], limit: number = 10) {
  const grouped: Record<string, { contractCount: number; totalAnnualRevenue: number; latestStatus: string; firstContractDate: string }> = {};

  for (const c of contracts) {
    if (!grouped[c.clientName]) {
      grouped[c.clientName] = { contractCount: 0, totalAnnualRevenue: 0, latestStatus: c.status, firstContractDate: c.startDate };
    }
    grouped[c.clientName].contractCount += 1;
    if (c.status === 'active') {
      grouped[c.clientName].totalAnnualRevenue += c.annualValue;
    }
    grouped[c.clientName].latestStatus = c.status;
    if (c.startDate < grouped[c.clientName].firstContractDate) {
      grouped[c.clientName].firstContractDate = c.startDate;
    }
  }

  return Object.entries(grouped)
    .map(([clientName, data]) => ({ clientName, ...data }))
    .sort((a, b) => b.totalAnnualRevenue - a.totalAnnualRevenue)
    .slice(0, limit);
}

export function getRetentionRate(contracts: ClientContract[]): number {
  const oneYearAgo = new Date();
  oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

  const expiredInPeriod = contracts.filter((c) => {
    const end = new Date(c.endDate);
    return end >= oneYearAgo && (c.status === 'expired' || c.status === 'active');
  });

  const renewed = contracts.filter((c) => {
    return c.contractType === 'renewal' && new Date(c.startDate) >= oneYearAgo;
  });

  if (expiredInPeriod.length === 0) return 100;
  return Math.min(100, Math.round((renewed.length / expiredInPeriod.length) * 100));
}

export function getRevenueGrowth(contracts: ClientContract[]): number {
  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const prevMonth = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;

  const trend = getMonthlyRevenueTrend(contracts, 2);
  const current = trend.find((t) => t.month === currentMonth)?.revenue || 0;
  const previous = trend.find((t) => t.month === prevMonth)?.revenue || 0;

  if (previous === 0) return current > 0 ? 100 : 0;
  return Math.round(((current - previous) / previous) * 100);
}