// CSV Export Utility with Arabic support

function escapeCsvValue(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportToCSV(
  data: Record<string, string | number | boolean | null | undefined>[],
  headers: { key: string; label: string }[],
  filename: string
): void {
  if (data.length === 0) return;

  const headerRow = headers.map((h) => escapeCsvValue(h.label)).join(',');
  const rows = data.map((row) =>
    headers.map((h) => escapeCsvValue(row[h.key])).join(',')
  );

  // BOM for Excel Arabic support
  const BOM = '\uFEFF';
  const csvContent = BOM + [headerRow, ...rows].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}