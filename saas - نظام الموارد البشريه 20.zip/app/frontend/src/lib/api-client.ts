/**
 * Centralized API client that uses the SDK's request mechanism.
 * This ensures proper token exchange and authentication headers
 * are handled by the SDK's interceptors.
 */
import { client } from './api';

export interface ApiResponse<T = any> {
  data: T;
  status: number;
  ok: boolean;
}

export interface ApiError {
  status: number;
  data: any;
  message: string;
}

/**
 * Make a GET request to the backend API using SDK's apiCall
 */
export async function apiGet<T = any>(path: string, params?: Record<string, string>): Promise<ApiResponse<T>> {
  let url = path;
  if (params) {
    const searchParams = new URLSearchParams(params);
    url += `?${searchParams.toString()}`;
  }
  try {
    const res = await client.apiCall.invoke({
      url,
      method: 'GET',
    });
    return { data: res.data as T, status: res.status || 200, ok: true };
  } catch (err: any) {
    const status = err?.response?.status || err?.status || 500;
    const data = err?.response?.data || err?.data || { detail: err?.message || 'Request failed' };
    const error: ApiError = {
      status,
      data,
      message: data?.detail || data?.message || `Request failed: ${status}`,
    };
    throw error;
  }
}

/**
 * Make a POST request to the backend API using SDK's apiCall
 */
export async function apiPost<T = any>(path: string, body?: any): Promise<ApiResponse<T>> {
  try {
    const res = await client.apiCall.invoke({
      url: path,
      method: 'POST',
      data: body,
    });
    return { data: res.data as T, status: res.status || 200, ok: true };
  } catch (err: any) {
    const status = err?.response?.status || err?.status || 500;
    const data = err?.response?.data || err?.data || { detail: err?.message || 'Request failed' };
    const error: ApiError = {
      status,
      data,
      message: data?.detail || data?.message || `Request failed: ${status}`,
    };
    throw error;
  }
}

/**
 * Make a PUT request to the backend API using SDK's apiCall
 */
export async function apiPut<T = any>(path: string, body?: any): Promise<ApiResponse<T>> {
  try {
    const res = await client.apiCall.invoke({
      url: path,
      method: 'PUT',
      data: body,
    });
    return { data: res.data as T, status: res.status || 200, ok: true };
  } catch (err: any) {
    const status = err?.response?.status || err?.status || 500;
    const data = err?.response?.data || err?.data || { detail: err?.message || 'Request failed' };
    const error: ApiError = {
      status,
      data,
      message: data?.detail || data?.message || `Request failed: ${status}`,
    };
    throw error;
  }
}

/**
 * Make a DELETE request to the backend API using SDK's apiCall
 */
export async function apiDelete<T = any>(path: string): Promise<ApiResponse<T>> {
  try {
    const res = await client.apiCall.invoke({
      url: path,
      method: 'DELETE',
    });
    return { data: res.data as T, status: res.status || 200, ok: true };
  } catch (err: any) {
    const status = err?.response?.status || err?.status || 500;
    const data = err?.response?.data || err?.data || { detail: err?.message || 'Request failed' };
    const error: ApiError = {
      status,
      data,
      message: data?.detail || data?.message || `Request failed: ${status}`,
    };
    throw error;
  }
}

/**
 * Call an edge function (replaces client.callFunction)
 */
export async function callFunction<T = any>(functionPath: string, body?: any): Promise<ApiResponse<T>> {
  return apiPost<T>(`/api/v1/functions/${functionPath}`, body);
}