/**
 * Entity API helper that uses the SDK's apiCall for proper authentication.
 *
 * The SDK's axios instance handles token exchange and adds proper
 * App-Host and Authorization headers automatically.
 */
import { client } from './api';

interface QueryParams {
  query?: Record<string, unknown>;
  sort?: string;
  limit?: number;
  skip?: number;
  fields?: string[];
}

interface GetParams {
  id: string | number;
  fields?: string[];
}

interface CreateParams {
  data: Record<string, unknown>;
}

interface UpdateParams {
  id: string | number;
  data: Record<string, unknown>;
}

interface DeleteParams {
  id: string | number;
}

interface BatchDeleteParams {
  ids: (string | number)[];
}

interface BatchCreateParams {
  data: Record<string, unknown>[];
}

interface BatchUpdateParams {
  data: { id: string | number; updates: Record<string, unknown> }[];
}

function buildQueryString(params?: QueryParams): string {
  if (!params) return '';
  const searchParams = new URLSearchParams();
  if (params.query && Object.keys(params.query).length > 0) {
    searchParams.set('query', JSON.stringify(params.query));
  }
  if (params.sort) searchParams.set('sort', params.sort);
  if (params.limit !== undefined) searchParams.set('limit', String(params.limit));
  if (params.skip !== undefined) searchParams.set('skip', String(params.skip));
  if (params.fields && params.fields.length > 0) {
    searchParams.set('fields', params.fields.join(','));
  }
  const qs = searchParams.toString();
  return qs ? `?${qs}` : '';
}

async function invokeEntity(url: string, method: string, data?: any): Promise<any> {
  try {
    const res = await client.apiCall.invoke({
      url,
      method,
      data,
    });
    return { data: res.data };
  } catch (err: any) {
    const status = err?.response?.status || err?.status || 500;
    const errorData = err?.response?.data || err?.data;
    const errorText = errorData?.detail || errorData?.message || err?.message || `Entity API error ${status}`;
    throw new Error(`Entity API error ${status}: ${errorText}`);
  }
}

function createEntityClient(entityName: string) {
  const getBasePath = () => `/api/v1/entities/${entityName}`;

  return {
    async query(params?: QueryParams) {
      const qs = buildQueryString(params);
      const url = `${getBasePath()}${qs}`;
      return invokeEntity(url, 'GET');
    },

    async queryAll(params?: QueryParams) {
      const qs = buildQueryString(params);
      const url = `${getBasePath()}/all${qs}`;
      return invokeEntity(url, 'GET');
    },

    async get(params: GetParams) {
      const fieldsQs = params.fields?.length
        ? `?fields=${params.fields.join(',')}`
        : '';
      const url = `${getBasePath()}/${params.id}${fieldsQs}`;
      return invokeEntity(url, 'GET');
    },

    async create(params: CreateParams) {
      const url = getBasePath();
      return invokeEntity(url, 'POST', params.data);
    },

    async update(params: UpdateParams) {
      const url = `${getBasePath()}/${params.id}`;
      return invokeEntity(url, 'PUT', params.data);
    },

    async delete(params: DeleteParams) {
      const url = `${getBasePath()}/${params.id}`;
      return invokeEntity(url, 'DELETE');
    },

    async deleteBatch(params: BatchDeleteParams) {
      const url = `${getBasePath()}/batch`;
      return invokeEntity(url, 'DELETE', { ids: params.ids });
    },

    async createBatch(params: BatchCreateParams) {
      const url = `${getBasePath()}/batch`;
      return invokeEntity(url, 'POST', { items: params.data });
    },

    async updateBatch(params: BatchUpdateParams) {
      const url = `${getBasePath()}/batch`;
      return invokeEntity(url, 'PUT', { items: params.data });
    },
  };
}

/**
 * Entity API that uses SDK's apiCall for proper authentication.
 * Usage: entities.contracts.query({ ... })
 * Same interface as client.entities but routes through SDK's authenticated requests
 */
export const entities = {
  employees: createEntityClient('employees'),
  attendance_records: createEntityClient('attendance_records'),
  ideas: createEntityClient('ideas'),
  overtime_records: createEntityClient('overtime_records'),
  violations: createEntityClient('violations'),
  performance_records: createEntityClient('performance_records'),
  contracts: createEntityClient('contracts'),
  performance_kpis: createEntityClient('performance_kpis'),
  client_contracts: createEntityClient('client_contracts'),
  incentive_records: createEntityClient('incentive_records'),
  incentive_settings: createEntityClient('incentive_settings'),
  contract_alerts: createEntityClient('contract_alerts'),
  clickup_settings: createEntityClient('clickup_settings'),
  clickup_sync_logs: createEntityClient('clickup_sync_logs'),
  clickup_kpi_snapshots: createEntityClient('clickup_kpi_snapshots'),
  monthly_performance_results: createEntityClient('monthly_performance_results'),
  pending_users: createEntityClient('pending_users'),
  user_roles: createEntityClient('user_roles'),
  reward_settings: createEntityClient('reward_settings'),
};