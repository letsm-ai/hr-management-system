import { client } from './api';

/**
 * Simplified auth API that delegates to the SDK.
 * The SDK handles all platform-specific routing (App-Host headers, token exchange, etc.)
 */
class RPApi {
  async getCurrentUser() {
    try {
      const res = await client.auth.me();
      return res?.data || null;
    } catch {
      return null;
    }
  }

  async login() {
    client.auth.toLogin();
  }

  async logout() {
    try {
      await client.auth.logout();
    } catch {
      localStorage.removeItem('token');
      window.location.href = '/';
    }
  }
}

export const authApi = new RPApi();