import { ContractRecord, Employee } from './hr-api';

interface ContractPDFData {
  contract: ContractRecord;
  employee: Employee;
  companyName?: string;
  companyRegister?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyEmail?: string;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return '_______________';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
}

function formatNum(n: number): string {
  return n.toLocaleString('ar-EG', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
}

function getContractTypeLabel(type: string): { fixed: boolean } {
  return { fixed: type === 'محدد المدة' };
}

function getJobDuties(jobTitle: string): string {
  const duties: Record<string, string[]> = {
    'مطور برمجيات': [
      'تصميم وتطوير تطبيقات الويب والموبايل وفقاً للمتطلبات المحددة',
      'كتابة أكواد نظيفة وقابلة للصيانة مع الالتزام بأفضل الممارسات البرمجية',
      'تصميم وإنشاء قواعد البيانات المناسبة للمشاريع وكتابة الاستعلامات وتحسين أدائها',
      'ربط التطبيقات مع واجهات برمجة التطبيقات (APIs) الخارجية وضمان التكامل السلس بين الأنظمة',
      'إجراء اختبارات الوحدات (Unit Tests) واختبارات التكامل ومراجعة الأكواد وإصلاح الأخطاء البرمجية',
      'كتابة التوثيق التقني للأكواد والأنظمة المطورة وإعداد أدلة الاستخدام والتشغيل',
      'استخدام أنظمة التحكم بالإصدارات (Git) لإدارة الأكواد والالتزام بمعايير التسمية والتفريع',
      'متابعة أداء التطبيقات المنشورة وحل المشاكل التقنية وتطبيق التحديثات الأمنية والتحسينات الدورية',
      'التنسيق مع فريق التصميم لتحويل التصاميم إلى واجهات تفاعلية ومراجعة ملفات التصميم',
      'المشاركة في اجتماعات التخطيط وتقدير الوقت اللازم للمهام وتحديث حالة المهام على نظام إدارة المشاريع',
    ],
    'مصمم جرافيكي': [
      'تصميم الهويات البصرية والشعارات',
      'إنشاء التصاميم الإعلانية والتسويقية',
      'تصميم المواد المطبوعة (بروشورات، كتيبات، ملصقات)',
      'تصميم محتوى وسائل التواصل الاجتماعي',
      'العمل على تصاميم المواقع الإلكترونية والتطبيقات',
      'التنسيق مع فريق التسويق والمحتوى',
      'الالتزام بمعايير الهوية البصرية للعلامة التجارية',
    ],
    'مصور فوتوغرافي': [
      'تصوير المنتجات والأحداث والفعاليات',
      'معالجة وتحرير الصور باستخدام البرامج المتخصصة',
      'إعداد وتجهيز مواقع التصوير',
      'الحفاظ على معدات التصوير وصيانتها',
      'التنسيق مع فريق التسويق لتلبية احتياجات المحتوى البصري',
    ],
    'مصور فيديو': [
      'تصوير الفيديوهات الإعلانية والتسويقية',
      'مونتاج وتحرير الفيديوهات',
      'إعداد السيناريوهات المرئية',
      'التنسيق مع فريق الإنتاج والتسويق',
      'إدارة معدات التصوير والإنتاج',
    ],
    'كاتب محتوى': [
      'كتابة محتوى وسائل التواصل الاجتماعي (فيسبوك، إنستجرام، اكس، لينكدإن، سناب شات وغيرها)',
      'إعداد مقالات ونصوص التسويق بالبريد الإلكتروني',
      'كتابة مقالات المدونة والمواد المرتبطة (نصوص الإنفوجرافيك، دراسات الحالة، العروض التقديمية)',
      'كتابة نصوص الإعلانات والحملات الترويجية',
      'إعداد الملفات التعريفية بالشركة والكُتيبات التعريفية بالمنتجات والخدمات',
      'إعداد تصور محتوى الفعاليات والحملات التسويقية',
      'إدارة منصات التواصل الاجتماعي والتفاعل مع الجمهور',
      'تحليل أداء المحتوى المنشور وتقديم التقارير والتوصيات للتحسين',
      'التنسيق مع فريق التصميم والإنتاج لإنتاج المحتوى البصري',
      'مراجعة وتدقيق المحتوى لغوياً وضمان اتساقه مع صوت العلامة التجارية',
    ],
    'مدير حساب': [
      'إدارة حسابات العملاء وبناء العلاقات',
      'التنسيق بين العميل والفرق الداخلية',
      'إعداد التقارير الدورية للعملاء',
      'متابعة تنفيذ المشاريع وضمان الجودة',
      'تطوير فرص الأعمال مع العملاء الحاليين',
    ],
    'مدير قسم الإبداع': [
      'قيادة وإدارة فريق التصميم والإبداع',
      'وضع الرؤية الإبداعية للمشاريع',
      'مراجعة واعتماد التصاميم النهائية',
      'التنسيق مع الأقسام الأخرى لضمان جودة المخرجات',
      'تطوير معايير الجودة الإبداعية',
    ],
    'مدير مالي إداري': [
      'إدارة الشؤون المالية والمحاسبية وإدخال وتحديث المعاملات المالية في نظام Odoo',
      'مراجعة كشوفات الحسابات البنكية وإجراء التسوية الأسبوعية والتحقيق في التباينات',
      'إدارة المشتريات والمصروفات والمبيعات وتصنيف المعاملات المحاسبية',
      'متابعة مدفوعات العملاء يومياً وإرسال التذكيرات للمتأخرين وإغلاق المشاريع عند استلام الدفعات',
      'تحسين التدفقات النقدية والتعاون مع فريق المبيعات لتوقع الإيرادات المستقبلية',
      'إدارة الرواتب والعقود وتجهيز كشوفات الرواتب الشهرية وضمان دفعها في الوقت المحدد',
      'إدارة المشاريع والاستثمارات باستخدام Trello ومتابعة الجداول الزمنية والميزانيات',
      'مراقبة أداء الموظفين وإجراء مراجعات دورية وتقديم التغذية الراجعة',
      'إجراء التدقيقات الداخلية السنوية ومراجعة البيانات المالية وضوابط المخاطر',
      'إدارة الوثائق القانونية وإعداد التقارير الدورية للمدير التنفيذي',
    ],
    'موظف إداري': [
      'إدخال وتحديث المعاملات المالية بشكل دوري على نظام Odoo والتحقق من دقة البيانات',
      'مراجعة كشوفات الحسابات البنكية أسبوعياً وإعداد تقارير التسوية البنكية',
      'تصنيف المعاملات المحاسبية (مشتريات، مصروفات، مبيعات) والتحقق من المستندات المساندة',
      'متابعة المدفوعات الواردة من العملاء يومياً وإرسال التذكيرات للمتأخرين في السداد',
      'تحليل بيانات التدفقات النقدية وتنفيذ استراتيجيات لتحسين الوضع المالي',
      'إدارة المشاريع والاستثمارات باستخدام Trello ومتابعة تقدم المشاريع والميزانيات',
      'مراقبة أداء الموظفين وتتبع الحضور والانضباط ومعالجة الشكاوى',
      'إجراء التدقيقات الداخلية ومراجعة البيانات المالية وضوابط المخاطر',
      'حفظ ومراجعة الوثائق القانونية وضمان امتثالها لجميع اللوائح السارية',
      'إعداد التقارير الدورية حول مؤشرات الأداء الرئيسية (KPIs) وتقديمها للمدير التنفيذي',
    ],
    'منسق مالي إداري': [
      'إدخال وتحديث المعاملات المالية بشكل دوري على نظام Odoo والتحقق من دقة البيانات',
      'مراجعة كشوفات الحسابات البنكية أسبوعياً وإعداد تقارير التسوية البنكية',
      'تصنيف المعاملات المحاسبية (مشتريات، مصروفات، مبيعات) والتحقق من المستندات المساندة',
      'متابعة المدفوعات الواردة من العملاء يومياً وإرسال التذكيرات للمتأخرين في السداد',
      'تحليل بيانات التدفقات النقدية وتنفيذ استراتيجيات لتحسين الوضع المالي',
      'إدارة الرواتب والعقود وتجهيز كشوفات الرواتب الشهرية',
      'تنظيم وتخزين الوثائق المالية والقانونية عبر جوجل درايف',
      'إدارة المشاريع والاستثمارات ومتابعة تنفيذ المشاريع الحالية والمستقبلية',
      'مراقبة وتحليل أداء الموظفين بشكل دوري وتقديم التقارير والتوصيات',
      'إعداد التقارير المالية والإدارية الدورية للمدير التنفيذي',
    ],
  };

  // Try exact match first, then partial match
  const exactMatch = duties[jobTitle];
  if (exactMatch) return exactMatch.map(d => `<li>${d}</li>`).join('\n');

  for (const [key, val] of Object.entries(duties)) {
    if (jobTitle.includes(key) || key.includes(jobTitle)) {
      return val.map(d => `<li>${d}</li>`).join('\n');
    }
  }

  // Default duties
  return [
    'أداء المهام والواجبات المتعلقة بالوظيفة المتفق عليها',
    'الالتزام بسياسات وإجراءات الشركة',
    'التعاون مع فريق العمل لتحقيق أهداف الشركة',
    'تقديم التقارير الدورية عن سير العمل',
    'تطوير المهارات المهنية باستمرار',
  ].map(d => `<li>${d}</li>`).join('\n');
}

interface JobDescriptionDetail {
  categories: { title: string; duties: string[] }[];
  workMechanism: string[];
  kpis: string[];
}

function getDetailedJobDescription(jobTitle: string): JobDescriptionDetail {
  const descriptions: Record<string, JobDescriptionDetail> = {
    'مطور برمجيات': {
      categories: [
        {
          title: 'التطوير والبرمجة',
          duties: [
            'تصميم وتطوير تطبيقات الويب والموبايل وفقاً للمتطلبات المحددة من العميل أو الفريق الداخلي',
            'كتابة أكواد نظيفة وقابلة للصيانة مع الالتزام بأفضل الممارسات البرمجية ومعايير الجودة',
            'تصميم وإنشاء قواعد البيانات المناسبة للمشاريع وكتابة الاستعلامات وتحسين أدائها',
            'ربط التطبيقات مع واجهات برمجة التطبيقات (APIs) الخارجية وضمان التكامل السلس بين الأنظمة',
          ],
        },
        {
          title: 'الاختبار وضمان الجودة',
          duties: [
            'إجراء اختبارات الوحدات (Unit Tests) واختبارات التكامل لضمان جودة الأكواد',
            'مراجعة الأكواد البرمجية (Code Review) وإصلاح الأخطاء البرمجية بشكل دوري',
            'كتابة التوثيق التقني للأكواد والأنظمة المطورة وإعداد أدلة الاستخدام والتشغيل',
            'استخدام أنظمة التحكم بالإصدارات (Git) لإدارة الأكواد والالتزام بمعايير التسمية والتفريع',
          ],
        },
        {
          title: 'الصيانة والتنسيق',
          duties: [
            'متابعة أداء التطبيقات المنشورة وحل المشاكل التقنية وتطبيق التحديثات الأمنية والتحسينات الدورية',
            'التنسيق مع فريق التصميم لتحويل التصاميم إلى واجهات تفاعلية ومراجعة ملفات التصميم (Figma/Adobe XD)',
            'المشاركة في اجتماعات التخطيط وتقدير الوقت اللازم للمهام وتحديث حالة المهام على نظام إدارة المشاريع',
            'تقديم الدعم الفني للفرق الداخلية والعملاء وحل المشاكل التقنية الطارئة',
          ],
        },
      ],
      workMechanism: [
        'استلام المهام عبر نظام إدارة المشاريع (Trello/Jira) مع تحديد الأولويات والمواعيد النهائية',
        'تحليل المتطلبات الفنية وتقسيمها إلى مهام فرعية قابلة للتنفيذ',
        'تطوير الحلول البرمجية وفقاً لمنهجية Agile مع تقديم تحديثات يومية عن التقدم',
        'رفع الأكواد على منصة Git مع كتابة رسائل واضحة للتغييرات (Commit Messages)',
        'إجراء الاختبارات قبل نشر أي تحديث على بيئة الإنتاج',
        'تقديم تقرير أسبوعي عن المهام المنجزة والتحديات والخطط المستقبلية',
      ],
      kpis: [
        'نسبة إنجاز المهام في الوقت المحدد (الهدف: 90% أو أعلى)',
        'عدد الأخطاء البرمجية المكتشفة بعد النشر (الهدف: أقل من 5 شهرياً)',
        'جودة الأكواد البرمجية وفقاً لمعايير المراجعة (الهدف: 85% أو أعلى)',
        'سرعة الاستجابة للمشاكل التقنية الطارئة (الهدف: خلال 4 ساعات)',
        'مستوى رضا العملاء والفرق الداخلية عن الحلول المقدمة',
      ],
    },
    'مصمم جرافيكي': {
      categories: [
        {
          title: 'التصميم والإبداع',
          duties: [
            'تصميم الهويات البصرية الكاملة والشعارات وفقاً لمتطلبات العملاء ومعايير العلامة التجارية',
            'إنشاء التصاميم الإعلانية والتسويقية للحملات الرقمية والمطبوعة',
            'تصميم المواد المطبوعة (بروشورات، كتيبات، ملصقات، بطاقات أعمال)',
            'تصميم محتوى وسائل التواصل الاجتماعي بأحجام وأنماط متنوعة',
          ],
        },
        {
          title: 'التصميم الرقمي والتنسيق',
          duties: [
            'تصميم واجهات المواقع الإلكترونية والتطبيقات (UI/UX) وفقاً لأفضل الممارسات',
            'إعداد ملفات التصميم الجاهزة للطباعة والنشر الرقمي بالمقاسات المطلوبة',
            'التنسيق مع فريق التسويق والمحتوى لضمان اتساق الرسائل البصرية',
            'الالتزام بمعايير الهوية البصرية للعلامة التجارية في جميع التصاميم',
          ],
        },
      ],
      workMechanism: [
        'استلام طلبات التصميم عبر نظام إدارة المشاريع مع الملخص الإبداعي (Creative Brief)',
        'إعداد المسودات الأولية (Mockups) وعرضها للمراجعة والاعتماد',
        'تنفيذ التعديلات المطلوبة وتسليم الملفات النهائية بالصيغ المطلوبة',
        'تنظيم وأرشفة ملفات التصميم على Google Drive/Dropbox بشكل منظم',
        'تقديم تقرير أسبوعي عن المشاريع المنجزة والجارية',
      ],
      kpis: [
        'نسبة إنجاز التصاميم في الوقت المحدد (الهدف: 90% أو أعلى)',
        'عدد التعديلات المطلوبة لكل تصميم (الهدف: أقل من 3 جولات)',
        'مستوى رضا العملاء عن جودة التصاميم (الهدف: 85% أو أعلى)',
        'الالتزام بمعايير الهوية البصرية في جميع التصاميم',
      ],
    },
    'كاتب محتوى': {
      categories: [
        {
          title: 'كتابة المحتوى الرقمي',
          duties: [
            'كتابة محتوى وسائل التواصل الاجتماعي (فيسبوك، إنستجرام، اكس، لينكدإن، سناب شات وغيرها)',
            'إعداد مقالات ونصوص التسويق بالبريد الإلكتروني (Email Marketing)',
            'كتابة مقالات المدونة والمواد المرتبطة (نصوص الإنفوجرافيك، دراسات الحالة، العروض التقديمية)',
            'كتابة نصوص الإعلانات والحملات الترويجية (Google Ads, Meta Ads)',
          ],
        },
        {
          title: 'إدارة المحتوى والتنسيق',
          duties: [
            'إعداد الملفات التعريفية بالشركة والكُتيبات التعريفية بالمنتجات والخدمات',
            'إعداد تصور محتوى الفعاليات والحملات التسويقية وتقويم المحتوى الشهري',
            'إدارة منصات التواصل الاجتماعي والتفاعل مع الجمهور والرد على التعليقات',
            'تحليل أداء المحتوى المنشور وتقديم التقارير والتوصيات للتحسين',
            'التنسيق مع فريق التصميم والإنتاج لإنتاج المحتوى البصري المصاحب',
            'مراجعة وتدقيق المحتوى لغوياً وضمان اتساقه مع صوت العلامة التجارية',
          ],
        },
      ],
      workMechanism: [
        'إعداد تقويم المحتوى الشهري بالتنسيق مع فريق التسويق واعتماده من المدير المباشر',
        'كتابة المحتوى وفقاً للجدول الزمني المحدد مع مراعاة SEO والكلمات المفتاحية',
        'مراجعة المحتوى لغوياً وتدقيقه قبل التسليم لفريق التصميم',
        'جدولة المنشورات على المنصات المختلفة باستخدام أدوات الجدولة المعتمدة',
        'إعداد تقرير أداء المحتوى الشهري مع التوصيات والتحسينات',
      ],
      kpis: [
        'نسبة الالتزام بتقويم المحتوى الشهري (الهدف: 95% أو أعلى)',
        'معدل التفاعل على المنشورات (الهدف: زيادة 10% شهرياً)',
        'جودة المحتوى اللغوية (الهدف: أقل من 2 أخطاء لغوية لكل 1000 كلمة)',
        'عدد المقالات والمحتوى المنشور شهرياً وفقاً للخطة المعتمدة',
      ],
    },
    'مصور فوتوغرافي': {
      categories: [
        {
          title: 'التصوير والإنتاج',
          duties: [
            'تصوير المنتجات والأحداث والفعاليات بجودة احترافية عالية',
            'معالجة وتحرير الصور باستخدام البرامج المتخصصة (Lightroom, Photoshop)',
            'إعداد وتجهيز مواقع التصوير والإضاءة المناسبة',
            'التصوير الإبداعي للحملات التسويقية والإعلانية',
          ],
        },
        {
          title: 'الإدارة والتنسيق',
          duties: [
            'الحفاظ على معدات التصوير وصيانتها بشكل دوري',
            'التنسيق مع فريق التسويق والمحتوى لتلبية احتياجات المحتوى البصري',
            'تنظيم وأرشفة الصور بشكل منهجي على أنظمة التخزين المعتمدة',
            'تسليم الصور المعالجة في الوقت المحدد وبالصيغ المطلوبة',
          ],
        },
      ],
      workMechanism: [
        'استلام طلبات التصوير مع الملخص الإبداعي والجدول الزمني',
        'إعداد خطة التصوير وتجهيز المعدات والموقع قبل الموعد المحدد',
        'تنفيذ جلسة التصوير وفقاً للرؤية الإبداعية المعتمدة',
        'معالجة وتحرير الصور وتسليمها خلال 48 ساعة من التصوير',
        'أرشفة الصور الأصلية والمعالجة على النظام المعتمد',
      ],
      kpis: [
        'جودة الصور المسلمة ومطابقتها للمعايير المطلوبة',
        'الالتزام بمواعيد التسليم المحددة (الهدف: 95% أو أعلى)',
        'عدد جلسات التصوير المنجزة شهرياً',
        'مستوى رضا العملاء والفرق الداخلية عن جودة الصور',
      ],
    },
    'مصور فيديو': {
      categories: [
        {
          title: 'التصوير والإنتاج',
          duties: [
            'تصوير الفيديوهات الإعلانية والتسويقية بجودة احترافية',
            'مونتاج وتحرير الفيديوهات باستخدام البرامج المتخصصة (Premiere Pro, After Effects)',
            'إعداد السيناريوهات المرئية والقصص المصورة (Storyboard)',
            'تصوير المقابلات والفعاليات والأحداث الخاصة',
          ],
        },
        {
          title: 'الإدارة والتنسيق',
          duties: [
            'التنسيق مع فريق الإنتاج والتسويق لضمان تنفيذ الرؤية الإبداعية',
            'إدارة معدات التصوير والإنتاج وصيانتها بشكل دوري',
            'تسليم الفيديوهات بالصيغ والأحجام المطلوبة لكل منصة',
            'أرشفة المواد المصورة الخام والنهائية بشكل منظم',
          ],
        },
      ],
      workMechanism: [
        'استلام طلبات الإنتاج مع الملخص الإبداعي والسيناريو المعتمد',
        'إعداد خطة الإنتاج وتجهيز المعدات والفريق والموقع',
        'تنفيذ التصوير وفقاً للسيناريو والرؤية الإبداعية',
        'المونتاج والتحرير وإضافة المؤثرات والموسيقى المناسبة',
        'تسليم النسخة النهائية بعد اعتماد المراجعات',
      ],
      kpis: [
        'جودة الفيديوهات المنتجة ومطابقتها للمعايير المطلوبة',
        'الالتزام بمواعيد التسليم المحددة (الهدف: 90% أو أعلى)',
        'عدد الفيديوهات المنتجة شهرياً وفقاً للخطة',
        'معدل التفاعل على الفيديوهات المنشورة',
      ],
    },
    'مدير حساب': {
      categories: [
        {
          title: 'إدارة العملاء',
          duties: [
            'إدارة حسابات العملاء وبناء علاقات طويلة الأمد معهم',
            'التنسيق بين العميل والفرق الداخلية (تصميم، محتوى، تطوير) لضمان تنفيذ المشاريع',
            'إعداد التقارير الدورية للعملاء عن أداء الحملات والمشاريع',
            'متابعة تنفيذ المشاريع وضمان الجودة والالتزام بالمواعيد',
          ],
        },
        {
          title: 'تطوير الأعمال',
          duties: [
            'تطوير فرص الأعمال مع العملاء الحاليين واقتراح خدمات إضافية',
            'إعداد العروض التقديمية والمقترحات التجارية للعملاء',
            'حل المشاكل والتحديات التي تواجه العملاء بشكل استباقي',
            'جمع ملاحظات العملاء وتحويلها إلى تحسينات في الخدمات',
          ],
        },
      ],
      workMechanism: [
        'عقد اجتماعات دورية مع العملاء (أسبوعية/شهرية) لمتابعة المشاريع',
        'إعداد ملخصات المشاريع (Briefs) وتوزيعها على الفرق المختصة',
        'متابعة تقدم المهام عبر نظام إدارة المشاريع وتحديث العملاء',
        'إعداد التقارير الشهرية وعرضها على العملاء مع التوصيات',
        'تقييم رضا العملاء بشكل دوري واتخاذ الإجراءات التصحيحية',
      ],
      kpis: [
        'مستوى رضا العملاء (الهدف: 90% أو أعلى)',
        'نسبة تجديد العقود مع العملاء الحاليين (الهدف: 85% أو أعلى)',
        'قيمة المبيعات الإضافية من العملاء الحاليين',
        'الالتزام بمواعيد تسليم المشاريع (الهدف: 95% أو أعلى)',
      ],
    },
    'مدير قسم الإبداع': {
      categories: [
        {
          title: 'القيادة والإدارة',
          duties: [
            'قيادة وإدارة فريق التصميم والإبداع وتوزيع المهام وفقاً للأولويات',
            'وضع الرؤية الإبداعية للمشاريع والحملات التسويقية',
            'مراجعة واعتماد التصاميم النهائية قبل تسليمها للعملاء',
            'تطوير معايير الجودة الإبداعية وضمان الالتزام بها',
          ],
        },
        {
          title: 'التطوير والتنسيق',
          duties: [
            'التنسيق مع الأقسام الأخرى لضمان جودة المخرجات واتساقها',
            'تدريب وتطوير أعضاء الفريق ورفع مستوى مهاراتهم',
            'متابعة أحدث الاتجاهات في التصميم والإبداع وتطبيقها',
            'إعداد التقارير الدورية عن أداء القسم والمشاريع المنجزة',
          ],
        },
      ],
      workMechanism: [
        'عقد اجتماع أسبوعي مع الفريق لمراجعة المهام وتوزيع العمل',
        'مراجعة جميع المخرجات الإبداعية قبل التسليم النهائي',
        'التنسيق مع مديري الحسابات لفهم متطلبات العملاء بدقة',
        'إعداد تقرير شهري عن أداء القسم وتقديمه للإدارة العليا',
        'إجراء تقييم دوري لأداء أعضاء الفريق وتقديم التغذية الراجعة',
      ],
      kpis: [
        'جودة المخرجات الإبداعية ومستوى رضا العملاء',
        'نسبة إنجاز المشاريع في الوقت المحدد (الهدف: 90% أو أعلى)',
        'تطوير مهارات أعضاء الفريق (عدد التدريبات/الورش)',
        'عدد الأفكار الإبداعية المبتكرة المقدمة شهرياً',
      ],
    },
    'مدير مالي إداري': {
      categories: [
        {
          title: 'الإدارة المالية والمحاسبية',
          duties: [
            'إدارة الشؤون المالية والمحاسبية وإدخال وتحديث المعاملات المالية في نظام Odoo',
            'مراجعة كشوفات الحسابات البنكية وإجراء التسوية الأسبوعية والتحقيق في التباينات',
            'إدارة المشتريات والمصروفات والمبيعات وتصنيف المعاملات المحاسبية بدقة',
            'متابعة مدفوعات العملاء يومياً وإرسال التذكيرات للمتأخرين وإغلاق المشاريع عند استلام الدفعات',
            'تحسين التدفقات النقدية والتعاون مع فريق المبيعات لتوقع الإيرادات المستقبلية',
          ],
        },
        {
          title: 'الإدارة والموارد البشرية',
          duties: [
            'إدارة الرواتب والعقود وتجهيز كشوفات الرواتب الشهرية وضمان دفعها في الوقت المحدد',
            'إدارة المشاريع والاستثمارات باستخدام Trello ومتابعة الجداول الزمنية والميزانيات',
            'مراقبة أداء الموظفين وإجراء مراجعات دورية وتقديم التغذية الراجعة',
            'إجراء التدقيقات الداخلية السنوية ومراجعة البيانات المالية وضوابط المخاطر',
            'إدارة الوثائق القانونية وإعداد التقارير الدورية للمدير التنفيذي',
          ],
        },
      ],
      workMechanism: [
        'إدخال المعاملات المالية يومياً على نظام Odoo والتحقق من دقة البيانات',
        'إجراء التسوية البنكية أسبوعياً ومعالجة أي تباينات خلال 24 ساعة',
        'إعداد كشوفات الرواتب قبل نهاية كل شهر بأسبوع على الأقل',
        'تقديم التقارير المالية الشهرية للمدير التنفيذي في أول أسبوع من كل شهر',
        'إجراء التدقيق الداخلي ربع سنوي وتقديم التوصيات للتحسين',
        'متابعة المدفوعات المتأخرة يومياً وإرسال التذكيرات وفقاً للسياسة المعتمدة',
      ],
      kpis: [
        'دقة البيانات المالية المدخلة (الهدف: 99% أو أعلى)',
        'نسبة التحصيل من العملاء (الهدف: 90% خلال 30 يوم)',
        'الالتزام بمواعيد صرف الرواتب (الهدف: 100%)',
        'إنجاز التسوية البنكية الأسبوعية في الوقت المحدد',
        'تقليل المصروفات غير الضرورية بنسبة محددة سنوياً',
      ],
    },
    'موظف إداري': {
      categories: [
        {
          title: 'المهام المالية والمحاسبية',
          duties: [
            'إدخال وتحديث المعاملات المالية بشكل دوري على نظام Odoo والتحقق من دقة البيانات',
            'مراجعة كشوفات الحسابات البنكية أسبوعياً وإعداد تقارير التسوية البنكية',
            'تصنيف المعاملات المحاسبية (مشتريات، مصروفات، مبيعات) والتحقق من المستندات المساندة',
            'متابعة المدفوعات الواردة من العملاء يومياً وإرسال التذكيرات للمتأخرين في السداد',
            'تحليل بيانات التدفقات النقدية وتنفيذ استراتيجيات لتحسين الوضع المالي',
          ],
        },
        {
          title: 'المهام الإدارية والتنظيمية',
          duties: [
            'إدارة المشاريع والاستثمارات باستخدام Trello ومتابعة تقدم المشاريع والميزانيات',
            'مراقبة أداء الموظفين وتتبع الحضور والانضباط ومعالجة الشكاوى',
            'إجراء التدقيقات الداخلية ومراجعة البيانات المالية وضوابط المخاطر',
            'حفظ ومراجعة الوثائق القانونية وضمان امتثالها لجميع اللوائح السارية',
            'إعداد التقارير الدورية حول مؤشرات الأداء الرئيسية (KPIs) وتقديمها للمدير التنفيذي',
          ],
        },
      ],
      workMechanism: [
        'إدخال المعاملات المالية يومياً على نظام Odoo مع التحقق من دقة كل معاملة',
        'إجراء التسوية البنكية كل يوم أحد وتقديم التقرير للمدير المالي',
        'متابعة المدفوعات المتأخرة يومياً وإرسال التذكيرات وفقاً للجدول المعتمد',
        'تحديث حالة المشاريع على Trello بشكل يومي ورفع التقارير الأسبوعية',
        'إعداد تقرير الأداء الشهري وتقديمه في أول أسبوع من كل شهر',
        'تنظيم وأرشفة الوثائق المالية والقانونية عبر Google Drive بشكل منظم',
      ],
      kpis: [
        'دقة إدخال البيانات المالية (الهدف: 98% أو أعلى)',
        'الالتزام بمواعيد التسوية البنكية الأسبوعية',
        'نسبة متابعة المدفوعات المتأخرة (الهدف: 100% يومياً)',
        'إنجاز التقارير الدورية في المواعيد المحددة',
        'مستوى تنظيم الوثائق والملفات الإدارية',
      ],
    },
    'منسق مالي إداري': {
      categories: [
        {
          title: 'التنسيق المالي',
          duties: [
            'إدخال وتحديث المعاملات المالية بشكل دوري على نظام Odoo والتحقق من دقة البيانات',
            'مراجعة كشوفات الحسابات البنكية أسبوعياً وإعداد تقارير التسوية البنكية',
            'تصنيف المعاملات المحاسبية (مشتريات، مصروفات، مبيعات) والتحقق من المستندات المساندة',
            'متابعة المدفوعات الواردة من العملاء يومياً وإرسال التذكيرات للمتأخرين في السداد',
            'تحليل بيانات التدفقات النقدية وتنفيذ استراتيجيات لتحسين الوضع المالي',
          ],
        },
        {
          title: 'التنسيق الإداري',
          duties: [
            'إدارة الرواتب والعقود وتجهيز كشوفات الرواتب الشهرية',
            'تنظيم وتخزين الوثائق المالية والقانونية عبر جوجل درايف',
            'إدارة المشاريع والاستثمارات ومتابعة تنفيذ المشاريع الحالية والمستقبلية',
            'مراقبة وتحليل أداء الموظفين بشكل دوري وتقديم التقارير والتوصيات',
            'إعداد التقارير المالية والإدارية الدورية للمدير التنفيذي',
          ],
        },
      ],
      workMechanism: [
        'إدخال المعاملات المالية يومياً على نظام Odoo مع التحقق من دقة كل معاملة',
        'إجراء التسوية البنكية أسبوعياً وتقديم التقرير للمدير المالي',
        'تجهيز كشوفات الرواتب الشهرية قبل نهاية كل شهر بأسبوع',
        'تحديث ملفات المشاريع والاستثمارات بشكل أسبوعي',
        'إعداد التقارير الدورية وتقديمها في المواعيد المحددة',
      ],
      kpis: [
        'دقة إدخال البيانات المالية (الهدف: 98% أو أعلى)',
        'الالتزام بمواعيد التسوية البنكية والتقارير الدورية',
        'نسبة متابعة المدفوعات المتأخرة (الهدف: 100% يومياً)',
        'إنجاز كشوفات الرواتب في الوقت المحدد (الهدف: 100%)',
      ],
    },
  };

  // Try exact match first, then partial match
  const exactMatch = descriptions[jobTitle];
  if (exactMatch) return exactMatch;

  for (const [key, val] of Object.entries(descriptions)) {
    if (jobTitle.includes(key) || key.includes(jobTitle)) {
      return val;
    }
  }

  // Default
  return {
    categories: [
      {
        title: 'المهام والمسؤوليات الرئيسية',
        duties: [
          'أداء المهام والواجبات المتعلقة بالوظيفة المتفق عليها بكفاءة وإتقان',
          'الالتزام بسياسات وإجراءات الشركة والمعايير المهنية المعتمدة',
          'التعاون مع فريق العمل لتحقيق أهداف الشركة والقسم',
          'تقديم التقارير الدورية عن سير العمل والإنجازات',
          'تطوير المهارات المهنية باستمرار ومواكبة التطورات في مجال العمل',
        ],
      },
    ],
    workMechanism: [
      'استلام المهام عبر نظام إدارة المشاريع المعتمد',
      'تنفيذ المهام وفقاً للأولويات والمواعيد المحددة',
      'تقديم تقارير دورية عن التقدم والإنجازات',
      'التنسيق مع الفرق المعنية لضمان جودة المخرجات',
    ],
    kpis: [
      'نسبة إنجاز المهام في الوقت المحدد',
      'جودة المخرجات ومطابقتها للمعايير المطلوبة',
      'مستوى التعاون والعمل الجماعي',
      'الالتزام بسياسات وإجراءات الشركة',
    ],
  };
}

export function generateContractPDF(data: ContractPDFData): void {
  const { contract, employee } = data;
  const companyName = data.companyName || '_______________';
  const companyRegister = data.companyRegister || '_______________';
  const companyAddress = data.companyAddress || '_______________';
  const companyPhone = data.companyPhone || '_______________';
  const companyEmail = data.companyEmail || '_______________';

  const totalSalary = contract.basicSalary + contract.housingAllowance +
    contract.transportAllowance + contract.foodAllowance + contract.otherAllowances;

  const contractTypeInfo = getContractTypeLabel(contract.contractType);
  const fixedCheck = contractTypeInfo.fixed ? '☑' : '☐';
  const openCheck = contractTypeInfo.fixed ? '☐' : '☑';

  const logoUrl = window.location.origin + '/assets/logo.png';
  const jobDuties = getJobDuties(employee.jobTitle);
  const detailedDesc = getDetailedJobDescription(employee.jobTitle);

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>عقد عمل - ${employee.fullName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&display=swap');
  
  * { margin: 0; padding: 0; box-sizing: border-box; }
  
  body {
    font-family: 'Noto Naskh Arabic', 'Arial', serif;
    font-size: 13px;
    line-height: 1.9;
    color: #1a1a1a;
    background: #e5e7eb;
    direction: rtl;
  }

  .page {
    width: 210mm;
    min-height: 297mm;
    margin: 10px auto;
    padding: 20mm 20mm 25mm 20mm;
    background: white;
    position: relative;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
  }

  .page-break { page-break-before: always; }

  .header {
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 3px double #1E3A5F;
    padding-bottom: 20px;
  }

  .header img {
    max-width: 120px;
    max-height: 80px;
    margin-bottom: 10px;
  }

  .header h1 {
    font-size: 26px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 5px;
  }

  .header h2 {
    font-size: 18px;
    font-weight: 600;
    color: #4a5568;
  }

  .contract-meta {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    color: #718096;
    margin-bottom: 20px;
    padding: 8px 12px;
    background: #f7fafc;
    border-radius: 6px;
  }

  .section {
    margin-bottom: 20px;
  }

  .section-title {
    font-size: 15px;
    font-weight: 700;
    color: #1E3A5F;
    background: #f0f4f8;
    padding: 8px 15px;
    border-right: 4px solid #1E3A5F;
    margin-bottom: 12px;
    border-radius: 0 4px 4px 0;
  }

  .parties-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 15px;
  }

  .party-box {
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 15px;
    background: #fafbfc;
  }

  .party-box h3 {
    font-size: 14px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 10px;
    border-bottom: 1px solid #e2e8f0;
    padding-bottom: 5px;
  }

  .party-box .field {
    display: flex;
    justify-content: space-between;
    padding: 4px 0;
    font-size: 12px;
    border-bottom: 1px dotted #e2e8f0;
  }

  .party-box .field:last-child { border-bottom: none; }

  .party-box .field .label {
    font-weight: 600;
    color: #4a5568;
  }

  .party-box .field .value {
    color: #1a1a1a;
    font-weight: 500;
  }

  .article {
    margin-bottom: 18px;
  }

  .article-title {
    font-size: 14px;
    font-weight: 700;
    color: #2d3748;
    margin-bottom: 8px;
    padding-bottom: 4px;
    border-bottom: 1px solid #e2e8f0;
  }

  .article-content {
    padding-right: 15px;
    font-size: 13px;
    line-height: 2;
  }

  .article-content p {
    margin-bottom: 5px;
  }

  .bullet-list {
    list-style: none;
    padding: 0;
  }

  .bullet-list li {
    padding: 2px 0;
    padding-right: 20px;
    position: relative;
  }

  .bullet-list li::before {
    content: '•';
    position: absolute;
    right: 0;
    color: #1E3A5F;
    font-weight: bold;
  }

  .salary-table {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0;
    font-size: 13px;
  }

  .salary-table th, .salary-table td {
    border: 1px solid #d1d5db;
    padding: 8px 12px;
    text-align: right;
  }

  .salary-table th {
    background: #1E3A5F;
    color: white;
    font-weight: 600;
  }

  .salary-table .total-row {
    background: #f0f4f8;
    font-weight: 700;
    color: #1E3A5F;
  }

  .salary-table .total-row td {
    border-top: 2px solid #1E3A5F;
  }

  .checkbox-line {
    font-size: 14px;
    margin-bottom: 5px;
  }

  .numbered-list {
    list-style: none;
    padding: 0;
    counter-reset: item;
  }

  .numbered-list li {
    padding: 3px 0;
    padding-right: 25px;
    position: relative;
    counter-increment: item;
  }

  .numbered-list li::before {
    content: counter(item) '.';
    position: absolute;
    right: 0;
    font-weight: 600;
    color: #1E3A5F;
  }

  .sub-list {
    list-style: none;
    padding-right: 20px;
    margin-top: 5px;
  }

  .sub-list li {
    padding-right: 15px;
  }

  .sub-list li::before {
    content: '•';
    color: #4a5568;
  }

  .signatures {
    margin-top: 50px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
  }

  .sig-box {
    text-align: center;
    padding: 20px;
    border-top: 2px solid #1E3A5F;
  }

  .sig-box h4 {
    font-size: 14px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 40px;
  }

  .sig-box .sig-line {
    border-bottom: 1px dotted #999;
    margin-bottom: 10px;
    padding-bottom: 5px;
    font-size: 12px;
    color: #555;
  }

  .footer-note {
    margin-top: 30px;
    padding: 10px 15px;
    background: #f8f9fa;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 11px;
    color: #718096;
    text-align: center;
  }

  .work-info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px 20px;
    font-size: 13px;
  }

  .work-info-grid .item {
    display: flex;
    gap: 5px;
  }

  .work-info-grid .item .label {
    font-weight: 600;
    color: #4a5568;
    white-space: nowrap;
  }

  .highlight-box {
    background: #fffbeb;
    border: 1px solid #fbbf24;
    border-radius: 6px;
    padding: 10px 15px;
    margin: 10px 0;
    font-size: 12px;
    color: #92400e;
  }

  .page-number {
    position: absolute;
    bottom: 15mm;
    left: 50%;
    transform: translateX(-50%);
    font-size: 11px;
    color: #718096;
    font-family: 'Noto Naskh Arabic', Arial, serif;
  }

  .appendix-title {
    text-align: center;
    font-size: 20px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 25px;
    padding: 15px;
    background: linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
    border: 2px solid #1E3A5F;
    border-radius: 8px;
  }

  .appendix-subtitle {
    font-size: 11px;
    font-weight: 500;
    color: #718096;
    margin-top: 5px;
  }

  .job-info-header {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 20px;
    padding: 12px 15px;
    background: #f7fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 13px;
  }

  .job-info-header .info-item {
    display: flex;
    gap: 8px;
  }

  .job-info-header .info-label {
    font-weight: 700;
    color: #1E3A5F;
    white-space: nowrap;
  }

  .job-info-header .info-value {
    color: #2d3748;
    font-weight: 500;
  }

  .duty-category {
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    overflow: hidden;
  }

  .duty-category-title {
    font-size: 14px;
    font-weight: 700;
    color: white;
    background: #1E3A5F;
    padding: 10px 15px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .duty-category-title .cat-number {
    background: rgba(255,255,255,0.2);
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 700;
  }

  .duty-category-content {
    padding: 12px 15px;
    background: #fafbfc;
  }

  .duty-category-content .duty-item {
    padding: 6px 0;
    padding-right: 22px;
    position: relative;
    font-size: 12.5px;
    line-height: 1.8;
    border-bottom: 1px dotted #e2e8f0;
  }

  .duty-category-content .duty-item:last-child {
    border-bottom: none;
  }

  .duty-category-content .duty-item::before {
    content: '◆';
    position: absolute;
    right: 0;
    color: #1E3A5F;
    font-size: 8px;
    top: 10px;
  }

  .work-mechanism-box {
    margin-top: 20px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    overflow: hidden;
  }

  .work-mechanism-title {
    font-size: 14px;
    font-weight: 700;
    color: white;
    background: #2d5a3f;
    padding: 10px 15px;
  }

  .work-mechanism-content {
    padding: 12px 15px;
    background: #f0fdf4;
  }

  .mechanism-item {
    padding: 5px 0;
    padding-right: 22px;
    position: relative;
    font-size: 12.5px;
    line-height: 1.8;
    border-bottom: 1px dotted #d1fae5;
  }

  .mechanism-item:last-child {
    border-bottom: none;
  }

  .mechanism-item::before {
    content: '✓';
    position: absolute;
    right: 0;
    color: #2d5a3f;
    font-weight: bold;
    font-size: 11px;
    top: 8px;
  }

  .kpi-box {
    margin-top: 20px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    overflow: hidden;
  }

  .kpi-title {
    font-size: 14px;
    font-weight: 700;
    color: white;
    background: #7c3aed;
    padding: 10px 15px;
  }

  .kpi-content {
    padding: 12px 15px;
    background: #faf5ff;
  }

  .kpi-item {
    padding: 5px 0;
    padding-right: 22px;
    position: relative;
    font-size: 12.5px;
    line-height: 1.8;
    border-bottom: 1px dotted #e9d5ff;
  }

  .kpi-item:last-child {
    border-bottom: none;
  }

  .kpi-item::before {
    content: '📊';
    position: absolute;
    right: 0;
    font-size: 10px;
    top: 7px;
  }

  .appendix-signatures {
    margin-top: 40px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
  }

  .appendix-sig-box {
    text-align: center;
    padding: 15px;
    border-top: 2px solid #1E3A5F;
  }

  .appendix-sig-box .sig-label {
    font-size: 13px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 30px;
  }

  .appendix-sig-box .sig-line {
    border-bottom: 1px dotted #999;
    margin-bottom: 8px;
    padding-bottom: 4px;
    font-size: 11px;
    color: #555;
  }

  @media print {
    body { background: white; }
    .page { margin: 0; padding: 15mm; box-shadow: none; }
    .no-print { display: none !important; }
  }
</style>
</head>
<body>

<div class="no-print" style="text-align:center; padding:15px; background:#1E3A5F; color:white; position:sticky; top:0; z-index:100;">
  <button onclick="window.print()" style="padding:10px 30px; font-size:16px; background:white; color:#1E3A5F; border:none; border-radius:6px; cursor:pointer; font-weight:bold; font-family:'Noto Naskh Arabic',Arial,serif;">
    🖨️ طباعة / تحميل PDF
  </button>
  <button onclick="window.close()" style="padding:10px 30px; font-size:16px; background:transparent; color:white; border:1px solid white; border-radius:6px; cursor:pointer; margin-right:10px; font-family:'Noto Naskh Arabic',Arial,serif;">
    إغلاق
  </button>
</div>

<!-- PAGE 1 -->
<div class="page">
  <div class="page-number">صفحة 1 من 4</div>
  <!-- Header with Logo -->
  <div class="header">
    <img src="${logoUrl}" alt="شعار الشركة" onerror="this.style.display='none'" />
    <h1>عقد عمل</h1>
    <h2>${employee.jobTitle} (${employee.department})</h2>
  </div>

  <!-- Contract Meta Info -->
  <div class="contract-meta">
    <span>رقم العقد: ${contract.id}</span>
    <span>حالة العقد: ${contract.status}</span>
    <span>تاريخ الإنشاء: ${formatDate(contract.startDate)}</span>
  </div>

  <!-- Parties -->
  <div class="section">
    <div class="section-title">أطراف العقد</div>
    <div class="parties-grid">
      <div class="party-box">
        <h3>الطرف الأول (صاحب العمل)</h3>
        <div class="field"><span class="label">اسم المنشأة:</span> <span class="value">${companyName}</span></div>
        <div class="field"><span class="label">السجل التجاري:</span> <span class="value">${companyRegister}</span></div>
        <div class="field"><span class="label">العنوان:</span> <span class="value">${companyAddress}</span></div>
        <div class="field"><span class="label">الهاتف:</span> <span class="value">${companyPhone}</span></div>
        <div class="field"><span class="label">البريد الإلكتروني:</span> <span class="value">${companyEmail}</span></div>
      </div>
      <div class="party-box">
        <h3>الطرف الثاني (العامل)</h3>
        <div class="field"><span class="label">الاسم الكامل:</span> <span class="value">${employee.fullName}</span></div>
        <div class="field"><span class="label">الرقم الوظيفي:</span> <span class="value">${employee.empCode || '_______________'}</span></div>
        <div class="field"><span class="label">المسمى الوظيفي:</span> <span class="value">${employee.jobTitle}</span></div>
        <div class="field"><span class="label">القسم:</span> <span class="value">${employee.department}</span></div>
        <div class="field"><span class="label">تاريخ التعيين:</span> <span class="value">${formatDate(employee.hireDate)}</span></div>
        <div class="field"><span class="label">البريد الإلكتروني:</span> <span class="value">${employee.email || '_______________'}</span></div>
      </div>
    </div>
  </div>

  <!-- Contract Terms -->
  <div class="section">
    <div class="section-title">بنود العقد</div>
    
    <!-- Article 1: Subject -->
    <div class="article">
      <div class="article-title">المادة الأولى: موضوع العقد</div>
      <div class="article-content">
        <p>يتعهد الطرف الثاني بالعمل لدى الطرف الأول بوظيفة <strong>${employee.jobTitle}</strong> في قسم <strong>${employee.department}</strong>، ويشمل ذلك على سبيل المثال لا الحصر:</p>
        <ul class="bullet-list">
          ${jobDuties}
        </ul>
      </div>
    </div>

    <!-- Article 2: Duration -->
    <div class="article">
      <div class="article-title">المادة الثانية: مدة العقد</div>
      <div class="article-content">
        <p class="checkbox-line">نوع العقد: &nbsp; ${fixedCheck} محدد المدة &nbsp;&nbsp;&nbsp; ${openCheck} غير محدد المدة</p>
        <div class="work-info-grid">
          <div class="item"><span class="label">تاريخ البدء:</span> <span>${formatDate(contract.startDate)}</span></div>
          <div class="item"><span class="label">تاريخ الانتهاء:</span> <span>${contract.endDate ? formatDate(contract.endDate) : '_______________'}</span></div>
          <div class="item"><span class="label">فترة الاختبار:</span> <span>${contract.probationPeriod} أشهر</span></div>
          <div class="item"><span class="label">فترة الإشعار:</span> <span>${contract.noticePeriod} يوم</span></div>
        </div>
        <div class="highlight-box">
          ملاحظة: فترة الاختبار بحد أقصى 3 أشهر وفقاً للمادة 38 من قانون العمل العماني
        </div>
      </div>
    </div>

    <!-- Article 3: Salary -->
    <div class="article">
      <div class="article-title">المادة الثالثة: الأجر والبدلات</div>
      <div class="article-content">
        <table class="salary-table">
          <thead>
            <tr>
              <th>البند</th>
              <th>المبلغ (ر.ع) شهرياً</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>الراتب الأساسي</td>
              <td>${formatNum(contract.basicSalary)}</td>
            </tr>
            <tr>
              <td>بدل السكن</td>
              <td>${formatNum(contract.housingAllowance)}</td>
            </tr>
            <tr>
              <td>بدل المواصلات</td>
              <td>${formatNum(contract.transportAllowance)}</td>
            </tr>
            <tr>
              <td>بدل الطعام</td>
              <td>${formatNum(contract.foodAllowance)}</td>
            </tr>
            <tr>
              <td>بدلات أخرى</td>
              <td>${formatNum(contract.otherAllowances)}</td>
            </tr>
            <tr class="total-row">
              <td>إجمالي الأجر الشهري</td>
              <td>${formatNum(totalSalary)}</td>
            </tr>
          </tbody>
        </table>
        <p>يُصرف الأجر في نهاية كل شهر ميلادي عن طريق التحويل البنكي.</p>
      </div>
    </div>

    <!-- Article 4: Working Hours -->
    <div class="article">
      <div class="article-title">المادة الرابعة: ساعات العمل</div>
      <div class="article-content">
        <p>وفقاً للمادة 71 من قانون العمل العماني:</p>
        <ul class="bullet-list">
          <li>ساعات العمل اليومية: <strong>${contract.workingHours}</strong> ساعات</li>
          <li>ساعات العمل الأسبوعية: <strong>${contract.workingHours * 5}</strong> ساعة (حد أقصى 45 ساعة)</li>
          <li>أيام العمل: من الأحد إلى الخميس</li>
          <li>يوم الراحة الأسبوعية: الجمعة والسبت</li>
        </ul>
      </div>
    </div>

    <!-- Article 5: Leaves -->
    <div class="article">
      <div class="article-title">المادة الخامسة: الإجازات</div>
      <div class="article-content">
        <p>وفقاً لقانون العمل العماني:</p>
        <ol class="numbered-list">
          <li><strong>الإجازة السنوية (المادة 75):</strong> ${contract.annualLeaveDays} يوم عمل مدفوعة الأجر سنوياً، تُحدد بالاتفاق بين الطرفين</li>
          <li><strong>الإجازة المرضية (المادة 82):</strong> أول أسبوعين بأجر كامل، الأربعة أسابيع التالية بنصف الأجر، تتطلب شهادة طبية معتمدة</li>
          <li><strong>إجازة الأمومة (المادة 83):</strong> 50 يوم مدفوعة الأجر (للموظفات)</li>
          <li><strong>إجازات خاصة:</strong> إجازة وفاة 3 أيام مدفوعة، إجازة زواج 3 أيام مدفوعة، إجازة الحج 10 أيام مدفوعة (مرة واحدة طوال فترة الخدمة)</li>
          <li><strong>الإجازات الرسمية:</strong> حسب التقويم الرسمي لسلطنة عمان</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<!-- PAGE 2 -->
<div class="page page-break">
  <div class="page-number">صفحة 2 من 4</div>
  <!-- Continue header on page 2 -->
  <div style="text-align:center; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid #1E3A5F;">
    <img src="${logoUrl}" alt="شعار الشركة" style="max-width:80px; max-height:50px;" onerror="this.style.display='none'" />
    <p style="font-size:12px; color:#718096; margin-top:5px;">عقد عمل - ${employee.fullName} - ${employee.jobTitle} (تابع)</p>
  </div>

  <div class="section">
    <!-- Article 6: Social Insurance -->
    <div class="article">
      <div class="article-title">المادة السادسة: التأمينات الاجتماعية</div>
      <div class="article-content">
        <p>يلتزم الطرفان بالمساهمة في صندوق الحماية الاجتماعية:</p>
        <ul class="bullet-list">
          <li>مساهمة صاحب العمل: <strong>11.5%</strong> من الأجر الأساسي (${formatNum(contract.basicSalary * 0.115)} ر.ع)</li>
          <li>مساهمة العامل: <strong>7%</strong> من الأجر الأساسي (${formatNum(contract.basicSalary * 0.07)} ر.ع)</li>
        </ul>
        <p>يتم خصم مساهمة العامل من راتبه الشهري وتحويلها مع مساهمة صاحب العمل إلى صندوق الحماية الاجتماعية.</p>
      </div>
    </div>

    <!-- Article 7: Employee Obligations -->
    <div class="article">
      <div class="article-title">المادة السابعة: التزامات العامل</div>
      <div class="article-content">
        <p>يلتزم الطرف الثاني بما يلي:</p>
        <ol class="numbered-list">
          <li>أداء العمل بإخلاص وأمانة وكفاءة</li>
          <li>الالتزام بسياسات وإجراءات الشركة</li>
          <li>الحفاظ على سرية معلومات الشركة</li>
          <li>الالتزام بمواعيد العمل</li>
          <li>احترام زملاء العمل والعملاء</li>
          <li>الحفاظ على ممتلكات الشركة</li>
          <li>الالتزام بقواعد السلامة والصحة المهنية</li>
          <li>تطوير المهارات المهنية باستمرار</li>
          <li>إبلاغ الإدارة عن أي مشاكل فوراً</li>
          <li>الالتزام بقواعد السلوك المهني</li>
        </ol>
      </div>
    </div>

    <!-- Article 8: Employer Obligations -->
    <div class="article">
      <div class="article-title">المادة الثامنة: التزامات صاحب العمل</div>
      <div class="article-content">
        <p>يلتزم الطرف الأول بما يلي:</p>
        <ol class="numbered-list">
          <li>صرف الأجر المتفق عليه في موعده</li>
          <li>توفير بيئة عمل آمنة ومناسبة</li>
          <li>تسجيل العامل في صندوق الحماية الاجتماعية</li>
          <li>منح الإجازات المستحقة وفقاً للقانون</li>
          <li>توفير التدريب اللازم لتطوير مهارات العامل</li>
          <li>توفير الأدوات والموارد اللازمة للعمل</li>
          <li>احترام حقوق العامل وفقاً للقانون</li>
        </ol>
      </div>
    </div>

    <!-- Article 9: Termination -->
    <div class="article">
      <div class="article-title">المادة التاسعة: إنهاء العقد</div>
      <div class="article-content">
        <p>وفقاً للمواد 40 و 41 من قانون العمل العماني:</p>
        <ol class="numbered-list">
          <li><strong>للعقود غير محددة المدة:</strong> يجوز لأي من الطرفين إنهاء العقد بإشعار كتابي قبل ${contract.noticePeriod} يوم على الأقل، ويجوز الاستعاضة عن مدة الإشعار بأجر مماثل</li>
          <li><strong>للعقود محددة المدة:</strong> ينتهي العقد بانتهاء مدته، ويجوز إنهاؤه قبل ذلك بالاتفاق بين الطرفين</li>
          <li><strong>حالات الإنهاء الفوري:</strong>
            <ul class="sub-list">
              <li>الاعتداء على صاحب العمل أو أحد زملاء العمل</li>
              <li>عدم الالتزام بتعليمات السلامة رغم التحذير</li>
              <li>الغياب بدون عذر مشروع لمدة 7 أيام متصلة أو 10 أيام متقطعة</li>
              <li>إفشاء أسرار العمل</li>
              <li>الثبوت النهائي لارتكاب جريمة مخلة بالشرف</li>
            </ul>
          </li>
        </ol>
      </div>
    </div>

    <!-- Article 10: End of Service -->
    <div class="article">
      <div class="article-title">المادة العاشرة: مكافأة نهاية الخدمة</div>
      <div class="article-content">
        <p>وفقاً للمادة 95 من قانون العمل العماني:</p>
        <p>يستحق العامل عند انتهاء خدمته مكافأة نهاية الخدمة تُحسب كالتالي:</p>
        <ul class="bullet-list">
          <li>أجر <strong>15 يوم</strong> عن كل سنة من السنوات الخمس الأولى</li>
          <li>أجر <strong>شهر كامل</strong> عن كل سنة من السنوات التالية</li>
        </ul>
        <div class="highlight-box">
          <strong>ملاحظات هامة:</strong><br/>
          • تُحسب المكافأة على أساس آخر أجر أساسي (${formatNum(contract.basicSalary)} ر.ع)<br/>
          • لا تُحسب البدلات ضمن المكافأة<br/>
          • في حالة الاستقالة قبل 3 سنوات: يستحق ثلث المكافأة<br/>
          • في حالة الاستقالة بعد 3 سنوات وقبل 5 سنوات: يستحق ثلثي المكافأة<br/>
          • في حالة الاستقالة بعد 5 سنوات: يستحق المكافأة كاملة
        </div>
      </div>
    </div>
  </div>
</div>

<!-- PAGE 3 -->
<div class="page page-break">
  <div class="page-number">صفحة 3 من 4</div>
  <!-- Continue header on page 3 -->
  <div style="text-align:center; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid #1E3A5F;">
    <img src="${logoUrl}" alt="شعار الشركة" style="max-width:80px; max-height:50px;" onerror="this.style.display='none'" />
    <p style="font-size:12px; color:#718096; margin-top:5px;">عقد عمل - ${employee.fullName} - ${employee.jobTitle} (تابع)</p>
  </div>

  <div class="section">
    <!-- Article 11: Confidentiality -->
    <div class="article">
      <div class="article-title">المادة الحادية عشرة: السرية وعدم المنافسة</div>
      <div class="article-content">
        <p><strong>1. السرية:</strong></p>
        <ul class="bullet-list">
          <li>يلتزم العامل بالحفاظ على سرية جميع معلومات الشركة</li>
          <li>يلتزم بعدم إفشاء أي معلومات تجارية أو فنية</li>
          <li>يستمر هذا الالتزام حتى بعد انتهاء العقد</li>
        </ul>
        <p style="margin-top:10px;"><strong>2. عدم المنافسة:</strong></p>
        <ul class="bullet-list">
          <li>يلتزم العامل بعدم العمل لدى منافس مباشر خلال فترة العقد</li>
          <li>يلتزم بعدم استقطاب عملاء الشركة لمدة _____ بعد انتهاء العقد</li>
          <li>يلتزم بعدم استقطاب موظفي الشركة لمدة _____ بعد انتهاء العقد</li>
        </ul>
      </div>
    </div>

    <!-- Article 12: Disputes -->
    <div class="article">
      <div class="article-title">المادة الثانية عشرة: تسوية المنازعات</div>
      <div class="article-content">
        <p>في حالة نشوء أي خلاف حول تفسير أو تنفيذ هذا العقد:</p>
        <ol class="numbered-list">
          <li>يتم حل الخلاف ودياً بين الطرفين</li>
          <li>إذا تعذر ذلك، يُحال الخلاف إلى دائرة العمل المختصة</li>
          <li>تطبق أحكام قانون العمل العماني على ما لم يرد به نص في هذا العقد</li>
        </ol>
      </div>
    </div>

    <!-- Article 13: General -->
    <div class="article">
      <div class="article-title">المادة الثالثة عشرة: أحكام عامة</div>
      <div class="article-content">
        <ol class="numbered-list">
          <li>هذا العقد خاضع لأحكام قانون العمل العماني</li>
          <li>يُحرر هذا العقد من نسختين، لكل طرف نسخة للعمل بموجبها</li>
          <li>أي تعديل على هذا العقد يجب أن يكون كتابياً وموقعاً من الطرفين</li>
          <li>يسري هذا العقد من تاريخ توقيعه من الطرفين</li>
        </ol>
      </div>
    </div>

    ${contract.notes ? `
    <!-- Additional Notes -->
    <div class="article">
      <div class="article-title">ملاحظات إضافية</div>
      <div class="article-content">
        <p>${contract.notes}</p>
      </div>
    </div>
    ` : ''}

    <!-- Signatures -->
    <div class="signatures">
      <div class="sig-box">
        <h4>الطرف الأول (صاحب العمل)</h4>
        <div class="sig-line">الاسم: ${companyName}</div>
        <div class="sig-line">التوقيع: _______________</div>
        <div class="sig-line">التاريخ: ${contract.signedDate ? formatDate(contract.signedDate) : '_______________'}</div>
        <div class="sig-line">الختم: _______________</div>
      </div>
      <div class="sig-box">
        <h4>الطرف الثاني (العامل)</h4>
        <div class="sig-line">الاسم: ${employee.fullName}</div>
        <div class="sig-line">الرقم الوظيفي: ${employee.empCode || '_______________'}</div>
        <div class="sig-line">التوقيع: _______________</div>
        <div class="sig-line">التاريخ: ${contract.signedDate ? formatDate(contract.signedDate) : '_______________'}</div>
      </div>
    </div>

    <div class="footer-note">
      هذا العقد مُعد وفقاً لأحكام قانون العمل العماني الصادر بالمرسوم السلطاني رقم 35/2003 وتعديلاته
      <br/>
      تم إنشاء هذا العقد بتاريخ ${formatDate(new Date().toISOString().split('T')[0])}
    </div>
  </div>
</div>

<!-- PAGE 4: APPENDIX - DETAILED JOB DESCRIPTION -->
<div class="page page-break">
  <div class="page-number">صفحة 4 من 4</div>
  <!-- Appendix header -->
  <div style="text-align:center; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid #1E3A5F;">
    <img src="${logoUrl}" alt="شعار الشركة" style="max-width:80px; max-height:50px;" onerror="this.style.display='none'" />
    <p style="font-size:12px; color:#718096; margin-top:5px;">عقد عمل - ${employee.fullName} - ${employee.jobTitle} (ملحق)</p>
  </div>

  <div class="appendix-title">
    ملحق (أ): الوصف الوظيفي التفصيلي وآلية العمل
    <div class="appendix-subtitle">هذا الملحق جزء لا يتجزأ من عقد العمل رقم ${contract.id}</div>
  </div>

  <!-- Job Info Header -->
  <div class="job-info-header">
    <div class="info-item"><span class="info-label">الموظف:</span> <span class="info-value">${employee.fullName}</span></div>
    <div class="info-item"><span class="info-label">المسمى الوظيفي:</span> <span class="info-value">${employee.jobTitle}</span></div>
    <div class="info-item"><span class="info-label">القسم:</span> <span class="info-value">${employee.department}</span></div>
    <div class="info-item"><span class="info-label">تاريخ العقد:</span> <span class="info-value">${formatDate(contract.startDate)}</span></div>
  </div>

  <!-- Section 1: Detailed Duties by Category -->
  <div class="section">
    <div class="section-title">أولاً: المهام والمسؤوليات التفصيلية</div>
    ${detailedDesc.categories.map((cat, idx) => `
    <div class="duty-category">
      <div class="duty-category-title">
        <span class="cat-number">${idx + 1}</span>
        ${cat.title}
      </div>
      <div class="duty-category-content">
        ${cat.duties.map(d => `<div class="duty-item">${d}</div>`).join('\n        ')}
      </div>
    </div>
    `).join('\n    ')}
  </div>

  <!-- Section 2: Work Mechanism -->
  <div class="work-mechanism-box">
    <div class="work-mechanism-title">ثانياً: آلية العمل والتنفيذ</div>
    <div class="work-mechanism-content">
      ${detailedDesc.workMechanism.map(m => `<div class="mechanism-item">${m}</div>`).join('\n      ')}
    </div>
  </div>

  <!-- Section 3: KPIs -->
  <div class="kpi-box">
    <div class="kpi-title">ثالثاً: مؤشرات الأداء الرئيسية (KPIs)</div>
    <div class="kpi-content">
      ${detailedDesc.kpis.map(k => `<div class="kpi-item">${k}</div>`).join('\n      ')}
    </div>
  </div>

  <!-- Appendix Note -->
  <div class="highlight-box" style="margin-top:20px;">
    <strong>ملاحظة:</strong> يُعد هذا الملحق جزءاً لا يتجزأ من عقد العمل المبرم بين الطرفين. يحق للطرف الأول تعديل المهام والمسؤوليات بما يتناسب مع متطلبات العمل ومصلحة الشركة، على أن يتم إخطار الطرف الثاني بذلك كتابياً.
  </div>

  <!-- Appendix Signatures -->
  <div class="appendix-signatures">
    <div class="appendix-sig-box">
      <div class="sig-label">الطرف الأول (صاحب العمل)</div>
      <div class="sig-line">الاسم: ${companyName}</div>
      <div class="sig-line">التوقيع: _______________</div>
      <div class="sig-line">التاريخ: ${contract.signedDate ? formatDate(contract.signedDate) : '_______________'}</div>
    </div>
    <div class="appendix-sig-box">
      <div class="sig-label">الطرف الثاني (العامل)</div>
      <div class="sig-line">الاسم: ${employee.fullName}</div>
      <div class="sig-line">التوقيع: _______________</div>
      <div class="sig-line">التاريخ: ${contract.signedDate ? formatDate(contract.signedDate) : '_______________'}</div>
    </div>
  </div>
</div>

</body>
</html>`;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
  }
}