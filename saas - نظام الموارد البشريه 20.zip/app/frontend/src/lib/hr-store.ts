// HR Management System - Central Data Store
// All data persisted in localStorage

// ============ TYPE DEFINITIONS ============

export interface Employee {
  id: string;
  fullName: string;
  department: string;
  jobTitle: string;
  hireDate: string;
  basicSalary: number;
  email: string;
  status: string;
  annualLeaveBalance: number;
  dailyWorkHours: number;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  employeeId: string;
  checkIn: string;
  checkOut: string;
  actualHours: number;
  requiredHours: number;
  tardiness: number;
  earlyDeparture: number;
  dayStatus: string;
  absenceType: string;
  notes: string;
  approved: string;
}

export interface LeaveBalanceRecord {
  employeeId: string;
  year: number;
  annualEntitled: number;
  annualUsed: number;
  sickEntitled: number;
  sickUsed: number;
  emergencyUsed: number;
  unpaidUsed: number;
}

export interface PerformanceRecord {
  id: string;
  month: string;
  employeeId: string;
  workQuality: number;
  punctuality: number;
  customerSatisfaction: number;
  teamwork: number;
  initiative: number;
  selfDevelopment: number;
}

export interface IdeaRecord {
  id: string;
  month: string;
  employeeId: string;
  title: string;
  status: string;
  classification: string;
  expectedImpact: string;
  submissionDate: string;
  decisionDate: string;
  revenueGenerated: number;
  notes: string;
}

export interface OvertimeRecord {
  id: string;
  date: string;
  employeeId: string;
  dayType: string;
  overtimeHours: number;
  compensationMethod: string;
  approved: string;
}

export interface ViolationRecord {
  id: string;
  date: string;
  employeeId: string;
  violationType: string;
  details: string;
  severity: string;
  isRepeated: string;
  penalty: string;
  deductionAmount: number;
  deductionDays: number;
  notificationDate: string;
  grievanceStatus: string;
  notes: string;
}

// ============ DROPDOWN OPTIONS ============

export const DEPARTMENTS = [
  'قسم الإبداع',
  'قسم الإدارة',
  'القسم التجاري',
];

export const EMPLOYEE_STATUSES = ['نشط', 'إجازة', 'متوقف مؤقتاً', 'منتهي الخدمة'];

export const DAY_STATUSES = [
  'حاضر',
  'غائب',
  'إجازة سنوية',
  'إجازة مرضية',
  'إجازة طارئة',
  'إجازة بدون راتب',
  'يوم عطلة رسمية',
  'يوم راحة أسبوعية',
];

export const ABSENCE_TYPES = [
  'لا ينطبق',
  'إجازة سنوية مدفوعة',
  'إجازة مرضية مدفوعة',
  'إجازة طارئة مدفوعة',
  'إجازة بدون راتب',
  'غياب بإذن',
  'غياب بدون إذن',
];

export const APPROVAL_STATUSES = ['نعم', 'لا', 'قيد المراجعة', 'لا ينطبق'];

export const IDEA_STATUSES = ['قيد المراجعة', 'مقبولة', 'قيد التنفيذ', 'منفذة', 'مرفوضة'];

export const IDEA_CLASSIFICATIONS = [
  'تحسين العمليات',
  'خدمة جديدة',
  'تحسين خدمة موجودة',
  'توفير التكاليف',
  'زيادة الإيرادات',
];

export const IMPACT_LEVELS = ['عالي جداً', 'عالي', 'متوسط', 'منخفض'];

export const DAY_TYPES = ['يوم عادي', 'إجازة أسبوعية', 'إجازة رسمية'];

export const COMPENSATION_METHODS = ['مكافأة مالية', 'يوم إجازة بديل', 'إضافة للراتب'];

export const VIOLATION_TYPES = [
  'التأخر في تسليم الأعمال',
  'أخطاء متكررة في الأعمال',
  'عدم تحديث نظام Odoo',
  'عدم تسليم التقرير الشهري',
  'التأخر في الحضور (أكثر من 30 دقيقة)',
  'التأخر المتكرر في الحضور',
  'الغياب بدون إذن',
  'الانصراف المبكر المتكرر',
];

export const SEVERITY_LEVELS = ['بسيط', 'متوسط', 'خطير', 'خطير جداً'];

export const RECURRENCE_OPTIONS = [
  'المرة الأولى',
  'المرة الثانية',
  'المرة الثالثة',
  'المرة الرابعة أو أكثر',
];

export const PENALTY_TYPES = [
  'إنذار شفهي',
  'إنذار كتابي',
  'خصم نصف يوم',
  'خصم يوم كامل',
  'خصم يومين',
  'خصم 3 أيام',
  'خصم 5 أيام',
  'إيقاف عن العمل',
  'الفصل',
];

export const GRIEVANCE_STATUSES = [
  'لا يوجد تظلم',
  'تظلم قيد المراجعة',
  'تظلم مقبول',
  'تظلم مرفوض',
];

// ============ STORAGE HELPERS ============

function getStore<T>(key: string): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function setStore<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// ============ EMPLOYEE CRUD ============

export function getEmployees(): Employee[] {
  return getStore<Employee>('hr_employees');
}

export function addEmployee(emp: Omit<Employee, 'id'>): Employee {
  const employees = getEmployees();
  const newEmp: Employee = { ...emp, id: emp.id || `EMP${String(employees.length + 1).padStart(3, '0')}` } as Employee;
  // Fix: if id wasn't in Omit, we need to handle it
  const finalEmp: Employee = { id: `EMP${String(employees.length + 1).padStart(3, '0')}`, ...emp };
  employees.push(finalEmp);
  setStore('hr_employees', employees);
  return finalEmp;
}

export function updateEmployee(id: string, updates: Partial<Employee>): void {
  const employees = getEmployees();
  const idx = employees.findIndex((e) => e.id === id);
  if (idx !== -1) {
    employees[idx] = { ...employees[idx], ...updates };
    setStore('hr_employees', employees);
  }
}

export function deleteEmployee(id: string): void {
  const employees = getEmployees().filter((e) => e.id !== id);
  setStore('hr_employees', employees);
}

export function getEmployeeById(id: string): Employee | undefined {
  return getEmployees().find((e) => e.id === id);
}

export function getEmployeeName(id: string): string {
  const emp = getEmployeeById(id);
  return emp ? emp.fullName : 'غير معروف';
}

// ============ ATTENDANCE CRUD ============

export function getAttendanceRecords(): AttendanceRecord[] {
  return getStore<AttendanceRecord>('hr_attendance');
}

export function addAttendanceRecord(record: Omit<AttendanceRecord, 'id'>): AttendanceRecord {
  const records = getAttendanceRecords();
  const newRecord: AttendanceRecord = { id: generateId(), ...record };
  records.push(newRecord);
  setStore('hr_attendance', records);
  return newRecord;
}

export function updateAttendanceRecord(id: string, updates: Partial<AttendanceRecord>): void {
  const records = getAttendanceRecords();
  const idx = records.findIndex((r) => r.id === id);
  if (idx !== -1) {
    records[idx] = { ...records[idx], ...updates };
    setStore('hr_attendance', records);
  }
}

export function deleteAttendanceRecord(id: string): void {
  const records = getAttendanceRecords().filter((r) => r.id !== id);
  setStore('hr_attendance', records);
}

// ============ IDEAS CRUD ============

export function getIdeas(): IdeaRecord[] {
  return getStore<IdeaRecord>('hr_ideas');
}

export function addIdea(idea: Omit<IdeaRecord, 'id'>): IdeaRecord {
  const ideas = getIdeas();
  const newIdea: IdeaRecord = { id: generateId(), ...idea };
  ideas.push(newIdea);
  setStore('hr_ideas', ideas);
  return newIdea;
}

export function updateIdea(id: string, updates: Partial<IdeaRecord>): void {
  const ideas = getIdeas();
  const idx = ideas.findIndex((i) => i.id === id);
  if (idx !== -1) {
    ideas[idx] = { ...ideas[idx], ...updates };
    setStore('hr_ideas', ideas);
  }
}

export function deleteIdea(id: string): void {
  const ideas = getIdeas().filter((i) => i.id !== id);
  setStore('hr_ideas', ideas);
}

// ============ OVERTIME CRUD ============

export function getOvertimeRecords(): OvertimeRecord[] {
  return getStore<OvertimeRecord>('hr_overtime');
}

export function addOvertimeRecord(record: Omit<OvertimeRecord, 'id'>): OvertimeRecord {
  const records = getOvertimeRecords();
  const newRecord: OvertimeRecord = { id: generateId(), ...record };
  records.push(newRecord);
  setStore('hr_overtime', records);
  return newRecord;
}

export function updateOvertimeRecord(id: string, updates: Partial<OvertimeRecord>): void {
  const records = getOvertimeRecords();
  const idx = records.findIndex((r) => r.id === id);
  if (idx !== -1) {
    records[idx] = { ...records[idx], ...updates };
    setStore('hr_overtime', records);
  }
}

export function deleteOvertimeRecord(id: string): void {
  const records = getOvertimeRecords().filter((r) => r.id !== id);
  setStore('hr_overtime', records);
}

// ============ VIOLATIONS CRUD ============

export function getViolations(): ViolationRecord[] {
  return getStore<ViolationRecord>('hr_violations');
}

export function addViolation(record: Omit<ViolationRecord, 'id'>): ViolationRecord {
  const records = getViolations();
  const newRecord: ViolationRecord = { id: generateId(), ...record };
  records.push(newRecord);
  setStore('hr_violations', records);
  return newRecord;
}

export function updateViolation(id: string, updates: Partial<ViolationRecord>): void {
  const records = getViolations();
  const idx = records.findIndex((r) => r.id === id);
  if (idx !== -1) {
    records[idx] = { ...records[idx], ...updates };
    setStore('hr_violations', records);
  }
}

export function deleteViolation(id: string): void {
  const records = getViolations().filter((r) => r.id !== id);
  setStore('hr_violations', records);
}

// ============ PERFORMANCE CRUD ============

export function getPerformanceRecords(): PerformanceRecord[] {
  return getStore<PerformanceRecord>('hr_performance');
}

export function addPerformanceRecord(record: Omit<PerformanceRecord, 'id'>): PerformanceRecord {
  const records = getPerformanceRecords();
  const newRecord: PerformanceRecord = { id: generateId(), ...record };
  records.push(newRecord);
  setStore('hr_performance', records);
  return newRecord;
}

export function updatePerformanceRecord(id: string, updates: Partial<PerformanceRecord>): void {
  const records = getPerformanceRecords();
  const idx = records.findIndex((r) => r.id === id);
  if (idx !== -1) {
    records[idx] = { ...records[idx], ...updates };
    setStore('hr_performance', records);
  }
}

export function deletePerformanceRecord(id: string): void {
  const records = getPerformanceRecords().filter((r) => r.id !== id);
  setStore('hr_performance', records);
}

// ============ CALCULATION FUNCTIONS ============

export function calculateTardiness(checkIn: string): number {
  if (!checkIn) return 0;
  const [h, m] = checkIn.split(':').map(Number);
  const checkInMinutes = h * 60 + m;
  const startMinutes = 9 * 60; // 09:00
  return Math.max(0, checkInMinutes - startMinutes);
}

export function calculateEarlyDeparture(checkOut: string): number {
  if (!checkOut) return 0;
  const [h, m] = checkOut.split(':').map(Number);
  const checkOutMinutes = h * 60 + m;
  const endMinutes = 17 * 60; // 17:00
  return Math.max(0, endMinutes - checkOutMinutes);
}

export function calculateActualHours(checkIn: string, checkOut: string): number {
  if (!checkIn || !checkOut) return 0;
  const [h1, m1] = checkIn.split(':').map(Number);
  const [h2, m2] = checkOut.split(':').map(Number);
  return Math.max(0, (h2 * 60 + m2 - (h1 * 60 + m1)) / 60);
}

export function calculateOvertimeRate(dayType: string): number {
  if (dayType === 'يوم عادي') return 1.25;
  if (dayType === 'إجازة أسبوعية' || dayType === 'إجازة رسمية') return 1.5;
  return 1;
}

export function calculateOvertimeAmount(
  basicSalary: number,
  hours: number,
  dayType: string
): number {
  const hourlyRate = basicSalary / 176;
  const rate = calculateOvertimeRate(dayType);
  return hours * hourlyRate * rate;
}

export function calculatePerformanceScore(record: PerformanceRecord, employeeId: string, month: string): number {
  const ideas = getIdeas().filter((i) => i.employeeId === employeeId && i.month === month);
  const ideasCount = ideas.length;
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة').length;
  const acceptanceRate = ideasCount > 0 ? (acceptedIdeas / ideasCount) * 100 : 0;

  const ideasScore = ideasCount >= 3 ? 10 : ideasCount * 3.33;
  const acceptanceScore = acceptanceRate >= 20 ? 10 : acceptanceRate / 2;

  return (
    record.workQuality * 0.25 +
    record.punctuality * 0.15 +
    ideasScore * 0.1 +
    acceptanceScore * 0.1 +
    record.customerSatisfaction * 0.15 +
    record.teamwork * 0.1 +
    record.initiative * 0.1 +
    record.selfDevelopment * 0.05
  );
}

export function getPerformanceRating(score: number): string {
  if (score >= 9) return 'ممتاز - استثنائي';
  if (score >= 7) return 'جيد جداً - يفوق التوقعات';
  if (score >= 5) return 'جيد - يلبي التوقعات';
  if (score >= 3) return 'مقبول - يحتاج تحسين';
  return 'ضعيف - يحتاج تدخل فوري';
}

export function getRatingColor(score: number): string {
  if (score >= 9) return 'text-emerald-600 bg-emerald-50';
  if (score >= 7) return 'text-green-600 bg-green-50';
  if (score >= 5) return 'text-yellow-600 bg-yellow-50';
  if (score >= 3) return 'text-orange-600 bg-orange-50';
  return 'text-red-600 bg-red-50';
}

// ============ LEAVE BALANCE CALCULATIONS ============

export function calculateLeaveBalance(employeeId: string, year: number): LeaveBalanceRecord {
  const emp = getEmployeeById(employeeId);
  const attendance = getAttendanceRecords().filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d.getFullYear() === year;
  });

  const annualUsed = attendance.filter((a) => a.absenceType === 'إجازة سنوية مدفوعة').length;
  const sickUsed = attendance.filter((a) => a.absenceType === 'إجازة مرضية مدفوعة').length;
  const emergencyUsed = attendance.filter((a) => a.absenceType === 'إجازة طارئة مدفوعة').length;
  const unpaidUsed = attendance.filter((a) => a.absenceType === 'إجازة بدون راتب').length;

  return {
    employeeId,
    year,
    annualEntitled: emp?.annualLeaveBalance || 30,
    annualUsed,
    sickEntitled: 15,
    sickUsed,
    emergencyUsed,
    unpaidUsed,
  };
}

// ============ MONTHLY STATS ============

export function getMonthlyAttendanceStats(employeeId: string, month: string) {
  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const records = getAttendanceRecords().filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d >= startDate && d <= endDate;
  });

  const presentDays = records.filter((r) => r.dayStatus === 'حاضر').length;
  const absentDays = records.filter((r) => r.dayStatus === 'غائب').length;
  const totalTardiness = records.reduce((sum, r) => sum + (r.tardiness || 0), 0);
  const tardinessCount = records.filter((r) => r.tardiness > 0).length;

  // Calculate working days in month (approximate: exclude weekends)
  let workingDays = 0;
  const current = new Date(startDate);
  while (current <= endDate) {
    const day = current.getDay();
    if (day !== 5 && day !== 6) workingDays++; // Exclude Friday & Saturday
    current.setDate(current.getDate() + 1);
  }

  const attendanceRate = workingDays > 0 ? (presentDays / workingDays) * 100 : 0;

  return {
    presentDays,
    absentDays,
    totalTardiness,
    tardinessCount,
    workingDays,
    attendanceRate,
    totalRecords: records.length,
  };
}

// ============ REWARDS CALCULATION ============

export function calculateMonthlyRewards(employeeId: string, month: string) {
  const emp = getEmployeeById(employeeId);
  if (!emp) return null;

  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  // Overtime rewards
  const overtimeRecords = getOvertimeRecords().filter((o) => {
    const d = new Date(o.date);
    return o.employeeId === employeeId && d >= startDate && d <= endDate && o.approved === 'نعم';
  });
  const overtimeReward = overtimeRecords.reduce(
    (sum, o) => sum + calculateOvertimeAmount(emp.basicSalary, o.overtimeHours, o.dayType),
    0
  );

  // Ideas rewards
  const ideas = getIdeas().filter(
    (i) => i.employeeId === employeeId && i.month === month
  );
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length;
  const ideaReward = acceptedIdeas * 50;
  const ideaRevenue = ideas.reduce((sum, i) => sum + (i.revenueGenerated || 0), 0);

  // Business development commission
  let commission = 0;
  if (ideaRevenue > 0) {
    if (ideaRevenue < 5000) commission = ideaRevenue * 0.03;
    else if (ideaRevenue < 10000) commission = ideaRevenue * 0.05;
    else commission = ideaRevenue * 0.07;
  }

  // Absence deductions
  const attendance = getAttendanceRecords().filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d >= startDate && d <= endDate;
  });
  const unauthorizedAbsences = attendance.filter(
    (a) => a.absenceType === 'غياب بدون إذن'
  ).length;
  const absenceDeduction = unauthorizedAbsences * (emp.basicSalary / 26);

  // Violation deductions
  const violations = getViolations().filter((v) => {
    const d = new Date(v.date);
    return v.employeeId === employeeId && d >= startDate && d <= endDate;
  });
  const violationDeduction = violations.reduce((sum, v) => sum + (v.deductionAmount || 0), 0);

  const totalRewards = overtimeReward + ideaReward + commission;
  const totalDeductions = absenceDeduction + violationDeduction;
  const netAmount = totalRewards - totalDeductions;
  const finalSalary = emp.basicSalary + netAmount;

  return {
    basicSalary: emp.basicSalary,
    overtimeReward: Math.round(overtimeReward * 100) / 100,
    acceptedIdeas,
    ideaReward,
    ideaRevenue,
    commission: Math.round(commission * 100) / 100,
    totalRewards: Math.round(totalRewards * 100) / 100,
    absenceDeduction: Math.round(absenceDeduction * 100) / 100,
    violationDeduction: Math.round(violationDeduction * 100) / 100,
    totalDeductions: Math.round(totalDeductions * 100) / 100,
    netAmount: Math.round(netAmount * 100) / 100,
    finalSalary: Math.round(finalSalary * 100) / 100,
  };
}

// ============ DASHBOARD STATS ============

export function getDashboardStats(month: string) {
  const employees = getEmployees();
  const activeEmployees = employees.filter((e) => e.status === 'نشط');

  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const attendance = getAttendanceRecords().filter((a) => {
    const d = new Date(a.date);
    return d >= startDate && d <= endDate;
  });

  const presentCount = attendance.filter((a) => a.dayStatus === 'حاضر').length;
  const absentCount = attendance.filter((a) => a.dayStatus === 'غائب').length;
  const totalTardiness = attendance.reduce((sum, a) => sum + (a.tardiness || 0), 0);
  const attendanceRate = attendance.length > 0 ? (presentCount / attendance.length) * 100 : 0;

  const ideas = getIdeas().filter((i) => i.month === month);
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length;

  const overtime = getOvertimeRecords().filter((o) => {
    const d = new Date(o.date);
    return d >= startDate && d <= endDate;
  });
  const totalOvertimeHours = overtime.reduce((sum, o) => sum + o.overtimeHours, 0);

  const violations = getViolations().filter((v) => {
    const d = new Date(v.date);
    return d >= startDate && d <= endDate;
  });

  // Calculate total rewards and deductions
  let totalRewards = 0;
  let totalDeductions = 0;
  activeEmployees.forEach((emp) => {
    const rewards = calculateMonthlyRewards(emp.id, month);
    if (rewards) {
      totalRewards += rewards.totalRewards;
      totalDeductions += rewards.totalDeductions;
    }
  });

  // Top 5 employees by attendance
  const employeeAttendance = activeEmployees.map((emp) => {
    const stats = getMonthlyAttendanceStats(emp.id, month);
    return { ...emp, ...stats };
  });
  const top5Attendance = employeeAttendance
    .sort((a, b) => b.attendanceRate - a.attendanceRate)
    .slice(0, 5);

  // Alerts
  const lowAttendance = employeeAttendance.filter(
    (e) => e.attendanceRate < 90 && e.totalRecords > 0
  );
  const repeatedTardiness = employeeAttendance.filter((e) => e.tardinessCount > 3);

  // Department stats
  const deptStats = DEPARTMENTS.map((dept) => {
    const deptEmps = activeEmployees.filter((e) => e.department === dept);
    const deptAttendance = deptEmps.map((emp) => getMonthlyAttendanceStats(emp.id, month));
    const avgAttendance =
      deptAttendance.length > 0
        ? deptAttendance.reduce((sum, s) => sum + s.attendanceRate, 0) / deptAttendance.length
        : 0;
    return { department: dept, employeeCount: deptEmps.length, avgAttendance: Math.round(avgAttendance) };
  }).filter((d) => d.employeeCount > 0);

  return {
    totalEmployees: employees.length,
    activeEmployees: activeEmployees.length,
    attendanceRate: Math.round(attendanceRate * 10) / 10,
    presentCount,
    absentCount,
    totalTardiness,
    totalIdeas: ideas.length,
    acceptedIdeas,
    totalOvertimeHours: Math.round(totalOvertimeHours * 10) / 10,
    totalViolations: violations.length,
    totalRewards: Math.round(totalRewards * 100) / 100,
    totalDeductions: Math.round(totalDeductions * 100) / 100,
    top5Attendance,
    lowAttendance,
    repeatedTardiness,
    deptStats,
  };
}

// ============ DEMO DATA ============

export function loadDemoData(): void {
  if (getEmployees().length > 0) return;

  const employees: Employee[] = [
    { id: 'EMP001', fullName: 'أحمد محمد', department: 'التصميم الجرافيكي', jobTitle: 'مصمم جرافيك', hireDate: '2023-01-15', basicSalary: 800, email: 'ahmed@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
    { id: 'EMP002', fullName: 'فاطمة علي', department: 'التسويق الرقمي', jobTitle: 'أخصائية تسويق', hireDate: '2023-03-01', basicSalary: 900, email: 'fatima@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
    { id: 'EMP003', fullName: 'خالد سعيد', department: 'إدارة المحتوى', jobTitle: 'كاتب محتوى', hireDate: '2023-06-15', basicSalary: 750, email: 'khaled@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
    { id: 'EMP004', fullName: 'مريم حسن', department: 'إدارة الحملات', jobTitle: 'مديرة حملات', hireDate: '2022-11-01', basicSalary: 1000, email: 'mariam@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
    { id: 'EMP005', fullName: 'عمر ناصر', department: 'خدمة العملاء', jobTitle: 'ممثل خدمة عملاء', hireDate: '2024-01-10', basicSalary: 650, email: 'omar@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
    { id: 'EMP006', fullName: 'نورة سالم', department: 'الإدارة', jobTitle: 'مساعدة إدارية', hireDate: '2023-09-01', basicSalary: 700, email: 'noura@company.om', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8 },
  ];
  setStore('hr_employees', employees);

  // Generate attendance for current month (March 2026)
  const attendanceRecords: AttendanceRecord[] = [];
  const currentYear = 2026;
  const currentMonth = 3;

  for (let day = 1; day <= 28; day++) {
    const date = new Date(currentYear, currentMonth - 1, day);
    const dayOfWeek = date.getDay();
    if (dayOfWeek === 5 || dayOfWeek === 6) continue; // Skip Fri/Sat

    employees.forEach((emp) => {
      const rand = Math.random();
      let dayStatus = 'حاضر';
      let absenceType = 'لا ينطبق';
      let checkIn = '';
      let checkOut = '';
      let tardiness = 0;
      let earlyDeparture = 0;
      let actualHours = 0;

      if (rand > 0.92) {
        dayStatus = 'غائب';
        absenceType = rand > 0.96 ? 'غياب بدون إذن' : 'غياب بإذن';
      } else if (rand > 0.88) {
        dayStatus = 'إجازة سنوية';
        absenceType = 'إجازة سنوية مدفوعة';
      } else {
        // Present with some variation
        const lateMinutes = Math.random() > 0.7 ? Math.floor(Math.random() * 45) : 0;
        const earlyMinutes = Math.random() > 0.85 ? Math.floor(Math.random() * 30) : 0;
        const checkInH = 9 + Math.floor(lateMinutes / 60);
        const checkInM = lateMinutes % 60;
        checkIn = `${String(checkInH).padStart(2, '0')}:${String(checkInM).padStart(2, '0')}`;

        const checkOutH = 17 - Math.floor(earlyMinutes / 60);
        const checkOutM = 60 - (earlyMinutes % 60);
        checkOut = checkOutM === 60
          ? `${String(checkOutH).padStart(2, '0')}:00`
          : `${String(checkOutH - 1).padStart(2, '0')}:${String(checkOutM).padStart(2, '0')}`;
        if (earlyMinutes === 0) checkOut = `17:${String(Math.floor(Math.random() * 30)).padStart(2, '0')}`;

        tardiness = lateMinutes;
        earlyDeparture = earlyMinutes;
        actualHours = calculateActualHours(checkIn, checkOut);
      }

      const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      attendanceRecords.push({
        id: generateId(),
        date: dateStr,
        employeeId: emp.id,
        checkIn,
        checkOut,
        actualHours: Math.round(actualHours * 100) / 100,
        requiredHours: emp.dailyWorkHours,
        tardiness,
        earlyDeparture,
        dayStatus,
        absenceType,
        notes: '',
        approved: dayStatus === 'حاضر' ? 'لا ينطبق' : 'نعم',
      });
    });
  }
  setStore('hr_attendance', attendanceRecords);

  // Demo ideas
  const ideas: IdeaRecord[] = [
    { id: generateId(), month: '2026-03', employeeId: 'EMP001', title: 'تصميم هوية بصرية جديدة للعملاء', status: 'مقبولة', classification: 'خدمة جديدة', expectedImpact: 'عالي', submissionDate: '2026-03-05', decisionDate: '2026-03-10', revenueGenerated: 3000, notes: '' },
    { id: generateId(), month: '2026-03', employeeId: 'EMP002', title: 'حملة تسويقية عبر وسائل التواصل', status: 'قيد التنفيذ', classification: 'زيادة الإيرادات', expectedImpact: 'عالي جداً', submissionDate: '2026-03-08', decisionDate: '2026-03-12', revenueGenerated: 8000, notes: '' },
    { id: generateId(), month: '2026-03', employeeId: 'EMP003', title: 'تحسين استراتيجية المحتوى', status: 'مقبولة', classification: 'تحسين العمليات', expectedImpact: 'متوسط', submissionDate: '2026-03-10', decisionDate: '2026-03-15', revenueGenerated: 0, notes: '' },
    { id: generateId(), month: '2026-03', employeeId: 'EMP004', title: 'أتمتة تقارير الحملات', status: 'منفذة', classification: 'توفير التكاليف', expectedImpact: 'عالي', submissionDate: '2026-03-03', decisionDate: '2026-03-07', revenueGenerated: 5000, notes: '' },
  ];
  setStore('hr_ideas', ideas);

  // Demo overtime
  const overtimeRecords: OvertimeRecord[] = [
    { id: generateId(), date: '2026-03-05', employeeId: 'EMP001', dayType: 'يوم عادي', overtimeHours: 3, compensationMethod: 'مكافأة مالية', approved: 'نعم' },
    { id: generateId(), date: '2026-03-12', employeeId: 'EMP002', dayType: 'إجازة أسبوعية', overtimeHours: 5, compensationMethod: 'مكافأة مالية', approved: 'نعم' },
    { id: generateId(), date: '2026-03-15', employeeId: 'EMP004', dayType: 'يوم عادي', overtimeHours: 2, compensationMethod: 'إضافة للراتب', approved: 'نعم' },
    { id: generateId(), date: '2026-03-20', employeeId: 'EMP005', dayType: 'يوم عادي', overtimeHours: 4, compensationMethod: 'مكافأة مالية', approved: 'قيد المراجعة' },
  ];
  setStore('hr_overtime', overtimeRecords);

  // Demo violations
  const violations: ViolationRecord[] = [
    { id: generateId(), date: '2026-03-10', employeeId: 'EMP005', violationType: 'التأخر في الحضور (أكثر من 30 دقيقة)', details: 'تأخر 45 دقيقة', severity: 'بسيط', isRepeated: 'المرة الأولى', penalty: 'إنذار شفهي', deductionAmount: 0, deductionDays: 0, notificationDate: '2026-03-10', grievanceStatus: 'لا يوجد تظلم', notes: '' },
    { id: generateId(), date: '2026-03-18', employeeId: 'EMP003', violationType: 'التأخر في تسليم الأعمال', details: 'تأخر في تسليم تقرير المحتوى الأسبوعي', severity: 'متوسط', isRepeated: 'المرة الثانية', penalty: 'خصم نصف يوم', deductionAmount: 14.42, deductionDays: 0.5, notificationDate: '2026-03-18', grievanceStatus: 'لا يوجد تظلم', notes: '' },
  ];
  setStore('hr_violations', violations);

  // Demo performance
  const performanceRecords: PerformanceRecord[] = employees.map((emp) => ({
    id: generateId(),
    month: '2026-03',
    employeeId: emp.id,
    workQuality: Math.floor(Math.random() * 3) + 7,
    punctuality: Math.floor(Math.random() * 3) + 7,
    customerSatisfaction: Math.floor(Math.random() * 3) + 7,
    teamwork: Math.floor(Math.random() * 3) + 7,
    initiative: Math.floor(Math.random() * 3) + 7,
    selfDevelopment: Math.floor(Math.random() * 3) + 6,
  }));
  setStore('hr_performance', performanceRecords);
}

// ============ UTILITY ============

export function formatCurrency(amount: number): string {
  return `${amount.toFixed(2)} ر.ع`;
}

export function getCurrentMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}