import { ContractRecord, Employee } from './hr-api';

interface NDAPDFData {
  contract: ContractRecord;
  employee: Employee;
  companyName?: string;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return '_______________';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
}

export function generateNDAPDF(data: NDAPDFData): void {
  const { contract, employee } = data;
  const companyName = data.companyName || '_______________';
  const logoUrl = window.location.origin + 'https://mgx-backend-cdn.metadl.com/generate/images/867866/2026-03-04/e9ed9e6f-c904-4331-aaa5-001f695df6bb.png';
  const today = formatDate(new Date().toISOString().split('T')[0]);
  const signedDate = contract.signedDate ? formatDate(contract.signedDate) : '_______________';

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تعهد عدم المنافسة والإفصاح - ${employee.fullName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&display=swap');
  
  * { margin: 0; padding: 0; box-sizing: border-box; }
  
  body {
    font-family: 'Noto Naskh Arabic', 'Arial', serif;
    font-size: 13px;
    line-height: 2;
    color: #1a1a1a;
    background: #e5e7eb;
    direction: rtl;
  }

  .page {
    width: 210mm;
    min-height: 297mm;
    margin: 10px auto;
    padding: 20mm 20mm 25mm 20mm;
    background: white;
    position: relative;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
  }

  .page-break { page-break-before: always; }

  .header {
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 3px double #1E3A5F;
    padding-bottom: 20px;
  }

  .header img {
    max-width: 120px;
    max-height: 80px;
    margin-bottom: 10px;
  }

  .header h1 {
    font-size: 22px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 3px;
  }

  .header h2 {
    font-size: 16px;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 3px;
  }

  .header h3 {
    font-size: 14px;
    font-weight: 500;
    color: #718096;
  }

  .bilingual-title {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    text-align: center;
    margin-bottom: 25px;
  }

  .bilingual-title .en {
    text-align: left;
    font-size: 12px;
    color: #4a5568;
  }

  .bilingual-title .ar {
    text-align: right;
    font-size: 13px;
    color: #1a1a1a;
  }

  .intro-section {
    margin-bottom: 20px;
    padding: 15px;
    background: #f7fafc;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
  }

  .intro-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
  }

  .intro-grid .en {
    text-align: left;
    font-size: 12px;
    color: #4a5568;
    line-height: 1.8;
  }

  .intro-grid .ar {
    text-align: right;
    font-size: 13px;
    color: #1a1a1a;
    line-height: 2;
  }

  .employee-info {
    margin-bottom: 20px;
    padding: 12px 15px;
    background: #fffbeb;
    border: 1px solid #fbbf24;
    border-radius: 6px;
  }

  .employee-info .field {
    display: flex;
    justify-content: space-between;
    padding: 3px 0;
    font-size: 13px;
    border-bottom: 1px dotted #e2e8f0;
  }

  .employee-info .field:last-child { border-bottom: none; }

  .employee-info .field .label {
    font-weight: 600;
    color: #92400e;
  }

  .employee-info .field .value {
    color: #1a1a1a;
    font-weight: 500;
  }

  .clause {
    margin-bottom: 18px;
  }

  .clause-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    padding: 10px 0;
    border-bottom: 1px solid #e2e8f0;
  }

  .clause-content .en {
    text-align: left;
    font-size: 11.5px;
    color: #4a5568;
    line-height: 1.8;
  }

  .clause-content .ar {
    text-align: right;
    font-size: 12.5px;
    color: #1a1a1a;
    line-height: 2;
  }

  .clause-number {
    font-weight: 700;
    color: #1E3A5F;
    font-size: 14px;
    margin-bottom: 5px;
  }

  .sub-clause {
    padding-right: 15px;
    margin-bottom: 8px;
  }

  .sub-clause-label {
    font-weight: 600;
    color: #2d3748;
  }

  .signatures {
    margin-top: 40px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
  }

  .sig-box {
    text-align: center;
    padding: 20px;
    border-top: 2px solid #1E3A5F;
  }

  .sig-box h4 {
    font-size: 14px;
    font-weight: 700;
    color: #1E3A5F;
    margin-bottom: 8px;
  }

  .sig-box .bilingual-label {
    font-size: 11px;
    color: #718096;
    margin-bottom: 2px;
  }

  .sig-box .sig-line {
    border-bottom: 1px dotted #999;
    margin-bottom: 10px;
    padding-bottom: 5px;
    font-size: 12px;
    color: #555;
  }

  .footer-note {
    margin-top: 30px;
    padding: 10px 15px;
    background: #f8f9fa;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 11px;
    color: #718096;
    text-align: center;
  }

  .section-divider {
    border: none;
    border-top: 2px solid #1E3A5F;
    margin: 20px 0;
  }

  @media print {
    body { background: white; }
    .page { margin: 0; padding: 15mm; box-shadow: none; }
    .no-print { display: none !important; }
  }
</style>
</head>
<body>

<div class="no-print" style="text-align:center; padding:15px; background:#1E3A5F; color:white; position:sticky; top:0; z-index:100;">
  <button onclick="window.print()" style="padding:10px 30px; font-size:16px; background:white; color:#1E3A5F; border:none; border-radius:6px; cursor:pointer; font-weight:bold; font-family:'Noto Naskh Arabic',Arial,serif;">
    🖨️ طباعة / تحميل PDF
  </button>
  <button onclick="window.close()" style="padding:10px 30px; font-size:16px; background:transparent; color:white; border:1px solid white; border-radius:6px; cursor:pointer; margin-right:10px; font-family:'Noto Naskh Arabic',Arial,serif;">
    إغلاق
  </button>
</div>

<!-- PAGE 1 -->
<div class="page">
  <!-- Header with Logo -->
  <div class="header">
    <img src="${logoUrl}" alt="شعار الشركة" onerror="this.style.display='none'" />
    <h1>تعهد بعدم المنافسة وعدم التحريض وعدم الإفصاح عن المعلومات السرية</h1>
    <h2>UNDERTAKING FOR NON-COMPETITION, NON-SOLICITATION AND NON-DISCLOSURE OF CONFIDENTIAL INFORMATION</h2>
    <h3>("Undertaking" / "التعهد")</h3>
  </div>

  <!-- Employee Info Box -->
  <div class="employee-info">
    <div class="field"><span class="label">الاسم الكامل:</span> <span class="value">${employee.fullName}</span></div>
    <div class="field"><span class="label">الرقم الوظيفي:</span> <span class="value">${employee.empCode || '_______________'}</span></div>
    <div class="field"><span class="label">المسمى الوظيفي:</span> <span class="value">${employee.jobTitle}</span></div>
    <div class="field"><span class="label">القسم:</span> <span class="value">${employee.department}</span></div>
    <div class="field"><span class="label">الجنسية:</span> <span class="value">${employee.nationality || '_______________'}</span></div>
    <div class="field"><span class="label">تاريخ التعهد:</span> <span class="value">${signedDate}</span></div>
  </div>

  <!-- Introduction -->
  <div class="intro-section">
    <div class="intro-grid">
      <div class="en">
        On this date <strong>${signedDate}</strong>, I, the undersigned <strong>${employee.fullName}</strong>,
        a national of <strong>${employee.nationality || '_______________'}</strong>,
        holding ID/Passport No. <strong>${employee.idNumber || '_______________'}</strong>,
        employed by <strong>${companyName}</strong> as <strong>${employee.jobTitle}</strong>,
        do hereby acknowledge and undertake the following:
      </div>
      <div class="ar">
        في هذا اليوم الموافق <strong>${signedDate}</strong>، أقر أنا الموقع أدناه <strong>${employee.fullName}</strong>،
        وجنسيتي <strong>${employee.nationality || '_______________'}</strong>،
        رقم الهوية/جواز السفر <strong>${employee.idNumber || '_______________'}</strong>،
        العامل لدى <strong>${companyName}</strong> بوظيفة <strong>${employee.jobTitle}</strong>،
        أتعهد بموجب ذلك بما يلي:
      </div>
    </div>
  </div>

  <hr class="section-divider" />

  <!-- Clause 1: Main Undertaking -->
  <div class="clause">
    <div class="clause-number">1. أتعهد بموجب ذلك بما يلي: / I hereby undertake:</div>
  </div>

  <!-- Sub-clause a: Non-Competition -->
  <div class="clause">
    <div class="clause-content">
      <div class="en">
        <span class="sub-clause-label">a)</span> To refrain from being employed, engaged, concerned or interested in any organization directly or indirectly competing with the Employer in the practice of:
        <br/>- Digital marketing business
        <br/>- Selling outdoor products such as camping and trip equipment
        <br/>- Any other business activities carried out by the Employer
        <br/><br/>
        for a period of <strong>5 years</strong> from the date of this undertaking, whether during or after the termination of my employment.
      </div>
      <div class="ar">
        <span class="sub-clause-label">أ.</span> الامتناع عن العمل لدى أو الارتباط أو الاهتمام بأية جهة تنافس صاحب العمل بشكل مباشر أو غير مباشر في ممارسة أنشطة الشركة:
        <br/>- الترويج والتسويق الإلكتروني
        <br/>- بيع منتجات الاستخدامات الخارجية كأدوات الرحلات
        <br/>- أي أنشطة تجارية أخرى يمارسها صاحب العمل
        <br/><br/>
        لمدة تبلغ <strong>5 سنوات</strong> من تاريخ إبرام هذا التعهد، سواء خلال أو بعد انتهاء عملي.
      </div>
    </div>
  </div>

  <!-- Sub-clause b: Non-Solicitation of Business -->
  <div class="clause">
    <div class="clause-content">
      <div class="en">
        <span class="sub-clause-label">b)</span> To refrain from directly or indirectly soliciting business from, or attempting to sell, license or provide the same or similar products or services as are provided to any customer or client of the Employer.
      </div>
      <div class="ar">
        <span class="sub-clause-label">ب.</span> الامتناع عن اجتذاب العمل بشكل مباشر أو غير مباشر أو محاولة بيع أو ترخيص أو تقديم نفس المنتجات أو الخدمات أو منتجات أو خدمات مماثلة بشكل مباشر أو غير مباشر حسبما يتم تقديمها لأي زبون أو عميل يخص صاحب العمل.
      </div>
    </div>
  </div>

  <!-- Sub-clause c: Non-Solicitation of Employees -->
  <div class="clause">
    <div class="clause-content">
      <div class="en">
        <span class="sub-clause-label">c)</span> To refrain from directly or indirectly soliciting, inducing, or attempting to induce or solicit any other employee of the Employer to terminate his/her employment with the Employer for a period of <strong>5 years</strong> from the date of this undertaking.
      </div>
      <div class="ar">
        <span class="sub-clause-label">ت.</span> الامتناع عن استمالة أو حث أو محاولة حث أي موظف آخر لدى صاحب العمل على إنهاء عمله/عملها لدى صاحب العمل لمدة تبلغ <strong>5 سنوات</strong> من إبرام هذا العقد.
      </div>
    </div>
  </div>
</div>

<!-- PAGE 2 -->
<div class="page page-break">
  <div style="text-align:center; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid #1E3A5F;">
    <img src="${logoUrl}" alt="شعار الشركة" style="max-width:80px; max-height:50px;" onerror="this.style.display='none'" />
    <p style="font-size:12px; color:#718096; margin-top:5px;">تعهد عدم المنافسة والإفصاح - ${employee.fullName} (تابع)</p>
  </div>

  <!-- Sub-clause d: Confidentiality -->
  <div class="clause">
    <div class="clause-content">
      <div class="en">
        <span class="sub-clause-label">d)</span> To respect the Employer's confidential information (whether or not recorded in documentary form, or stored on any magnetic or optical disk or memory) relating to the Employer's business, including but not limited to:
        <br/>- Trade secrets and business strategies
        <br/>- Customer lists and contact information
        <br/>- Financial information and pricing
        <br/>- Technical know-how and processes
        <br/>- Marketing plans and campaigns
        <br/>- Employee information
      </div>
      <div class="ar">
        <span class="sub-clause-label">ث.</span> المحافظة على المعلومات السرية (سواء كانت موثقة أو لم تكن وسواء كانت مخزنة في أي قرص مغناطيسي أو بصري أو في أية ذاكرة مغناطيسية أو بصرية أو لم تكن) المتعلقة بأعمال صاحب العمل بما في ذلك، لكن دون حصر:
        <br/>- الأسرار التجارية واستراتيجيات العمل
        <br/>- قوائم العملاء ومعلومات الاتصال
        <br/>- المعلومات المالية والتسعير
        <br/>- المعرفة الفنية والعمليات
        <br/>- خطط التسويق والحملات
        <br/>- معلومات الموظفين
      </div>
    </div>
  </div>

  <hr class="section-divider" />

  <!-- Clause 2: Acknowledgment -->
  <div class="clause">
    <div class="clause-number">2. الإقرار / Acknowledgment</div>
    <div class="clause-content">
      <div class="en">
        I acknowledge that the restrictions set out above are necessary in order to protect the Employer's business interests, confidential information, customer connections, goodwill and stability of the workforce.
      </div>
      <div class="ar">
        أقر بأن القيود الواردة أعلاه ضرورية من أجل حماية المصالح التجارية والمعلومات السرية ومعلومات الاتصال بالعملاء وحسن النية واستقرار القوة العاملة لدى صاحب العمل.
      </div>
    </div>
  </div>

  <!-- Clause 3: Breach -->
  <div class="clause">
    <div class="clause-number">3. المخالفة / Breach</div>
    <div class="clause-content">
      <div class="en">
        If I breach any provision(s) of this Undertaking, I agree to pay the Employer damages equivalent to my monthly remuneration for each month or part of a month that I am in breach as compensation for the damages caused to the Employer as a result of such breach. The Employer reserves the right to seek additional legal remedies.
      </div>
      <div class="ar">
        في حال مخالفتي لهذا التعهد، فإنني أتعهد بدفع ما يعادل قيمة مستحقاتي الشهرية لكل شهر أو جزء من الشهر الذي تقع فيه المخالفة كتعويض عن الأضرار التي تلحق بصاحب العمل نتيجة لتلك المخالفة. ويحق لصاحب العمل باتخاذ الإجراءات القانونية الإضافية.
      </div>
    </div>
  </div>

  <!-- Clause 4: Governing Law -->
  <div class="clause">
    <div class="clause-number">4. القانون الحاكم / Governing Law</div>
    <div class="clause-content">
      <div class="en">
        I agree that this Undertaking shall be governed by the laws of the Sultanate of Oman, and any dispute or claim arising out of or in connection to this Undertaking or breach thereof shall be subject to the applicable laws of the judiciary in the Sultanate of Oman.
      </div>
      <div class="ar">
        أقر بأن هذا التعهد يخضع لقوانين سلطنة عمان، وأن أي نزاع أو مطالبة ينشأ أو تنشأ عن التعهد أو بخصوصه أو عن مخالفة هذا التعهد ستكون خاضعة للقوانين المعمول بها لدى القضاء في سلطنة عمان.
      </div>
    </div>
  </div>

  <!-- Clause 5: Severability -->
  <div class="clause">
    <div class="clause-number">5. قابلية الفصل / Severability</div>
    <div class="clause-content">
      <div class="en">
        Each of the restrictions in this Undertaking is intended to be separate and severable and in the event that any of the restrictions shall be adjudged void or ineffective for whatever reason but would be adjudged to be valid and effective if part of the wording thereof were deleted, it shall apply with such modification as may be necessary to make it valid and effective.
      </div>
      <div class="ar">
        المقصود بكل قيد من القيود الواردة في هذا التعهد أن يكون منفصلاً ومستقلاً وفي حال اعتبر أي من هذه القيود لاغياً أو باطلاً لأي سبب من الأسباب ولكنه يعتبر صحيحاً وساري المفعول إذا تم خفض جزء من نطاق الصياغة أو تعديلها، فإنه يسري بالتعديل اللازم لجعله صحيحاً وسارياً.
      </div>
    </div>
  </div>
</div>

<!-- PAGE 3 -->
<div class="page page-break">
  <div style="text-align:center; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid #1E3A5F;">
    <img src="${logoUrl}" alt="شعار الشركة" style="max-width:80px; max-height:50px;" onerror="this.style.display='none'" />
    <p style="font-size:12px; color:#718096; margin-top:5px;">تعهد عدم المنافسة والإفصاح - ${employee.fullName} (تابع)</p>
  </div>

  <!-- Clause 6: Third Party Offers -->
  <div class="clause">
    <div class="clause-number">6. عروض الأطراف الثالثة / Third Party Offers</div>
    <div class="clause-content">
      <div class="en">
        I agree that if I receive an offer from any third party to be involved in a business concern in any capacity either during my employment with the Employer or prior to the expiry of the restrictions mentioned above, I shall present the terms of this Undertaking to the offeror.
      </div>
      <div class="ar">
        أتعهد بأنني في حال تلقيت عرضاً من أي طرف ثالث للمشاركة في أي عمل بأية صفة سواء خلال عملي لدى صاحب العمل أو قبل انتهاء أو إنهاء القيود المذكورة أعلاه، سأقوم بتقديم بنود هذا التعهد إلى مقدم العرض.
      </div>
    </div>
  </div>

  <!-- Clause 7: Execution -->
  <div class="clause">
    <div class="clause-number">7. التنفيذ / Execution</div>
    <div class="clause-content">
      <div class="en">
        This Undertaking must be executed by the parties in accordance with any execution formalities required and/or permitted by the OCCI from time to time and may be executed in any number of counterparts, each of which when executed shall be an original, and all of which together shall constitute one and the same instrument.
      </div>
      <div class="ar">
        يجب تنفيذ هذا التعهد من قبل الطرفين وفقاً لأية إجراءات تنفيذ تشترطها غرفة تجارة وصناعة عمان من وقت لآخر، ويجوز إبرام هذا التعهد بأي عدد من النسخ المتطابقة، يتعين أن تكون كل نسخة عند التنفيذ أصلية، وكلها مجتمعة تشكل وثيقة واحدة.
      </div>
    </div>
  </div>

  <hr class="section-divider" />

  <!-- Signatures -->
  <div class="signatures">
    <div class="sig-box">
      <h4>صاحب العمل / Employer</h4>
      <div class="bilingual-label">اسم صاحب العمل / Employer Name</div>
      <div class="sig-line">${companyName}</div>
      <div class="bilingual-label">توقيع صاحب العمل / Employer Signature</div>
      <div class="sig-line">_______________</div>
      <div class="bilingual-label">التاريخ / Date</div>
      <div class="sig-line">${signedDate}</div>
    </div>
    <div class="sig-box">
      <h4>الموظف / Employee</h4>
      <div class="bilingual-label">اسم الموظف / Employee Name</div>
      <div class="sig-line">${employee.fullName}</div>
      <div class="bilingual-label">الرقم الوظيفي / Employee Code</div>
      <div class="sig-line">${employee.empCode || '_______________'}</div>
      <div class="bilingual-label">توقيع الموظف / Employee Signature</div>
      <div class="sig-line">_______________</div>
      <div class="bilingual-label">التاريخ / Date</div>
      <div class="sig-line">${signedDate}</div>
    </div>
  </div>

  <div class="footer-note">
    هذا التعهد مُعد وفقاً لأحكام قانون العمل العماني الصادر بالمرسوم السلطاني رقم 35/2003 وتعديلاته
    <br/>
    This Undertaking is prepared in accordance with the Oman Labour Law issued by Royal Decree No. 35/2003 and its amendments
    <br/>
    تم إنشاء هذا التعهد بتاريخ ${today}
  </div>
</div>

</body>
</html>`;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
  }
}