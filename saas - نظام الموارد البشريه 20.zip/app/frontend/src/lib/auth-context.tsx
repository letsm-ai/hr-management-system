import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { client } from './api';

interface User {
  id: string;
  email?: string;
  name?: string;
  avatar?: string;
  role?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  refreshAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  login: async () => {},
  logout: async () => {},
  refreshAuth: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const checkAuth = useCallback(async () => {
    try {
      // Check if there's a token in the URL (from OIDC callback redirect)
      const urlParams = new URLSearchParams(window.location.search);
      const urlToken = urlParams.get('token');
      if (urlToken) {
        localStorage.setItem('token', urlToken);
        localStorage.setItem('isLougOutManual', 'false');
        const expiresAt = urlParams.get('expires_at');
        if (expiresAt) {
          localStorage.setItem('token_expires_at', expiresAt);
        }
        // Clean URL
        window.history.replaceState({}, '', window.location.pathname);
      }

      // Check if we have a token at all
      let token = localStorage.getItem('token');

      // If no token and in iframe (App Viewer), wait briefly for SDK token exchange
      if (!token && window.self !== window.top) {
        token = await waitForToken(3000);
      }

      if (!token) {
        // No token = not logged in, show login page immediately
        setUser(null);
        setLoading(false);
        return;
      }

      // Use SDK to get current user - this is the primary and simplest method
      try {
        const meRes = await client.auth.me();
        if (meRes?.data) {
          setUser(meRes.data);
          setLoading(false);
          return;
        }
      } catch (sdkErr) {
        console.warn('SDK auth.me() failed:', sdkErr);
      }

      // If SDK returns no data, user is not authenticated
      setUser(null);
    } catch (err) {
      console.error('Auth check error:', err);
      // Any error means not authenticated
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  async function login() {
    // SDK's toLogin handles the full OIDC redirect flow on Atoms platform
    try {
      client.auth.toLogin();
    } catch (err) {
      console.error('Login redirect failed:', err);
    }
  }

  async function logout() {
    try {
      await client.auth.logout();
    } catch {
      // If SDK logout fails, clear manually
      localStorage.removeItem('token');
      localStorage.setItem('isLougOutManual', 'true');
      setUser(null);
      window.location.href = '/';
    }
  }

  async function refreshAuth() {
    setLoading(true);
    await checkAuth();
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, refreshAuth }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

/**
 * Wait for token to appear in localStorage (SDK async token exchange in iframe).
 */
function waitForToken(maxWaitMs: number): Promise<string | null> {
  return new Promise((resolve) => {
    let elapsed = 0;
    const interval = 100;
    const poll = setInterval(() => {
      const t = localStorage.getItem('token');
      if (t) {
        clearInterval(poll);
        resolve(t);
      } else {
        elapsed += interval;
        if (elapsed >= maxWaitMs) {
          clearInterval(poll);
          resolve(null);
        }
      }
    }, interval);
  });
}