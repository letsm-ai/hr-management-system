import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import {
  Employee, AttendanceRecord, IdeaRecord, OvertimeRecord, ViolationRecord, PerformanceRecord,
  ContractRecord, PerformanceKpiRecord,
  fetchEmployees, fetchAttendanceRecords, fetchIdeas, fetchOvertimeRecords, fetchViolations,
  fetchPerformanceRecords, fetchContracts, fetchPerformanceKpis,
} from './hr-api';
import { useAuth } from './auth-context';

interface HRDataContextType {
  employees: Employee[];
  attendance: AttendanceRecord[];
  ideas: IdeaRecord[];
  overtime: OvertimeRecord[];
  violations: ViolationRecord[];
  performance: PerformanceRecord[];
  contracts: ContractRecord[];
  performanceKpis: PerformanceKpiRecord[];
  loading: boolean;
  refreshEmployees: () => Promise<void>;
  refreshAttendance: () => Promise<void>;
  refreshIdeas: () => Promise<void>;
  refreshOvertime: () => Promise<void>;
  refreshViolations: () => Promise<void>;
  refreshPerformance: () => Promise<void>;
  refreshContracts: () => Promise<void>;
  refreshPerformanceKpis: () => Promise<void>;
  refreshAll: () => Promise<void>;
}

const HRDataContext = createContext<HRDataContextType>({
  employees: [],
  attendance: [],
  ideas: [],
  overtime: [],
  violations: [],
  performance: [],
  contracts: [],
  performanceKpis: [],
  loading: true,
  refreshEmployees: async () => {},
  refreshAttendance: async () => {},
  refreshIdeas: async () => {},
  refreshOvertime: async () => {},
  refreshViolations: async () => {},
  refreshPerformance: async () => {},
  refreshContracts: async () => {},
  refreshPerformanceKpis: async () => {},
  refreshAll: async () => {},
});

export function HRDataProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [ideas, setIdeas] = useState<IdeaRecord[]>([]);
  const [overtime, setOvertime] = useState<OvertimeRecord[]>([]);
  const [violations, setViolations] = useState<ViolationRecord[]>([]);
  const [performance, setPerformance] = useState<PerformanceRecord[]>([]);
  const [contracts, setContracts] = useState<ContractRecord[]>([]);
  const [performanceKpis, setPerformanceKpis] = useState<PerformanceKpiRecord[]>([]);
  const [loading, setLoading] = useState(false);

  const refreshEmployees = useCallback(async () => {
    const data = await fetchEmployees();
    setEmployees(data);
  }, []);

  const refreshAttendance = useCallback(async () => {
    const data = await fetchAttendanceRecords();
    setAttendance(data);
  }, []);

  const refreshIdeas = useCallback(async () => {
    const data = await fetchIdeas();
    setIdeas(data);
  }, []);

  const refreshOvertime = useCallback(async () => {
    const data = await fetchOvertimeRecords();
    setOvertime(data);
  }, []);

  const refreshViolations = useCallback(async () => {
    const data = await fetchViolations();
    setViolations(data);
  }, []);

  const refreshPerformance = useCallback(async () => {
    const data = await fetchPerformanceRecords();
    setPerformance(data);
  }, []);

  const refreshContracts = useCallback(async () => {
    const data = await fetchContracts();
    setContracts(data);
  }, []);

  const refreshPerformanceKpis = useCallback(async () => {
    const data = await fetchPerformanceKpis();
    setPerformanceKpis(data);
  }, []);

  const refreshAll = useCallback(async () => {
    setLoading(true);
    try {
      await Promise.all([
        refreshEmployees(),
        refreshAttendance(),
        refreshIdeas(),
        refreshOvertime(),
        refreshViolations(),
        refreshPerformance(),
        refreshContracts(),
        refreshPerformanceKpis(),
      ]);
    } finally {
      setLoading(false);
    }
  }, [refreshEmployees, refreshAttendance, refreshIdeas, refreshOvertime, refreshViolations, refreshPerformance, refreshContracts, refreshPerformanceKpis]);

  useEffect(() => {
    if (user) {
      refreshAll();
    } else {
      // Reset data when user logs out
      setEmployees([]);
      setAttendance([]);
      setIdeas([]);
      setOvertime([]);
      setViolations([]);
      setPerformance([]);
      setContracts([]);
      setPerformanceKpis([]);
      setLoading(false);
    }
  }, [user, refreshAll]);

  return (
    <HRDataContext.Provider
      value={{
        employees, attendance, ideas, overtime, violations, performance, contracts, performanceKpis, loading,
        refreshEmployees, refreshAttendance, refreshIdeas, refreshOvertime,
        refreshViolations, refreshPerformance, refreshContracts, refreshPerformanceKpis, refreshAll,
      }}
    >
      {children}
    </HRDataContext.Provider>
  );
}

export function useHRData() {
  return useContext(HRDataContext);
}