// Shared ClickUp member-to-employee matching utility
// Used by both PerformanceKpi and ClickUpIntegration pages

import type { Employee } from './hr-api';

export interface ClickUpMemberInfo {
  clickup_id: string;
  username: string;
  email: string;
}

interface MatchResult {
  employeeId: string;
  confidence: number; // 0-100
  method: string;
}

/**
 * Normalize Arabic text by removing diacritics (tashkeel) and extra whitespace
 */
function normalizeArabic(text: string): string {
  return text
    // Remove Arabic diacritics (fathah, dammah, kasrah, sukun, shadda, tanween, etc.)
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED]/g, '')
    // Normalize alef variations (أ إ آ ٱ) to ا
    .replace(/[أإآٱ]/g, 'ا')
    // Normalize taa marbuta ة to هـ (optional, helps with name matching)
    .replace(/ة/g, 'ه')
    // Remove extra whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalize a name for comparison
 */
function normalizeName(name: string): string {
  return normalizeArabic(name).toLowerCase().trim();
}

/**
 * Split a full name into parts for partial matching
 */
function getNameParts(name: string): string[] {
  return normalizeName(name).split(/\s+/).filter(Boolean);
}

/**
 * Calculate how many name parts match between two names
 */
function countMatchingParts(name1: string, name2: string): number {
  const parts1 = getNameParts(name1);
  const parts2 = getNameParts(name2);
  let matches = 0;
  for (const p1 of parts1) {
    for (const p2 of parts2) {
      if (p1 === p2 && p1.length >= 2) {
        matches++;
        break;
      }
    }
  }
  return matches;
}

/**
 * Check if two strings are similar using simple Levenshtein-like approach
 * Returns true if strings are within acceptable edit distance
 */
function isSimilar(a: string, b: string, threshold = 0.8): boolean {
  const na = normalizeName(a);
  const nb = normalizeName(b);
  if (na === nb) return true;
  if (na.length === 0 || nb.length === 0) return false;

  // Check containment
  if (na.includes(nb) || nb.includes(na)) return true;

  // Simple character overlap ratio
  const longer = na.length > nb.length ? na : nb;
  const shorter = na.length > nb.length ? nb : na;
  let matchCount = 0;
  const used = new Set<number>();
  for (const ch of shorter) {
    for (let i = 0; i < longer.length; i++) {
      if (!used.has(i) && longer[i] === ch) {
        matchCount++;
        used.add(i);
        break;
      }
    }
  }
  const ratio = matchCount / longer.length;
  return ratio >= threshold;
}

/**
 * Try to find the best employee match for a ClickUp member
 * Returns null if no good match found
 */
function findBestMatch(
  member: ClickUpMemberInfo,
  employees: Employee[],
  alreadyMapped: Set<string>,
): MatchResult | null {
  const candidates: MatchResult[] = [];

  for (const emp of employees) {
    // Skip already mapped employees (to avoid duplicates)
    if (alreadyMapped.has(emp.id)) continue;

    // Method 1: Exact email match (highest confidence)
    if (member.email && emp.email) {
      const memberEmail = member.email.toLowerCase().trim();
      const empEmail = emp.email.toLowerCase().trim();
      if (memberEmail === empEmail) {
        candidates.push({ employeeId: emp.id, confidence: 100, method: 'email_exact' });
        continue;
      }
      // Check email username part (before @) matches
      const memberUser = memberEmail.split('@')[0];
      const empUser = empEmail.split('@')[0];
      if (memberUser && empUser && memberUser === empUser) {
        candidates.push({ employeeId: emp.id, confidence: 90, method: 'email_username' });
        continue;
      }
    }

    // Method 2: Full name exact match (after normalization)
    if (member.username && emp.fullName) {
      const normalizedMember = normalizeName(member.username);
      const normalizedEmp = normalizeName(emp.fullName);
      if (normalizedMember === normalizedEmp) {
        candidates.push({ employeeId: emp.id, confidence: 95, method: 'name_exact' });
        continue;
      }
    }

    // Method 3: Full name containment
    if (member.username && emp.fullName) {
      const normalizedMember = normalizeName(member.username);
      const normalizedEmp = normalizeName(emp.fullName);
      if (normalizedMember.includes(normalizedEmp) || normalizedEmp.includes(normalizedMember)) {
        candidates.push({ employeeId: emp.id, confidence: 85, method: 'name_contains' });
        continue;
      }
    }

    // Method 4: Partial name matching (first name + last name)
    if (member.username && emp.fullName) {
      const matchingParts = countMatchingParts(member.username, emp.fullName);
      const memberParts = getNameParts(member.username);
      const empParts = getNameParts(emp.fullName);
      const totalParts = Math.max(memberParts.length, empParts.length);

      if (matchingParts >= 2 && totalParts > 0) {
        const ratio = matchingParts / totalParts;
        const confidence = Math.round(60 + ratio * 20); // 60-80
        candidates.push({ employeeId: emp.id, confidence, method: 'name_partial' });
        continue;
      }

      // At least first name matches
      if (matchingParts === 1 && memberParts.length > 0 && empParts.length > 0) {
        // Check if the first name matches (more significant)
        if (memberParts[0] === empParts[0]) {
          candidates.push({ employeeId: emp.id, confidence: 55, method: 'firstname_match' });
          continue;
        }
      }
    }

    // Method 5: Email-to-name cross match
    // Check if ClickUp username matches employee email username
    if (member.username && emp.email) {
      const empEmailUser = emp.email.toLowerCase().split('@')[0].replace(/[._-]/g, ' ');
      if (isSimilar(member.username, empEmailUser, 0.7)) {
        candidates.push({ employeeId: emp.id, confidence: 50, method: 'username_email_cross' });
        continue;
      }
    }

    // Check if ClickUp email username matches employee name
    if (member.email && emp.fullName) {
      const memberEmailUser = member.email.toLowerCase().split('@')[0].replace(/[._-]/g, ' ');
      if (isSimilar(memberEmailUser, emp.fullName, 0.7)) {
        candidates.push({ employeeId: emp.id, confidence: 50, method: 'email_name_cross' });
        continue;
      }
    }
  }

  if (candidates.length === 0) return null;

  // Sort by confidence descending and return the best
  candidates.sort((a, b) => b.confidence - a.confidence);

  // Only return if confidence is above minimum threshold
  const best = candidates[0];
  if (best.confidence >= 50) {
    return best;
  }

  return null;
}

/**
 * Auto-match all ClickUp members to employees.
 * Respects saved mappings (won't override them).
 * Returns merged mapping: { clickup_id: employee_id }
 */
export function autoMatchMembers(
  members: ClickUpMemberInfo[],
  employees: Employee[],
  savedMapping: Record<string, string> = {},
): {
  mapping: Record<string, string>;
  matchDetails: Record<string, { confidence: number; method: string }>;
  unmatchedMembers: ClickUpMemberInfo[];
  stats: { total: number; matched: number; savedKept: number; autoMatched: number; unmatched: number };
} {
  const mapping: Record<string, string> = {};
  const matchDetails: Record<string, { confidence: number; method: string }> = {};
  const unmatchedMembers: ClickUpMemberInfo[] = [];
  const alreadyMapped = new Set<string>();

  let savedKept = 0;
  let autoMatched = 0;

  // Step 1: Apply saved mappings first (highest priority)
  for (const member of members) {
    if (savedMapping[member.clickup_id]) {
      const empId = savedMapping[member.clickup_id];
      // Verify the employee still exists
      const empExists = employees.some((e) => e.id === empId);
      if (empExists) {
        mapping[member.clickup_id] = empId;
        matchDetails[member.clickup_id] = { confidence: 100, method: 'saved' };
        alreadyMapped.add(empId);
        savedKept++;
      }
    }
  }

  // Step 2: Auto-match remaining members
  // Sort members by those with email first (more reliable matching)
  const unmappedMembers = members.filter((m) => !mapping[m.clickup_id]);
  const sortedUnmapped = [...unmappedMembers].sort((a, b) => {
    if (a.email && !b.email) return -1;
    if (!a.email && b.email) return 1;
    return 0;
  });

  for (const member of sortedUnmapped) {
    const match = findBestMatch(member, employees, alreadyMapped);
    if (match) {
      mapping[member.clickup_id] = match.employeeId;
      matchDetails[member.clickup_id] = { confidence: match.confidence, method: match.method };
      alreadyMapped.add(match.employeeId);
      autoMatched++;
    } else {
      unmatchedMembers.push(member);
    }
  }

  return {
    mapping,
    matchDetails,
    unmatchedMembers,
    stats: {
      total: members.length,
      matched: savedKept + autoMatched,
      savedKept,
      autoMatched,
      unmatched: unmatchedMembers.length,
    },
  };
}

/**
 * Get a human-readable label for the match method
 */
export function getMatchMethodLabel(method: string): string {
  switch (method) {
    case 'saved': return 'ربط محفوظ';
    case 'email_exact': return 'تطابق البريد الإلكتروني';
    case 'email_username': return 'تطابق اسم المستخدم في البريد';
    case 'name_exact': return 'تطابق الاسم الكامل';
    case 'name_contains': return 'الاسم يحتوي على';
    case 'name_partial': return 'تطابق جزئي للاسم';
    case 'firstname_match': return 'تطابق الاسم الأول';
    case 'username_email_cross': return 'تقاطع اسم المستخدم والبريد';
    case 'email_name_cross': return 'تقاطع البريد والاسم';
    default: return method;
  }
}

/**
 * Get confidence color class based on confidence level
 */
export function getConfidenceColor(confidence: number): string {
  if (confidence >= 90) return 'text-emerald-600';
  if (confidence >= 70) return 'text-blue-600';
  if (confidence >= 50) return 'text-amber-600';
  return 'text-red-600';
}

/**
 * Get confidence badge variant
 */
export function getConfidenceBadgeClass(confidence: number): string {
  if (confidence >= 90) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
  if (confidence >= 70) return 'bg-blue-100 text-blue-700 border-blue-200';
  if (confidence >= 50) return 'bg-amber-100 text-amber-700 border-amber-200';
  return 'bg-red-100 text-red-700 border-red-200';
}