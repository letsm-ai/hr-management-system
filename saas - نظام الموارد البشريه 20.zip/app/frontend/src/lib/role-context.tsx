import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useAuth } from './auth-context';
import { client } from './api';

export type UserRole = 'admin' | 'employee' | null;

interface RoleContextType {
  role: UserRole;
  employeeId: number | null;
  loading: boolean;
  isAdmin: boolean;
  isEmployee: boolean;
  isFirstUser: boolean;
  refreshRole: () => Promise<void>;
}

const RoleContext = createContext<RoleContextType>({
  role: null,
  employeeId: null,
  loading: true,
  isAdmin: false,
  isEmployee: false,
  isFirstUser: false,
  refreshRole: async () => {},
});

export function RoleProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [role, setRole] = useState<UserRole>(null);
  const [employeeId, setEmployeeId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFirstUser, setIsFirstUser] = useState(false);

  async function checkRole() {
    if (!user) {
      setRole(null);
      setEmployeeId(null);
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const res = await client.apiCall.invoke({
        url: '/api/v1/roles/check',
        method: 'GET',
      });
      const data = res.data as any;
      if (data?.has_role) {
        setRole(data.role as UserRole);
        setEmployeeId(data.employee_id || null);
        setIsFirstUser(data.is_first_user || false);
      } else {
        // First user auto-becomes admin
        setRole('admin');
        setEmployeeId(null);
        setIsFirstUser(true);
      }
    } catch (e) {
      console.error('Failed to check role:', e);
      // If role check fails (backend not reachable), default to admin for first-time setup
      setRole('admin');
      setEmployeeId(null);
      setIsFirstUser(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    checkRole();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return (
    <RoleContext.Provider
      value={{
        role,
        employeeId,
        loading,
        isAdmin: role === 'admin',
        isEmployee: role === 'employee',
        isFirstUser,
        refreshRole: checkRole,
      }}
    >
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  return useContext(RoleContext);
}