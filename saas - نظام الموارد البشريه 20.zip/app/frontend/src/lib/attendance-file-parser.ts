// Attendance File Parser - Supports Excel (.xlsx/.xls), CSV, and Text files
// Parses biometric/fingerprint device export files
// Supports both standard tabular format AND "Attendance Card Report" multi-block format

import * as XLSX from 'xlsx';

export interface ParsedAttendanceRow {
  empCode: string;
  empName: string;
  date: string; // YYYY-MM-DD
  checkIn: string; // HH:mm
  checkOut: string; // HH:mm
}

export interface ParseResult {
  success: boolean;
  data: ParsedAttendanceRow[];
  errors: string[];
  totalRows: number;
  parsedRows: number;
  skippedRows: number;
}

// Known column name mappings (Arabic + English)
const EMP_CODE_COLS = ['رقم الموظف', 'كود الموظف', 'رمز الموظف', 'emp_code', 'empcode', 'employee_code', 'employee_id', 'emp_id', 'empid', 'id', 'no', 'رقم', 'الرقم الوظيفي', 'ac-no', 'ac-no.', 'user id', 'userid'];
const EMP_NAME_COLS = ['اسم الموظف', 'الاسم', 'الموظف', 'name', 'employee_name', 'emp_name', 'empname', 'full_name', 'fullname'];
const DATE_COLS = ['التاريخ', 'تاريخ', 'date', 'attendance_date', 'day', 'اليوم'];
const CHECK_IN_COLS = ['وقت الحضور', 'الحضور', 'وقت الدخول', 'الدخول', 'check_in', 'checkin', 'clock_in', 'clockin', 'time_in', 'in', 'punch_in', 'first_in', 'on duty'];
const CHECK_OUT_COLS = ['وقت الانصراف', 'الانصراف', 'وقت الخروج', 'الخروج', 'check_out', 'checkout', 'clock_out', 'clockout', 'time_out', 'out', 'punch_out', 'last_out', 'off duty'];

function normalizeColName(col: string): string {
  return col.toString().trim().toLowerCase().replace(/[\s_\-.]+/g, ' ');
}

function findColumnIndex(headers: string[], candidates: string[]): number {
  const normalizedHeaders = headers.map(normalizeColName);
  for (const candidate of candidates) {
    const normalized = normalizeColName(candidate);
    const idx = normalizedHeaders.indexOf(normalized);
    if (idx !== -1) return idx;
  }
  // Partial match
  for (const candidate of candidates) {
    const normalized = normalizeColName(candidate);
    const idx = normalizedHeaders.findIndex(h => h.includes(normalized) || normalized.includes(h));
    if (idx !== -1) return idx;
  }
  return -1;
}

function parseDate(value: unknown): string {
  if (!value) return '';
  const str = String(value).trim();

  // Already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[/\-.](\\d{1,2})[/\-.](\d{4})$/);
  if (dmyMatch) {
    const [, d, m, y] = dmyMatch;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  // YYYY/MM/DD
  const ymdMatch = str.match(/^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$/);
  if (ymdMatch) {
    const [, y, m, d] = ymdMatch;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  // Excel serial date number
  if (typeof value === 'number' && value > 30000 && value < 60000) {
    const excelEpoch = new Date(1899, 11, 30);
    const date = new Date(excelEpoch.getTime() + value * 86400000);
    return date.toISOString().split('T')[0];
  }

  // Try Date constructor
  const d = new Date(str);
  if (!isNaN(d.getTime())) {
    return d.toISOString().split('T')[0];
  }

  return '';
}

function parseTime(value: unknown): string {
  if (!value) return '';
  const str = String(value).trim();
  if (!str) return '';

  // HH:mm or HH:mm:ss
  const timeMatch = str.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
  if (timeMatch) {
    const [, h, m] = timeMatch;
    return `${h.padStart(2, '0')}:${m}`;
  }

  // Excel time fraction (0.0 to 1.0)
  if (typeof value === 'number' && value >= 0 && value < 1) {
    const totalMinutes = Math.round(value * 24 * 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  }

  // h:mm AM/PM
  const ampmMatch = str.match(/(\d{1,2}):(\d{2})\s*(AM|PM|ص|م)/i);
  if (ampmMatch) {
    const [, h, m, period] = ampmMatch;
    let hour = parseInt(h);
    if ((period.toUpperCase() === 'PM' || period === 'م') && hour < 12) hour += 12;
    if ((period.toUpperCase() === 'AM' || period === 'ص') && hour === 12) hour = 0;
    return `${String(hour).padStart(2, '0')}:${m}`;
  }

  return '';
}

// ============================================================
// Attendance Card Report Parser (multi-block side-by-side format)
// ============================================================

interface EmployeeBlock {
  name: string;
  id: string;
  dateRange: string; // e.g. "2026/03/01-2026/03/31"
  colOffset: number; // starting column index for this employee block
}

/**
 * Detect if the workbook is in "Attendance Card Report" format.
 * Key indicators:
 * - Row 0 contains "Attendance Employee"
 * - Row 3 contains "Name" labels at specific positions
 * - Row 10 contains "Date", "Week", "First" headers
 */
function isAttendanceCardFormat(sheet: unknown[][]): boolean {
  if (!sheet || sheet.length < 12) return false;
  const row0 = sheet[0];
  const row0Str = String(row0?.[0] || '').trim().toLowerCase();
  if (row0Str.includes('attendance employee')) return true;

  // Also check row 3 for "Name" pattern
  const row3 = sheet[3];
  if (row3) {
    const hasNameLabel = row3.some((cell, idx) =>
      String(cell || '').trim().toLowerCase() === 'name' && idx < 30
    );
    const hasDeptLabel = String(row3[0] || '').trim().toLowerCase() === 'dept';
    if (hasNameLabel && hasDeptLabel) return true;
  }

  return false;
}

/**
 * Extract date range from the card report.
 * Looks for pattern like "2026/03/01-2026/03/31" in row 4.
 */
function extractDateRange(row: unknown[]): { year: number; month: number } | null {
  for (const cell of row) {
    const str = String(cell || '').trim();
    const match = str.match(/(\d{4})\/(\d{2})\/(\d{2})-(\d{4})\/(\d{2})\/(\d{2})/);
    if (match) {
      return { year: parseInt(match[1]), month: parseInt(match[2]) };
    }
  }
  return null;
}

/**
 * Parse employee blocks from a header row.
 * Each sheet can have up to 3 employees side-by-side, and multiple vertical blocks.
 * Employee blocks start at columns 0, 11, 22 (each 11 cols wide with separator).
 */
function extractEmployeeBlocks(
  sheet: unknown[][],
  nameRowIdx: number,
  idRowIdx: number,
): EmployeeBlock[] {
  const blocks: EmployeeBlock[] = [];
  const nameRow = sheet[nameRowIdx];
  const idRow = sheet[idRowIdx];
  if (!nameRow || !idRow) return blocks;

  // Employee blocks are at column offsets 0, 11, 22
  const offsets = [0, 11, 22];

  for (const offset of offsets) {
    // Name is at offset+6 (label) and offset+7 (value)
    const nameLabel = String(nameRow[offset + 6] || '').trim().toLowerCase();
    const nameValue = String(nameRow[offset + 7] || '').trim();

    if (nameLabel === 'name' && nameValue) {
      // ID is at offset+6 (label) and offset+7 (value) in the ID row
      const idLabel = String(idRow[offset + 6] || '').trim().toLowerCase();
      const idValue = String(idRow[offset + 7] || '').trim();

      // Date range from the same row
      const dateRangeStr = String(idRow[offset + 1] || '').trim();

      blocks.push({
        name: nameValue,
        id: idLabel === 'id' ? idValue : '',
        dateRange: dateRangeStr,
        colOffset: offset,
      });
    }
  }

  return blocks;
}

/**
 * Parse the "Attendance Card Report" format.
 * Structure per block (vertical):
 *   Row N+0: Dept/Name row
 *   Row N+1: Date/ID row
 *   Row N+2-4: Summary stats
 *   Row N+5: empty
 *   Row N+6: "Attendance Info"
 *   Row N+7: Date/Week/First/Second/Third/Over headers
 *   Row N+8: On/Off sub-headers
 *   Row N+9 to N+39: Daily data (day 1-31)
 *
 * Each sheet can have multiple vertical blocks (e.g., rows 3-42, 44-83).
 */
function parseAttendanceCardReport(workbook: XLSX.WorkBook): ParseResult {
  const data: ParsedAttendanceRow[] = [];
  const errors: string[] = [];
  let totalDayRows = 0;

  for (const sheetName of workbook.SheetNames) {
    const ws = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, raw: false, defval: '' });
    if (jsonData.length < 12) continue;

    // Find all vertical block starts by looking for rows with "Dept" in column 0
    const blockStarts: number[] = [];
    for (let r = 0; r < jsonData.length; r++) {
      const row = jsonData[r] as unknown[];
      const cell0 = String(row?.[0] || '').trim().toLowerCase();
      if (cell0 === 'dept') {
        blockStarts.push(r);
      }
    }

    for (const blockStart of blockStarts) {
      const nameRowIdx = blockStart;      // Row with Dept/Name
      const idRowIdx = blockStart + 1;    // Row with Date/ID
      const dataStartIdx = blockStart + 9; // Daily data starts 9 rows after block start

      // Extract date range
      const dateInfo = extractDateRange(jsonData[idRowIdx] as unknown[]);
      if (!dateInfo) {
        errors.push(`لم يتم العثور على نطاق التاريخ في الورقة "${sheetName}" صف ${idRowIdx + 1}`);
        continue;
      }

      // Extract employee blocks (up to 3 per horizontal group)
      const empBlocks = extractEmployeeBlocks(
        jsonData as unknown[][],
        nameRowIdx,
        idRowIdx,
      );

      if (empBlocks.length === 0) {
        continue;
      }

      // Parse daily attendance for each employee
      for (const emp of empBlocks) {
        const { year, month } = dateInfo;

        // Read up to 31 days of data
        for (let dayOffset = 0; dayOffset < 31; dayOffset++) {
          const rowIdx = dataStartIdx + dayOffset;
          if (rowIdx >= jsonData.length) break;

          const row = jsonData[rowIdx] as unknown[];
          if (!row) continue;

          const offset = emp.colOffset;

          // Column layout per employee block (relative to offset):
          // 0: Day number, 1: Weekday, 2: First On, 3: First Off,
          // 4: Second On, 5: Second Off, 6: Third On, 7: Third Off,
          // 8: Over In, 9: Over Out

          const dayNum = String(row[offset] || '').trim();
          if (!dayNum || isNaN(parseInt(dayNum))) continue;

          const day = parseInt(dayNum);
          if (day < 1 || day > 31) continue;

          // Validate this day exists in the month
          const daysInMonth = new Date(year, month, 0).getDate();
          if (day > daysInMonth) continue;

          totalDayRows++;

          const firstOn = parseTime(row[offset + 2]);
          const firstOff = parseTime(row[offset + 3]);
          const secondOn = parseTime(row[offset + 4]);
          const secondOff = parseTime(row[offset + 5]);

          // Determine check-in (earliest "On") and check-out (latest "Off")
          const checkIn = firstOn || secondOn || '';
          const checkOut = secondOff || firstOff || '';

          // Skip days with no attendance data at all
          if (!checkIn && !checkOut) continue;

          const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

          data.push({
            empCode: emp.id,
            empName: emp.name,
            date: dateStr,
            checkIn,
            checkOut,
          });
        }
      }
    }
  }

  if (data.length === 0 && errors.length === 0) {
    errors.push('لم يتم استخراج أي بيانات حضور من ملف تقرير بطاقة الحضور');
  }

  return {
    success: data.length > 0,
    data,
    errors,
    totalRows: totalDayRows,
    parsedRows: data.length,
    skippedRows: totalDayRows - data.length,
  };
}

// ============================================================
// Standard Tabular Format Parser (original logic)
// ============================================================

function parseRowsToData(rows: unknown[][], headers: string[]): ParseResult {
  const errors: string[] = [];

  const empCodeIdx = findColumnIndex(headers, EMP_CODE_COLS);
  const empNameIdx = findColumnIndex(headers, EMP_NAME_COLS);
  const dateIdx = findColumnIndex(headers, DATE_COLS);
  const checkInIdx = findColumnIndex(headers, CHECK_IN_COLS);
  const checkOutIdx = findColumnIndex(headers, CHECK_OUT_COLS);

  if (dateIdx === -1) {
    errors.push('لم يتم العثور على عمود التاريخ في الملف');
  }
  if (empCodeIdx === -1 && empNameIdx === -1) {
    errors.push('لم يتم العثور على عمود رقم الموظف أو اسم الموظف');
  }
  if (checkInIdx === -1 && checkOutIdx === -1) {
    errors.push('لم يتم العثور على عمود وقت الحضور أو الانصراف');
  }

  if (errors.length > 0) {
    return { success: false, data: [], errors, totalRows: rows.length, parsedRows: 0, skippedRows: rows.length };
  }

  const data: ParsedAttendanceRow[] = [];
  let skippedRows = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) {
      skippedRows++;
      continue;
    }

    const empCode = empCodeIdx !== -1 ? String(row[empCodeIdx] || '').trim() : '';
    const empName = empNameIdx !== -1 ? String(row[empNameIdx] || '').trim() : '';
    const date = dateIdx !== -1 ? parseDate(row[dateIdx]) : '';
    const checkIn = checkInIdx !== -1 ? parseTime(row[checkInIdx]) : '';
    const checkOut = checkOutIdx !== -1 ? parseTime(row[checkOutIdx]) : '';

    if (!date) {
      skippedRows++;
      continue;
    }

    if (!empCode && !empName) {
      skippedRows++;
      continue;
    }

    data.push({ empCode, empName, date, checkIn, checkOut });
  }

  return {
    success: data.length > 0,
    data,
    errors: data.length === 0 ? ['لم يتم استخراج أي بيانات صالحة من الملف'] : errors,
    totalRows: rows.length,
    parsedRows: data.length,
    skippedRows,
  };
}

function detectDelimiter(text: string): string {
  const firstLine = text.split('\n')[0] || '';
  const tabCount = (firstLine.match(/\t/g) || []).length;
  const commaCount = (firstLine.match(/,/g) || []).length;
  const semicolonCount = (firstLine.match(/;/g) || []).length;
  const pipeCount = (firstLine.match(/\|/g) || []).length;

  const max = Math.max(tabCount, commaCount, semicolonCount, pipeCount);
  if (max === 0) return ',';
  if (max === tabCount) return '\t';
  if (max === commaCount) return ',';
  if (max === semicolonCount) return ';';
  return '|';
}

function parseCSVText(text: string): { headers: string[]; rows: unknown[][] } {
  const delimiter = detectDelimiter(text);
  const lines = text.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };

  const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, ''));
  const rows = lines.slice(1).map(line =>
    line.split(delimiter).map(cell => cell.trim().replace(/^["']|["']$/g, ''))
  );

  return { headers, rows };
}

// ============================================================
// Main Entry Point
// ============================================================

export async function parseAttendanceFile(file: File): Promise<ParseResult> {
  const fileName = file.name.toLowerCase();
  const errors: string[] = [];

  try {
    if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
      // Excel file
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      const sheetName = workbook.SheetNames[0];
      if (!sheetName) {
        return { success: false, data: [], errors: ['الملف لا يحتوي على أي ورقة عمل'], totalRows: 0, parsedRows: 0, skippedRows: 0 };
      }

      // Check if this is an "Attendance Card Report" format
      const firstSheet = workbook.Sheets[sheetName];
      const previewData = XLSX.utils.sheet_to_json<unknown[]>(firstSheet, { header: 1, raw: false, defval: '' });

      if (isAttendanceCardFormat(previewData as unknown[][])) {
        // Use the special card report parser (processes ALL sheets)
        return parseAttendanceCardReport(workbook);
      }

      // Standard tabular format
      if (previewData.length < 2) {
        return { success: false, data: [], errors: ['الملف لا يحتوي على بيانات كافية'], totalRows: 0, parsedRows: 0, skippedRows: 0 };
      }
      const headers = (previewData[0] as unknown[]).map(h => String(h || ''));
      const rows = previewData.slice(1) as unknown[][];
      return parseRowsToData(rows, headers);

    } else if (fileName.endsWith('.csv') || fileName.endsWith('.txt')) {
      // CSV or Text file
      const text = await file.text();
      if (!text.trim()) {
        return { success: false, data: [], errors: ['الملف فارغ'], totalRows: 0, parsedRows: 0, skippedRows: 0 };
      }
      const { headers, rows } = parseCSVText(text);
      if (headers.length === 0) {
        return { success: false, data: [], errors: ['لم يتم العثور على عناوين الأعمدة'], totalRows: 0, parsedRows: 0, skippedRows: 0 };
      }
      return parseRowsToData(rows, headers);

    } else {
      errors.push(`صيغة الملف غير مدعومة: ${fileName}. الصيغ المدعومة: xlsx, xls, csv, txt`);
      return { success: false, data: [], errors, totalRows: 0, parsedRows: 0, skippedRows: 0 };
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { success: false, data: [], errors: [`خطأ في قراءة الملف: ${msg}`], totalRows: 0, parsedRows: 0, skippedRows: 0 };
  }
}