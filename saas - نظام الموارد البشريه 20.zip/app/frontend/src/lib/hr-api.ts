// HR Management System - API Layer using Atoms Cloud Web SDK
// Replaces localStorage with backend database

import { apiGet, apiPost } from './api-client';
import { entities } from './entity-api';

// ============ TYPE DEFINITIONS (matching backend schema) ============

export interface DbEmployee {
  id: number;
  emp_code: string;
  full_name: string;
  department: string;
  job_title: string;
  hire_date: string;
  basic_salary: number;
  email: string;
  status: string;
  annual_leave_balance: number;
  daily_work_hours: number;
}

export interface DbAttendanceRecord {
  id: number;
  date: string;
  employee_id: number;
  check_in: string;
  check_out: string;
  actual_hours: number;
  required_hours: number;
  tardiness: number;
  early_departure: number;
  day_status: string;
  absence_type: string;
  notes: string;
  approved: string;
}

export interface DbIdea {
  id: number;
  month: string;
  employee_id: number;
  title: string;
  status: string;
  classification: string;
  expected_impact: string;
  submission_date: string;
  decision_date: string;
  revenue_generated: number;
  notes: string;
}

export interface DbOvertimeRecord {
  id: number;
  date: string;
  employee_id: number;
  day_type: string;
  overtime_hours: number;
  compensation_method: string;
  approved: string;
}

export interface DbViolation {
  id: number;
  date: string;
  employee_id: number;
  violation_type: string;
  details: string;
  severity: string;
  is_repeated: string;
  penalty: string;
  deduction_amount: number;
  deduction_days: number;
  notification_date: string;
  grievance_status: string;
  notes: string;
}

export interface DbPerformanceRecord {
  id: number;
  month: string;
  employee_id: number;
  work_quality: number;
  punctuality: number;
  customer_satisfaction: number;
  teamwork: number;
  initiative: number;
  self_development: number;
}

export interface DbContract {
  id: number;
  employee_id: number;
  contract_type: string;
  job_title: string;
  department: string;
  start_date: string;
  end_date: string;
  basic_salary: number;
  housing_allowance: number;
  transport_allowance: number;
  food_allowance: number;
  other_allowances: number;
  total_salary: number;
  working_hours: number;
  annual_leave_days: number;
  probation_period: number;
  notice_period: number;
  status: string;
  notes: string;
  signed_date: string;
  termination_date: string;
  termination_reason: string;
}

export interface DbPerformanceKpi {
  id: number;
  employee_id: number;
  month: string;
  tasks_target: number;
  tasks_completed: number;
  achievement_rate: number;
  kpi_bonus: number;
  quality_score: number;
  timeliness_score: number;
  collaboration_score: number;
  innovation_score: number;
  overall_rating: string;
  manager_notes: string;
  employee_goals: string;
}

// ============ FRONTEND INTERFACES (camelCase for UI) ============

export interface Employee {
  id: string;
  empCode: string;
  fullName: string;
  department: string;
  jobTitle: string;
  hireDate: string;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  foodAllowance: number;
  otherAllowances: number;
  email: string;
  status: string;
  annualLeaveBalance: number;
  dailyWorkHours: number;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  employeeId: string;
  checkIn: string;
  checkOut: string;
  actualHours: number;
  requiredHours: number;
  tardiness: number;
  earlyDeparture: number;
  dayStatus: string;
  absenceType: string;
  notes: string;
  approved: string;
}

export interface IdeaRecord {
  id: string;
  month: string;
  employeeId: string;
  title: string;
  status: string;
  classification: string;
  expectedImpact: string;
  submissionDate: string;
  decisionDate: string;
  revenueGenerated: number;
  notes: string;
}

export interface OvertimeRecord {
  id: string;
  date: string;
  employeeId: string;
  dayType: string;
  overtimeHours: number;
  compensationMethod: string;
  approved: string;
}

export interface ViolationRecord {
  id: string;
  date: string;
  employeeId: string;
  violationType: string;
  details: string;
  severity: string;
  isRepeated: string;
  penalty: string;
  deductionAmount: number;
  deductionDays: number;
  notificationDate: string;
  grievanceStatus: string;
  notes: string;
}

export interface PerformanceRecord {
  id: string;
  month: string;
  employeeId: string;
  workQuality: number;
  punctuality: number;
  customerSatisfaction: number;
  teamwork: number;
  initiative: number;
  selfDevelopment: number;
}

export interface ContractRecord {
  id: string;
  employeeId: string;
  contractType: string;
  jobTitle: string;
  department: string;
  startDate: string;
  endDate: string;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  foodAllowance: number;
  otherAllowances: number;
  totalSalary: number;
  workingHours: number;
  annualLeaveDays: number;
  probationPeriod: number;
  noticePeriod: number;
  status: string;
  notes: string;
  signedDate: string;
  terminationDate: string;
  terminationReason: string;
}

export interface PerformanceKpiRecord {
  id: string;
  employeeId: string;
  month: string;
  tasksTarget: number;
  tasksCompleted: number;
  achievementRate: number;
  kpiBonus: number;
  qualityScore: number;
  timelinessScore: number;
  collaborationScore: number;
  innovationScore: number;
  overallRating: string;
  managerNotes: string;
  employeeGoals: string;
}

export interface LeaveBalanceRecord {
  employeeId: string;
  year: number;
  annualEntitled: number;
  annualUsed: number;
  sickEntitled: number;
  sickUsed: number;
  emergencyUsed: number;
  unpaidUsed: number;
}

// ============ MAPPERS: DB <-> Frontend ============

function mapDbEmployee(db: DbEmployee): Employee {
  return {
    id: String(db.id),
    empCode: db.emp_code || '',
    fullName: db.full_name,
    department: db.department,
    jobTitle: db.job_title,
    hireDate: db.hire_date,
    basicSalary: db.basic_salary,
    housingAllowance: db.housing_allowance || 0,
    transportAllowance: db.transport_allowance || 0,
    foodAllowance: db.food_allowance || 0,
    otherAllowances: db.other_allowances || 0,
    email: db.email,
    status: db.status,
    annualLeaveBalance: db.annual_leave_balance,
    dailyWorkHours: db.daily_work_hours,
  };
}

function mapDbAttendance(db: DbAttendanceRecord): AttendanceRecord {
  return {
    id: String(db.id),
    date: db.date,
    employeeId: String(db.employee_id),
    checkIn: db.check_in || '',
    checkOut: db.check_out || '',
    actualHours: db.actual_hours || 0,
    requiredHours: db.required_hours || 8,
    tardiness: db.tardiness || 0,
    earlyDeparture: db.early_departure || 0,
    dayStatus: db.day_status,
    absenceType: db.absence_type,
    notes: db.notes || '',
    approved: db.approved,
  };
}

function mapDbIdea(db: DbIdea): IdeaRecord {
  return {
    id: String(db.id),
    month: db.month,
    employeeId: String(db.employee_id),
    title: db.title,
    status: db.status,
    classification: db.classification,
    expectedImpact: db.expected_impact,
    submissionDate: db.submission_date,
    decisionDate: db.decision_date || '',
    revenueGenerated: db.revenue_generated || 0,
    notes: db.notes || '',
  };
}

function mapDbOvertime(db: DbOvertimeRecord): OvertimeRecord {
  return {
    id: String(db.id),
    date: db.date,
    employeeId: String(db.employee_id),
    dayType: db.day_type,
    overtimeHours: db.overtime_hours,
    compensationMethod: db.compensation_method,
    approved: db.approved,
  };
}

function mapDbViolation(db: DbViolation): ViolationRecord {
  return {
    id: String(db.id),
    date: db.date,
    employeeId: String(db.employee_id),
    violationType: db.violation_type,
    details: db.details || '',
    severity: db.severity,
    isRepeated: db.is_repeated,
    penalty: db.penalty,
    deductionAmount: db.deduction_amount || 0,
    deductionDays: db.deduction_days || 0,
    notificationDate: db.notification_date || '',
    grievanceStatus: db.grievance_status,
    notes: db.notes || '',
  };
}

function mapDbPerformance(db: DbPerformanceRecord): PerformanceRecord {
  return {
    id: String(db.id),
    month: db.month,
    employeeId: String(db.employee_id),
    workQuality: db.work_quality,
    punctuality: db.punctuality,
    customerSatisfaction: db.customer_satisfaction,
    teamwork: db.teamwork,
    initiative: db.initiative,
    selfDevelopment: db.self_development,
  };
}

function mapDbContract(db: DbContract): ContractRecord {
  return {
    id: String(db.id),
    employeeId: String(db.employee_id),
    contractType: db.contract_type || '',
    jobTitle: db.job_title || '',
    department: db.department || '',
    startDate: db.start_date || '',
    endDate: db.end_date || '',
    basicSalary: db.basic_salary || 0,
    housingAllowance: db.housing_allowance || 0,
    transportAllowance: db.transport_allowance || 0,
    foodAllowance: db.food_allowance || 0,
    otherAllowances: db.other_allowances || 0,
    totalSalary: db.total_salary || 0,
    workingHours: db.working_hours || 8,
    annualLeaveDays: db.annual_leave_days || 30,
    probationPeriod: db.probation_period || 3,
    noticePeriod: db.notice_period || 30,
    status: db.status || 'مسودة',
    notes: db.notes || '',
    signedDate: db.signed_date || '',
    terminationDate: db.termination_date || '',
    terminationReason: db.termination_reason || '',
  };
}

function mapDbPerformanceKpi(db: DbPerformanceKpi): PerformanceKpiRecord {
  return {
    id: String(db.id),
    employeeId: String(db.employee_id),
    month: db.month || '',
    tasksTarget: db.tasks_target || 0,
    tasksCompleted: db.tasks_completed || 0,
    achievementRate: db.achievement_rate || 0,
    kpiBonus: db.kpi_bonus || 0,
    qualityScore: db.quality_score || 0,
    timelinessScore: db.timeliness_score || 0,
    collaborationScore: db.collaboration_score || 0,
    innovationScore: db.innovation_score || 0,
    overallRating: db.overall_rating || '',
    managerNotes: db.manager_notes || '',
    employeeGoals: db.employee_goals || '',
  };
}

// ============ EMPLOYEE API ============

export async function fetchEmployees(): Promise<Employee[]> {
  try {
    const res = await entities.employees.query({ query: {}, limit: 100 });
    const items = res?.data?.items || [];
    return items.map(mapDbEmployee);
  } catch (e) {
    console.error('Failed to fetch employees:', e);
    return [];
  }
}

export async function createEmployee(emp: Omit<Employee, 'id'>): Promise<Employee | null> {
  try {
    const res = await entities.employees.create({
      data: {
        emp_code: emp.empCode,
        full_name: emp.fullName,
        department: emp.department,
        job_title: emp.jobTitle,
        hire_date: emp.hireDate,
        basic_salary: emp.basicSalary,
        email: emp.email,
        status: emp.status,
        annual_leave_balance: emp.annualLeaveBalance,
        daily_work_hours: emp.dailyWorkHours,
      },
    });
    return res?.data ? mapDbEmployee(res.data) : null;
  } catch (e) {
    console.error('Failed to create employee:', e);
    return null;
  }
}

export async function updateEmployee(id: string, updates: Partial<Employee>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.empCode !== undefined) data.emp_code = updates.empCode;
    if (updates.fullName !== undefined) data.full_name = updates.fullName;
    if (updates.department !== undefined) data.department = updates.department;
    if (updates.jobTitle !== undefined) data.job_title = updates.jobTitle;
    if (updates.hireDate !== undefined) data.hire_date = updates.hireDate;
    if (updates.basicSalary !== undefined) data.basic_salary = updates.basicSalary;
    if (updates.email !== undefined) data.email = updates.email;
    if (updates.status !== undefined) data.status = updates.status;
    if (updates.annualLeaveBalance !== undefined) data.annual_leave_balance = updates.annualLeaveBalance;
    if (updates.dailyWorkHours !== undefined) data.daily_work_hours = updates.dailyWorkHours;
    await entities.employees.update({ id, data });
  } catch (e) {
    console.error('Failed to update employee:', e);
  }
}

export async function deleteEmployee(id: string): Promise<void> {
  try {
    await entities.employees.delete({ id });
  } catch (e) {
    console.error('Failed to delete employee:', e);
  }
}

// ============ ATTENDANCE API ============

export async function fetchAttendanceRecords(): Promise<AttendanceRecord[]> {
  try {
    const res = await entities.attendance_records.query({ query: {}, limit: 500 });
    const items = res?.data?.items || [];
    return items.map(mapDbAttendance);
  } catch (e) {
    console.error('Failed to fetch attendance:', e);
    return [];
  }
}

export async function createAttendanceRecord(record: Omit<AttendanceRecord, 'id'>): Promise<AttendanceRecord | null> {
  try {
    const res = await entities.attendance_records.create({
      data: {
        date: record.date,
        employee_id: Number(record.employeeId),
        check_in: record.checkIn,
        check_out: record.checkOut,
        actual_hours: record.actualHours,
        required_hours: record.requiredHours,
        tardiness: record.tardiness,
        early_departure: record.earlyDeparture,
        day_status: record.dayStatus,
        absence_type: record.absenceType,
        notes: record.notes,
        approved: record.approved,
      },
    });
    return res?.data ? mapDbAttendance(res.data) : null;
  } catch (e) {
    console.error('Failed to create attendance record:', e);
    return null;
  }
}

export async function updateAttendanceRecord(id: string, updates: Partial<AttendanceRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.date !== undefined) data.date = updates.date;
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.checkIn !== undefined) data.check_in = updates.checkIn;
    if (updates.checkOut !== undefined) data.check_out = updates.checkOut;
    if (updates.actualHours !== undefined) data.actual_hours = updates.actualHours;
    if (updates.requiredHours !== undefined) data.required_hours = updates.requiredHours;
    if (updates.tardiness !== undefined) data.tardiness = updates.tardiness;
    if (updates.earlyDeparture !== undefined) data.early_departure = updates.earlyDeparture;
    if (updates.dayStatus !== undefined) data.day_status = updates.dayStatus;
    if (updates.absenceType !== undefined) data.absence_type = updates.absenceType;
    if (updates.notes !== undefined) data.notes = updates.notes;
    if (updates.approved !== undefined) data.approved = updates.approved;
    await entities.attendance_records.update({ id, data });
  } catch (e) {
    console.error('Failed to update attendance record:', e);
  }
}

export async function deleteAttendanceRecord(id: string): Promise<void> {
  try {
    await entities.attendance_records.delete({ id });
  } catch (e) {
    console.error('Failed to delete attendance record:', e);
  }
}

// ============ IDEAS API ============

export async function fetchIdeas(): Promise<IdeaRecord[]> {
  try {
    const res = await entities.ideas.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbIdea);
  } catch (e) {
    console.error('Failed to fetch ideas:', e);
    return [];
  }
}

export async function createIdea(idea: Omit<IdeaRecord, 'id'>): Promise<IdeaRecord | null> {
  try {
    const res = await entities.ideas.create({
      data: {
        month: idea.month,
        employee_id: Number(idea.employeeId),
        title: idea.title,
        status: idea.status,
        classification: idea.classification,
        expected_impact: idea.expectedImpact,
        submission_date: idea.submissionDate,
        decision_date: idea.decisionDate,
        revenue_generated: idea.revenueGenerated,
        notes: idea.notes,
      },
    });
    return res?.data ? mapDbIdea(res.data) : null;
  } catch (e) {
    console.error('Failed to create idea:', e);
    return null;
  }
}

export async function updateIdea(id: string, updates: Partial<IdeaRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.month !== undefined) data.month = updates.month;
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.title !== undefined) data.title = updates.title;
    if (updates.status !== undefined) data.status = updates.status;
    if (updates.classification !== undefined) data.classification = updates.classification;
    if (updates.expectedImpact !== undefined) data.expected_impact = updates.expectedImpact;
    if (updates.submissionDate !== undefined) data.submission_date = updates.submissionDate;
    if (updates.decisionDate !== undefined) data.decision_date = updates.decisionDate;
    if (updates.revenueGenerated !== undefined) data.revenue_generated = updates.revenueGenerated;
    if (updates.notes !== undefined) data.notes = updates.notes;
    await entities.ideas.update({ id, data });
  } catch (e) {
    console.error('Failed to update idea:', e);
  }
}

export async function deleteIdea(id: string): Promise<void> {
  try {
    await entities.ideas.delete({ id });
  } catch (e) {
    console.error('Failed to delete idea:', e);
  }
}

// ============ OVERTIME API ============

export async function fetchOvertimeRecords(): Promise<OvertimeRecord[]> {
  try {
    const res = await entities.overtime_records.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbOvertime);
  } catch (e) {
    console.error('Failed to fetch overtime records:', e);
    return [];
  }
}

export async function createOvertimeRecord(record: Omit<OvertimeRecord, 'id'>): Promise<OvertimeRecord | null> {
  try {
    const res = await entities.overtime_records.create({
      data: {
        date: record.date,
        employee_id: Number(record.employeeId),
        day_type: record.dayType,
        overtime_hours: record.overtimeHours,
        compensation_method: record.compensationMethod,
        approved: record.approved,
      },
    });
    return res?.data ? mapDbOvertime(res.data) : null;
  } catch (e) {
    console.error('Failed to create overtime record:', e);
    return null;
  }
}

export async function updateOvertimeRecord(id: string, updates: Partial<OvertimeRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.date !== undefined) data.date = updates.date;
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.dayType !== undefined) data.day_type = updates.dayType;
    if (updates.overtimeHours !== undefined) data.overtime_hours = updates.overtimeHours;
    if (updates.compensationMethod !== undefined) data.compensation_method = updates.compensationMethod;
    if (updates.approved !== undefined) data.approved = updates.approved;
    await entities.overtime_records.update({ id, data });
  } catch (e) {
    console.error('Failed to update overtime record:', e);
  }
}

export async function deleteOvertimeRecord(id: string): Promise<void> {
  try {
    await entities.overtime_records.delete({ id });
  } catch (e) {
    console.error('Failed to delete overtime record:', e);
  }
}

// ============ VIOLATIONS API ============

export async function fetchViolations(): Promise<ViolationRecord[]> {
  try {
    const res = await entities.violations.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbViolation);
  } catch (e) {
    console.error('Failed to fetch violations:', e);
    return [];
  }
}

export async function createViolation(record: Omit<ViolationRecord, 'id'>): Promise<ViolationRecord | null> {
  try {
    const res = await entities.violations.create({
      data: {
        date: record.date,
        employee_id: Number(record.employeeId),
        violation_type: record.violationType,
        details: record.details,
        severity: record.severity,
        is_repeated: record.isRepeated,
        penalty: record.penalty,
        deduction_amount: record.deductionAmount,
        deduction_days: record.deductionDays,
        notification_date: record.notificationDate,
        grievance_status: record.grievanceStatus,
        notes: record.notes,
      },
    });
    return res?.data ? mapDbViolation(res.data) : null;
  } catch (e) {
    console.error('Failed to create violation:', e);
    return null;
  }
}

export async function updateViolation(id: string, updates: Partial<ViolationRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.date !== undefined) data.date = updates.date;
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.violationType !== undefined) data.violation_type = updates.violationType;
    if (updates.details !== undefined) data.details = updates.details;
    if (updates.severity !== undefined) data.severity = updates.severity;
    if (updates.isRepeated !== undefined) data.is_repeated = updates.isRepeated;
    if (updates.penalty !== undefined) data.penalty = updates.penalty;
    if (updates.deductionAmount !== undefined) data.deduction_amount = updates.deductionAmount;
    if (updates.deductionDays !== undefined) data.deduction_days = updates.deductionDays;
    if (updates.notificationDate !== undefined) data.notification_date = updates.notificationDate;
    if (updates.grievanceStatus !== undefined) data.grievance_status = updates.grievanceStatus;
    if (updates.notes !== undefined) data.notes = updates.notes;
    await entities.violations.update({ id, data });
  } catch (e) {
    console.error('Failed to update violation:', e);
  }
}

export async function deleteViolation(id: string): Promise<void> {
  try {
    await entities.violations.delete({ id });
  } catch (e) {
    console.error('Failed to delete violation:', e);
  }
}

// ============ PERFORMANCE API ============

export async function fetchPerformanceRecords(): Promise<PerformanceRecord[]> {
  try {
    const res = await entities.performance_records.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbPerformance);
  } catch (e) {
    console.error('Failed to fetch performance records:', e);
    return [];
  }
}

export async function createPerformanceRecord(record: Omit<PerformanceRecord, 'id'>): Promise<PerformanceRecord | null> {
  try {
    const res = await entities.performance_records.create({
      data: {
        month: record.month,
        employee_id: Number(record.employeeId),
        work_quality: record.workQuality,
        punctuality: record.punctuality,
        customer_satisfaction: record.customerSatisfaction,
        teamwork: record.teamwork,
        initiative: record.initiative,
        self_development: record.selfDevelopment,
      },
    });
    return res?.data ? mapDbPerformance(res.data) : null;
  } catch (e) {
    console.error('Failed to create performance record:', e);
    return null;
  }
}

export async function updatePerformanceRecord(id: string, updates: Partial<PerformanceRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.month !== undefined) data.month = updates.month;
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.workQuality !== undefined) data.work_quality = updates.workQuality;
    if (updates.punctuality !== undefined) data.punctuality = updates.punctuality;
    if (updates.customerSatisfaction !== undefined) data.customer_satisfaction = updates.customerSatisfaction;
    if (updates.teamwork !== undefined) data.teamwork = updates.teamwork;
    if (updates.initiative !== undefined) data.initiative = updates.initiative;
    if (updates.selfDevelopment !== undefined) data.self_development = updates.selfDevelopment;
    await entities.performance_records.update({ id, data });
  } catch (e) {
    console.error('Failed to update performance record:', e);
  }
}

export async function deletePerformanceRecord(id: string): Promise<void> {
  try {
    await entities.performance_records.delete({ id });
  } catch (e) {
    console.error('Failed to delete performance record:', e);
  }
}

// ============ CONTRACTS API ============

export async function fetchContracts(): Promise<ContractRecord[]> {
  try {
    const res = await entities.contracts.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbContract);
  } catch (e) {
    console.error('Failed to fetch contracts:', e);
    return [];
  }
}

export async function createContract(record: Omit<ContractRecord, 'id'>): Promise<ContractRecord | null> {
  try {
    const totalSalary = record.basicSalary + record.housingAllowance + record.transportAllowance + record.foodAllowance + record.otherAllowances;
    const res = await entities.contracts.create({
      data: {
        employee_id: Number(record.employeeId),
        contract_type: record.contractType,
        job_title: record.jobTitle || '',
        department: record.department || '',
        start_date: record.startDate,
        end_date: record.endDate || '',
        basic_salary: record.basicSalary,
        housing_allowance: record.housingAllowance,
        transport_allowance: record.transportAllowance,
        food_allowance: record.foodAllowance,
        other_allowances: record.otherAllowances,
        total_salary: totalSalary,
        working_hours: record.workingHours,
        annual_leave_days: record.annualLeaveDays,
        probation_period: record.probationPeriod,
        notice_period: record.noticePeriod,
        status: record.status,
        notes: record.notes || '',
        signed_date: record.signedDate || '',
        termination_date: record.terminationDate || '',
        termination_reason: record.terminationReason || '',
      },
    });
    return res?.data ? mapDbContract(res.data) : null;
  } catch (e) {
    console.error('Failed to create contract:', e);
    return null;
  }
}

export async function updateContract(id: string, updates: Partial<ContractRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.contractType !== undefined) data.contract_type = updates.contractType;
    if (updates.jobTitle !== undefined) data.job_title = updates.jobTitle;
    if (updates.department !== undefined) data.department = updates.department;
    if (updates.startDate !== undefined) data.start_date = updates.startDate;
    if (updates.endDate !== undefined) data.end_date = updates.endDate || '';
    if (updates.basicSalary !== undefined) data.basic_salary = updates.basicSalary;
    if (updates.housingAllowance !== undefined) data.housing_allowance = updates.housingAllowance;
    if (updates.transportAllowance !== undefined) data.transport_allowance = updates.transportAllowance;
    if (updates.foodAllowance !== undefined) data.food_allowance = updates.foodAllowance;
    if (updates.otherAllowances !== undefined) data.other_allowances = updates.otherAllowances;
    if (updates.basicSalary !== undefined || updates.housingAllowance !== undefined || updates.transportAllowance !== undefined || updates.foodAllowance !== undefined || updates.otherAllowances !== undefined) {
      const bs = updates.basicSalary ?? 0;
      const ha = updates.housingAllowance ?? 0;
      const ta = updates.transportAllowance ?? 0;
      const fa = updates.foodAllowance ?? 0;
      const oa = updates.otherAllowances ?? 0;
      data.total_salary = bs + ha + ta + fa + oa;
    }
    if (updates.workingHours !== undefined) data.working_hours = updates.workingHours;
    if (updates.annualLeaveDays !== undefined) data.annual_leave_days = updates.annualLeaveDays;
    if (updates.probationPeriod !== undefined) data.probation_period = updates.probationPeriod;
    if (updates.noticePeriod !== undefined) data.notice_period = updates.noticePeriod;
    if (updates.status !== undefined) data.status = updates.status;
    if (updates.notes !== undefined) data.notes = updates.notes;
    if (updates.signedDate !== undefined) data.signed_date = updates.signedDate || '';
    if (updates.terminationDate !== undefined) data.termination_date = updates.terminationDate || '';
    if (updates.terminationReason !== undefined) data.termination_reason = updates.terminationReason;
    await entities.contracts.update({ id, data });
  } catch (e) {
    console.error('Failed to update contract:', e);
  }
}

export async function deleteContract(id: string): Promise<void> {
  try {
    await entities.contracts.delete({ id });
  } catch (e) {
    console.error('Failed to delete contract:', e);
  }
}

// ============ PERFORMANCE KPI API ============

export async function fetchPerformanceKpis(): Promise<PerformanceKpiRecord[]> {
  try {
    const res = await entities.performance_kpis.query({ query: {}, limit: 200 });
    const items = res?.data?.items || [];
    return items.map(mapDbPerformanceKpi);
  } catch (e) {
    console.error('Failed to fetch performance KPIs:', e);
    return [];
  }
}

export async function createPerformanceKpi(record: Omit<PerformanceKpiRecord, 'id'>): Promise<PerformanceKpiRecord | null> {
  try {
    const achievementRate = record.tasksTarget > 0 ? Math.floor((record.tasksCompleted / record.tasksTarget) * 100) : 0;
    let kpiBonus = 0;
    // Find employee salary for bonus calculation - will be passed from frontend
    if (achievementRate >= 100) kpiBonus = record.kpiBonus;
    else if (achievementRate >= 90) kpiBonus = record.kpiBonus;

    const overallRating = getKpiRating(achievementRate);

    const res = await entities.performance_kpis.create({
      data: {
        employee_id: Number(record.employeeId),
        month: record.month,
        tasks_target: record.tasksTarget,
        tasks_completed: record.tasksCompleted,
        achievement_rate: achievementRate,
        kpi_bonus: kpiBonus,
        quality_score: record.qualityScore,
        timeliness_score: record.timelinessScore,
        collaboration_score: record.collaborationScore,
        innovation_score: record.innovationScore,
        overall_rating: overallRating,
        manager_notes: record.managerNotes || '',
        employee_goals: record.employeeGoals || '',
      },
    });
    return res?.data ? mapDbPerformanceKpi(res.data) : null;
  } catch (e) {
    console.error('Failed to create performance KPI:', e);
    return null;
  }
}

export async function updatePerformanceKpi(id: string, updates: Partial<PerformanceKpiRecord>): Promise<void> {
  try {
    const data: Record<string, unknown> = {};
    if (updates.employeeId !== undefined) data.employee_id = Number(updates.employeeId);
    if (updates.month !== undefined) data.month = updates.month;
    if (updates.tasksTarget !== undefined) data.tasks_target = updates.tasksTarget;
    if (updates.tasksCompleted !== undefined) data.tasks_completed = updates.tasksCompleted;
    if (updates.tasksTarget !== undefined && updates.tasksCompleted !== undefined) {
      data.achievement_rate = updates.tasksTarget > 0 ? Math.floor((updates.tasksCompleted / updates.tasksTarget) * 100) : 0;
      data.overall_rating = getKpiRating(data.achievement_rate as number);
    }
    if (updates.kpiBonus !== undefined) data.kpi_bonus = updates.kpiBonus;
    if (updates.qualityScore !== undefined) data.quality_score = updates.qualityScore;
    if (updates.timelinessScore !== undefined) data.timeliness_score = updates.timelinessScore;
    if (updates.collaborationScore !== undefined) data.collaboration_score = updates.collaborationScore;
    if (updates.innovationScore !== undefined) data.innovation_score = updates.innovationScore;
    if (updates.overallRating !== undefined) data.overall_rating = updates.overallRating;
    if (updates.managerNotes !== undefined) data.manager_notes = updates.managerNotes;
    if (updates.employeeGoals !== undefined) data.employee_goals = updates.employeeGoals;
    await entities.performance_kpis.update({ id, data });
  } catch (e) {
    console.error('Failed to update performance KPI:', e);
  }
}

export async function deletePerformanceKpi(id: string): Promise<void> {
  try {
    await entities.performance_kpis.delete({ id });
  } catch (e) {
    console.error('Failed to delete performance KPI:', e);
  }
}

// ============ KPI CALCULATION FUNCTIONS ============

export function calculateKpiAchievementRate(tasksCompleted: number, tasksTarget: number): number {
  if (tasksTarget <= 0) return 0;
  return Math.floor((tasksCompleted / tasksTarget) * 100);
}

export function calculateKpiBonus(achievementRate: number, basicSalary: number): number {
  if (achievementRate >= 100) return Math.floor(basicSalary * 0.10);
  if (achievementRate >= 90) return Math.floor(basicSalary * 0.05);
  return 0;
}

export function getKpiRating(achievementRate: number): string {
  if (achievementRate >= 100) return 'ممتاز - تجاوز المستهدف';
  if (achievementRate >= 90) return 'جيد جداً - قريب من المستهدف';
  if (achievementRate >= 75) return 'جيد - أداء مقبول';
  if (achievementRate >= 50) return 'يحتاج تحسين';
  return 'ضعيف - يحتاج تدخل';
}

export function getKpiRatingColor(achievementRate: number): string {
  if (achievementRate >= 100) return 'text-emerald-600 bg-emerald-50';
  if (achievementRate >= 90) return 'text-green-600 bg-green-50';
  if (achievementRate >= 75) return 'text-yellow-600 bg-yellow-50';
  if (achievementRate >= 50) return 'text-orange-600 bg-orange-50';
  return 'text-red-600 bg-red-50';
}

// ============ CONTRACT HELPER FUNCTIONS ============

export function getContractStatusColor(status: string): string {
  switch (status) {
    case 'نشط': return 'text-emerald-600 bg-emerald-50';
    case 'مسودة': return 'text-yellow-600 bg-yellow-50';
    case 'منتهي': return 'text-gray-600 bg-gray-100';
    case 'ملغي': return 'text-red-600 bg-red-50';
    default: return 'text-gray-600 bg-gray-100';
  }
}

export function calculateContractTotal(
  basicSalary: number,
  housingAllowance: number,
  transportAllowance: number,
  foodAllowance: number,
  otherAllowances: number
): number {
  return basicSalary + housingAllowance + transportAllowance + foodAllowance + otherAllowances;
}

export function calculateHourlyRate(monthlySalary: number): number {
  return Math.floor((monthlySalary / 192) * 100) / 100;
}

// ============ CALCULATION FUNCTIONS ============

export function calculateTardiness(checkIn: string): number {
  if (!checkIn) return 0;
  const [h, m] = checkIn.split(':').map(Number);
  const checkInMinutes = h * 60 + m;
  const startMinutes = 9 * 60;
  return Math.max(0, checkInMinutes - startMinutes);
}

export function calculateEarlyDeparture(checkOut: string): number {
  if (!checkOut) return 0;
  const [h, m] = checkOut.split(':').map(Number);
  const checkOutMinutes = h * 60 + m;
  const endMinutes = 17 * 60;
  return Math.max(0, endMinutes - checkOutMinutes);
}

export function calculateActualHours(checkIn: string, checkOut: string): number {
  if (!checkIn || !checkOut) return 0;
  const [h1, m1] = checkIn.split(':').map(Number);
  const [h2, m2] = checkOut.split(':').map(Number);
  return Math.max(0, (h2 * 60 + m2 - (h1 * 60 + m1)) / 60);
}

export function calculateOvertimeRate(dayType: string): number {
  if (dayType === 'يوم عادي') return 1.25;
  if (dayType === 'إجازة أسبوعية' || dayType === 'إجازة رسمية') return 1.5;
  return 1;
}

export function calculateOvertimeAmount(basicSalary: number, hours: number, dayType: string): number {
  const hourlyRate = basicSalary / 176;
  const rate = calculateOvertimeRate(dayType);
  return hours * hourlyRate * rate;
}

export function calculatePerformanceScore(
  record: PerformanceRecord,
  ideas: IdeaRecord[]
): number {
  const ideasCount = ideas.length;
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة').length;
  const acceptanceRate = ideasCount > 0 ? (acceptedIdeas / ideasCount) * 100 : 0;

  const ideasScore = ideasCount >= 3 ? 10 : ideasCount * 3.33;
  const acceptanceScore = acceptanceRate >= 20 ? 10 : acceptanceRate / 2;

  return (
    record.workQuality * 0.25 +
    record.punctuality * 0.15 +
    ideasScore * 0.1 +
    acceptanceScore * 0.1 +
    record.customerSatisfaction * 0.15 +
    record.teamwork * 0.1 +
    record.initiative * 0.1 +
    record.selfDevelopment * 0.05
  );
}

export function getPerformanceRating(score: number): string {
  if (score >= 9) return 'ممتاز - استثنائي';
  if (score >= 7) return 'جيد جداً - يفوق التوقعات';
  if (score >= 5) return 'جيد - يلبي التوقعات';
  if (score >= 3) return 'مقبول - يحتاج تحسين';
  return 'ضعيف - يحتاج تدخل فوري';
}

export function getRatingColor(score: number): string {
  if (score >= 9) return 'text-emerald-600 bg-emerald-50';
  if (score >= 7) return 'text-green-600 bg-green-50';
  if (score >= 5) return 'text-yellow-600 bg-yellow-50';
  if (score >= 3) return 'text-orange-600 bg-orange-50';
  return 'text-red-600 bg-red-50';
}

export function formatCurrency(amount: number): string {
  return `${amount.toFixed(2)} ر.ع`;
}

export function getCurrentMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

// ============ HELPER: Get employee name from list ============

export function getEmployeeNameFromList(employees: Employee[], id: string): string {
  const emp = employees.find((e) => e.id === id);
  return emp ? emp.fullName : 'غير معروف';
}

export function getEmployeeByIdFromList(employees: Employee[], id: string): Employee | undefined {
  return employees.find((e) => e.id === id);
}

// ============ LEAVE BALANCE CALCULATION ============

export function calculateLeaveBalance(
  employeeId: string,
  year: number,
  employees: Employee[],
  attendance: AttendanceRecord[]
): LeaveBalanceRecord {
  const emp = employees.find((e) => e.id === employeeId);
  const empAttendance = attendance.filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d.getFullYear() === year;
  });

  const annualUsed = empAttendance.filter((a) => a.absenceType === 'إجازة سنوية مدفوعة').length;
  const sickUsed = empAttendance.filter((a) => a.absenceType === 'إجازة مرضية مدفوعة').length;
  const emergencyUsed = empAttendance.filter((a) => a.absenceType === 'إجازة طارئة مدفوعة').length;
  const unpaidUsed = empAttendance.filter((a) => a.absenceType === 'إجازة بدون راتب').length;

  return {
    employeeId,
    year,
    annualEntitled: emp?.annualLeaveBalance || 30,
    annualUsed,
    sickEntitled: 15,
    sickUsed,
    emergencyUsed,
    unpaidUsed,
  };
}

// ============ MONTHLY ATTENDANCE STATS ============

export function getMonthlyAttendanceStats(
  employeeId: string,
  month: string,
  allAttendance: AttendanceRecord[]
) {
  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const records = allAttendance.filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d >= startDate && d <= endDate;
  });

  const presentDays = records.filter((r) => r.dayStatus === 'حاضر').length;
  const absentDays = records.filter((r) => r.dayStatus === 'غائب').length;
  const totalTardiness = records.reduce((sum, r) => sum + (r.tardiness || 0), 0);
  const tardinessCount = records.filter((r) => r.tardiness > 0).length;

  let workingDays = 0;
  const current = new Date(startDate);
  while (current <= endDate) {
    const day = current.getDay();
    if (day !== 5 && day !== 6) workingDays++;
    current.setDate(current.getDate() + 1);
  }

  const attendanceRate = workingDays > 0 ? (presentDays / workingDays) * 100 : 0;

  return {
    presentDays,
    absentDays,
    totalTardiness,
    tardinessCount,
    workingDays,
    attendanceRate,
    totalRecords: records.length,
  };
}

// ============ REWARDS CALCULATION ============

export function calculateMonthlyRewards(
  employeeId: string,
  month: string,
  employees: Employee[],
  allAttendance: AttendanceRecord[],
  allIdeas: IdeaRecord[],
  allOvertime: OvertimeRecord[],
  allViolations: ViolationRecord[]
) {
  const emp = employees.find((e) => e.id === employeeId);
  if (!emp) return null;

  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const overtimeRecords = allOvertime.filter((o) => {
    const d = new Date(o.date);
    return o.employeeId === employeeId && d >= startDate && d <= endDate && o.approved === 'نعم';
  });
  const overtimeReward = overtimeRecords.reduce(
    (sum, o) => sum + calculateOvertimeAmount(emp.basicSalary, o.overtimeHours, o.dayType),
    0
  );

  const ideas = allIdeas.filter(
    (i) => i.employeeId === employeeId && i.month === month
  );
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length;
  const ideaReward = acceptedIdeas * 50;
  const ideaRevenue = ideas.reduce((sum, i) => sum + (i.revenueGenerated || 0), 0);

  let commission = 0;
  if (ideaRevenue > 0) {
    if (ideaRevenue < 5000) commission = ideaRevenue * 0.03;
    else if (ideaRevenue < 10000) commission = ideaRevenue * 0.05;
    else commission = ideaRevenue * 0.07;
  }

  const attendance = allAttendance.filter((a) => {
    const d = new Date(a.date);
    return a.employeeId === employeeId && d >= startDate && d <= endDate;
  });
  const unauthorizedAbsences = attendance.filter(
    (a) => a.absenceType === 'غياب بدون إذن'
  ).length;
  const absenceDeduction = unauthorizedAbsences * (emp.basicSalary / 26);

  // Tardiness deduction: convert total tardiness minutes to hours, then multiply by hourly rate
  const totalTardinessMinutes = attendance.reduce((sum, a) => sum + (a.tardiness || 0), 0);
  const hourlyRate = emp.basicSalary / 176; // 22 working days × 8 hours
  const tardinessDeduction = (totalTardinessMinutes / 60) * hourlyRate;

  const violations = allViolations.filter((v) => {
    const d = new Date(v.date);
    return v.employeeId === employeeId && d >= startDate && d <= endDate;
  });
  const violationDeduction = violations.reduce((sum, v) => sum + (v.deductionAmount || 0), 0);

  const totalRewards = overtimeReward + ideaReward + commission;
  const totalDeductions = absenceDeduction + tardinessDeduction + violationDeduction;
  const netAmount = totalRewards - totalDeductions;
  const finalSalary = emp.basicSalary + netAmount;

  return {
    basicSalary: emp.basicSalary,
    overtimeReward: Math.round(overtimeReward * 100) / 100,
    acceptedIdeas,
    ideaReward,
    ideaRevenue,
    commission: Math.round(commission * 100) / 100,
    totalRewards: Math.round(totalRewards * 100) / 100,
    absenceDeduction: Math.round(absenceDeduction * 100) / 100,
    tardinessMinutes: totalTardinessMinutes,
    tardinessDeduction: Math.round(tardinessDeduction * 100) / 100,
    violationDeduction: Math.round(violationDeduction * 100) / 100,
    totalDeductions: Math.round(totalDeductions * 100) / 100,
    netAmount: Math.round(netAmount * 100) / 100,
    finalSalary: Math.round(finalSalary * 100) / 100,
  };
}

// ============ DASHBOARD STATS ============

export function getDashboardStats(
  month: string,
  employees: Employee[],
  allAttendance: AttendanceRecord[],
  allIdeas: IdeaRecord[],
  allOvertime: OvertimeRecord[],
  allViolations: ViolationRecord[]
) {
  const activeEmployees = employees.filter((e) => e.status === 'نشط');

  const [yearStr, monthStr] = month.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const attendance = allAttendance.filter((a) => {
    const d = new Date(a.date);
    return d >= startDate && d <= endDate;
  });

  const presentCount = attendance.filter((a) => a.dayStatus === 'حاضر').length;
  const absentCount = attendance.filter((a) => a.dayStatus === 'غائب').length;
  const totalTardiness = attendance.reduce((sum, a) => sum + (a.tardiness || 0), 0);
  const attendanceRate = attendance.length > 0 ? (presentCount / attendance.length) * 100 : 0;

  const ideas = allIdeas.filter((i) => i.month === month);
  const acceptedIdeas = ideas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length;

  const overtime = allOvertime.filter((o) => {
    const d = new Date(o.date);
    return d >= startDate && d <= endDate;
  });
  const totalOvertimeHours = overtime.reduce((sum, o) => sum + o.overtimeHours, 0);

  const violations = allViolations.filter((v) => {
    const d = new Date(v.date);
    return d >= startDate && d <= endDate;
  });

  let totalRewards = 0;
  let totalDeductions = 0;
  activeEmployees.forEach((emp) => {
    const rewards = calculateMonthlyRewards(
      emp.id, month, employees, allAttendance, allIdeas, allOvertime, allViolations
    );
    if (rewards) {
      totalRewards += rewards.totalRewards;
      totalDeductions += rewards.totalDeductions;
    }
  });

  const employeeAttendance = activeEmployees.map((emp) => {
    const stats = getMonthlyAttendanceStats(emp.id, month, allAttendance);
    return { ...emp, ...stats };
  });
  const top5Attendance = employeeAttendance
    .sort((a, b) => b.attendanceRate - a.attendanceRate)
    .slice(0, 5);

  const lowAttendance = employeeAttendance.filter(
    (e) => e.attendanceRate < 90 && e.totalRecords > 0
  );
  const repeatedTardiness = employeeAttendance.filter((e) => e.tardinessCount > 3);

  const DEPARTMENTS = [
    'قسم الإبداع', 'قسم الإدارة', 'القسم التجاري',
  ];

  const deptStats = DEPARTMENTS.map((dept) => {
    const deptEmps = activeEmployees.filter((e) => e.department === dept);
    const deptAttendance = deptEmps.map((emp) => getMonthlyAttendanceStats(emp.id, month, allAttendance));
    const avgAttendance =
      deptAttendance.length > 0
        ? deptAttendance.reduce((sum, s) => sum + s.attendanceRate, 0) / deptAttendance.length
        : 0;
    return { department: dept, employeeCount: deptEmps.length, avgAttendance: Math.round(avgAttendance) };
  }).filter((d) => d.employeeCount > 0);

  return {
    totalEmployees: employees.length,
    activeEmployees: activeEmployees.length,
    attendanceRate: Math.round(attendanceRate * 10) / 10,
    presentCount,
    absentCount,
    totalTardiness,
    totalIdeas: ideas.length,
    acceptedIdeas,
    totalOvertimeHours: Math.round(totalOvertimeHours * 10) / 10,
    totalViolations: violations.length,
    totalRewards: Math.round(totalRewards * 100) / 100,
    totalDeductions: Math.round(totalDeductions * 100) / 100,
    top5Attendance,
    lowAttendance,
    repeatedTardiness,
    deptStats,
  };
}

// ============ DROPDOWN OPTIONS (re-exported) ============

export const DEPARTMENTS = [
  'قسم الإبداع', 'قسم الإدارة', 'القسم التجاري',
];

export const EMPLOYEE_STATUSES = ['نشط', 'إجازة', 'متوقف مؤقتاً', 'منتهي الخدمة'];

export const DAY_STATUSES = [
  'حاضر', 'غائب', 'إجازة سنوية', 'إجازة مرضية',
  'إجازة طارئة', 'إجازة بدون راتب', 'يوم عطلة رسمية', 'يوم راحة أسبوعية',
];

export const ABSENCE_TYPES = [
  'لا ينطبق', 'إجازة سنوية مدفوعة', 'إجازة مرضية مدفوعة',
  'إجازة طارئة مدفوعة', 'إجازة بدون راتب', 'غياب بإذن', 'غياب بدون إذن',
];

export const APPROVAL_STATUSES = ['نعم', 'لا', 'قيد المراجعة', 'لا ينطبق'];

export const IDEA_STATUSES = ['قيد المراجعة', 'مقبولة', 'قيد التنفيذ', 'منفذة', 'مرفوضة'];

export const IDEA_CLASSIFICATIONS = [
  'تحسين العمليات', 'خدمة جديدة', 'تحسين خدمة موجودة', 'توفير التكاليف', 'زيادة الإيرادات',
];

export const IMPACT_LEVELS = ['عالي جداً', 'عالي', 'متوسط', 'منخفض'];

export const DAY_TYPES = ['يوم عادي', 'إجازة أسبوعية', 'إجازة رسمية'];

export const COMPENSATION_METHODS = ['مكافأة مالية', 'يوم إجازة بديل', 'إضافة للراتب'];

export const VIOLATION_TYPES = [
  'التأخر في تسليم الأعمال', 'أخطاء متكررة في الأعمال', 'عدم تحديث نظام Odoo',
  'عدم تسليم التقرير الشهري', 'التأخر في الحضور (أكثر من 30 دقيقة)',
  'التأخر المتكرر في الحضور', 'الغياب بدون إذن', 'الانصراف المبكر المتكرر',
];

export const SEVERITY_LEVELS = ['بسيط', 'متوسط', 'خطير', 'خطير جداً'];

export const RECURRENCE_OPTIONS = [
  'المرة الأولى', 'المرة الثانية', 'المرة الثالثة', 'المرة الرابعة أو أكثر',
];

export const PENALTY_TYPES = [
  'إنذار شفهي', 'إنذار كتابي', 'خصم نصف يوم', 'خصم يوم كامل',
  'خصم يومين', 'خصم 3 أيام', 'خصم 5 أيام', 'إيقاف عن العمل', 'الفصل',
];

export const GRIEVANCE_STATUSES = [
  'لا يوجد تظلم', 'تظلم قيد المراجعة', 'تظلم مقبول', 'تظلم مرفوض',
];

export const JOB_TITLES = [
  'مطور برمجيات',
  'مصمم جرافيكي',
  'مصور فوتوغرافي',
  'مصور فيديو',
  'كاتب محتوى',
  'مدير حساب',
  'مدير قسم الإبداع',
  'مدير مالي إداري',
  'موظف إداري',
];

export const CONTRACT_TYPES = ['محدد المدة', 'غير محدد المدة', 'تجربة'];

export const CONTRACT_STATUSES = ['مسودة', 'نشط', 'منتهي', 'ملغي'];

// ============ NOTIFICATION TYPES & API ============

export interface NotificationRecord {
  id: number;
  userId: string;
  employeeId: number;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  relatedId: number | null;
  createdAt: string;
}

interface DbNotification {
  id: number;
  user_id: string;
  employee_id: number;
  type: string;
  title: string;
  message: string;
  is_read: boolean;
  related_id: number | null;
  created_at: string | null;
}

function mapDbNotification(db: DbNotification): NotificationRecord {
  return {
    id: db.id,
    userId: db.user_id,
    employeeId: db.employee_id,
    type: db.type,
    title: db.title,
    message: db.message,
    isRead: db.is_read,
    relatedId: db.related_id,
    createdAt: db.created_at || '',
  };
}

export async function fetchNotifications(unreadOnly = false): Promise<NotificationRecord[]> {
  try {
    const params: Record<string, string> = { limit: '50' };
    if (unreadOnly) params.unread_only = 'true';
    const res = await apiGet('/api/v1/notifications/list', params);
    const items = res?.data?.items || [];
    return items.map(mapDbNotification);
  } catch (e) {
    console.error('Failed to fetch notifications:', e);
    return [];
  }
}

export async function fetchUnreadCount(): Promise<number> {
  try {
    const res = await apiGet('/api/v1/notifications/unread_count');
    return res?.data?.count || 0;
  } catch (e) {
    console.error('Failed to fetch unread count:', e);
    return 0;
  }
}

export async function markNotificationRead(notificationId: number): Promise<void> {
  try {
    await apiPost(`/api/v1/notifications/read/${notificationId}`);
  } catch (e) {
    console.error('Failed to mark notification as read:', e);
  }
}

export async function markAllNotificationsRead(): Promise<void> {
  try {
    await apiPost('/api/v1/notifications/read_all');
  } catch (e) {
    console.error('Failed to mark all notifications as read:', e);
  }
}

export async function createNotification(
  employeeId: number,
  type: string,
  title: string,
  message: string,
  relatedId?: number,
  targetUserId?: string,
): Promise<void> {
  try {
    await apiPost('/api/v1/notifications/create', {
      employee_id: employeeId,
      type,
      title,
      message,
      related_id: relatedId || null,
      target_user_id: targetUserId || null,
    });
  } catch (e) {
    console.error('Failed to create notification:', e);
  }
}

// ============ CLICKUP INTEGRATION API ============

export interface ClickUpWorkspace {
  id: string;
  name: string;
}

export interface ClickUpMember {
  clickup_id: string;
  username: string;
  email: string;
  total_tasks: number;
  completed_tasks: number;
  in_progress_tasks: number;
  completion_rate: number;
}

export interface ClickUpSummary {
  members: ClickUpMember[];
  total_tasks: number;
  total_completed: number;
}

export async function fetchClickUpWorkspaces(): Promise<ClickUpWorkspace[]> {
  try {
    const res = await apiGet('/api/v1/clickup/workspaces');
    return res?.data?.workspaces || [];
  } catch (error: any) {
    const status = error?.status;
    const detail = error?.data?.detail || '';
    
    // 401 = user's auth token expired (NOT ClickUp token)
    if (status === 401) {
      const authError = new Error('SESSION_EXPIRED') as any;
      authError.response = { status, data: error.data };
      authError.isAuthError = true;
      throw authError;
    }
    
    // 400 with TOKEN_NOT_CONFIGURED = ClickUp token not saved
    if (status === 400 && detail === 'TOKEN_NOT_CONFIGURED') {
      const tokenError = new Error('TOKEN_NOT_CONFIGURED') as any;
      tokenError.response = { status, data: error.data };
      throw tokenError;
    }
    
    // Re-throw with original response data preserved
    throw error;
  }
}

export async function fetchClickUpSummary(
  teamId: string,
  dateFrom?: string,
  dateTo?: string,
): Promise<ClickUpSummary | null> {
  try {
    const res = await apiPost('/api/v1/clickup/summary', {
      team_id: teamId,
      date_from: dateFrom || null,
      date_to: dateTo || null,
    });
    return res?.data || null;
  } catch (e) {
    console.error('Failed to fetch ClickUp summary:', e);
    return null;
  }
}

export function getNotificationIcon(type: string): string {
  switch (type) {
    case 'leave_approved': return '✅';
    case 'leave_rejected': return '❌';
    case 'idea_accepted': return '💡';
    case 'idea_rejected': return '🚫';
    case 'violation_added': return '⚠️';
    case 'kpi_updated': return '📊';
    case 'overtime_approved': return '⏰';
    case 'grievance_response': return '📋';
    default: return '🔔';
  }
}

export function getNotificationTypeLabel(type: string): string {
  switch (type) {
    case 'leave_approved': return 'إجازة معتمدة';
    case 'leave_rejected': return 'إجازة مرفوضة';
    case 'idea_accepted': return 'فكرة مقبولة';
    case 'idea_rejected': return 'فكرة مرفوضة';
    case 'violation_added': return 'مخالفة جديدة';
    case 'kpi_updated': return 'تحديث الأداء';
    case 'overtime_approved': return 'عمل إضافي معتمد';
    case 'grievance_response': return 'رد على التظلم';
    default: return 'إشعار';
  }
}