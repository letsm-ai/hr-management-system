/**
 * Configuration for the HR system.
 * On Atoms platform, API calls use relative URLs (same origin).
 * The SDK handles routing automatically.
 */

export function getAPIBaseURL(): string {
  // For VPS deployment, set VITE_API_URL environment variable
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }
  // On Atoms platform, use empty string (relative URLs)
  return '';
}

export const config = {
  get API_BASE_URL() {
    return getAPIBaseURL();
  },
};