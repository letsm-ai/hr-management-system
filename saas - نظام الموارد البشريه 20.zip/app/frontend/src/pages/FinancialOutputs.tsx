import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DollarSign, FileSpreadsheet, Menu, Award, Users, TrendingUp } from 'lucide-react';
import { Sidebar } from './Index';
import { useHRData } from '@/lib/hr-data-context';
import { useAuth } from '@/lib/auth-context';
import IncentiveReport from './IncentiveReport';
import MonthlyRewards from './MonthlyRewards';

export default function FinancialOutputs() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('report');
  const { user, loading: authLoading, login } = useAuth();
  const { employees } = useHRData();

  const totalEmployees = employees.filter(e => e.status === 'نشط').length;

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card><CardContent className="p-8 text-center">
          <DollarSign className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
          <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
        </CardContent></Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <DollarSign className="w-6 h-6 text-emerald-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">المخرجات المالية</h1>
              <p className="text-xs text-[#64748B]">الرواتب والمكافآت والمخالفات والصافي النهائي</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-100">
                  <Users className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-emerald-600 font-medium">الموظفين النشطين</p>
                  <p className="text-lg font-bold text-emerald-800">{totalEmployees}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-blue-600 font-medium">المستفيدين المحتملين</p>
                  <p className="text-lg font-bold text-blue-800">{totalEmployees}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-100">
                  <Award className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-xs text-purple-600 font-medium">نظام الحساب</p>
                  <p className="text-lg font-bold text-purple-800">مُفعّل</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 h-11">
              <TabsTrigger value="report" className="gap-1.5 text-xs sm:text-sm">
                <FileSpreadsheet className="w-4 h-4" />
                التقرير المالي الشامل
              </TabsTrigger>
              <TabsTrigger value="results" className="gap-1.5 text-xs sm:text-sm">
                <Award className="w-4 h-4" />
                نتائج المكافآت
              </TabsTrigger>
            </TabsList>

            <TabsContent value="report" className="mt-4 embedded-page">
              <IncentiveReport />
            </TabsContent>
            <TabsContent value="results" className="mt-4 embedded-page">
              <MonthlyRewards />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}