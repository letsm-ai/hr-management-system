import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { useRole } from '@/lib/role-context';
import { useHRData } from '@/lib/hr-data-context';
import { client } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight, Users, Shield, Trash2, Edit, UserCheck, Clock, RefreshCw, UserPlus, AlertCircle,
} from 'lucide-react';

interface UserRoleItem {
  id: number;
  user_id: string;
  role: string;
  employee_id: number | null;
  email?: string;
  name?: string;
}

interface PendingUser {
  id: number;
  user_id: string;
  email: string;
  name: string;
  created_at: string;
}

async function rolesApiGet(path: string) {
  try {
    const res = await client.apiCall.invoke({ url: path, method: 'GET' });
    return res.data;
  } catch (err: any) {
    const errData = err?.response?.data || err?.data || {};
    throw { status: err?.response?.status || 500, data: errData, message: errData?.detail || `Request failed` };
  }
}

async function rolesApiPost(path: string, body: Record<string, unknown>) {
  try {
    const res = await client.apiCall.invoke({ url: path, method: 'POST', data: body });
    return res.data;
  } catch (err: any) {
    const errData = err?.response?.data || err?.data || {};
    throw { status: err?.response?.status || 500, data: errData, message: errData?.detail || `Request failed` };
  }
}

async function rolesApiDelete(path: string) {
  try {
    const res = await client.apiCall.invoke({ url: path, method: 'DELETE' });
    return res.data;
  } catch (err: any) {
    const errData = err?.response?.data || err?.data || {};
    throw { status: err?.response?.status || 500, data: errData, message: errData?.detail || `Request failed` };
  }
}

export default function UserManagement() {
  const { user } = useAuth();
  const { isAdmin } = useRole();
  const { employees } = useHRData();
  const navigate = useNavigate();

  const [roles, setRoles] = useState<UserRoleItem[]>([]);
  const [pendingUsers, setPendingUsers] = useState<PendingUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [pendingError, setPendingError] = useState('');
  const [approveDialogOpen, setApproveDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [manualDialogOpen, setManualDialogOpen] = useState(false);
  const [selectedPending, setSelectedPending] = useState<PendingUser | null>(null);
  const [editingRole, setEditingRole] = useState<UserRoleItem | null>(null);

  const [formRole, setFormRole] = useState('employee');
  const [formEmployeeId, setFormEmployeeId] = useState('');
  const [manualUserId, setManualUserId] = useState('');

  useEffect(() => {
    fetchAll();
  }, []);

  async function fetchAll() {
    try {
      setLoading(true);
      setPendingError('');

      // Fetch roles
      let rolesData: UserRoleItem[] = [];
      try {
        const rolesRes = await rolesApiGet('/api/v1/roles/all');
        rolesData = rolesRes?.items || [];
      } catch (e) {
        console.error('Failed to fetch roles:', e);
      }
      setRoles(rolesData);

      // Fetch pending users separately to handle errors
      let pendingData: PendingUser[] = [];
      try {
        const pendingRes = await rolesApiGet('/api/v1/roles/pending');
        pendingData = pendingRes?.items || [];
      } catch (e: any) {
        console.error('Failed to fetch pending users:', e);
        setPendingError(e?.data?.detail || e?.message || 'فشل في تحميل طلبات الدخول المعلقة');
      }
      setPendingUsers(pendingData);
    } finally {
      setLoading(false);
    }
  }

  function openApproveDialog(pending: PendingUser) {
    setSelectedPending(pending);
    setFormRole('employee');
    setFormEmployeeId('');
    setApproveDialogOpen(true);
  }

  function openEditDialog(role: UserRoleItem) {
    setEditingRole(role);
    setFormRole(role.role);
    setFormEmployeeId(role.employee_id ? String(role.employee_id) : '');
    setEditDialogOpen(true);
  }

  function openManualDialog() {
    setManualUserId('');
    setFormRole('employee');
    setFormEmployeeId('');
    setManualDialogOpen(true);
  }

  async function handleApproveUser() {
    if (!selectedPending) return;
    if (formRole === 'employee' && !formEmployeeId) {
      toast.error('يرجى ربط المستخدم بملف موظف');
      return;
    }
    try {
      await rolesApiPost('/api/v1/roles/assign', {
        target_user_id: selectedPending.user_id,
        role: formRole,
        employee_id: formEmployeeId ? Number(formEmployeeId) : null,
      });
      toast.success('تم قبول المستخدم وتعيين الدور بنجاح');
      setApproveDialogOpen(false);
      setSelectedPending(null);
      fetchAll();
    } catch (e: any) {
      const detail = e?.data?.detail || e?.message || 'فشل في تعيين الدور';
      toast.error(detail);
    }
  }

  async function handleManualAssign() {
    if (!manualUserId.trim()) {
      toast.error('يرجى إدخال معرف المستخدم');
      return;
    }
    if (formRole === 'employee' && !formEmployeeId) {
      toast.error('يرجى ربط المستخدم بملف موظف');
      return;
    }
    try {
      await rolesApiPost('/api/v1/roles/assign', {
        target_user_id: manualUserId.trim(),
        role: formRole,
        employee_id: formEmployeeId ? Number(formEmployeeId) : null,
      });
      toast.success('تم تعيين الدور بنجاح');
      setManualDialogOpen(false);
      setManualUserId('');
      fetchAll();
    } catch (e: any) {
      const detail = e?.data?.detail || e?.message || 'فشل في تعيين الدور';
      toast.error(detail);
    }
  }

  async function handleUpdateRole() {
    if (!editingRole) return;
    try {
      await rolesApiPost('/api/v1/roles/assign', {
        target_user_id: editingRole.user_id,
        role: formRole,
        employee_id: formEmployeeId ? Number(formEmployeeId) : null,
      });
      toast.success('تم تحديث الدور بنجاح');
      setEditDialogOpen(false);
      setEditingRole(null);
      fetchAll();
    } catch (e: any) {
      const detail = e?.data?.detail || e?.message || 'فشل في تحديث الدور';
      toast.error(detail);
    }
  }

  async function handleDeleteRole(roleId: number) {
    if (!confirm('هل أنت متأكد من حذف هذا الدور؟')) return;
    try {
      await rolesApiDelete(`/api/v1/roles/${roleId}`);
      toast.success('تم حذف الدور بنجاح');
      fetchAll();
    } catch (e: any) {
      const detail = e?.data?.detail || e?.message || 'فشل في حذف الدور';
      toast.error(detail);
    }
  }

  function getEmployeeName(empId: number | null) {
    if (!empId) return '-';
    const emp = employees.find((e) => e.id === String(empId));
    return emp ? emp.fullName : `#${empId}`;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <Shield className="h-16 w-16 mx-auto text-red-400 mb-4" />
            <h2 className="text-xl font-bold">غير مصرح</h2>
            <p className="text-gray-500">هذه الصفحة متاحة للإداريين فقط</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir="rtl">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Users className="h-6 w-6 text-blue-600" />
          <h1 className="text-2xl font-bold">إدارة المستخدمين والصلاحيات</h1>
          <div className="mr-auto flex gap-2">
            <Button variant="outline" size="sm" onClick={fetchAll}>
              <RefreshCw className="h-4 w-4 ml-1" />
              تحديث
            </Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" onClick={openManualDialog}>
              <UserPlus className="h-4 w-4 ml-1" />
              إضافة مستخدم يدوياً
            </Button>
          </div>
        </div>

        {/* Current User Info */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-green-600" />
              <span className="text-sm">أنت مسجل كـ <Badge className="bg-green-600 text-white">مدير النظام</Badge></span>
            </div>
          </CardContent>
        </Card>

        {/* Pending Users Section */}
        <Card className="mb-6 border-2 border-yellow-400 shadow-md">
          <CardHeader className="pb-3 bg-yellow-50">
            <CardTitle className="text-lg flex items-center gap-2 text-yellow-700">
              <Clock className="h-6 w-6" />
              طلبات الدخول المعلقة ({pendingUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            {loading ? (
              <p className="text-center py-4 text-gray-500">جاري التحميل...</p>
            ) : pendingError ? (
              <div className="text-center py-4">
                <AlertCircle className="h-8 w-8 text-red-400 mx-auto mb-2" />
                <p className="text-sm text-red-500">{pendingError}</p>
                <Button variant="outline" size="sm" className="mt-2" onClick={fetchAll}>
                  إعادة المحاولة
                </Button>
              </div>
            ) : pendingUsers.length === 0 ? (
              <div className="text-center py-6 bg-gray-50 rounded-lg">
                <UserCheck className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">لا توجد طلبات معلقة حالياً</p>
                <p className="text-xs text-gray-400 mt-1">عندما يسجل مستخدم جديد دخوله سيظهر هنا تلقائياً</p>
                <p className="text-xs text-gray-400 mt-2">
                  💡 يمكنك أيضاً إضافة مستخدم يدوياً بالضغط على زر "إضافة مستخدم يدوياً" أعلاه
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingUsers.map((p) => (
                  <div key={p.id} className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg border-2 border-yellow-300">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className="bg-yellow-500 text-white">معلق</Badge>
                        {p.email && <span className="text-sm font-bold">{p.email}</span>}
                        {p.name && <span className="text-sm text-gray-600">({p.name})</span>}
                      </div>
                      <p className="text-xs text-gray-500 font-mono">
                        المعرف: {p.user_id}
                      </p>
                      {p.created_at && (
                        <p className="text-xs text-gray-400">
                          تاريخ التسجيل: {p.created_at.substring(0, 19)}
                        </p>
                      )}
                    </div>
                    <Button
                      size="default"
                      className="bg-green-600 hover:bg-green-700 text-white font-bold px-6"
                      onClick={() => openApproveDialog(p)}
                    >
                      <UserCheck className="h-5 w-5 ml-2" />
                      قبول وتعيين دور
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Existing Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>المستخدمون المعتمدون ({roles.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-center py-8 text-gray-500">جاري التحميل...</p>
            ) : roles.length === 0 ? (
              <p className="text-center py-8 text-gray-500">لا يوجد مستخدمون مسجلون</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">#</TableHead>
                    <TableHead className="text-right">الاسم</TableHead>
                    <TableHead className="text-right">البريد الإلكتروني</TableHead>
                    <TableHead className="text-right">الدور</TableHead>
                    <TableHead className="text-right">الموظف المرتبط</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roles.map((role, idx) => (
                    <TableRow key={role.id}>
                      <TableCell>{idx + 1}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{role.name || '-'}</span>
                          {role.user_id === user?.id && (
                            <Badge variant="outline" className="text-xs">أنت</Badge>
                          )}
                        </div>
                        <span className="text-xs text-gray-400 font-mono">#{role.user_id}</span>
                      </TableCell>
                      <TableCell className="text-sm">
                        {role.email || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge className={role.role === 'admin' ? 'bg-green-600 text-white' : 'bg-blue-600 text-white'}>
                          {role.role === 'admin' ? 'مدير' : 'موظف'}
                        </Badge>
                      </TableCell>
                      <TableCell>{getEmployeeName(role.employee_id)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openEditDialog(role)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          {role.user_id !== user?.id && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:bg-red-50"
                              onClick={() => handleDeleteRole(role.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>تعليمات إدارة المستخدمين</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-600 space-y-2">
            <p>1. <strong>أول مستخدم</strong> يسجل دخول للنظام يصبح تلقائياً مدير النظام (Admin).</p>
            <p>2. <strong>لإضافة موظف (تلقائي):</strong> اطلب من الموظف تسجيل الدخول - سيظهر تلقائياً في قسم "طلبات الدخول المعلقة" أعلاه.</p>
            <p>3. <strong>لإضافة موظف (يدوي):</strong> اضغط "إضافة مستخدم يدوياً" وأدخل معرف المستخدم الذي يظهر في صفحة انتظار الموظف.</p>
            <p>4. <strong>الموافقة:</strong> اضغط "قبول وتعيين دور" واختر الدور المناسب واربطه بملف الموظف.</p>
            <p>5. <strong>المدير:</strong> يمكنه الوصول لجميع صفحات النظام وإدارة جميع البيانات.</p>
            <p>6. <strong>الموظف:</strong> يرى فقط تقرير أدائه الشخصي، ويمكنه طلب إجازة وتقديم تظلم.</p>
          </CardContent>
        </Card>
      </div>

      {/* Approve Pending User Dialog */}
      <Dialog open={approveDialogOpen} onOpenChange={setApproveDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>قبول المستخدم وتعيين الدور</DialogTitle>
          </DialogHeader>
          {selectedPending && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm text-gray-500">معلومات المستخدم:</p>
                {selectedPending.email && (
                  <p className="font-medium">{selectedPending.email}</p>
                )}
                {selectedPending.name && (
                  <p className="text-sm text-gray-600">{selectedPending.name}</p>
                )}
                <p className="text-xs text-gray-400 font-mono mt-1">
                  المعرف: {selectedPending.user_id}
                </p>
              </div>
              <div>
                <Label>الدور</Label>
                <Select value={formRole} onValueChange={setFormRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">مدير (Admin) - صلاحيات كاملة</SelectItem>
                    <SelectItem value="employee">موظف (Employee) - صلاحيات محدودة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formRole === 'employee' && (
                <div>
                  <Label>ربط بالموظف</Label>
                  <Select value={formEmployeeId} onValueChange={setFormEmployeeId}>
                    <SelectTrigger><SelectValue placeholder="اختر الموظف" /></SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.fullName} - {emp.department}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <Button onClick={handleApproveUser} className="w-full bg-green-600 hover:bg-green-700 text-white">
                <UserCheck className="h-4 w-4 ml-2" />
                قبول وتعيين الدور
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Manual Add User Dialog */}
      <Dialog open={manualDialogOpen} onOpenChange={setManualDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة مستخدم يدوياً</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 rounded-lg p-3 text-sm text-blue-700">
              <p>أدخل معرف المستخدم الذي يظهر في صفحة انتظار الموظف بعد تسجيل دخوله.</p>
            </div>
            <div>
              <Label>معرف المستخدم (User ID)</Label>
              <Input
                value={manualUserId}
                onChange={(e) => setManualUserId(e.target.value)}
                placeholder="أدخل معرف المستخدم هنا..."
                className="font-mono text-sm"
                dir="ltr"
              />
            </div>
            <div>
              <Label>الدور</Label>
              <Select value={formRole} onValueChange={setFormRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">مدير (Admin) - صلاحيات كاملة</SelectItem>
                  <SelectItem value="employee">موظف (Employee) - صلاحيات محدودة</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formRole === 'employee' && (
              <div>
                <Label>ربط بالموظف</Label>
                <Select value={formEmployeeId} onValueChange={setFormEmployeeId}>
                  <SelectTrigger><SelectValue placeholder="اختر الموظف" /></SelectTrigger>
                  <SelectContent>
                    {employees.map((emp) => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.fullName} - {emp.department}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <Button onClick={handleManualAssign} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              <UserPlus className="h-4 w-4 ml-2" />
              إضافة وتعيين الدور
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل دور المستخدم</DialogTitle>
          </DialogHeader>
          {editingRole && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-3">
                {editingRole.name && (
                  <p className="font-medium">{editingRole.name}</p>
                )}
                {editingRole.email && (
                  <p className="text-sm text-gray-600">{editingRole.email}</p>
                )}
                <p className="text-xs text-gray-400 font-mono mt-1">
                  المعرف: {editingRole.user_id}
                </p>
              </div>
              <div>
                <Label>الدور</Label>
                <Select value={formRole} onValueChange={setFormRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">مدير (Admin) - صلاحيات كاملة</SelectItem>
                    <SelectItem value="employee">موظف (Employee) - صلاحيات محدودة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formRole === 'employee' && (
                <div>
                  <Label>ربط بالموظف</Label>
                  <Select value={formEmployeeId} onValueChange={setFormEmployeeId}>
                    <SelectTrigger><SelectValue placeholder="اختر الموظف" /></SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.fullName} - {emp.department}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <Button onClick={handleUpdateRole} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                تحديث الدور
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}