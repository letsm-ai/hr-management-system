import { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Briefcase, Plus, Clock, BarChart3, Pencil, Trash2, RefreshCw, Menu, X,
  Users, LayoutDashboard, UserCog, CalendarDays, CalendarRange, FileText,
  Link2, Zap, Shield, ClipboardList, LogIn, LogOut, UserCircle, ChevronRight,
  Calculator, TrendingUp, FileSpreadsheet, Search,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import {
  ClientContract, fetchAllClientContracts, createClientContract, updateClientContract,
  deleteClientContract, CONTRACT_TYPE_LABELS, CONTRACT_STATUS_LABELS, SERVICE_TYPES,
  formatOMR, getContractStats, getExpiringContracts, omrToBaisa, generateContractAlerts,
} from '@/lib/incentive-api';
import ContractAlertsBell from '@/components/ContractAlertsBell';
import { Sidebar } from './Index';

const emptyForm = {
  clientName: '',
  contractType: 'new',
  serviceType: '',
  monthlyValue: '',
  annualValue: '',
  previousValue: '',
  renewalYear: '',
  startDate: '',
  endDate: '',
  salesEmployeeId: '',
  accountManagerId: '',
  notes: '',
  status: 'active',
};

export default function ClientContracts() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, loading: authLoading } = useAuth();
  const { employees, loading: dataLoading } = useHRData();

  const [contracts, setContracts] = useState<ClientContract[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  // Filters
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Form
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState<string | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Expiring filter
  const [expiringDays, setExpiringDays] = useState(30);

  useEffect(() => {
    loadContracts();
  }, []);

  async function loadContracts() {
    setLoading(true);
    const data = await fetchAllClientContracts();
    setContracts(data);
    setLoading(false);
    // Generate alerts for expiring contracts in background
    generateContractAlerts(data).catch(console.error);
  }

  const activeEmployees = employees.filter((e) => e.status === 'نشط');

  // Filtered contracts
  const filteredContracts = contracts.filter((c) => {
    if (filterType !== 'all' && c.contractType !== filterType) return false;
    if (filterStatus !== 'all' && c.status !== filterStatus) return false;
    if (searchQuery && !c.clientName.includes(searchQuery)) return false;
    return true;
  });

  const stats = getContractStats(contracts);
  const expiringContracts = getExpiringContracts(contracts, expiringDays);

  function getEmployeeName(id: string) {
    const emp = employees.find((e) => e.id === id);
    return emp ? emp.fullName : '—';
  }

  function getContractTypeBadge(type: string) {
    const colors: Record<string, string> = {
      new: 'bg-emerald-100 text-emerald-700',
      renewal: 'bg-blue-100 text-blue-700',
      upsell: 'bg-purple-100 text-purple-700',
    };
    return <Badge className={colors[type] || 'bg-gray-100 text-gray-700'}>{CONTRACT_TYPE_LABELS[type] || type}</Badge>;
  }

  function getStatusBadge(status: string) {
    const colors: Record<string, string> = {
      active: 'bg-emerald-100 text-emerald-700',
      expired: 'bg-gray-200 text-gray-600',
      cancelled: 'bg-red-100 text-red-700',
      pending_renewal: 'bg-amber-100 text-amber-700',
    };
    return <Badge className={colors[status] || 'bg-gray-100 text-gray-700'}>{CONTRACT_STATUS_LABELS[status] || status}</Badge>;
  }

  async function handleSubmit() {
    if (!form.clientName || !form.serviceType || !form.monthlyValue || !form.startDate || !form.endDate || !form.salesEmployeeId) {
      alert('يرجى ملء جميع الحقول المطلوبة (*)');
      return;
    }

    const monthlyBaisa = omrToBaisa(parseFloat(form.monthlyValue));
    const annualBaisa = form.annualValue ? omrToBaisa(parseFloat(form.annualValue)) : monthlyBaisa * 12;
    const previousBaisa = form.previousValue ? omrToBaisa(parseFloat(form.previousValue)) : 0;

    const payload = {
      clientName: form.clientName,
      contractType: form.contractType,
      serviceType: form.serviceType,
      monthlyValue: monthlyBaisa,
      annualValue: annualBaisa,
      previousValue: previousBaisa,
      startDate: form.startDate,
      endDate: form.endDate,
      renewalYear: form.renewalYear ? parseInt(form.renewalYear) : 0,
      status: form.status,
      salesEmployeeId: form.salesEmployeeId,
      accountManagerId: form.accountManagerId || '',
      notes: form.notes,
    };

    try {
      if (editId) {
        await updateClientContract(editId, payload);
      } else {
        const result = await createClientContract(payload);
        if (!result) {
          alert('فشل في إضافة العقد. يرجى المحاولة مرة أخرى.');
          return;
        }
      }

      setForm(emptyForm);
      setEditId(null);
      setActiveTab('all');
      await loadContracts();
    } catch (e) {
      console.error('Error submitting contract:', e);
      alert('حدث خطأ أثناء حفظ العقد. يرجى المحاولة مرة أخرى.');
    }
  }

  function handleEdit(contract: ClientContract) {
    setForm({
      clientName: contract.clientName,
      contractType: contract.contractType,
      serviceType: contract.serviceType,
      monthlyValue: String(contract.monthlyValue / 1000),
      annualValue: String(contract.annualValue / 1000),
      previousValue: contract.previousValue ? String(contract.previousValue / 1000) : '',
      renewalYear: contract.renewalYear ? String(contract.renewalYear) : '',
      startDate: contract.startDate,
      endDate: contract.endDate,
      salesEmployeeId: contract.salesEmployeeId,
      accountManagerId: contract.accountManagerId || '',
      notes: contract.notes,
      status: contract.status,
    });
    setEditId(contract.id);
    setActiveTab('add');
  }

  function handleRenew(contract: ClientContract) {
    const nextYear = new Date(contract.endDate);
    nextYear.setDate(nextYear.getDate() + 1);
    const endDate = new Date(nextYear);
    endDate.setFullYear(endDate.getFullYear() + 1);
    endDate.setDate(endDate.getDate() - 1);

    setForm({
      clientName: contract.clientName,
      contractType: 'renewal',
      serviceType: contract.serviceType,
      monthlyValue: String(contract.monthlyValue / 1000),
      annualValue: '',
      previousValue: String(contract.monthlyValue / 1000),
      renewalYear: String((contract.renewalYear || 0) + 1),
      startDate: nextYear.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      salesEmployeeId: contract.salesEmployeeId,
      accountManagerId: contract.accountManagerId || '',
      notes: `تجديد عقد: ${contract.clientName}`,
      status: 'active',
    });
    setEditId(null);
    setActiveTab('add');
  }

  async function handleDelete() {
    if (deleteId) {
      await deleteClientContract(deleteId);
      setShowDeleteDialog(false);
      setDeleteId(null);
      await loadContracts();
    }
  }

  if (authLoading || dataLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E3A5F] mx-auto mb-4" />
          <p className="text-[#64748B]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
                <Menu className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-lg font-bold text-[#1E293B]">إدارة عقود العملاء</h1>
                <p className="text-xs text-[#64748B]">تسجيل ومتابعة العقود والتجديدات</p>
              </div>
            </div>
            <ContractAlertsBell />
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="all" className="gap-1"><Briefcase className="w-4 h-4" /> جميع العقود</TabsTrigger>
              <TabsTrigger value="add" className="gap-1"><Plus className="w-4 h-4" /> {editId ? 'تعديل عقد' : 'إضافة عقد'}</TabsTrigger>
              <TabsTrigger value="expiring" className="gap-1"><Clock className="w-4 h-4" /> تنتهي قريباً</TabsTrigger>
              <TabsTrigger value="stats" className="gap-1"><BarChart3 className="w-4 h-4" /> إحصائيات</TabsTrigger>
            </TabsList>

            {/* TAB 1: All Contracts */}
            <TabsContent value="all">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[200px]">
                      <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        placeholder="بحث باسم العميل..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pr-9"
                      />
                    </div>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger className="w-[150px]"><SelectValue placeholder="نوع العقد" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">الكل</SelectItem>
                        <SelectItem value="new">جديد</SelectItem>
                        <SelectItem value="renewal">تجديد</SelectItem>
                        <SelectItem value="upsell">زيادة قيمة</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-[160px]"><SelectValue placeholder="الحالة" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">الكل</SelectItem>
                        <SelectItem value="active">نشط</SelectItem>
                        <SelectItem value="expired">منتهي</SelectItem>
                        <SelectItem value="cancelled">ملغي</SelectItem>
                        <SelectItem value="pending_renewal">بانتظار التجديد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="text-right p-3 font-medium">العميل</th>
                          <th className="text-right p-3 font-medium">النوع</th>
                          <th className="text-right p-3 font-medium">الخدمة</th>
                          <th className="text-right p-3 font-medium">الشهري</th>
                          <th className="text-right p-3 font-medium">السنوي</th>
                          <th className="text-right p-3 font-medium">موظف المبيعات</th>
                          <th className="text-right p-3 font-medium">البدء</th>
                          <th className="text-right p-3 font-medium">الانتهاء</th>
                          <th className="text-right p-3 font-medium">الحالة</th>
                          <th className="text-right p-3 font-medium">إجراءات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredContracts.length === 0 ? (
                          <tr><td colSpan={10} className="text-center py-8 text-gray-400">لا توجد عقود</td></tr>
                        ) : (
                          filteredContracts.map((c) => (
                            <tr key={c.id} className="border-b hover:bg-gray-50">
                              <td className="p-3 font-medium">{c.clientName}</td>
                              <td className="p-3">{getContractTypeBadge(c.contractType)}</td>
                              <td className="p-3 text-xs">{c.serviceType}</td>
                              <td className="p-3">{formatOMR(c.monthlyValue)}</td>
                              <td className="p-3">{formatOMR(c.annualValue)}</td>
                              <td className="p-3 text-xs">{getEmployeeName(c.salesEmployeeId)}</td>
                              <td className="p-3 text-xs">{c.startDate}</td>
                              <td className="p-3 text-xs">{c.endDate}</td>
                              <td className="p-3">{getStatusBadge(c.status)}</td>
                              <td className="p-3">
                                <div className="flex gap-1">
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(c)}>
                                    <Pencil className="w-3.5 h-3.5" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleRenew(c)}>
                                    <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setDeleteId(c.id); setShowDeleteDialog(true); }}>
                                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* TAB 2: Add/Edit Contract */}
            <TabsContent value="add">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">{editId ? 'تعديل العقد' : 'إضافة عقد جديد'}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <Label>اسم العميل *</Label>
                      <Input value={form.clientName} onChange={(e) => setForm({ ...form, clientName: e.target.value })} placeholder="اسم العميل" />
                    </div>
                    <div>
                      <Label>نوع العقد *</Label>
                      <Select value={form.contractType} onValueChange={(v) => setForm({ ...form, contractType: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">عقد جديد</SelectItem>
                          <SelectItem value="renewal">تجديد</SelectItem>
                          <SelectItem value="upsell">زيادة قيمة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>نوع الخدمة *</Label>
                      <Select value={form.serviceType} onValueChange={(v) => setForm({ ...form, serviceType: v })}>
                        <SelectTrigger><SelectValue placeholder="اختر الخدمة" /></SelectTrigger>
                        <SelectContent>
                          {SERVICE_TYPES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>القيمة الشهرية (ر.ع) *</Label>
                      <Input type="number" step="0.001" value={form.monthlyValue} onChange={(e) => {
                        const mv = e.target.value;
                        setForm({ ...form, monthlyValue: mv, annualValue: mv ? String(parseFloat(mv) * 12) : '' });
                      }} placeholder="0.000" />
                    </div>
                    <div>
                      <Label>القيمة السنوية (ر.ع)</Label>
                      <Input type="number" step="0.001" value={form.annualValue} onChange={(e) => setForm({ ...form, annualValue: e.target.value })} placeholder="تُحسب تلقائياً" />
                    </div>
                    {(form.contractType === 'renewal' || form.contractType === 'upsell') && (
                      <div>
                        <Label>القيمة السابقة (ر.ع) *</Label>
                        <Input type="number" step="0.001" value={form.previousValue} onChange={(e) => setForm({ ...form, previousValue: e.target.value })} placeholder="0.000" />
                      </div>
                    )}
                    {form.contractType === 'renewal' && (
                      <div>
                        <Label>سنة التجديد *</Label>
                        <Select value={form.renewalYear} onValueChange={(v) => setForm({ ...form, renewalYear: v })}>
                          <SelectTrigger><SelectValue placeholder="اختر" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">السنة الأولى</SelectItem>
                            <SelectItem value="2">السنة الثانية</SelectItem>
                            <SelectItem value="3">السنة الثالثة فأكثر</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                    <div>
                      <Label>تاريخ البدء *</Label>
                      <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
                    </div>
                    <div>
                      <Label>تاريخ الانتهاء *</Label>
                      <Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
                    </div>
                    <div>
                      <Label>موظف المبيعات *</Label>
                      <Select value={form.salesEmployeeId} onValueChange={(v) => setForm({ ...form, salesEmployeeId: v })}>
                        <SelectTrigger><SelectValue placeholder="اختر الموظف" /></SelectTrigger>
                        <SelectContent>
                          {activeEmployees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>مدير الحساب</Label>
                      <Select value={form.accountManagerId || 'none'} onValueChange={(v) => setForm({ ...form, accountManagerId: v === 'none' ? '' : v })}>
                        <SelectTrigger><SelectValue placeholder="اختياري" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون</SelectItem>
                          {activeEmployees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>الحالة</Label>
                      <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">نشط</SelectItem>
                          <SelectItem value="expired">منتهي</SelectItem>
                          <SelectItem value="cancelled">ملغي</SelectItem>
                          <SelectItem value="pending_renewal">بانتظار التجديد</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="md:col-span-2 lg:col-span-3">
                      <Label>ملاحظات</Label>
                      <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="ملاحظات إضافية" />
                    </div>
                  </div>
                  <div className="flex gap-3 mt-6">
                    <Button onClick={handleSubmit} className="bg-[#1E3A5F] hover:bg-[#15304F] text-white">
                      {editId ? 'حفظ التعديلات' : 'إضافة العقد'}
                    </Button>
                    {editId && (
                      <Button variant="outline" onClick={() => { setForm(emptyForm); setEditId(null); }}>
                        إلغاء التعديل
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* TAB 3: Expiring Soon */}
            <TabsContent value="expiring">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Clock className="w-5 h-5 text-amber-500" />
                      العقود المنتهية قريباً
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button variant={expiringDays === 30 ? 'default' : 'outline'} size="sm" onClick={() => setExpiringDays(30)}>
                        30 يوم
                      </Button>
                      <Button variant={expiringDays === 60 ? 'default' : 'outline'} size="sm" onClick={() => setExpiringDays(60)}>
                        60 يوم
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="text-right p-3 font-medium">العميل</th>
                          <th className="text-right p-3 font-medium">الخدمة</th>
                          <th className="text-right p-3 font-medium">القيمة الشهرية</th>
                          <th className="text-right p-3 font-medium">تاريخ الانتهاء</th>
                          <th className="text-right p-3 font-medium">الأيام المتبقية</th>
                          <th className="text-right p-3 font-medium">إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {expiringContracts.length === 0 ? (
                          <tr><td colSpan={6} className="text-center py-8 text-gray-400">لا توجد عقود تنتهي قريباً</td></tr>
                        ) : (
                          expiringContracts.map((c) => (
                            <tr key={c.id} className="border-b hover:bg-gray-50">
                              <td className="p-3 font-medium">{c.clientName}</td>
                              <td className="p-3 text-xs">{c.serviceType}</td>
                              <td className="p-3">{formatOMR(c.monthlyValue)}</td>
                              <td className="p-3 text-xs">{c.endDate}</td>
                              <td className="p-3">
                                <Badge className={c.daysRemaining <= 7 ? 'bg-red-100 text-red-700' : c.daysRemaining <= 15 ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}>
                                  {c.daysRemaining} يوم
                                </Badge>
                              </td>
                              <td className="p-3">
                                <Button size="sm" variant="outline" className="gap-1 text-xs" onClick={() => handleRenew(c)}>
                                  <RefreshCw className="w-3 h-3" /> تجديد
                                </Button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* TAB 4: Statistics */}
            <TabsContent value="stats">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-emerald-600">{stats.activeCount}</p>
                    <p className="text-xs text-gray-500 mt-1">عقود نشطة</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-blue-600">{formatOMR(stats.monthlyRevenue)}</p>
                    <p className="text-xs text-gray-500 mt-1">الإيراد الشهري</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-indigo-600">{formatOMR(stats.annualRevenue)}</p>
                    <p className="text-xs text-gray-500 mt-1">الإيراد السنوي</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-green-600">{stats.newThisMonth}</p>
                    <p className="text-xs text-gray-500 mt-1">عقود جديدة هذا الشهر</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-blue-500">{stats.renewalsThisMonth}</p>
                    <p className="text-xs text-gray-500 mt-1">تجديدات هذا الشهر</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-amber-600">{stats.expiringSoon}</p>
                    <p className="text-xs text-gray-500 mt-1">تنتهي خلال 30 يوم</p>
                  </CardContent>
                </Card>
              </div>

              {/* Contract type distribution */}
              <Card className="mt-6">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">توزيع العقود حسب النوع</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {['new', 'renewal', 'upsell'].map((type) => {
                      const count = contracts.filter((c) => c.contractType === type && c.status === 'active').length;
                      const total = contracts.filter((c) => c.status === 'active').length;
                      const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                      return (
                        <div key={type} className="text-center p-4 rounded-lg bg-gray-50">
                          <p className="text-2xl font-bold">{count}</p>
                          <p className="text-xs text-gray-500">{CONTRACT_TYPE_LABELS[type]}</p>
                          <p className="text-xs text-gray-400">{pct}%</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Delete Confirmation */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تأكيد الحذف</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600">هل أنت متأكد من حذف هذا العقد؟ لا يمكن التراجع عن هذا الإجراء.</p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>إلغاء</Button>
            <Button variant="destructive" onClick={handleDelete}>حذف</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}