import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { apiGet, apiPost } from '@/lib/api-client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight, Download, Upload, Database, RefreshCw, AlertTriangle,
  CheckCircle, XCircle, Loader2, FileJson, HardDrive, Eye,
  Plus, Pencil, Trash2, ArrowLeftRight, ShieldCheck, X,
} from 'lucide-react';

interface TableSummary {
  [tableName: string]: number;
}

interface ImportResult {
  status: string;
  imported?: number;
  error?: string;
  reason?: string;
}

interface PreviewTableInfo {
  current_count: number;
  import_count: number;
  new_count: number;
  updated_count: number;
  deleted_count: number;
  unchanged_count: number;
  status: string;
}

interface PreviewData {
  preview: Record<string, PreviewTableInfo>;
  totals: {
    new: number;
    updated: number;
    deleted: number;
    tables_affected: number;
  };
  mode: string;
}

const TABLE_LABELS: Record<string, string> = {
  employees: 'الموظفون',
  performance_records: 'سجلات الأداء',
  attendance_records: 'سجلات الحضور',
  violations: 'المخالفات',
  overtime_records: 'سجلات العمل الإضافي',
  performance_kpis: 'مؤشرات الأداء',
  incentive_settings: 'إعدادات الحوافز',
  incentive_records: 'سجلات الحوافز',
  client_contracts: 'عقود العملاء',
  contract_alerts: 'تنبيهات العقود',
  contracts: 'العقود',
  notifications: 'الإشعارات',
  clickup_settings: 'إعدادات ClickUp',
  clickup_kpi_snapshots: 'لقطات KPI من ClickUp',
  clickup_sync_logs: 'سجلات مزامنة ClickUp',
  users: 'المستخدمون',
  user_roles: 'أدوار المستخدمين',
  pending_users: 'المستخدمون المعلقون',
};

export default function DataSync() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [summary, setSummary] = useState<TableSummary>({});
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importMode, setImportMode] = useState<string>('merge');
  const [importResults, setImportResults] = useState<Record<string, ImportResult> | null>(null);
  const [lastExportDate, setLastExportDate] = useState<string | null>(null);

  // Preview state
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [pendingImportData, setPendingImportData] = useState<any>(null);
  const [pendingFileName, setPendingFileName] = useState<string>('');
  const [showPreview, setShowPreview] = useState(false);

  const fetchSummary = async () => {
    setLoadingSummary(true);
    try {
      const res = await apiGet('/api/v1/data-sync/export/summary');
      if (res?.data?.summary) {
        setSummary(res.data.summary);
      }
    } catch (err: any) {
      toast.error('فشل في تحميل ملخص البيانات');
      console.error(err);
    } finally {
      setLoadingSummary(false);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, []);

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await apiGet('/api/v1/data-sync/export');
      if (res?.data) {
        const jsonStr = JSON.stringify(res.data, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const now = new Date();
        const dateStr = now.toISOString().slice(0, 10);
        a.download = `hr-system-backup-${dateStr}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setLastExportDate(now.toLocaleString('ar-SA'));
        toast.success('تم تصدير البيانات بنجاح');
      }
    } catch (err: any) {
      toast.error('فشل في تصدير البيانات');
      console.error(err);
    } finally {
      setExporting(false);
    }
  };

  const handleSelectFile = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        const data = JSON.parse(text);

        if (!data.tables) {
          toast.error('ملف غير صالح: لا يحتوي على بيانات الجداول');
          return;
        }

        setPendingImportData(data);
        setPendingFileName(file.name);

        // Fetch preview from backend
        setPreviewLoading(true);
        setShowPreview(true);
        setPreviewData(null);

        try {
          const res = await apiPost('/api/v1/data-sync/import/preview', {
            tables: data.tables,
            mode: importMode,
          });
          if (res?.data) {
            setPreviewData(res.data as PreviewData);
          }
        } catch (err: any) {
          toast.error('فشل في تحميل معاينة البيانات');
          console.error(err);
          setShowPreview(false);
        } finally {
          setPreviewLoading(false);
        }
      } catch (err: any) {
        toast.error('فشل في قراءة الملف');
        console.error(err);
      }
    };
    input.click();
  };

  const handleConfirmImport = async () => {
    if (!pendingImportData) return;

    setImporting(true);
    setShowPreview(false);
    setImportResults(null);

    try {
      const res = await apiPost('/api/v1/data-sync/import', {
        tables: pendingImportData.tables,
        mode: importMode,
      });

      if (res?.data?.results) {
        setImportResults(res.data.results);
        const successCount = Object.values(res.data.results as Record<string, ImportResult>).filter(
          (r) => r.status === 'success'
        ).length;
        toast.success(`تم استيراد ${successCount} جدول بنجاح`);
        fetchSummary();
      }
    } catch (err: any) {
      toast.error('فشل في استيراد البيانات');
      console.error(err);
    } finally {
      setImporting(false);
      setPendingImportData(null);
      setPendingFileName('');
      setPreviewData(null);
    }
  };

  const handleCancelPreview = () => {
    setShowPreview(false);
    setPreviewData(null);
    setPendingImportData(null);
    setPendingFileName('');
  };

  const totalRecords = Object.values(summary).reduce((acc, v) => acc + (v > 0 ? v : 0), 0);
  const tableCount = Object.keys(summary).filter((k) => summary[k] >= 0).length;

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
              <ArrowRight className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <Database className="h-5 w-5 text-blue-600" />
                مزامنة وتصدير البيانات
              </h1>
              <p className="text-sm text-gray-500">تصدير واستيراد بيانات النظام بصيغة JSON</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={fetchSummary} disabled={loadingSummary}>
            <RefreshCw className={`h-4 w-4 ml-1 ${loadingSummary ? 'animate-spin' : ''}`} />
            تحديث
          </Button>
        </div>
      </div>

      <div className="p-6 max-w-6xl mx-auto space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-blue-100 p-3 rounded-lg">
                <HardDrive className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">إجمالي السجلات</p>
                <p className="text-2xl font-bold">{totalRecords.toLocaleString('ar-SA')}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-green-100 p-3 rounded-lg">
                <Database className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">الجداول النشطة</p>
                <p className="text-2xl font-bold">{tableCount}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-purple-100 p-3 rounded-lg">
                <FileJson className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">آخر تصدير</p>
                <p className="text-sm font-medium">{lastExportDate || 'لم يتم التصدير بعد'}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Export / Import Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Export Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Download className="h-5 w-5 text-blue-600" />
                تصدير البيانات
              </CardTitle>
              <CardDescription>
                تصدير جميع بيانات النظام إلى ملف JSON لعمل نسخة احتياطية أو نقل البيانات
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700">
                سيتم تصدير جميع الجداول بما في ذلك الموظفين، الحضور، الأداء، العقود، والمستخدمين.
              </div>
              <Button
                onClick={handleExport}
                disabled={exporting}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                {exporting ? (
                  <>
                    <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                    جاري التصدير...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 ml-2" />
                    تصدير جميع البيانات
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Import Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Upload className="h-5 w-5 text-green-600" />
                استيراد البيانات
              </CardTitle>
              <CardDescription>
                استيراد بيانات من ملف JSON مع معاينة الفروقات قبل التأكيد
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">وضع الاستيراد</label>
                <Select value={importMode} onValueChange={setImportMode}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="merge">دمج (إضافة وتحديث)</SelectItem>
                    <SelectItem value="replace">استبدال (حذف القديم)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {importMode === 'replace' && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700 flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>تحذير: وضع الاستبدال سيحذف جميع البيانات الحالية قبل الاستيراد!</span>
                </div>
              )}
              <Button
                onClick={handleSelectFile}
                disabled={importing || previewLoading}
                variant="outline"
                className="w-full border-green-300 text-green-700 hover:bg-green-50"
              >
                {importing ? (
                  <>
                    <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                    جاري الاستيراد...
                  </>
                ) : (
                  <>
                    <Eye className="h-4 w-4 ml-2" />
                    اختيار ملف ومعاينة الفروقات
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Preview / Comparison Modal */}
        {showPreview && (
          <Card className="border-2 border-blue-300 shadow-lg">
            <CardHeader className="bg-blue-50 border-b border-blue-200">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <ArrowLeftRight className="h-5 w-5 text-blue-600" />
                  معاينة ومقارنة البيانات
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={handleCancelPreview}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <CardDescription>
                الملف: <span className="font-mono text-blue-700">{pendingFileName}</span>
                {' • '}
                الوضع: <Badge variant="outline" className="mr-1">
                  {importMode === 'merge' ? 'دمج' : 'استبدال'}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {previewLoading ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600 mb-3" />
                  <p className="text-gray-500">جاري تحليل الفروقات...</p>
                </div>
              ) : previewData ? (
                <>
                  {/* Summary Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Plus className="h-5 w-5 text-green-600" />
                        <span className="text-sm font-medium text-green-700">سجلات جديدة</span>
                      </div>
                      <p className="text-3xl font-bold text-green-600">
                        {previewData.totals.new.toLocaleString('ar-SA')}
                      </p>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Pencil className="h-5 w-5 text-blue-600" />
                        <span className="text-sm font-medium text-blue-700">سجلات محدثة</span>
                      </div>
                      <p className="text-3xl font-bold text-blue-600">
                        {previewData.totals.updated.toLocaleString('ar-SA')}
                      </p>
                    </div>
                    <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Trash2 className="h-5 w-5 text-red-600" />
                        <span className="text-sm font-medium text-red-700">سجلات محذوفة</span>
                      </div>
                      <p className="text-3xl font-bold text-red-600">
                        {previewData.totals.deleted.toLocaleString('ar-SA')}
                      </p>
                    </div>
                    <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Database className="h-5 w-5 text-gray-600" />
                        <span className="text-sm font-medium text-gray-700">جداول متأثرة</span>
                      </div>
                      <p className="text-3xl font-bold text-gray-600">
                        {previewData.totals.tables_affected}
                      </p>
                    </div>
                  </div>

                  {/* Detailed Table Comparison */}
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right font-semibold">الجدول</TableHead>
                          <TableHead className="text-center font-semibold">الحالي</TableHead>
                          <TableHead className="text-center font-semibold">في الملف</TableHead>
                          <TableHead className="text-center font-semibold">
                            <span className="text-green-600">جديد</span>
                          </TableHead>
                          <TableHead className="text-center font-semibold">
                            <span className="text-blue-600">محدث</span>
                          </TableHead>
                          <TableHead className="text-center font-semibold">
                            <span className="text-red-600">محذوف</span>
                          </TableHead>
                          <TableHead className="text-center font-semibold">الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Object.entries(previewData.preview)
                          .sort(([, a], [, b]) => {
                            const aTotal = a.new_count + a.updated_count + a.deleted_count;
                            const bTotal = b.new_count + b.updated_count + b.deleted_count;
                            return bTotal - aTotal;
                          })
                          .map(([table, info]) => {
                            const hasChanges = info.new_count > 0 || info.updated_count > 0 || info.deleted_count > 0;
                            return (
                              <TableRow
                                key={table}
                                className={hasChanges ? 'bg-yellow-50/50' : ''}
                              >
                                <TableCell className="font-medium">
                                  <div>
                                    <span>{TABLE_LABELS[table] || table}</span>
                                    <span className="block text-xs text-gray-400 font-mono">{table}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className="font-semibold">{info.current_count.toLocaleString('ar-SA')}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className="font-semibold">
                                    {info.status === 'not_in_file' ? '-' : info.import_count.toLocaleString('ar-SA')}
                                  </span>
                                </TableCell>
                                <TableCell className="text-center">
                                  {info.new_count > 0 ? (
                                    <Badge className="bg-green-100 text-green-700 gap-1">
                                      <Plus className="h-3 w-3" />
                                      {info.new_count.toLocaleString('ar-SA')}
                                    </Badge>
                                  ) : (
                                    <span className="text-gray-300">-</span>
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {info.updated_count > 0 ? (
                                    <Badge className="bg-blue-100 text-blue-700 gap-1">
                                      <Pencil className="h-3 w-3" />
                                      {info.updated_count.toLocaleString('ar-SA')}
                                    </Badge>
                                  ) : (
                                    <span className="text-gray-300">-</span>
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {info.deleted_count > 0 ? (
                                    <Badge variant="destructive" className="gap-1">
                                      <Trash2 className="h-3 w-3" />
                                      {info.deleted_count.toLocaleString('ar-SA')}
                                    </Badge>
                                  ) : (
                                    <span className="text-gray-300">-</span>
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {info.status === 'not_in_file' ? (
                                    <Badge variant="secondary" className="text-xs">غير موجود بالملف</Badge>
                                  ) : hasChanges ? (
                                    <Badge className="bg-yellow-100 text-yellow-700 text-xs">تغييرات</Badge>
                                  ) : (
                                    <Badge className="bg-gray-100 text-gray-500 text-xs">بدون تغيير</Badge>
                                  )}
                                </TableCell>
                              </TableRow>
                            );
                          })}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Warning for replace mode */}
                  {previewData.mode === 'replace' && previewData.totals.deleted > 0 && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-red-700">تحذير: وضع الاستبدال</p>
                        <p className="text-sm text-red-600 mt-1">
                          سيتم حذف <strong>{previewData.totals.deleted.toLocaleString('ar-SA')}</strong> سجل
                          من قاعدة البيانات الحالية واستبدالها بالبيانات المستوردة. هذا الإجراء لا يمكن التراجع عنه.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center justify-end gap-3 pt-2">
                    <Button variant="outline" onClick={handleCancelPreview}>
                      <X className="h-4 w-4 ml-2" />
                      إلغاء
                    </Button>
                    <Button
                      onClick={handleConfirmImport}
                      disabled={importing}
                      className={
                        previewData.mode === 'replace'
                          ? 'bg-red-600 hover:bg-red-700 text-white'
                          : 'bg-green-600 hover:bg-green-700 text-white'
                      }
                    >
                      {importing ? (
                        <>
                          <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                          جاري الاستيراد...
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="h-4 w-4 ml-2" />
                          تأكيد الاستيراد
                        </>
                      )}
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <XCircle className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                  <p>فشل في تحميل المعاينة</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Import Results */}
        {importResults && (
          <Card className="border-green-200">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                نتائج الاستيراد
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الجدول</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                    <TableHead className="text-right">التفاصيل</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(importResults).map(([table, result]) => (
                    <TableRow key={table}>
                      <TableCell className="font-medium">
                        {TABLE_LABELS[table] || table}
                      </TableCell>
                      <TableCell>
                        {result.status === 'success' ? (
                          <Badge className="bg-green-100 text-green-700">
                            <CheckCircle className="h-3 w-3 ml-1" />
                            نجاح
                          </Badge>
                        ) : result.status === 'skipped' ? (
                          <Badge variant="secondary">تم التخطي</Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="h-3 w-3 ml-1" />
                            خطأ
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {result.status === 'success'
                          ? `تم استيراد ${result.imported} سجل`
                          : result.reason || result.error || '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Data Summary Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Database className="h-5 w-5" />
              ملخص البيانات الحالية
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingSummary ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
                <span className="mr-2 text-gray-500">جاري التحميل...</span>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الجدول</TableHead>
                    <TableHead className="text-right">الاسم التقني</TableHead>
                    <TableHead className="text-right">عدد السجلات</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(summary)
                    .sort(([, a], [, b]) => b - a)
                    .map(([table, count]) => (
                      <TableRow key={table}>
                        <TableCell className="font-medium">
                          {TABLE_LABELS[table] || table}
                        </TableCell>
                        <TableCell className="text-sm text-gray-400 font-mono">
                          {table}
                        </TableCell>
                        <TableCell>
                          <span className="font-semibold">
                            {count >= 0 ? count.toLocaleString('ar-SA') : '-'}
                          </span>
                        </TableCell>
                        <TableCell>
                          {count < 0 ? (
                            <Badge variant="destructive" className="text-xs">غير موجود</Badge>
                          ) : count === 0 ? (
                            <Badge variant="secondary" className="text-xs">فارغ</Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-700 text-xs">
                              {count} سجل
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}