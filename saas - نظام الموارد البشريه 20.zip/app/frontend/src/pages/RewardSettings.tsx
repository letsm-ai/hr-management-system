import { entities } from "@/lib/entity-api";
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Settings, Save, AlertCircle, Info, Percent, Clock, Calendar } from 'lucide-react';
import { Sidebar } from './Index';
import { Menu } from 'lucide-react';


interface RewardSettingsData {
  id?: number;
  attendance_weight: number;
  productivity_weight: number;
  quality_weight: number;
  excellent_threshold: number;
  excellent_reward_percent: number;
  good_threshold: number;
  good_reward_percent: number;
  fair_threshold: number;
  fair_reward_percent: number;
  working_days_per_month: number;
  late_minor_threshold_minutes: number;
  absent_annual_leave_points: number;
  absent_approved_points: number;
  absent_unapproved_points: number;
}

const DEFAULT_SETTINGS: RewardSettingsData = {
  attendance_weight: 0.30,
  productivity_weight: 0.45,
  quality_weight: 0.25,
  excellent_threshold: 0.85,
  excellent_reward_percent: 15.00,
  good_threshold: 0.70,
  good_reward_percent: 10.00,
  fair_threshold: 0.55,
  fair_reward_percent: 5.00,
  working_days_per_month: 30,
  late_minor_threshold_minutes: 15,
  absent_annual_leave_points: 100,
  absent_approved_points: 50,
  absent_unapproved_points: 0,
};

export default function RewardSettings() {
  const [settings, setSettings] = useState<RewardSettingsData>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [weightError, setWeightError] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  useEffect(() => {
    const total = settings.attendance_weight + settings.productivity_weight + settings.quality_weight;
    const totalPercent = Math.round(total * 100);
    if (totalPercent !== 100) {
      setWeightError(`مجموع الأوزان = ${totalPercent}% (يجب أن يكون 100%)`);
    } else {
      setWeightError('');
    }
  }, [settings.attendance_weight, settings.productivity_weight, settings.quality_weight]);

  async function loadSettings() {
    setLoading(true);
    try {
      const res = await entities.reward_settings.query({ query: {}, limit: 1 });
      const items = res?.data?.items || res?.items || [];
      if (items.length > 0) {
        setSettings(items[0]);
      } else {
        // Create default settings
        const createRes = await entities.reward_settings.create({ data: DEFAULT_SETTINGS });
        if (createRes?.data) {
          setSettings(createRes.data);
        }
      }
    } catch (err) {
      console.error('Failed to load reward settings:', err);
      toast.error('فشل في تحميل الإعدادات');
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    if (weightError) {
      toast.error('يجب أن يكون مجموع الأوزان = 100%');
      return;
    }
    setSaving(true);
    try {
      if (settings.id) {
        const { id, ...data } = settings;
        await entities.reward_settings.update({ id, data });
      } else {
        const res = await entities.reward_settings.create({ data: settings });
        if (res?.data) {
          setSettings(res.data);
        }
      }
      toast.success('تم حفظ الإعدادات بنجاح');
    } catch (err) {
      console.error('Failed to save reward settings:', err);
      toast.error('فشل في حفظ الإعدادات');
    } finally {
      setSaving(false);
    }
  }

  function updateWeight(field: 'attendance_weight' | 'productivity_weight' | 'quality_weight', value: number) {
    setSettings(prev => ({ ...prev, [field]: value / 100 }));
  }

  function updateField(field: keyof RewardSettingsData, value: number) {
    setSettings(prev => ({ ...prev, [field]: value }));
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
        <div className="text-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-600 border-t-transparent mx-auto mb-4" />
          <p className="text-gray-500">جاري تحميل الإعدادات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="flex-1 lg:mr-72">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white border-b px-4 py-3 flex items-center gap-3 shadow-sm">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <Settings className="w-6 h-6 text-blue-600" />
          <h1 className="text-xl font-bold text-gray-800">إعدادات المكافآت</h1>
          <Badge variant="outline" className="mr-auto text-xs">
            نظام المكافآت الموحد - المرحلة الأولى
          </Badge>
        </header>

        <div className="p-4 md:p-6 space-y-6 max-w-4xl mx-auto">
          {/* Section 1: Weights */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Percent className="w-5 h-5 text-blue-600" />
                أوزان المعايير
              </CardTitle>
              <p className="text-sm text-gray-500">حدد نسبة كل معيار من التقييم الإجمالي (المجموع يجب أن يساوي 100%)</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">الانضباط (الحضور)</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={Math.round(settings.attendance_weight * 100)}
                      onChange={(e) => updateWeight('attendance_weight', Number(e.target.value))}
                      className="text-center"
                    />
                    <span className="text-sm text-gray-500">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">الإنتاجية</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={Math.round(settings.productivity_weight * 100)}
                      onChange={(e) => updateWeight('productivity_weight', Number(e.target.value))}
                      className="text-center"
                    />
                    <span className="text-sm text-gray-500">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">الجودة</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={Math.round(settings.quality_weight * 100)}
                      onChange={(e) => updateWeight('quality_weight', Number(e.target.value))}
                      className="text-center"
                    />
                    <span className="text-sm text-gray-500">%</span>
                  </div>
                </div>
              </div>

              {/* Weight total indicator */}
              <div className={`flex items-center gap-2 p-3 rounded-lg ${weightError ? 'bg-red-50 border border-red-200' : 'bg-green-50 border border-green-200'}`}>
                {weightError ? (
                  <>
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                    <span className="text-sm text-red-700">{weightError}</span>
                  </>
                ) : (
                  <>
                    <Info className="w-4 h-4 text-green-600 shrink-0" />
                    <span className="text-sm text-green-700">مجموع الأوزان = 100% ✓</span>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Reward Tiers */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Percent className="w-5 h-5 text-amber-600" />
                شرائح المكافآت
              </CardTitle>
              <p className="text-sm text-gray-500">حدد عتبات التقييم ونسبة المكافأة لكل شريحة</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Excellent */}
              <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className="bg-emerald-600">ممتاز</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">الحد الأدنى للنسبة</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={Math.round(settings.excellent_threshold * 100)}
                        onChange={(e) => updateField('excellent_threshold', Number(e.target.value) / 100)}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">% فأعلى</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">نسبة المكافأة من الراتب</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        step={0.5}
                        value={settings.excellent_reward_percent}
                        onChange={(e) => updateField('excellent_reward_percent', Number(e.target.value))}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Good */}
              <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className="bg-blue-600">جيد جداً</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">الحد الأدنى للنسبة</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={Math.round(settings.good_threshold * 100)}
                        onChange={(e) => updateField('good_threshold', Number(e.target.value) / 100)}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">% فأعلى</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">نسبة المكافأة من الراتب</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        step={0.5}
                        value={settings.good_reward_percent}
                        onChange={(e) => updateField('good_reward_percent', Number(e.target.value))}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Fair */}
              <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className="bg-amber-600">جيد</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">الحد الأدنى للنسبة</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={Math.round(settings.fair_threshold * 100)}
                        onChange={(e) => updateField('fair_threshold', Number(e.target.value) / 100)}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">% فأعلى</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-gray-600">نسبة المكافأة من الراتب</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        step={0.5}
                        value={settings.fair_reward_percent}
                        onChange={(e) => updateField('fair_reward_percent', Number(e.target.value))}
                        className="text-center"
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Needs Improvement */}
              <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="destructive">يحتاج تحسين</Badge>
                </div>
                <p className="text-sm text-gray-600">
                  أقل من {Math.round(settings.fair_threshold * 100)}% → لا مكافأة (0%)
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Section 3: General Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Calendar className="w-5 h-5 text-purple-600" />
                إعدادات عامة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    أيام العمل في الشهر
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    max={31}
                    value={settings.working_days_per_month}
                    onChange={(e) => updateField('working_days_per_month', Number(e.target.value))}
                    className="text-center"
                  />
                  <p className="text-xs text-amber-600 bg-amber-50 p-2 rounded">
                    ⚠️ 30 يوم شامل الويكند — العمل الفعلي 22 يوم لكن الراتب يُحسب على 30 يوم
                  </p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    حد التأخير الخفيف (دقائق)
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    max={60}
                    value={settings.late_minor_threshold_minutes}
                    onChange={(e) => updateField('late_minor_threshold_minutes', Number(e.target.value))}
                    className="text-center"
                  />
                  <p className="text-xs text-gray-500">
                    التأخير أقل من هذا الحد يُعتبر تأخيراً خفيفاً
                  </p>
                </div>
              </div>

              <Separator />

              {/* Attendance Points */}
              <div>
                <h4 className="text-sm font-semibold mb-3 text-gray-700">نقاط الحضور حسب نوع الغياب</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200 space-y-2">
                    <Label className="text-xs font-medium text-green-800">إجازة سنوية</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={settings.absent_annual_leave_points}
                        onChange={(e) => updateField('absent_annual_leave_points', Number(e.target.value))}
                        className="text-center text-sm"
                      />
                      <span className="text-xs text-gray-500">نقطة</span>
                    </div>
                    <p className="text-xs text-green-700">لا خصم — حق مكتسب</p>
                  </div>
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 space-y-2">
                    <Label className="text-xs font-medium text-yellow-800">إذن / طارئ (معتمد)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={settings.absent_approved_points}
                        onChange={(e) => updateField('absent_approved_points', Number(e.target.value))}
                        className="text-center text-sm"
                      />
                      <span className="text-xs text-gray-500">نقطة</span>
                    </div>
                    <p className="text-xs text-yellow-700">خصم جزئي</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 space-y-2">
                    <Label className="text-xs font-medium text-red-800">غياب بدون إذن</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        value={settings.absent_unapproved_points}
                        onChange={(e) => updateField('absent_unapproved_points', Number(e.target.value))}
                        className="text-center text-sm"
                      />
                      <span className="text-xs text-gray-500">نقطة</span>
                    </div>
                    <p className="text-xs text-red-700">خصم كامل</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end pb-6">
            <Button
              onClick={handleSave}
              disabled={saving || !!weightError}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8"
            >
              {saving ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent ml-2" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5 ml-2" />
                  حفظ الإعدادات
                </>
              )}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}