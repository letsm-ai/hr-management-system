import { useAuth } from '@/lib/auth-context';
import { useRole } from '@/lib/role-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { LogOut, Clock, Copy, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export default function PendingApproval() {
  const { user, logout } = useAuth();
  const { refreshRole } = useRole();

  function copyUserId() {
    if (user?.id) {
      navigator.clipboard.writeText(user.id);
      toast.success('تم نسخ معرف المستخدم');
    }
  }

  async function handleRefresh() {
    await refreshRole();
    toast.info('جاري التحقق من حالة الحساب...');
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardContent className="p-8 text-center space-y-4">
          <Clock className="h-16 w-16 mx-auto text-yellow-500" />
          <h2 className="text-xl font-bold">في انتظار موافقة المدير</h2>
          <p className="text-gray-500">
            تم تسجيل دخولك بنجاح وتم إرسال طلبك للمدير تلقائياً.
            يرجى الانتظار حتى يقوم المدير بالموافقة على حسابك وتعيين صلاحياتك.
          </p>

          {user?.email && (
            <div className="bg-blue-50 rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">البريد الإلكتروني:</p>
              <p className="text-sm font-medium">{user.email}</p>
            </div>
          )}

          <div className="bg-gray-100 rounded-lg p-3">
            <p className="text-xs text-gray-500 mb-1">معرف المستخدم الخاص بك:</p>
            <div className="flex items-center justify-center gap-2">
              <code className="text-xs font-mono bg-white px-2 py-1 rounded border break-all">
                {user?.id}
              </code>
              <Button size="sm" variant="outline" onClick={copyUserId}>
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" onClick={handleRefresh} className="flex-1">
              <RefreshCw className="h-4 w-4 ml-2" />
              تحقق من الحالة
            </Button>
            <Button variant="outline" onClick={logout} className="flex-1">
              <LogOut className="h-4 w-4 ml-2" />
              تسجيل الخروج
            </Button>
          </div>

          <p className="text-xs text-gray-400">
            💡 بعد موافقة المدير، اضغط "تحقق من الحالة" أو أعد تحميل الصفحة
          </p>
        </CardContent>
      </Card>
    </div>
  );
}