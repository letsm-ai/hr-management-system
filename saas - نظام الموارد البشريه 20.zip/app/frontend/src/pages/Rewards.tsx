import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  FileText, Calculator, Menu, TrendingUp, TrendingDown, Award,
  CalendarCheck, Lightbulb, Zap, AlertOctagon, DollarSign, Download
} from 'lucide-react';
import { Sidebar } from './Index';
import {
  getCurrentMonth, formatCurrency,
  calculateMonthlyRewards, getDashboardStats,
  getEmployeeNameFromList, getMonthlyAttendanceStats,
  calculatePerformanceScore, getPerformanceRating,
} from '@/lib/hr-api';
import { fetchIncentiveRecords, type IncentiveRecord } from '@/lib/incentive-api';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

interface RewardRow {
  employeeId: string;
  name: string;
  basicSalary: number;
  overtimeReward: number;
  acceptedIdeas: number;
  ideaReward: number;
  commission: number;
  contractIncentive: number;
  totalRewards: number;
  absenceDeduction: number;
  tardinessMinutes: number;
  tardinessDeduction: number;
  violationDeduction: number;
  totalDeductions: number;
  netAmount: number;
  finalSalary: number;
}

export default function RewardsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tab, setTab] = useState('rewards');
  const [month, setMonth] = useState(getCurrentMonth());
  const [incentiveRecords, setIncentiveRecords] = useState<IncentiveRecord[]>([]);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, ideas: allIdeas, overtime, violations, performance, loading: dataLoading } = useHRData();

  // Fetch incentive records
  useEffect(() => {
    fetchIncentiveRecords().then(setIncentiveRecords).catch(() => setIncentiveRecords([]));
  }, []);

  const rewardRows = useMemo(() => {
    const activeEmps = employees.filter((e) => e.status === 'نشط');
    return activeEmps.map((emp) => {
      const rewards = calculateMonthlyRewards(
        emp.id, month, employees, attendance, allIdeas, overtime, violations
      );
      if (!rewards) return null;

      // Get contract incentive for this employee this month
      const empIncentives = incentiveRecords.filter(
        (ir) => ir.employeeId === emp.id && ir.month === month && (ir.status === 'approved' || ir.status === 'paid' || ir.status === 'calculated')
      );
      const contractIncentive = empIncentives.reduce((sum, ir) => sum + ir.finalAmount, 0);

      // Recalculate totals including contract incentive
      const totalRewards = rewards.totalRewards + contractIncentive;
      const netAmount = totalRewards - rewards.totalDeductions;
      const finalSalary = emp.basicSalary + netAmount;

      return {
        employeeId: emp.id,
        name: emp.fullName,
        basicSalary: rewards.basicSalary,
        overtimeReward: rewards.overtimeReward,
        acceptedIdeas: rewards.acceptedIdeas,
        ideaReward: rewards.ideaReward,
        commission: rewards.commission,
        contractIncentive,
        totalRewards: Math.round(totalRewards * 100) / 100,
        absenceDeduction: rewards.absenceDeduction,
        tardinessMinutes: rewards.tardinessMinutes,
        tardinessDeduction: rewards.tardinessDeduction,
        violationDeduction: rewards.violationDeduction,
        totalDeductions: rewards.totalDeductions,
        netAmount: Math.round(netAmount * 100) / 100,
        finalSalary: Math.round(finalSalary * 100) / 100,
      };
    }).filter(Boolean) as RewardRow[];
  }, [employees, attendance, allIdeas, overtime, violations, month, incentiveRecords]);

  function handleExportRewards() {
    exportToCSV(
      rewardRows.map((r) => ({
        name: r.name, basicSalary: r.basicSalary, overtimeReward: r.overtimeReward,
        acceptedIdeas: r.acceptedIdeas, ideaReward: r.ideaReward, commission: r.commission,
        contractIncentive: r.contractIncentive,
        totalRewards: r.totalRewards, absenceDeduction: r.absenceDeduction,
        tardinessMinutes: r.tardinessMinutes, tardinessDeduction: r.tardinessDeduction,
        violationDeduction: r.violationDeduction, totalDeductions: r.totalDeductions,
        netAmount: r.netAmount, finalSalary: r.finalSalary,
      })),
      [
        { key: 'name', label: 'الموظف' }, { key: 'basicSalary', label: 'الراتب الأساسي' },
        { key: 'overtimeReward', label: 'عمل إضافي' }, { key: 'acceptedIdeas', label: 'أفكار مقبولة' },
        { key: 'ideaReward', label: 'مكافأة أفكار' }, { key: 'commission', label: 'عمولة' },
        { key: 'contractIncentive', label: 'حوافز العقود' },
        { key: 'totalRewards', label: 'إجمالي المكافآت' }, { key: 'absenceDeduction', label: 'خصم غياب' },
        { key: 'tardinessMinutes', label: 'دقائق التأخير' }, { key: 'tardinessDeduction', label: 'خصم تأخير' },
        { key: 'violationDeduction', label: 'خصم مخالفات' }, { key: 'totalDeductions', label: 'إجمالي الخصومات' },
        { key: 'netAmount', label: 'الصافي' }, { key: 'finalSalary', label: 'الراتب النهائي' },
      ],
      `تقرير_المكافآت_${month}`
    );
  }

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى المكافآت والتقرير الشهري</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const months: string[] = [];
  for (let m = 1; m <= 12; m++) months.push(`2026-${String(m).padStart(2, '0')}`);

  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  const totalRewards = rewardRows.reduce((s, r) => s + r.totalRewards, 0);
  const totalDeductions = rewardRows.reduce((s, r) => s + r.totalDeductions, 0);
  const totalFinalSalaries = rewardRows.reduce((s, r) => s + r.finalSalary, 0);
  const totalBasicSalaries = rewardRows.reduce((s, r) => s + r.basicSalary, 0);
  const totalContractIncentives = rewardRows.reduce((s, r) => s + r.contractIncentive, 0);

  const stats = getDashboardStats(month, employees, attendance, allIdeas, overtime, violations);
  const perfRecords = performance.filter((r) => r.month === month);

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <FileText className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">المكافآت والتقرير الشهري</h1>
              <p className="text-xs text-[#64748B]">حساب المكافآت والخصومات والتقرير الشامل</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Select value={month} onValueChange={setMonth}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {months.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <Tabs value={tab} onValueChange={setTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="rewards" className="gap-2"><Calculator className="w-4 h-4" /> حساب المكافآت</TabsTrigger>
                  <TabsTrigger value="report" className="gap-2"><FileText className="w-4 h-4" /> التقرير الشهري</TabsTrigger>
                </TabsList>

                <TabsContent value="rewards" className="space-y-4">
                  <div className="flex justify-end">
                    <Button onClick={handleExportRewards} variant="outline" className="gap-2"><Download className="w-4 h-4" /> تصدير CSV</Button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <Card><CardContent className="p-4 text-center"><DollarSign className="w-6 h-6 text-blue-500 mx-auto mb-1" /><p className="text-lg font-bold">{formatCurrency(totalBasicSalaries)}</p><p className="text-xs text-gray-500">الرواتب الأساسية</p></CardContent></Card>
                    <Card><CardContent className="p-4 text-center"><TrendingUp className="w-6 h-6 text-emerald-500 mx-auto mb-1" /><p className="text-lg font-bold text-emerald-600">{formatCurrency(totalRewards)}</p><p className="text-xs text-gray-500">إجمالي المكافآت</p></CardContent></Card>
                    <Card><CardContent className="p-4 text-center"><Award className="w-6 h-6 text-indigo-500 mx-auto mb-1" /><p className="text-lg font-bold text-indigo-600">{formatCurrency(totalContractIncentives)}</p><p className="text-xs text-gray-500">حوافز العقود</p></CardContent></Card>
                    <Card><CardContent className="p-4 text-center"><TrendingDown className="w-6 h-6 text-red-500 mx-auto mb-1" /><p className="text-lg font-bold text-red-600">{formatCurrency(totalDeductions)}</p><p className="text-xs text-gray-500">إجمالي الخصومات</p></CardContent></Card>
                    <Card><CardContent className="p-4 text-center"><DollarSign className="w-6 h-6 text-purple-500 mx-auto mb-1" /><p className="text-lg font-bold text-purple-600">{formatCurrency(totalFinalSalaries)}</p><p className="text-xs text-gray-500">الرواتب النهائية</p></CardContent></Card>
                  </div>

                  <Card>
                    <CardContent className="p-0">
                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">الراتب الأساسي</TableHead>
                              <TableHead className="text-right">عمل إضافي</TableHead>
                              <TableHead className="text-right">مكافأة أفكار</TableHead>
                              <TableHead className="text-right">عمولة</TableHead>
                              <TableHead className="text-right">حوافز العقود</TableHead>
                              <TableHead className="text-right">إجمالي المكافآت</TableHead>
                              <TableHead className="text-right">خصم غياب</TableHead>
                              <TableHead className="text-right">خصم تأخير</TableHead>
                              <TableHead className="text-right">خصم مخالفات</TableHead>
                              <TableHead className="text-right">إجمالي الخصومات</TableHead>
                              <TableHead className="text-right">الصافي</TableHead>
                              <TableHead className="text-right font-bold">الراتب النهائي</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rewardRows.length === 0 ? (
                              <TableRow><TableCell colSpan={13} className="text-center py-8 text-gray-400">لا توجد بيانات</TableCell></TableRow>
                            ) : (
                              rewardRows.map((row) => (
                                <TableRow key={row.employeeId} className="hover:bg-gray-50">
                                  <TableCell className="font-medium text-sm">{row.name}</TableCell>
                                  <TableCell className="text-sm">{formatCurrency(row.basicSalary)}</TableCell>
                                  <TableCell className="text-sm text-emerald-600">{row.overtimeReward > 0 ? formatCurrency(row.overtimeReward) : '-'}</TableCell>
                                  <TableCell className="text-sm text-emerald-600">{row.ideaReward > 0 ? formatCurrency(row.ideaReward) : '-'}</TableCell>
                                  <TableCell className="text-sm text-emerald-600">{row.commission > 0 ? formatCurrency(row.commission) : '-'}</TableCell>
                                  <TableCell className="text-sm font-semibold text-indigo-600">{row.contractIncentive > 0 ? formatCurrency(row.contractIncentive) : '-'}</TableCell>
                                  <TableCell className="text-sm font-semibold text-emerald-600">{formatCurrency(row.totalRewards)}</TableCell>
                                  <TableCell className="text-sm text-red-600">{row.absenceDeduction > 0 ? formatCurrency(row.absenceDeduction) : '-'}</TableCell>
                                  <TableCell className="text-sm text-red-600" title={`${row.tardinessMinutes} دقيقة تأخير`}>{row.tardinessDeduction > 0 ? formatCurrency(row.tardinessDeduction) : '-'}</TableCell>
                                  <TableCell className="text-sm text-red-600">{row.violationDeduction > 0 ? formatCurrency(row.violationDeduction) : '-'}</TableCell>
                                  <TableCell className="text-sm font-semibold text-red-600">{formatCurrency(row.totalDeductions)}</TableCell>
                                  <TableCell className={`text-sm font-semibold ${row.netAmount >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{formatCurrency(row.netAmount)}</TableCell>
                                  <TableCell className="text-sm font-bold text-[#1E3A5F]">{formatCurrency(row.finalSalary)}</TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 space-y-1">
                      <p className="text-xs text-gray-500">
                        <strong>حساب المكافآت:</strong> مكافأة الأفكار = 50 ر.ع لكل فكرة مقبولة • عمولة تطوير الأعمال: أقل من 5,000 = 3% | 5,000-10,000 = 5% | أكثر من 10,000 = 7%
                      </p>
                      <p className="text-xs text-gray-500">
                        <strong>حوافز العقود:</strong> تُحسب من نظام الحوافز بناءً على العقود الجديدة والتجديدات وزيادة القيمة × معامل الأداء
                      </p>
                      <p className="text-xs text-gray-500">
                        <strong>الراتب النهائي:</strong> الراتب الأساسي + إجمالي المكافآت (شاملة حوافز العقود) - إجمالي الخصومات
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="report" className="space-y-4">
                  <Card className="border-[#1E3A5F]/20">
                    <CardHeader className="bg-[#1E3A5F] text-white rounded-t-lg">
                      <CardTitle className="text-lg">
                        التقرير الشهري الشامل - {monthNames[month.split('-')[1]]} {month.split('-')[0]}
                      </CardTitle>
                      <p className="text-sm text-white/70">تاريخ الإعداد: {new Date().toLocaleDateString('ar-OM')}</p>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      {/* Section 1: Attendance */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <CalendarCheck className="w-5 h-5 text-emerald-500" /> القسم 1: ملخص الحضور والغياب
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          <div className="p-3 bg-emerald-50 rounded-lg text-center"><p className="text-xl font-bold text-emerald-600">{stats.attendanceRate}%</p><p className="text-xs text-gray-600">معدل الحضور العام</p></div>
                          <div className="p-3 bg-amber-50 rounded-lg text-center"><p className="text-xl font-bold text-amber-600">{stats.totalTardiness}</p><p className="text-xs text-gray-600">إجمالي دقائق التأخير</p></div>
                          <div className="p-3 bg-red-50 rounded-lg text-center"><p className="text-xl font-bold text-red-600">{stats.absentCount}</p><p className="text-xs text-gray-600">حالات الغياب</p></div>
                          <div className="p-3 bg-blue-50 rounded-lg text-center"><p className="text-xl font-bold text-blue-600">{stats.activeEmployees}</p><p className="text-xs text-gray-600">موظف نشط</p></div>
                        </div>
                        {stats.top5Attendance.length > 0 && (
                          <div className="mt-3">
                            <p className="text-sm font-medium mb-2">أفضل 5 موظفين التزاماً:</p>
                            <div className="flex flex-wrap gap-2">
                              {stats.top5Attendance.map((e, i) => (
                                <Badge key={e.id} variant="secondary" className="text-xs">
                                  {i + 1}. {e.fullName} ({Math.round(e.attendanceRate)}%)
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <Separator />

                      {/* Section 2: Performance */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <Award className="w-5 h-5 text-purple-500" /> القسم 2: ملخص الأداء
                        </h3>
                        {perfRecords.length === 0 ? (
                          <p className="text-sm text-gray-400">لا توجد تقييمات أداء لهذا الشهر</p>
                        ) : (
                          <div className="space-y-2">
                            {perfRecords.map((rec) => {
                              const empIdeas = allIdeas.filter((i) => i.employeeId === rec.employeeId && i.month === month);
                              const score = calculatePerformanceScore(rec, empIdeas);
                              const rating = getPerformanceRating(score);
                              return (
                                <div key={rec.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                                  <span className="text-sm">{getEmployeeNameFromList(employees, rec.employeeId)}</span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm font-bold">{score.toFixed(1)}/10</span>
                                    <Badge variant="secondary" className="text-xs">{rating}</Badge>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      <Separator />

                      {/* Section 3: Ideas */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <Lightbulb className="w-5 h-5 text-yellow-500" /> القسم 3: ملخص الأفكار والابتكار
                        </h3>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="p-3 bg-yellow-50 rounded-lg text-center"><p className="text-xl font-bold text-yellow-600">{stats.totalIdeas}</p><p className="text-xs text-gray-600">أفكار مقدمة</p></div>
                          <div className="p-3 bg-emerald-50 rounded-lg text-center"><p className="text-xl font-bold text-emerald-600">{stats.acceptedIdeas}</p><p className="text-xs text-gray-600">أفكار مقبولة</p></div>
                          <div className="p-3 bg-purple-50 rounded-lg text-center"><p className="text-xl font-bold text-purple-600">{stats.totalIdeas > 0 ? Math.round((stats.acceptedIdeas / stats.totalIdeas) * 100) : 0}%</p><p className="text-xs text-gray-600">معدل القبول</p></div>
                        </div>
                      </div>

                      <Separator />

                      {/* Section 4: Overtime */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <Zap className="w-5 h-5 text-indigo-500" /> القسم 4: ملخص العمل الإضافي
                        </h3>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="p-3 bg-indigo-50 rounded-lg text-center"><p className="text-xl font-bold text-indigo-600">{stats.totalOvertimeHours}h</p><p className="text-xs text-gray-600">إجمالي الساعات</p></div>
                          <div className="p-3 bg-indigo-50 rounded-lg text-center"><p className="text-xl font-bold text-indigo-600">{formatCurrency(rewardRows.reduce((s, r) => s + r.overtimeReward, 0))}</p><p className="text-xs text-gray-600">إجمالي تكلفة العمل الإضافي</p></div>
                        </div>
                      </div>

                      <Separator />

                      {/* Section 5: Violations */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <AlertOctagon className="w-5 h-5 text-red-500" /> القسم 5: ملخص المخالفات
                        </h3>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="p-3 bg-red-50 rounded-lg text-center"><p className="text-xl font-bold text-red-600">{stats.totalViolations}</p><p className="text-xs text-gray-600">عدد المخالفات</p></div>
                          <div className="p-3 bg-red-50 rounded-lg text-center"><p className="text-xl font-bold text-red-600">{formatCurrency(rewardRows.reduce((s, r) => s + r.violationDeduction, 0))}</p><p className="text-xs text-gray-600">إجمالي الخصومات</p></div>
                        </div>
                      </div>

                      <Separator />

                      {/* Section 6: Rewards Summary */}
                      <div>
                        <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                          <DollarSign className="w-5 h-5 text-emerald-500" /> القسم 6: ملخص المكافآت والرواتب
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                          <div className="p-3 bg-gray-50 rounded-lg text-center"><p className="text-lg font-bold">{formatCurrency(totalBasicSalaries)}</p><p className="text-xs text-gray-600">الرواتب الأساسية</p></div>
                          <div className="p-3 bg-emerald-50 rounded-lg text-center"><p className="text-lg font-bold text-emerald-600">{formatCurrency(totalRewards)}</p><p className="text-xs text-gray-600">إجمالي المكافآت</p></div>
                          <div className="p-3 bg-indigo-50 rounded-lg text-center"><p className="text-lg font-bold text-indigo-600">{formatCurrency(totalContractIncentives)}</p><p className="text-xs text-gray-600">حوافز العقود</p></div>
                          <div className="p-3 bg-red-50 rounded-lg text-center"><p className="text-lg font-bold text-red-600">{formatCurrency(totalDeductions)}</p><p className="text-xs text-gray-600">إجمالي الخصومات</p></div>
                          <div className="p-3 bg-blue-50 rounded-lg text-center border-2 border-blue-200"><p className="text-lg font-bold text-blue-700">{formatCurrency(totalFinalSalaries)}</p><p className="text-xs text-gray-600">الرواتب النهائية</p></div>
                        </div>
                      </div>

                      <Separator />

                      {/* Section 7: Recommendations */}
                      <div>
                        <h3 className="font-bold text-base mb-3">القسم 7: التوصيات</h3>
                        <div className="space-y-2 text-sm">
                          {stats.top5Attendance.length > 0 && (
                            <div className="p-3 bg-emerald-50 rounded-lg">
                              <p className="font-medium text-emerald-700">✅ موظفون يستحقون التقدير:</p>
                              <p className="text-gray-600">{stats.top5Attendance.slice(0, 3).map((e) => e.fullName).join('، ')}</p>
                            </div>
                          )}
                          {stats.lowAttendance.length > 0 && (
                            <div className="p-3 bg-amber-50 rounded-lg">
                              <p className="font-medium text-amber-700">⚠️ موظفون يحتاجون متابعة (حضور أقل من 90%):</p>
                              <p className="text-gray-600">{stats.lowAttendance.map((e) => e.fullName).join('، ')}</p>
                            </div>
                          )}
                          {stats.repeatedTardiness.length > 0 && (
                            <div className="p-3 bg-red-50 rounded-lg">
                              <p className="font-medium text-red-700">🔴 موظفون بتأخير متكرر:</p>
                              <p className="text-gray-600">{stats.repeatedTardiness.map((e) => e.fullName).join('، ')}</p>
                            </div>
                          )}
                          {stats.lowAttendance.length === 0 && stats.repeatedTardiness.length === 0 && (
                            <div className="p-3 bg-emerald-50 rounded-lg">
                              <p className="font-medium text-emerald-700">✅ جميع الموظفين ملتزمون بالحضور والمواعيد</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </main>
      </div>
    </div>
  );
}