import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  CalendarDays, CheckCircle2, XCircle, RefreshCw, Users, BarChart3,
  ClipboardCheck, Loader2, Menu, Calculator, Award, Eye,
} from 'lucide-react';
import { Sidebar } from './Index';
import { apiGet, apiPost } from '@/lib/api-client';

interface ReadinessData {
  attendance_ready: boolean;
  productivity_ready: boolean;
  quality_ready: boolean;
  employees_evaluated: number;
  employees_total: number;
}

interface ResultRecord {
  id: number;
  employee_id: number;
  employee_name: string;
  department: string;
  salary: number;
  attendance_score: number | null;
  productivity_score: number | null;
  quality_score: number | null;
  quality_output: number | null;
  quality_initiative: number | null;
  quality_teamwork: number | null;
  quality_client_satisfaction: number | null;
  quality_notes: string | null;
  final_score: number | null;
  grade: string | null;
  reward_percent: number | null;
  reward_amount: number | null;
  status: string | null;
  tasks_assigned: number | null;
  tasks_completed: number | null;
  tasks_on_time: number | null;
  evaluated_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
}

export default function MonthlyRewards() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [readiness, setReadiness] = useState<ReadinessData | null>(null);
  const [loadingReadiness, setLoadingReadiness] = useState(false);
  const [syncingClickUp, setSyncingClickUp] = useState(false);
  const [computingAttendance, setComputingAttendance] = useState(false);
  const [calculating, setCalculating] = useState(false);
  const [approving, setApproving] = useState(false);
  const [results, setResults] = useState<ResultRecord[]>([]);
  const [loadingResults, setLoadingResults] = useState(false);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedResult, setSelectedResult] = useState<ResultRecord | null>(null);

  useEffect(() => {
    if (selectedMonth) {
      autoComputeAndLoad();
    }
  }, [selectedMonth]);

  async function autoComputeAndLoad() {
    // First auto-compute attendance scores (same as MonthlyEvaluation)
    try {
      await apiPost('/api/v1/rewards/auto-compute', { month: selectedMonth });
    } catch (err) {
      console.warn('Auto-compute failed (non-critical):', err);
    }

    // Load readiness and results
    await loadReadiness();
    await loadResults();

    // Auto-calculate final rewards if all data is ready
    try {
      const readinessRes = await apiGet('/api/v1/rewards/readiness', { month: selectedMonth });
      if (readinessRes.ok && readinessRes.data) {
        const readinessData = readinessRes.data;
        if (readinessData.attendance_ready && readinessData.productivity_ready && readinessData.quality_ready) {
          // All ready - auto-calculate
          const calcRes = await apiPost('/api/v1/rewards/calculate', { month: selectedMonth });
          if (calcRes.ok) {
            // Reload results after calculation
            await loadResults();
          }
        }
      }
    } catch (err) {
      console.warn('Auto-calculate failed (non-critical):', err);
    }
  }

  async function loadReadiness() {
    setLoadingReadiness(true);
    try {
      const res = await apiGet('/api/v1/rewards/readiness', { month: selectedMonth });
      if (res.ok && res.data) {
        setReadiness(res.data);
      } else {
        setReadiness(null);
      }
    } catch (err) {
      console.error('Failed to load readiness:', err);
      setReadiness(null);
    } finally {
      setLoadingReadiness(false);
    }
  }

  async function loadResults() {
    setLoadingResults(true);
    try {
      const res = await apiGet('/api/v1/rewards/results', { month: selectedMonth });
      if (res.ok && res.data) {
        setResults(res.data.results || []);
      } else {
        setResults([]);
      }
    } catch (err) {
      console.error('Failed to load results:', err);
      setResults([]);
    } finally {
      setLoadingResults(false);
    }
  }

  async function handleComputeAttendance() {
    setComputingAttendance(true);
    try {
      const res = await apiPost('/api/v1/rewards/compute-attendance', { month: selectedMonth });
      if (res.ok && res.data) {
        if (res.data.employees_processed === 0) {
          toast.info('لا توجد سجلات حضور لهذا الشهر بعد. يرجى استيراد بيانات الحضور أولاً.');
        } else {
          toast.success(`تم حساب درجة الانضباط لـ ${res.data.employees_processed} موظف`);
        }
        await loadReadiness();
        await loadResults();
      }
    } catch (err: any) {
      console.error('Compute attendance failed:', err);
      toast.error(err?.data?.detail || 'فشل في حساب درجة الانضباط');
    } finally {
      setComputingAttendance(false);
    }
  }

  async function handleSyncClickUp() {
    setSyncingClickUp(true);
    try {
      const res = await apiPost('/api/v1/rewards/sync-clickup', { month: selectedMonth });
      if (res.ok && res.data) {
        toast.success(`تمت مزامنة بيانات ClickUp لـ ${res.data.employees_processed} موظف`);
        await loadReadiness();
        await loadResults();
      }
    } catch (err: any) {
      console.error('ClickUp sync failed:', err);
      toast.error(err?.data?.detail || 'فشل في مزامنة بيانات ClickUp');
    } finally {
      setSyncingClickUp(false);
    }
  }

  async function handleCalculate() {
    setCalculating(true);
    try {
      const res = await apiPost('/api/v1/rewards/calculate', { month: selectedMonth });
      if (res.ok && res.data) {
        toast.success(`تم حساب المكافآت لـ ${res.data.calculated_count} موظف. إجمالي: ${res.data.total_rewards} ر.ع.`);
        if (res.data.skipped_count > 0) {
          toast.warning(`تم تخطي ${res.data.skipped_count} موظف (بيانات ناقصة)`);
        }
        await loadResults();
      }
    } catch (err: any) {
      console.error('Calculate failed:', err);
      toast.error(err?.data?.detail || 'فشل في حساب المكافآت');
    } finally {
      setCalculating(false);
    }
  }

  async function handleApproveAll() {
    setApproving(true);
    try {
      const res = await apiPost('/api/v1/rewards/approve', { month: selectedMonth, all: true });
      if (res.ok && res.data) {
        toast.success(`تم اعتماد ${res.data.approved_count} مكافأة بنجاح`);
        await loadResults();
      }
    } catch (err: any) {
      console.error('Approve failed:', err);
      toast.error(err?.data?.detail || 'فشل في اعتماد المكافآت');
    } finally {
      setApproving(false);
    }
  }

  const monthOptions = Array.from({ length: 12 }, (_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const label = d.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long' });
    return { value, label };
  });

  const pendingApprovalCount = results.filter(r => r.status === 'pending_approval').length;
  const approvedCount = results.filter(r => r.status === 'approved').length;
  const totalRewardAmount = results.reduce((sum, r) => sum + (r.reward_amount || 0), 0);

  function getGradeBadge(grade: string | null, status: string | null) {
    if (!grade) return <Badge variant="outline" className="text-gray-500">غير محسوب</Badge>;
    if (status === 'approved') {
      return <Badge className="bg-green-600">{grade} ✅</Badge>;
    }
    if (grade === 'ممتاز') return <Badge className="bg-purple-600">{grade}</Badge>;
    if (grade === 'جيد جداً') return <Badge className="bg-blue-600">{grade}</Badge>;
    if (grade === 'جيد') return <Badge className="bg-amber-600">{grade}</Badge>;
    return <Badge variant="destructive">{grade}</Badge>;
  }

  function formatScore(score: number | null): string {
    if (score === null) return '-';
    return (score * 100).toFixed(0) + '%';
  }

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="flex-1 lg:mr-72">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white border-b px-4 py-3 flex items-center gap-3 shadow-sm">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <CalendarDays className="w-6 h-6 text-blue-600" />
          <h1 className="text-xl font-bold text-gray-800">المكافآت الشهرية</h1>
          <Badge variant="outline" className="mr-auto text-xs">
            المرحلة الثالثة
          </Badge>
        </header>

        <div className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto">
          {/* Month Selector */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700">اختر الشهر:</span>
                </div>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-[220px]">
                    <SelectValue placeholder="اختر الشهر" />
                  </SelectTrigger>
                  <SelectContent>
                    {monthOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Readiness Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Attendance Card */}
            <Card className={`border-2 ${readiness?.attendance_ready ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  {readiness?.attendance_ready ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-orange-600" />
                  )}
                  درجة الانضباط
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  {readiness?.attendance_ready
                    ? 'تم حساب درجة الانضباط ✓'
                    : 'لم يتم حساب درجة الانضباط بعد'}
                </p>
                <Button
                  size="sm"
                  variant={readiness?.attendance_ready ? 'outline' : 'default'}
                  onClick={handleComputeAttendance}
                  disabled={computingAttendance}
                  className="w-full"
                >
                  {computingAttendance ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري الحساب...
                    </>
                  ) : (
                    <>
                      <BarChart3 className="w-4 h-4 ml-2" />
                      {readiness?.attendance_ready ? 'إعادة الحساب' : 'حساب الانضباط'}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Productivity Card */}
            <Card className={`border-2 ${readiness?.productivity_ready ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  {readiness?.productivity_ready ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-orange-600" />
                  )}
                  درجة الإنتاجية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  {readiness?.productivity_ready
                    ? 'تمت مزامنة بيانات ClickUp ✓'
                    : 'لم تتم مزامنة ClickUp بعد'}
                </p>
                <Button
                  size="sm"
                  variant={readiness?.productivity_ready ? 'outline' : 'default'}
                  onClick={handleSyncClickUp}
                  disabled={syncingClickUp}
                  className="w-full"
                >
                  {syncingClickUp ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري المزامنة...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4 ml-2" />
                      {readiness?.productivity_ready ? 'إعادة المزامنة' : 'مزامنة ClickUp'}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Quality Card */}
            <Card className={`border-2 ${readiness?.quality_ready ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  {readiness?.quality_ready ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-orange-600" />
                  )}
                  تقييم الجودة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  {readiness?.quality_ready
                    ? 'تم تقييم جميع الموظفين ✓'
                    : 'لم يتم التقييم بعد'}
                </p>
                <Button
                  size="sm"
                  variant={readiness?.quality_ready ? 'outline' : 'default'}
                  onClick={() => window.location.href = '/monthly-evaluation'}
                  className="w-full"
                >
                  <ClipboardCheck className="w-4 h-4 ml-2" />
                  {readiness?.quality_ready ? 'مراجعة التقييم' : 'بدء التقييم'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-3 items-center">
                <Button
                  onClick={handleCalculate}
                  disabled={calculating || !(readiness?.attendance_ready && readiness?.productivity_ready && readiness?.quality_ready)}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {calculating ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري الحساب...
                    </>
                  ) : (
                    <>
                      <Calculator className="w-4 h-4 ml-2" />
                      حساب المكافآت النهائية
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleApproveAll}
                  disabled={approving || pendingApprovalCount === 0}
                  variant="default"
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  {approving ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري الاعتماد...
                    </>
                  ) : (
                    <>
                      <Award className="w-4 h-4 ml-2" />
                      اعتماد الكل ({pendingApprovalCount})
                    </>
                  )}
                </Button>
                <div className="mr-auto flex items-center gap-3">
                  {approvedCount > 0 && (
                    <Badge className="bg-green-100 text-green-700 text-sm px-3 py-1">
                      {approvedCount} معتمد
                    </Badge>
                  )}
                  {totalRewardAmount > 0 && (
                    <Badge variant="secondary" className="text-sm px-3 py-1">
                      إجمالي: {totalRewardAmount.toFixed(2)} ر.ع.
                    </Badge>
                  )}
                </div>
              </div>
              {!(readiness?.attendance_ready && readiness?.productivity_ready && readiness?.quality_ready) && (
                <p className="text-xs text-amber-600 mt-2">
                  ⚠️ يجب إكمال جميع المراحل (الانضباط + الإنتاجية + الجودة) قبل حساب المكافآت النهائية
                </p>
              )}
            </CardContent>
          </Card>

          {/* Results Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="w-5 h-5 text-blue-600" />
                نتائج الأداء الشهري
                {results.length > 0 && (
                  <Badge variant="secondary" className="mr-2">{results.length} موظف</Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingResults ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                  <span className="mr-2 text-gray-500">جاري التحميل...</span>
                </div>
              ) : results.length === 0 ? (
                <p className="text-center text-gray-500 py-8">لا توجد نتائج بعد. ابدأ بحساب الانضباط والإنتاجية والجودة.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-gray-50">
                        <th className="text-right p-3 font-medium text-gray-600">#</th>
                        <th className="text-right p-3 font-medium text-gray-600">الموظف</th>
                        <th className="text-right p-3 font-medium text-gray-600">القسم</th>
                        <th className="text-center p-3 font-medium text-gray-600">الانضباط</th>
                        <th className="text-center p-3 font-medium text-gray-600">الإنتاجية</th>
                        <th className="text-center p-3 font-medium text-gray-600">الجودة</th>
                        <th className="text-center p-3 font-medium text-gray-600">النتيجة</th>
                        <th className="text-center p-3 font-medium text-gray-600">التصنيف</th>
                        <th className="text-center p-3 font-medium text-gray-600">المكافأة</th>
                        <th className="text-center p-3 font-medium text-gray-600">تفاصيل</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map((r, idx) => (
                        <tr key={r.id} className="border-b hover:bg-gray-50 transition-colors">
                          <td className="p-3 text-gray-500">{idx + 1}</td>
                          <td className="p-3 font-medium">{r.employee_name}</td>
                          <td className="p-3 text-gray-600">{r.department || '-'}</td>
                          <td className="p-3 text-center">
                            <span className={r.attendance_score !== null ? 'font-semibold text-blue-600' : 'text-gray-400'}>
                              {formatScore(r.attendance_score)}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <span className={r.productivity_score !== null ? 'font-semibold text-indigo-600' : 'text-gray-400'}>
                              {formatScore(r.productivity_score)}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <span className={r.quality_score !== null ? 'font-semibold text-purple-600' : 'text-gray-400'}>
                              {formatScore(r.quality_score)}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <span className={r.final_score !== null ? 'font-bold text-gray-800' : 'text-gray-400'}>
                              {formatScore(r.final_score)}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            {getGradeBadge(r.grade, r.status)}
                          </td>
                          <td className="p-3 text-center">
                            {r.reward_amount !== null ? (
                              <span className="font-semibold text-green-600">
                                {r.reward_amount.toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setSelectedResult(r);
                                setDetailsDialogOpen(true);
                              }}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Summary Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="w-5 h-5 text-purple-600" />
                ملخص الجاهزية
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingReadiness ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                  <span className="mr-2 text-gray-500">جاري التحميل...</span>
                </div>
              ) : readiness ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">إجمالي الموظفين</span>
                    <Badge variant="secondary" className="text-lg px-3">
                      {readiness.employees_total}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">الموظفون المُقيَّمون بالكامل</span>
                    <Badge
                      className={`text-lg px-3 ${
                        readiness.employees_evaluated === readiness.employees_total && readiness.employees_total > 0
                          ? 'bg-green-600'
                          : 'bg-amber-600'
                      }`}
                    >
                      {readiness.employees_evaluated} / {readiness.employees_total}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className={`text-center p-3 rounded-lg ${readiness.attendance_ready ? 'bg-green-100' : 'bg-red-100'}`}>
                      <div className={`text-xs font-medium ${readiness.attendance_ready ? 'text-green-700' : 'text-red-700'}`}>
                        الانضباط
                      </div>
                      <div className="mt-1">
                        {readiness.attendance_ready ? '✅' : '❌'}
                      </div>
                    </div>
                    <div className={`text-center p-3 rounded-lg ${readiness.productivity_ready ? 'bg-green-100' : 'bg-red-100'}`}>
                      <div className={`text-xs font-medium ${readiness.productivity_ready ? 'text-green-700' : 'text-red-700'}`}>
                        الإنتاجية
                      </div>
                      <div className="mt-1">
                        {readiness.productivity_ready ? '✅' : '❌'}
                      </div>
                    </div>
                    <div className={`text-center p-3 rounded-lg ${readiness.quality_ready ? 'bg-green-100' : 'bg-red-100'}`}>
                      <div className={`text-xs font-medium ${readiness.quality_ready ? 'text-green-700' : 'text-red-700'}`}>
                        الجودة
                      </div>
                      <div className="mt-1">
                        {readiness.quality_ready ? '✅' : '❌'}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-center text-gray-500 py-4">اختر شهراً لعرض حالة الجاهزية</p>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-lg">
              تفاصيل: {selectedResult?.employee_name}
            </DialogTitle>
            <p className="text-sm text-gray-500">{selectedResult?.department}</p>
          </DialogHeader>

          {selectedResult && (
            <div className="space-y-4 py-4">
              {/* Scores */}
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-600 font-medium">الانضباط</p>
                  <p className="text-xl font-bold text-blue-700">{formatScore(selectedResult.attendance_score)}</p>
                </div>
                <div className="text-center p-3 bg-indigo-50 rounded-lg">
                  <p className="text-xs text-indigo-600 font-medium">الإنتاجية</p>
                  <p className="text-xl font-bold text-indigo-700">{formatScore(selectedResult.productivity_score)}</p>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <p className="text-xs text-purple-600 font-medium">الجودة</p>
                  <p className="text-xl font-bold text-purple-700">{formatScore(selectedResult.quality_score)}</p>
                </div>
              </div>

              {/* Final Score */}
              {selectedResult.final_score !== null && (
                <div className="p-4 bg-gray-50 rounded-lg border">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">النتيجة النهائية:</span>
                    <span className="text-2xl font-bold">{formatScore(selectedResult.final_score)}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-gray-600">التصنيف:</span>
                    {getGradeBadge(selectedResult.grade, selectedResult.status)}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-gray-600">المكافأة:</span>
                    <span className="font-bold text-green-600">
                      {selectedResult.reward_amount?.toFixed(2) || '0'} ر.ع. ({selectedResult.reward_percent || 0}%)
                    </span>
                  </div>
                </div>
              )}

              {/* Quality Details */}
              {selectedResult.quality_score !== null && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-700">تفاصيل تقييم الجودة:</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-gray-50 rounded flex justify-between">
                      <span>جودة المخرجات:</span>
                      <span className="font-semibold">{selectedResult.quality_output}/10</span>
                    </div>
                    <div className="p-2 bg-gray-50 rounded flex justify-between">
                      <span>المبادرة:</span>
                      <span className="font-semibold">{selectedResult.quality_initiative}/10</span>
                    </div>
                    <div className="p-2 bg-gray-50 rounded flex justify-between">
                      <span>التعاون:</span>
                      <span className="font-semibold">{selectedResult.quality_teamwork}/10</span>
                    </div>
                    <div className="p-2 bg-gray-50 rounded flex justify-between">
                      <span>رضا العملاء:</span>
                      <span className="font-semibold">{selectedResult.quality_client_satisfaction}/10</span>
                    </div>
                  </div>
                  {selectedResult.quality_notes && (
                    <div className="p-2 bg-yellow-50 rounded text-sm">
                      <span className="font-medium">ملاحظات: </span>
                      {selectedResult.quality_notes}
                    </div>
                  )}
                </div>
              )}

              {/* Productivity Details */}
              {selectedResult.tasks_assigned !== null && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-700">تفاصيل الإنتاجية (ClickUp):</h4>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-500">المهام المسندة</p>
                      <p className="font-bold">{selectedResult.tasks_assigned}</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-500">المنجزة</p>
                      <p className="font-bold text-green-600">{selectedResult.tasks_completed}</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-500">في الوقت</p>
                      <p className="font-bold text-blue-600">{selectedResult.tasks_on_time}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Status */}
              <div className="p-3 bg-gray-50 rounded-lg flex items-center justify-between">
                <span className="text-sm font-medium">الحالة:</span>
                <Badge variant={selectedResult.status === 'approved' ? 'default' : 'outline'}>
                  {selectedResult.status === 'approved' ? 'معتمد ✅' :
                   selectedResult.status === 'pending_approval' ? 'بانتظار الاعتماد' :
                   'مسودة'}
                </Badge>
              </div>

              {selectedResult.approved_at && (
                <p className="text-xs text-gray-500">
                  تم الاعتماد: {new Date(selectedResult.approved_at).toLocaleDateString('ar-SA')}
                </p>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}