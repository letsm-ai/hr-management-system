import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
      <div className="text-center space-y-4">
        <h1 className="text-6xl font-bold text-[#1E3A5F]">404</h1>
        <p className="text-xl text-gray-600">الصفحة غير موجودة</p>
        <p className="text-sm text-gray-400">الصفحة التي تبحث عنها غير متوفرة</p>
        <Link to="/">
          <Button className="bg-[#1E3A5F] hover:bg-[#2a4f7a] mt-4">
            <Home className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
        </Link>
      </div>
    </div>
  );
}