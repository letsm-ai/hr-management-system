import { useEffect, useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  FileSpreadsheet, Menu, Download, Printer, ChevronDown, ChevronUp,
  Award, Users, DollarSign, Search, ArrowUpDown, AlertTriangle,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import { apiGet } from '@/lib/api-client';
import {
  ClientContract, IncentiveSetting,
  fetchAllClientContracts, fetchIncentiveSettings,
  calculateMonthlyIncentives, formatOMR, baisaToOmr,
  IncentiveCalculationResult,
} from '@/lib/incentive-api';
import { fetchPerformanceKpis, PerformanceKpiRecord } from '@/lib/hr-api';
import { Sidebar } from './Index';

// Backend performance evaluation result
interface BackendPerfResult {
  employee_id: number;
  employee_name: string;
  attendance_score: number | null;
  productivity_score: number | null;
  quality_score: number | null;
  final_score: number | null;
  grade: string | null;
  reward_percent: number | null;
  reward_amount: number | null;
  status: string | null;
}

// Fetch backend performance results for a month
async function fetchBackendPerformanceResults(month: string): Promise<BackendPerfResult[]> {
  try {
    const res = await apiGet('/api/v1/rewards/results', { month });
    if (res.ok && res.data) {
      return res.data.results || [];
    }
    return [];
  } catch {
    return [];
  }
}

type SortField = 'name' | 'salary' | 'reward' | 'deductions' | 'total';
type SortDir = 'asc' | 'desc';

export default function IncentiveReport() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { loading: authLoading } = useAuth();
  const { employees, attendance, ideas, violations, overtime, loading: dataLoading } = useHRData();
  // violations is ViolationRecord[] with: id, date, employeeId, violationType, details, severity, deductionAmount, deductionDays

  const [contracts, setContracts] = useState<ClientContract[]>([]);
  const [settings, setSettings] = useState<IncentiveSetting[]>([]);
  const [kpis, setKpis] = useState<PerformanceKpiRecord[]>([]);
  const [backendPerfResults, setBackendPerfResults] = useState<BackendPerfResult[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [expandedEmployee, setExpandedEmployee] = useState<string | null>(null);
  const [calcResult, setCalcResult] = useState<IncentiveCalculationResult | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  // Reload backend performance results when month changes
  useEffect(() => {
    fetchBackendPerformanceResults(selectedMonth).then(setBackendPerfResults);
  }, [selectedMonth]);

  useEffect(() => {
    if (!loading && employees.length > 0) {
      recalculate();
    }
  }, [selectedMonth, contracts, employees, attendance, kpis, ideas, violations, overtime, settings, loading, backendPerfResults]);

  async function loadData() {
    setLoading(true);
    const [c, s, k, perfResults] = await Promise.all([
      fetchAllClientContracts(),
      fetchIncentiveSettings(),
      fetchPerformanceKpis(),
      fetchBackendPerformanceResults(new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0')),
    ]);
    setContracts(c);
    setSettings(s);
    setKpis(k);
    setBackendPerfResults(perfResults);
    setLoading(false);
  }

  function recalculate() {
    const result = calculateMonthlyIncentives(
      selectedMonth, contracts, employees, attendance, kpis, ideas, violations, overtime, settings
    );
    setCalcResult(result);
  }

  // Get backend performance multiplier for an employee (synced from evaluations)
  function getBackendPerformanceData(employeeId: string): { score: number; multiplier: number; grade: string } | null {
    const empIdNum = parseInt(employeeId);
    const backendResult = backendPerfResults.find(r => r.employee_id === empIdNum);
    if (!backendResult || backendResult.final_score === null) return null;
    
    // Map grade to multiplier (matching backend logic)
    let multiplier = 1.0;
    if (backendResult.grade === 'ممتاز') multiplier = 1.30;
    else if (backendResult.grade === 'جيد جداً') multiplier = 1.15;
    else if (backendResult.grade === 'جيد') multiplier = 1.05;
    else if (backendResult.grade === 'يحتاج تحسين') multiplier = 0.85;
    
    return {
      score: Math.round((backendResult.final_score || 0) * 100),
      multiplier,
      grade: backendResult.grade || '',
    };
  }

  // Get overtime amount for employee in month (in baisa)
  function getOvertimeAmount(employeeId: string, month: string): number {
    const [y, m] = month.split('-').map(Number);
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return 0;
    const empOvertime = overtime.filter((o) => {
      const d = new Date(o.date);
      return o.employeeId === employeeId && d.getFullYear() === y && d.getMonth() + 1 === m && o.approved === 'نعم';
    });
    return empOvertime.reduce((sum, o) => {
      const hourlyRate = emp.basicSalary / 176;
      const rate = o.dayType === 'يوم عادي' ? 1.25 : 1.5;
      return sum + (o.overtimeHours * hourlyRate * rate * 1000);
    }, 0);
  }

  // Get KPI bonus for employee in month (in baisa)
  function getKpiBonus(employeeId: string, month: string): number {
    const empKpis = kpis.filter((k) => k.employeeId === employeeId && k.month === month);
    const achieved = empKpis.filter((k) => k.achievementRate >= 80).length;
    return achieved * 10000; // 10 OMR per KPI achieved
  }

  // Get ideas bonus for employee in month (in baisa)
  function getIdeasBonus(employeeId: string, month: string): number {
    const empIdeas = ideas.filter((i) => {
      return i.employeeId === employeeId && i.month === month && (i.status === 'مقبولة' || i.status === 'منفذة');
    });
    return empIdeas.length * 5000; // 5 OMR per accepted idea
  }

  // Get violations for employee in month
  function getEmployeeViolations(employeeId: string, month: string) {
    const [y, m] = month.split('-').map(Number);
    return violations.filter((v) => {
      const d = new Date(v.date);
      return v.employeeId === employeeId && d.getFullYear() === y && d.getMonth() + 1 === m;
    });
  }

  // Build the report rows
  const reportRows = useMemo(() => {
    const activeEmployees = employees.filter(e => e.status === 'نشط');
    
    return activeEmployees.map(emp => {
      const calcEmp = calcResult?.employees.find(e => e.employeeId === emp.id);
      
      // Basic salary in OMR (already in OMR from the DB)
      const basicSalary = emp.basicSalary || 0;
      // Total salary with allowances
      const totalSalary = basicSalary + (emp.housingAllowance || 0) + (emp.transportAllowance || 0) + (emp.foodAllowance || 0) + (emp.otherAllowances || 0);
      
      // All rewards in baisa, convert to OMR
      const contractBonus = calcEmp ? calcEmp.totalContractBonus : 0;
      const poolShare = calcEmp ? calcEmp.poolShare : 0;
      const overtimeAmount = getOvertimeAmount(emp.id, selectedMonth);
      const kpiBonus = getKpiBonus(emp.id, selectedMonth);
      const ideasBonus = getIdeasBonus(emp.id, selectedMonth);
      
      // Use backend performance evaluation if available (synced from evaluations), otherwise fallback to frontend calc
      const backendPerf = getBackendPerformanceData(emp.id);
      const performanceMultiplier = backendPerf ? backendPerf.multiplier : (calcEmp ? calcEmp.performanceMultiplier : 1);
      const performanceScore = backendPerf ? backendPerf.score : (calcEmp?.performanceScore || 0);
      const performanceGrade = backendPerf ? backendPerf.grade : '';
      
      const totalRewardBaisa = Math.round((contractBonus + poolShare + overtimeAmount + kpiBonus + ideasBonus) * performanceMultiplier);
      const totalRewardOMR = baisaToOmr(totalRewardBaisa);
      
      // Violations deductions (already in OMR)
      const empViolations = getEmployeeViolations(emp.id, selectedMonth);
      const totalDeductions = empViolations.reduce((sum, v) => sum + (v.deductionAmount || 0), 0);
      
      // Net = Salary + Rewards - Deductions
      const netTotal = totalSalary + totalRewardOMR - totalDeductions;

      return {
        id: emp.id,
        name: emp.fullName,
        jobTitle: emp.jobTitle || '—',
        basicSalary,
        totalSalary,
        contractBonus: baisaToOmr(contractBonus),
        poolShare: baisaToOmr(poolShare),
        overtimeAmount: baisaToOmr(overtimeAmount),
        kpiBonus: baisaToOmr(kpiBonus),
        ideasBonus: baisaToOmr(ideasBonus),
        performanceMultiplier,
        performanceScore,
        performanceGrade,
        totalReward: totalRewardOMR,
        totalDeductions,
        violations: empViolations,
        netTotal,
        calcEmp,
      };
    });
  }, [employees, calcResult, selectedMonth, overtime, kpis, ideas, violations]);

  // Filter and sort
  const filteredRows = useMemo(() => {
    let rows = reportRows;
    
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      rows = rows.filter(r => r.name.toLowerCase().includes(q) || r.jobTitle.toLowerCase().includes(q));
    }

    rows.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name': cmp = a.name.localeCompare(b.name, 'ar'); break;
        case 'salary': cmp = a.totalSalary - b.totalSalary; break;
        case 'reward': cmp = a.totalReward - b.totalReward; break;
        case 'deductions': cmp = a.totalDeductions - b.totalDeductions; break;
        case 'total': cmp = a.netTotal - b.netTotal; break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return rows;
  }, [reportRows, searchQuery, sortField, sortDir]);

  // Summary totals
  const summaryTotals = useMemo(() => {
    const totalSalaries = reportRows.reduce((sum, r) => sum + r.totalSalary, 0);
    const totalRewards = reportRows.reduce((sum, r) => sum + r.totalReward, 0);
    const totalDeductions = reportRows.reduce((sum, r) => sum + r.totalDeductions, 0);
    const netTotal = reportRows.reduce((sum, r) => sum + r.netTotal, 0);
    const beneficiaries = reportRows.filter(r => r.totalReward > 0).length;
    const violators = reportRows.filter(r => r.totalDeductions > 0).length;
    return { totalSalaries, totalRewards, totalDeductions, netTotal, beneficiaries, violators };
  }, [reportRows]);

  function toggleSort(field: SortField) {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  }

  function handleExportCSV() {
    const headers = ['الموظف', 'الوظيفة', 'الراتب الأساسي', 'إجمالي الراتب', 'مكافآت العقود', 'حصة الصندوق', 'العمل الإضافي', 'مكافأة KPI', 'مكافأة الأفكار', 'مُعامل الأداء', 'إجمالي المكافأة', 'المخالفات (خصم)', 'الصافي النهائي'];
    const rows = filteredRows.map(r => [
      r.name,
      r.jobTitle,
      r.basicSalary.toFixed(3),
      r.totalSalary.toFixed(3),
      r.contractBonus.toFixed(3),
      r.poolShare.toFixed(3),
      r.overtimeAmount.toFixed(3),
      r.kpiBonus.toFixed(3),
      r.ideasBonus.toFixed(3),
      `×${r.performanceMultiplier}`,
      r.totalReward.toFixed(3),
      r.totalDeductions.toFixed(3),
      r.netTotal.toFixed(3),
    ].join(','));

    // Add summary row
    rows.push('');
    rows.push(`الإجمالي,,,${summaryTotals.totalSalaries.toFixed(3)},,,,,,,,${summaryTotals.totalDeductions.toFixed(3)},${summaryTotals.netTotal.toFixed(3)}`);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `تقرير-المكافآت-${selectedMonth}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handlePrint() {
    window.print();
  }

  const months = [];
  for (let m = 1; m <= 12; m++) {
    months.push(`2026-${String(m).padStart(2, '0')}`);
  }
  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  if (authLoading || dataLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E3A5F] mx-auto mb-4" />
          <p className="text-[#64748B]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
                <Menu className="w-5 h-5" />
              </Button>
              <FileSpreadsheet className="w-5 h-5 text-blue-600" />
              <div>
                <h1 className="text-lg font-bold text-[#1E293B]">تقرير الرواتب والمكافآت</h1>
                <p className="text-xs text-[#64748B]">كشف شهري تفصيلي لكل موظف</p>
              </div>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="p-3 text-center">
                <DollarSign className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-blue-700">{summaryTotals.totalSalaries.toFixed(3)}</p>
                <p className="text-xs text-blue-600">إجمالي الرواتب (ر.ع)</p>
              </CardContent>
            </Card>
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-3 text-center">
                <Award className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-emerald-700">{summaryTotals.totalRewards.toFixed(3)}</p>
                <p className="text-xs text-emerald-600">إجمالي المكافآت (ر.ع)</p>
              </CardContent>
            </Card>
            <Card className="border-red-200 bg-red-50/50">
              <CardContent className="p-3 text-center">
                <AlertTriangle className="w-5 h-5 text-red-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-red-700">{summaryTotals.totalDeductions.toFixed(3)}</p>
                <p className="text-xs text-red-600">إجمالي المخالفات (ر.ع)</p>
              </CardContent>
            </Card>
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="p-3 text-center">
                <DollarSign className="w-5 h-5 text-purple-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-purple-700">{summaryTotals.netTotal.toFixed(3)}</p>
                <p className="text-xs text-purple-600">الصافي النهائي (ر.ع)</p>
              </CardContent>
            </Card>
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="p-3 text-center">
                <Users className="w-5 h-5 text-amber-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-amber-700">{summaryTotals.beneficiaries} / {reportRows.length}</p>
                <p className="text-xs text-amber-600">مستفيدين من المكافآت</p>
              </CardContent>
            </Card>
          </div>

          {/* Controls: Month selector, search, export */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center gap-3">
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {months.map((m) => (
                      <SelectItem key={m} value={m}>{monthNames[m.split('-')[1]]} {m.split('-')[0]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="relative flex-1 min-w-[200px] max-w-[300px]">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="بحث بالاسم أو الوظيفة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-9"
                  />
                </div>
                <div className="flex gap-2 mr-auto">
                  <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
                    <Download className="w-4 h-4" /> تصدير CSV
                  </Button>
                  <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1.5">
                    <Printer className="w-4 h-4" /> طباعة
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Report Table */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4" />
                كشف الرواتب والمكافآت — {monthNames[selectedMonth.split('-')[1]]} {selectedMonth.split('-')[0]}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-right p-2.5 font-medium w-8">#</th>
                      <th className="text-right p-2.5 font-medium cursor-pointer hover:text-blue-600" onClick={() => toggleSort('name')}>
                        <span className="flex items-center gap-1">الموظف <ArrowUpDown className="w-3 h-3" /></span>
                      </th>
                      <th className="text-right p-2.5 font-medium">الوظيفة</th>
                      <th className="text-right p-2.5 font-medium cursor-pointer hover:text-blue-600" onClick={() => toggleSort('salary')}>
                        <span className="flex items-center gap-1">الراتب الشامل <ArrowUpDown className="w-3 h-3" /></span>
                      </th>
                      <th className="text-right p-2.5 font-medium cursor-pointer hover:text-blue-600" onClick={() => toggleSort('reward')}>
                        <span className="flex items-center gap-1">المكافأة <ArrowUpDown className="w-3 h-3" /></span>
                      </th>
                      <th className="text-right p-2.5 font-medium cursor-pointer hover:text-blue-600" onClick={() => toggleSort('deductions')}>
                        <span className="flex items-center gap-1 text-red-600">المخالفات <ArrowUpDown className="w-3 h-3" /></span>
                      </th>
                      <th className="text-right p-2.5 font-medium cursor-pointer hover:text-blue-600" onClick={() => toggleSort('total')}>
                        <span className="flex items-center gap-1 font-bold">الصافي <ArrowUpDown className="w-3 h-3" /></span>
                      </th>
                      <th className="text-right p-2.5 font-medium w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRows.length === 0 ? (
                      <tr><td colSpan={8} className="text-center py-10 text-gray-400">لا توجد بيانات لهذا الشهر</td></tr>
                    ) : (
                      filteredRows.map((row, idx) => (
                        <>
                          <tr
                            key={row.id}
                            className={`border-b hover:bg-blue-50/50 cursor-pointer transition-colors ${expandedEmployee === row.id ? 'bg-blue-50/30' : ''}`}
                            onClick={() => setExpandedEmployee(expandedEmployee === row.id ? null : row.id)}
                          >
                            <td className="p-2.5 text-gray-400 text-xs">{idx + 1}</td>
                            <td className="p-2.5 font-medium">{row.name}</td>
                            <td className="p-2.5 text-xs text-gray-600">{row.jobTitle}</td>
                            <td className="p-2.5 font-medium">{row.totalSalary.toFixed(3)}</td>
                            <td className="p-2.5">
                              {row.totalReward > 0 ? (
                                <span className="font-medium text-emerald-600">+{row.totalReward.toFixed(3)}</span>
                              ) : (
                                <span className="text-gray-400">0.000</span>
                              )}
                            </td>
                            <td className="p-2.5">
                              {row.totalDeductions > 0 ? (
                                <span className="font-medium text-red-600">-{row.totalDeductions.toFixed(3)}</span>
                              ) : (
                                <span className="text-gray-400">0.000</span>
                              )}
                            </td>
                            <td className="p-2.5 font-bold text-blue-700">{row.netTotal.toFixed(3)}</td>
                            <td className="p-2.5">
                              {expandedEmployee === row.id ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                            </td>
                          </tr>
                          {expandedEmployee === row.id && (
                            <tr key={`${row.id}-details`}>
                              <td colSpan={8} className="p-4 bg-gray-50/80 border-b">
                                <div className="grid md:grid-cols-3 gap-4">
                                  {/* Salary Breakdown */}
                                  <div>
                                    <h4 className="font-medium text-sm mb-2 text-gray-700">تفاصيل الراتب</h4>
                                    <div className="space-y-1.5 text-xs">
                                      <div className="flex justify-between p-2 bg-white rounded border">
                                        <span>الراتب الأساسي</span>
                                        <span className="font-medium">{row.basicSalary.toFixed(3)} ر.ع</span>
                                      </div>
                                      <div className="flex justify-between p-2 bg-white rounded border">
                                        <span>إجمالي الراتب (مع البدلات)</span>
                                        <span className="font-bold">{row.totalSalary.toFixed(3)} ر.ع</span>
                                      </div>
                                    </div>
                                  </div>
                                  {/* Reward Breakdown */}
                                  <div>
                                    <h4 className="font-medium text-sm mb-2 text-gray-700">تفاصيل المكافأة</h4>
                                    <div className="space-y-1.5 text-xs">
                                      {row.contractBonus > 0 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>مكافآت العقود</span>
                                          <span className="font-medium text-emerald-600">+{row.contractBonus.toFixed(3)} ر.ع</span>
                                        </div>
                                      )}
                                      {row.poolShare > 0 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>حصة صندوق الفريق</span>
                                          <span className="font-medium text-emerald-600">+{row.poolShare.toFixed(3)} ر.ع</span>
                                        </div>
                                      )}
                                      {row.overtimeAmount > 0 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>العمل الإضافي</span>
                                          <span className="font-medium text-emerald-600">+{row.overtimeAmount.toFixed(3)} ر.ع</span>
                                        </div>
                                      )}
                                      {row.kpiBonus > 0 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>مكافأة KPI</span>
                                          <span className="font-medium text-emerald-600">+{row.kpiBonus.toFixed(3)} ر.ع</span>
                                        </div>
                                      )}
                                      {row.ideasBonus > 0 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>مكافأة الأفكار</span>
                                          <span className="font-medium text-emerald-600">+{row.ideasBonus.toFixed(3)} ر.ع</span>
                                        </div>
                                      )}
                                      {row.performanceMultiplier !== 1 && (
                                        <div className="flex justify-between p-2 bg-white rounded border">
                                          <span>مُعامل الأداء</span>
                                          <Badge variant="secondary" className="text-xs">
                                            {row.performanceGrade ? `${row.performanceGrade} — ` : `${row.performanceScore}% — `}×{row.performanceMultiplier}
                                          </Badge>
                                        </div>
                                      )}
                                      <div className="flex justify-between p-2 bg-emerald-50 rounded border border-emerald-200 font-medium">
                                        <span>إجمالي المكافأة</span>
                                        <span className="text-emerald-700 font-bold">+{row.totalReward.toFixed(3)} ر.ع</span>
                                      </div>
                                    </div>
                                  </div>
                                  {/* Violations Breakdown */}
                                  <div>
                                    <h4 className="font-medium text-sm mb-2 text-red-700">المخالفات والخصومات</h4>
                                    <div className="space-y-1.5 text-xs">
                                      {row.violations.length === 0 ? (
                                        <p className="text-gray-400 text-center py-3">لا توجد مخالفات لهذا الشهر ✓</p>
                                      ) : (
                                        <>
                                          {row.violations.map((v, vi) => (
                                            <div key={vi} className="p-2 bg-white rounded border border-red-100">
                                              <div className="flex justify-between items-start">
                                                <div>
                                                  <p className="font-medium text-red-700">{v.violationType}</p>
                                                  <p className="text-gray-500">{v.date} — {v.severity}</p>
                                                  {v.details && <p className="text-gray-400 mt-0.5">{v.details}</p>}
                                                </div>
                                                <span className="font-bold text-red-600 whitespace-nowrap">-{(v.deductionAmount || 0).toFixed(3)}</span>
                                              </div>
                                            </div>
                                          ))}
                                          <div className="flex justify-between p-2 bg-red-50 rounded border border-red-200 font-medium">
                                            <span>إجمالي الخصومات</span>
                                            <span className="text-red-700 font-bold">-{row.totalDeductions.toFixed(3)} ر.ع</span>
                                          </div>
                                        </>
                                      )}
                                      {/* Net Summary */}
                                      <div className="flex justify-between p-2.5 bg-blue-50 rounded border border-blue-200 font-bold mt-3">
                                        <span>الصافي النهائي</span>
                                        <span className="text-blue-700">{row.netTotal.toFixed(3)} ر.ع</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </>
                      ))
                    )}
                  </tbody>
                  {/* Footer totals */}
                  {filteredRows.length > 0 && (
                    <tfoot>
                      <tr className="border-t-2 border-gray-300 bg-gray-100 font-bold">
                        <td className="p-2.5" colSpan={3}>الإجمالي ({filteredRows.length} موظف)</td>
                        <td className="p-2.5">{filteredRows.reduce((s, r) => s + r.totalSalary, 0).toFixed(3)}</td>
                        <td className="p-2.5 text-emerald-600">+{filteredRows.reduce((s, r) => s + r.totalReward, 0).toFixed(3)}</td>
                        <td className="p-2.5 text-red-600">-{filteredRows.reduce((s, r) => s + r.totalDeductions, 0).toFixed(3)}</td>
                        <td className="p-2.5 text-blue-700">{filteredRows.reduce((s, r) => s + r.netTotal, 0).toFixed(3)}</td>
                        <td></td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}