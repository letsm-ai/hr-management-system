import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Pencil, Trash2, FileSignature, Menu, Download, CheckCircle, XCircle, Clock, Printer, ShieldAlert } from 'lucide-react';
import { Sidebar } from './Index';
import {
  ContractRecord, createContract, updateContract, deleteContract,
  getEmployeeNameFromList, formatCurrency, getContractStatusColor,
  calculateContractTotal, calculateHourlyRate,
  CONTRACT_TYPES, CONTRACT_STATUSES, JOB_TITLES, DEPARTMENTS,
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import { generateContractPDF } from '@/lib/contract-pdf';
import { generateNDAPDF } from '@/lib/nda-pdf';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

const defaultForm = {
  employeeId: '',
  contractType: 'محدد المدة',
  jobTitle: '',
  department: '',
  startDate: '',
  endDate: '',
  basicSalary: 0,
  housingAllowance: 0,
  transportAllowance: 0,
  foodAllowance: 0,
  otherAllowances: 0,
  workingHours: 8,
  annualLeaveDays: 30,
  probationPeriod: 3,
  noticePeriod: 30,
  status: 'مسودة',
  notes: '',
  signedDate: '',
  terminationDate: '',
  terminationReason: '',
};

export default function ContractsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);
  const [filterStatus, setFilterStatus] = useState('الكل');
  const { user, loading: authLoading, login } = useAuth();
  const { employees, contracts, loading: dataLoading, refreshContracts } = useHRData();

  const filteredContracts = useMemo(() => {
    if (filterStatus === 'الكل') return contracts;
    return contracts.filter((c) => c.status === filterStatus);
  }, [contracts, filterStatus]);

  const stats = useMemo(() => {
    const active = contracts.filter((c) => c.status === 'نشط').length;
    const draft = contracts.filter((c) => c.status === 'مسودة').length;
    const expired = contracts.filter((c) => c.status === 'منتهي').length;
    const terminated = contracts.filter((c) => c.status === 'ملغي').length;
    return { active, draft, expired, terminated, total: contracts.length };
  }, [contracts]);

  function handleEmployeeChange(empId: string) {
    const emp = employees.find((e) => e.id === empId);
    setForm((prev) => ({
      ...prev,
      employeeId: empId,
      jobTitle: emp?.jobTitle || prev.jobTitle,
      department: emp?.department || prev.department,
    }));
  }

  function openAdd() {
    setEditId(null);
    const today = new Date().toISOString().split('T')[0];
    const firstEmp = employees[0];
    setForm({
      ...defaultForm,
      employeeId: firstEmp?.id || '',
      jobTitle: firstEmp?.jobTitle || '',
      department: firstEmp?.department || '',
      startDate: today,
    });
    setDialogOpen(true);
  }

  function openEdit(contract: ContractRecord) {
    setEditId(contract.id);
    setForm({
      employeeId: contract.employeeId,
      contractType: contract.contractType,
      jobTitle: contract.jobTitle,
      department: contract.department,
      startDate: contract.startDate,
      endDate: contract.endDate,
      basicSalary: contract.basicSalary,
      housingAllowance: contract.housingAllowance,
      transportAllowance: contract.transportAllowance,
      foodAllowance: contract.foodAllowance,
      otherAllowances: contract.otherAllowances,
      workingHours: contract.workingHours,
      annualLeaveDays: contract.annualLeaveDays,
      probationPeriod: contract.probationPeriod,
      noticePeriod: contract.noticePeriod,
      status: contract.status,
      notes: contract.notes,
      signedDate: contract.signedDate,
      terminationDate: contract.terminationDate,
      terminationReason: contract.terminationReason,
    });
    setDialogOpen(true);
  }

  async function handleSave() {
    if (!form.employeeId || !form.startDate) return;
    setSaving(true);
    try {
      const totalSalary = calculateContractTotal(
        form.basicSalary, form.housingAllowance, form.transportAllowance,
        form.foodAllowance, form.otherAllowances
      );
      const data = { ...form, totalSalary } as Omit<ContractRecord, 'id'>;
      if (editId) {
        await updateContract(editId, data);
      } else {
        await createContract(data);
      }
      setDialogOpen(false);
      await refreshContracts();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await deleteContract(id);
    await refreshContracts();
  }

  async function handleActivate(contract: ContractRecord) {
    const today = new Date().toISOString().split('T')[0];
    await updateContract(contract.id, { status: 'نشط', signedDate: today });
    await refreshContracts();
  }

  async function handleTerminate(contract: ContractRecord) {
    const today = new Date().toISOString().split('T')[0];
    await updateContract(contract.id, { status: 'ملغي', terminationDate: today });
    await refreshContracts();
  }

  function handleExport() {
    exportToCSV(
      filteredContracts.map((c) => ({
        employee: getEmployeeNameFromList(employees, c.employeeId),
        contractType: c.contractType,
        startDate: c.startDate,
        endDate: c.endDate,
        basicSalary: c.basicSalary,
        totalSalary: c.totalSalary,
        status: c.status,
      })),
      [
        { key: 'employee', label: 'الموظف' },
        { key: 'contractType', label: 'نوع العقد' },
        { key: 'startDate', label: 'تاريخ البداية' },
        { key: 'endDate', label: 'تاريخ النهاية' },
        { key: 'basicSalary', label: 'الراتب الأساسي' },
        { key: 'totalSalary', label: 'إجمالي الراتب' },
        { key: 'status', label: 'الحالة' },
      ],
      'تقرير_العقود'
    );
  }

  const totalSalaryPreview = calculateContractTotal(
    form.basicSalary, form.housingAllowance, form.transportAllowance,
    form.foodAllowance, form.otherAllowances
  );
  const hourlyRatePreview = calculateHourlyRate(totalSalaryPreview);

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <FileSignature className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى إدارة العقود</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <FileSignature className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">إدارة العقود</h1>
              <p className="text-xs text-[#64748B]">إنشاء وإدارة عقود العمل وفقاً لقانون العمل العماني</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-blue-600">{stats.total}</p><p className="text-xs text-gray-500">إجمالي العقود</p></CardContent></Card>
                <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-emerald-600">{stats.active}</p><p className="text-xs text-gray-500">عقود نشطة</p></CardContent></Card>
                <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-yellow-600">{stats.draft}</p><p className="text-xs text-gray-500">مسودات</p></CardContent></Card>
                <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-gray-600">{stats.expired}</p><p className="text-xs text-gray-500">منتهية</p></CardContent></Card>
                <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-red-600">{stats.terminated}</p><p className="text-xs text-gray-500">ملغاة</p></CardContent></Card>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between flex-wrap gap-3">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="الكل">الكل</SelectItem>
                    {CONTRACT_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Button onClick={handleExport} variant="outline" className="gap-2">
                    <Download className="w-4 h-4" /> تصدير
                  </Button>
                  <Button onClick={openAdd} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                    <Plus className="w-4 h-4 ml-2" /> إنشاء عقد جديد
                  </Button>
                </div>
              </div>

              {/* Table */}
              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">الموظف</TableHead>
                          <TableHead className="text-right">المسمى الوظيفي</TableHead>
                          <TableHead className="text-right">القسم</TableHead>
                          <TableHead className="text-right">نوع العقد</TableHead>
                          <TableHead className="text-right">تاريخ البداية</TableHead>
                          <TableHead className="text-right">تاريخ النهاية</TableHead>
                          <TableHead className="text-right">الراتب الأساسي</TableHead>
                          <TableHead className="text-right">إجمالي الراتب</TableHead>
                          <TableHead className="text-right">أجر الساعة</TableHead>
                          <TableHead className="text-right">الحالة</TableHead>
                          <TableHead className="text-right">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredContracts.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={11} className="text-center py-8 text-gray-400">لا توجد عقود</TableCell>
                          </TableRow>
                        ) : (
                          filteredContracts.map((contract) => {
                            const total = calculateContractTotal(
                              contract.basicSalary, contract.housingAllowance,
                              contract.transportAllowance, contract.foodAllowance, contract.otherAllowances
                            );
                            const hourly = calculateHourlyRate(total);
                            return (
                              <TableRow key={contract.id} className="hover:bg-gray-50">
                                <TableCell className="font-medium text-sm">{getEmployeeNameFromList(employees, contract.employeeId)}</TableCell>
                                <TableCell className="text-sm">{contract.jobTitle || '-'}</TableCell>
                                <TableCell className="text-sm">{contract.department || '-'}</TableCell>
                                <TableCell className="text-sm">{contract.contractType}</TableCell>
                                <TableCell className="text-sm">{contract.startDate}</TableCell>
                                <TableCell className="text-sm">{contract.endDate || '-'}</TableCell>
                                <TableCell className="text-sm">{formatCurrency(contract.basicSalary)}</TableCell>
                                <TableCell className="text-sm font-semibold">{formatCurrency(total)}</TableCell>
                                <TableCell className="text-sm">{formatCurrency(hourly)}</TableCell>
                                <TableCell>
                                  <Badge className={`${getContractStatusColor(contract.status)} border-0 text-xs`}>
                                    {contract.status}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex gap-1">
                                    {contract.status === 'مسودة' && (
                                      <Button variant="ghost" size="icon" title="تفعيل العقد" onClick={() => handleActivate(contract)}>
                                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                                      </Button>
                                    )}
                                    {contract.status === 'نشط' && (
                                      <Button variant="ghost" size="icon" title="إنهاء العقد" onClick={() => handleTerminate(contract)}>
                                        <XCircle className="w-4 h-4 text-red-500" />
                                      </Button>
                                    )}
                                    <Button variant="ghost" size="icon" title="طباعة عقد العمل PDF" onClick={() => {
                                      const emp = employees.find(e => e.id === contract.employeeId);
                                      if (emp) generateContractPDF({ contract, employee: emp });
                                    }}>
                                      <Printer className="w-4 h-4 text-purple-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" title="تعهد عدم المنافسة والإفصاح PDF" onClick={() => {
                                      const emp = employees.find(e => e.id === contract.employeeId);
                                      if (emp) generateNDAPDF({ contract, employee: emp });
                                    }}>
                                      <ShieldAlert className="w-4 h-4 text-orange-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => openEdit(contract)}>
                                      <Pencil className="w-4 h-4 text-blue-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => handleDelete(contract.id)}>
                                      <Trash2 className="w-4 h-4 text-red-500" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Contract Lifecycle Info */}
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm">دورة حياة العقد</CardTitle></CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-xs flex-wrap">
                    <div className="flex items-center gap-1 p-2 bg-yellow-50 rounded"><Clock className="w-3 h-3 text-yellow-600" /> مسودة</div>
                    <span className="text-gray-400">→</span>
                    <div className="flex items-center gap-1 p-2 bg-emerald-50 rounded"><CheckCircle className="w-3 h-3 text-emerald-600" /> نشط (بعد التوقيع)</div>
                    <span className="text-gray-400">→</span>
                    <div className="flex items-center gap-1 p-2 bg-gray-100 rounded"><Clock className="w-3 h-3 text-gray-600" /> منتهي</div>
                    <span className="text-gray-400">أو</span>
                    <div className="flex items-center gap-1 p-2 bg-red-50 rounded"><XCircle className="w-3 h-3 text-red-600" /> ملغي</div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </main>
      </div>

      {/* Contract Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editId ? 'تعديل العقد' : 'إنشاء عقد جديد'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            {/* Employee & Type */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">الموظف *</Label>
                <Select value={form.employeeId} onValueChange={handleEmployeeChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">نوع العقد *</Label>
                <Select value={form.contractType} onValueChange={(v) => setForm({ ...form, contractType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CONTRACT_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Job Title & Department */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">المسمى الوظيفي *</Label>
                <Select value={form.jobTitle} onValueChange={(v) => setForm({ ...form, jobTitle: v })}>
                  <SelectTrigger><SelectValue placeholder="اختر المسمى الوظيفي" /></SelectTrigger>
                  <SelectContent>
                    {JOB_TITLES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">القسم *</Label>
                <Select value={form.department} onValueChange={(v) => setForm({ ...form, department: v })}>
                  <SelectTrigger><SelectValue placeholder="اختر القسم" /></SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">تاريخ البداية *</Label>
                <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">تاريخ النهاية</Label>
                <Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
              </div>
            </div>

            {/* Salary Components */}
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm font-semibold text-blue-700 mb-3">مكونات الراتب (ر.ع)</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <Label className="text-xs">الراتب الأساسي *</Label>
                  <Input type="number" value={form.basicSalary} onChange={(e) => setForm({ ...form, basicSalary: Number(e.target.value) })} />
                </div>
                <div>
                  <Label className="text-xs">بدل السكن</Label>
                  <Input type="number" value={form.housingAllowance} onChange={(e) => setForm({ ...form, housingAllowance: Number(e.target.value) })} />
                </div>
                <div>
                  <Label className="text-xs">بدل النقل</Label>
                  <Input type="number" value={form.transportAllowance} onChange={(e) => setForm({ ...form, transportAllowance: Number(e.target.value) })} />
                </div>
                <div>
                  <Label className="text-xs">بدل الطعام</Label>
                  <Input type="number" value={form.foodAllowance} onChange={(e) => setForm({ ...form, foodAllowance: Number(e.target.value) })} />
                </div>
                <div>
                  <Label className="text-xs">بدلات أخرى</Label>
                  <Input type="number" value={form.otherAllowances} onChange={(e) => setForm({ ...form, otherAllowances: Number(e.target.value) })} />
                </div>
              </div>
              <div className="mt-3 p-2 bg-white rounded flex items-center justify-between">
                <span className="text-sm font-medium">إجمالي الراتب:</span>
                <span className="text-lg font-bold text-blue-700">{formatCurrency(totalSalaryPreview)}</span>
              </div>
              <div className="mt-1 p-2 bg-white rounded flex items-center justify-between">
                <span className="text-sm font-medium">أجر الساعة:</span>
                <span className="text-sm font-semibold text-blue-600">{formatCurrency(hourlyRatePreview)}</span>
              </div>
            </div>

            {/* Work Conditions */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <Label className="text-xs">ساعات العمل اليومية</Label>
                <Input type="number" value={form.workingHours} onChange={(e) => setForm({ ...form, workingHours: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-xs">أيام الإجازة السنوية</Label>
                <Input type="number" value={form.annualLeaveDays} onChange={(e) => setForm({ ...form, annualLeaveDays: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-xs">فترة التجربة (أشهر)</Label>
                <Input type="number" value={form.probationPeriod} onChange={(e) => setForm({ ...form, probationPeriod: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-xs">فترة الإشعار (أيام)</Label>
                <Input type="number" value={form.noticePeriod} onChange={(e) => setForm({ ...form, noticePeriod: Number(e.target.value) })} />
              </div>
            </div>

            {/* Status */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">حالة العقد</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CONTRACT_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">تاريخ التوقيع</Label>
                <Input type="date" value={form.signedDate} onChange={(e) => setForm({ ...form, signedDate: e.target.value })} />
              </div>
            </div>

            {/* Notes */}
            <div>
              <Label className="text-xs">ملاحظات</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}