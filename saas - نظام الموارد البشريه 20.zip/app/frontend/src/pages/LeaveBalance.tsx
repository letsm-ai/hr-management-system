import { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { CalendarRange, Menu, Download, FileText } from 'lucide-react';
import { Sidebar } from './Index';
import {
  calculateLeaveBalance, getEmployeeNameFromList,
  type ContractRecord,
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

export default function LeaveBalancePage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [year, setYear] = useState(2026);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, contracts, loading: dataLoading } = useHRData();

  const activeEmployees = employees.filter((e) => e.status === 'نشط');

  const getActiveContract = (employeeId: string): ContractRecord | undefined => {
    return contracts.find(
      (c) => c.employeeId === employeeId && c.status === 'نشط'
    );
  };

  const balances = useMemo(() => {
    return activeEmployees.map((emp) => {
      const baseBalance = calculateLeaveBalance(emp.id, year, employees, attendance);
      const activeContract = getActiveContract(emp.id);

      let annualEntitled = baseBalance.annualEntitled;
      let leaveSource: 'contract' | 'default' = 'default';

      if (activeContract && activeContract.annualLeaveDays > 0) {
        annualEntitled = activeContract.annualLeaveDays;
        leaveSource = 'contract';
      }

      return {
        ...baseBalance,
        annualEntitled,
        leaveSource,
        name: emp.fullName,
      };
    });
  }, [activeEmployees, employees, attendance, contracts, year]);

  function handleExport() {
    exportToCSV(
      balances.map((b) => ({
        name: b.name,
        employeeId: b.employeeId,
        leaveSource: b.leaveSource === 'contract' ? 'من العقد' : 'افتراضي',
        annualEntitled: b.annualEntitled,
        annualUsed: b.annualUsed,
        annualRemaining: b.annualEntitled - b.annualUsed,
        sickEntitled: b.sickEntitled,
        sickUsed: b.sickUsed,
        sickRemaining: b.sickEntitled - b.sickUsed,
        emergencyUsed: b.emergencyUsed,
        unpaidUsed: b.unpaidUsed,
        totalUsed: b.annualUsed + b.sickUsed + b.emergencyUsed + b.unpaidUsed,
      })),
      [
        { key: 'name', label: 'الاسم' },
        { key: 'employeeId', label: 'الرقم' },
        { key: 'leaveSource', label: 'مصدر الرصيد' },
        { key: 'annualEntitled', label: 'سنوية مستحقة' },
        { key: 'annualUsed', label: 'سنوية مستخدمة' },
        { key: 'annualRemaining', label: 'سنوية متبقية' },
        { key: 'sickEntitled', label: 'مرضية مستحقة' },
        { key: 'sickUsed', label: 'مرضية مستخدمة' },
        { key: 'sickRemaining', label: 'مرضية متبقية' },
        { key: 'emergencyUsed', label: 'طارئة' },
        { key: 'unpaidUsed', label: 'بدون راتب' },
        { key: 'totalUsed', label: 'إجمالي مستخدم' },
      ],
      `تقرير_الإجازات_${year}`
    );
  }

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <CalendarRange className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى رصيد الإجازات</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  function balanceColor(remaining: number, total: number): string {
    const pct = total > 0 ? (remaining / total) * 100 : 0;
    if (pct > 50) return 'text-emerald-600 bg-emerald-50';
    if (pct > 25) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <CalendarRange className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">رصيد الإجازات</h1>
              <p className="text-xs text-[#64748B]">متابعة أرصدة الإجازات لجميع الموظفين</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
                  <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                    <SelectItem value="2026">2026</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleExport} variant="outline" className="gap-2 mr-auto">
                  <Download className="w-4 h-4" />
                  تصدير CSV
                </Button>
              </div>

              <Card className="border-blue-200 bg-blue-50/50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <CalendarRange className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs text-blue-800">
                        <strong>قانون العمل العماني:</strong> إجازة سنوية 30 يوم بعد 6 أشهر خدمة | إجازة مرضية 15 يوم
                      </p>
                      <p className="text-xs text-blue-700 mt-1 flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        <strong>ملاحظة:</strong> إذا كان للموظف عقد نشط يحدد أيام الإجازة السنوية، يُستخدم كمصدر أساسي للرصيد.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {balances.map((b) => {
                  const annualRemaining = b.annualEntitled - b.annualUsed;
                  const sickRemaining = b.sickEntitled - b.sickUsed;
                  const totalUsed = b.annualUsed + b.sickUsed + b.emergencyUsed + b.unpaidUsed;

                  return (
                    <Card key={b.employeeId} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <p className="font-semibold text-sm">{b.name}</p>
                            <p className="text-xs text-gray-500">{b.employeeId}</p>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {totalUsed} يوم مستخدم
                          </Badge>
                        </div>

                        <div className="mb-3">
                          <Badge
                            className={`text-[10px] px-2 py-0.5 border-0 ${
                              b.leaveSource === 'contract'
                                ? 'bg-indigo-100 text-indigo-700'
                                : 'bg-gray-100 text-gray-600'
                            }`}
                          >
                            {b.leaveSource === 'contract' ? 'الرصيد من العقد' : 'الرصيد الافتراضي'}
                          </Badge>
                        </div>

                        <div className="space-y-3">
                          <div>
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span>إجازة سنوية</span>
                              <span className={`font-semibold px-2 py-0.5 rounded ${balanceColor(annualRemaining, b.annualEntitled)}`}>
                                {annualRemaining}/{b.annualEntitled}
                              </span>
                            </div>
                            <Progress value={b.annualEntitled > 0 ? (annualRemaining / b.annualEntitled) * 100 : 0} className="h-2" />
                          </div>

                          <div>
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span>إجازة مرضية</span>
                              <span className={`font-semibold px-2 py-0.5 rounded ${balanceColor(sickRemaining, b.sickEntitled)}`}>
                                {sickRemaining}/{b.sickEntitled}
                              </span>
                            </div>
                            <Progress value={b.sickEntitled > 0 ? (sickRemaining / b.sickEntitled) * 100 : 0} className="h-2" />
                          </div>

                          <div className="flex gap-3 text-xs text-gray-600 pt-1 border-t">
                            <span>طارئة: {b.emergencyUsed}</span>
                            <span>بدون راتب: {b.unpaidUsed}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">الرقم</TableHead>
                          <TableHead className="text-right">الاسم</TableHead>
                          <TableHead className="text-right">مصدر الرصيد</TableHead>
                          <TableHead className="text-right">سنوية مستحقة</TableHead>
                          <TableHead className="text-right">سنوية مستخدمة</TableHead>
                          <TableHead className="text-right">سنوية متبقية</TableHead>
                          <TableHead className="text-right">مرضية مستحقة</TableHead>
                          <TableHead className="text-right">مرضية مستخدمة</TableHead>
                          <TableHead className="text-right">مرضية متبقية</TableHead>
                          <TableHead className="text-right">طارئة</TableHead>
                          <TableHead className="text-right">بدون راتب</TableHead>
                          <TableHead className="text-right">إجمالي مستخدم</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {balances.map((b) => (
                          <TableRow key={b.employeeId} className="hover:bg-gray-50">
                            <TableCell className="font-mono text-sm">{b.employeeId}</TableCell>
                            <TableCell className="font-medium text-sm">{b.name}</TableCell>
                            <TableCell>
                              <Badge className={`text-[10px] border-0 ${b.leaveSource === 'contract' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-600'}`}>
                                {b.leaveSource === 'contract' ? 'العقد' : 'افتراضي'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{b.annualEntitled}</TableCell>
                            <TableCell className="text-sm">{b.annualUsed}</TableCell>
                            <TableCell className="text-sm font-semibold">
                              <Badge className={`${balanceColor(b.annualEntitled - b.annualUsed, b.annualEntitled)} border-0`}>
                                {b.annualEntitled - b.annualUsed}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{b.sickEntitled}</TableCell>
                            <TableCell className="text-sm">{b.sickUsed}</TableCell>
                            <TableCell className="text-sm font-semibold">
                              <Badge className={`${balanceColor(b.sickEntitled - b.sickUsed, b.sickEntitled)} border-0`}>
                                {b.sickEntitled - b.sickUsed}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{b.emergencyUsed}</TableCell>
                            <TableCell className="text-sm">{b.unpaidUsed}</TableCell>
                            <TableCell className="text-sm font-semibold">
                              {b.annualUsed + b.sickUsed + b.emergencyUsed + b.unpaidUsed}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </>
          )}
        </main>
      </div>
    </div>
  );
}