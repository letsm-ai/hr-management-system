import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Pencil, Trash2, BarChart3, Menu, Download, ArrowLeft, Target, Lightbulb } from 'lucide-react';
import { Sidebar } from './Index';
import { Link } from 'react-router-dom';
import {
  PerformanceRecord,
  createPerformanceRecord, updatePerformanceRecord, deletePerformanceRecord as apiDeletePerf,
  getEmployeeNameFromList, getMonthlyAttendanceStats,
  calculatePerformanceScore, getPerformanceRating, getRatingColor,
  getCurrentMonth,
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

export default function PerformancePage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [month, setMonth] = useState(getCurrentMonth());
  const [saving, setSaving] = useState(false);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, ideas: allIdeas, performance: allPerf, loading: dataLoading, refreshPerformance } = useHRData();

  const perfRecords = allPerf.filter((r) => r.month === month);

  const [perfDialogOpen, setPerfDialogOpen] = useState(false);
  const [perfEditId, setPerfEditId] = useState<string | null>(null);
  const [perfForm, setPerfForm] = useState({
    employeeId: '', workQuality: 7, punctuality: 7, customerSatisfaction: 7,
    teamwork: 7, initiative: 7, selfDevelopment: 7,
  });

  function handleExportPerf() {
    exportToCSV(
      perfRecords.map((rec) => {
        const empIdeas = allIdeas.filter((i) => i.employeeId === rec.employeeId && i.month === month);
        const score = calculatePerformanceScore(rec, empIdeas);
        return {
          employee: getEmployeeNameFromList(employees, rec.employeeId),
          workQuality: rec.workQuality, punctuality: rec.punctuality,
          customerSatisfaction: rec.customerSatisfaction, teamwork: rec.teamwork,
          initiative: rec.initiative, selfDevelopment: rec.selfDevelopment,
          score: score.toFixed(1), rating: getPerformanceRating(score),
        };
      }),
      [
        { key: 'employee', label: 'الموظف' }, { key: 'workQuality', label: 'جودة العمل' },
        { key: 'punctuality', label: 'الالتزام' }, { key: 'customerSatisfaction', label: 'رضا العملاء' },
        { key: 'teamwork', label: 'التعاون' }, { key: 'initiative', label: 'المبادرة' },
        { key: 'selfDevelopment', label: 'التطوير' }, { key: 'score', label: 'الدرجة' },
        { key: 'rating', label: 'التقييم' },
      ],
      `تقرير_الأداء_${month}`
    );
  }

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <BarChart3 className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى تقييم الأداء</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const months: string[] = [];
  for (let m = 1; m <= 12; m++) months.push(`2026-${String(m).padStart(2, '0')}`);

  function openAddPerf() {
    setPerfEditId(null);
    setPerfForm({ employeeId: employees[0]?.id || '', workQuality: 7, punctuality: 7, customerSatisfaction: 7, teamwork: 7, initiative: 7, selfDevelopment: 7 });
    setPerfDialogOpen(true);
  }

  function openEditPerf(rec: PerformanceRecord) {
    setPerfEditId(rec.id);
    setPerfForm({ employeeId: rec.employeeId, workQuality: rec.workQuality, punctuality: rec.punctuality, customerSatisfaction: rec.customerSatisfaction, teamwork: rec.teamwork, initiative: rec.initiative, selfDevelopment: rec.selfDevelopment });
    setPerfDialogOpen(true);
  }

  async function savePerf() {
    if (!perfForm.employeeId) return;
    setSaving(true);
    try {
      const data = { month, ...perfForm };
      if (perfEditId) await updatePerformanceRecord(perfEditId, data);
      else await createPerformanceRecord(data);
      setPerfDialogOpen(false);
      await refreshPerformance();
    } finally {
      setSaving(false);
    }
  }

  function ScoreInput({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
    return (
      <div>
        <div className="flex items-center justify-between mb-1">
          <Label className="text-xs">{label}</Label>
          <span className="text-xs font-bold text-blue-600">{value}/10</span>
        </div>
        <input
          type="range" min={1} max={10} value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">التقييم الشامل للأداء</h1>
              <p className="text-xs text-[#64748B]">تقييم الأداء الشهري بالمعايير التقليدية</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              {/* Integration Notice */}
              <Card className="border-blue-200 bg-blue-50/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5 text-blue-600 shrink-0" />
                      <p className="text-sm text-blue-800">
                        <strong>ملاحظة:</strong> هذه الصفحة مدمجة مع نظام مؤشرات الأداء (KPI).
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Ideas redirect notice */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <Lightbulb className="w-5 h-5 text-amber-600 shrink-0" />
                      <p className="text-sm text-amber-800">
                        <strong>الأفكار الإبداعية:</strong> تم نقل إدارة الأفكار إلى صفحة إدارة الطلبات لتوحيد الإدارة.
                      </p>
                    </div>
                    <Link to="/requests">
                      <Button variant="outline" size="sm" className="gap-2 border-amber-300 text-amber-700 hover:bg-amber-100">
                        <ArrowLeft className="w-4 h-4" />
                        إدارة الطلبات والأفكار
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <div className="flex items-center gap-3">
                <Select value={month} onValueChange={setMonth}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {months.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-2">
                <Button onClick={handleExportPerf} variant="outline" className="gap-2">
                  <Download className="w-4 h-4" /> تصدير CSV
                </Button>
                <Button onClick={openAddPerf} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                  <Plus className="w-4 h-4 ml-2" /> إضافة تقييم
                </Button>
              </div>
              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">الموظف</TableHead>
                          <TableHead className="text-right">جودة العمل</TableHead>
                          <TableHead className="text-right">الالتزام</TableHead>
                          <TableHead className="text-right">رضا العملاء</TableHead>
                          <TableHead className="text-right">التعاون</TableHead>
                          <TableHead className="text-right">المبادرة</TableHead>
                          <TableHead className="text-right">التطوير</TableHead>
                          <TableHead className="text-right">الدرجة</TableHead>
                          <TableHead className="text-right">التقييم</TableHead>
                          <TableHead className="text-right">الحضور %</TableHead>
                          <TableHead className="text-right">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {perfRecords.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={11} className="text-center py-8 text-gray-400">لا توجد تقييمات</TableCell>
                          </TableRow>
                        ) : (
                          perfRecords.map((rec) => {
                            const empIdeas = allIdeas.filter((i) => i.employeeId === rec.employeeId && i.month === month);
                            const score = calculatePerformanceScore(rec, empIdeas);
                            const rating = getPerformanceRating(score);
                            const ratingColor = getRatingColor(score);
                            const attStats = getMonthlyAttendanceStats(rec.employeeId, month, attendance);
                            return (
                              <TableRow key={rec.id} className="hover:bg-gray-50">
                                <TableCell className="font-medium text-sm">{getEmployeeNameFromList(employees, rec.employeeId)}</TableCell>
                                <TableCell className="text-sm text-center">{rec.workQuality}</TableCell>
                                <TableCell className="text-sm text-center">{rec.punctuality}</TableCell>
                                <TableCell className="text-sm text-center">{rec.customerSatisfaction}</TableCell>
                                <TableCell className="text-sm text-center">{rec.teamwork}</TableCell>
                                <TableCell className="text-sm text-center">{rec.initiative}</TableCell>
                                <TableCell className="text-sm text-center">{rec.selfDevelopment}</TableCell>
                                <TableCell className="text-sm font-bold">{score.toFixed(1)}</TableCell>
                                <TableCell>
                                  <Badge className={`${ratingColor} border-0 text-xs`}>{rating}</Badge>
                                </TableCell>
                                <TableCell className="text-sm">{Math.round(attStats.attendanceRate)}%</TableCell>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Button variant="ghost" size="icon" onClick={() => openEditPerf(rec)}>
                                      <Pencil className="w-4 h-4 text-blue-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={async () => { await apiDeletePerf(rec.id); await refreshPerformance(); }}>
                                      <Trash2 className="w-4 h-4 text-red-500" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm">دليل التقييم المرجح</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    <div className="p-2 bg-gray-50 rounded">جودة العمل: 25%</div>
                    <div className="p-2 bg-gray-50 rounded">الالتزام بالمواعيد: 15%</div>
                    <div className="p-2 bg-gray-50 rounded">الأفكار المقدمة: 10%</div>
                    <div className="p-2 bg-gray-50 rounded">معدل قبول الأفكار: 10%</div>
                    <div className="p-2 bg-gray-50 rounded">رضا العملاء: 15%</div>
                    <div className="p-2 bg-gray-50 rounded">التعاون: 10%</div>
                    <div className="p-2 bg-gray-50 rounded">المبادرة: 10%</div>
                    <div className="p-2 bg-gray-50 rounded">التطوير الذاتي: 5%</div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </main>
      </div>

      {/* Performance Dialog */}
      <Dialog open={perfDialogOpen} onOpenChange={setPerfDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{perfEditId ? 'تعديل التقييم' : 'إضافة تقييم جديد'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div>
              <Label className="text-xs">الموظف *</Label>
              <Select value={perfForm.employeeId} onValueChange={(v) => setPerfForm({ ...perfForm, employeeId: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <ScoreInput label="جودة العمل (25%)" value={perfForm.workQuality} onChange={(v) => setPerfForm({ ...perfForm, workQuality: v })} />
            <ScoreInput label="الالتزام بالمواعيد (15%)" value={perfForm.punctuality} onChange={(v) => setPerfForm({ ...perfForm, punctuality: v })} />
            <ScoreInput label="رضا العملاء (15%)" value={perfForm.customerSatisfaction} onChange={(v) => setPerfForm({ ...perfForm, customerSatisfaction: v })} />
            <ScoreInput label="التعاون مع الفريق (10%)" value={perfForm.teamwork} onChange={(v) => setPerfForm({ ...perfForm, teamwork: v })} />
            <ScoreInput label="المبادرة والابتكار (10%)" value={perfForm.initiative} onChange={(v) => setPerfForm({ ...perfForm, initiative: v })} />
            <ScoreInput label="التطوير الذاتي (5%)" value={perfForm.selfDevelopment} onChange={(v) => setPerfForm({ ...perfForm, selfDevelopment: v })} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPerfDialogOpen(false)}>إلغاء</Button>
            <Button onClick={savePerf} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}