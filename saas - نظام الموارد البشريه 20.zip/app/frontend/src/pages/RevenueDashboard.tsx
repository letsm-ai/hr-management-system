import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  TrendingUp, TrendingDown, DollarSign, Users, BarChart3, Menu,
  ArrowUpRight, ArrowDownRight,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import {
  ClientContract, fetchAllClientContracts, formatOMR, baisaToOmr,
  getContractStats, getMonthlyRevenueTrend, getRevenueByServiceType,
  getContractTrend, getTopClients, getRetentionRate, getRevenueGrowth,
  CONTRACT_STATUS_LABELS,
} from '@/lib/incentive-api';
import { Sidebar } from './Index';

const CHART_COLORS = [
  '#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444',
  '#06B6D4', '#EC4899', '#84CC16', '#F97316',
];

export default function RevenueDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { loading: authLoading } = useAuth();
  const { employees, loading: dataLoading } = useHRData();

  const [contracts, setContracts] = useState<ClientContract[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    const data = await fetchAllClientContracts();
    setContracts(data);
    setLoading(false);
  }

  const stats = getContractStats(contracts);
  const monthlyTrend = getMonthlyRevenueTrend(contracts, 12);
  const serviceDistribution = getRevenueByServiceType(contracts);
  const contractTrend = getContractTrend(contracts, 12);
  const topClients = getTopClients(contracts, 10);
  const retentionRate = getRetentionRate(contracts);
  const revenueGrowth = getRevenueGrowth(contracts);

  // Unique active clients
  const activeClients = new Set(contracts.filter((c) => c.status === 'active').map((c) => c.clientName)).size;
  const avgContractValue = stats.activeCount > 0 ? Math.round(stats.annualRevenue / stats.activeCount) : 0;

  // Max revenue for chart scaling
  const maxRevenue = Math.max(...monthlyTrend.map((t) => t.revenue), 1);
  const totalServiceRevenue = serviceDistribution.reduce((sum, s) => sum + s.totalRevenue, 0);

  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  function getShortMonth(m: string) {
    const parts = m.split('-');
    return monthNames[parts[1]] || parts[1];
  }

  if (authLoading || dataLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E3A5F] mx-auto mb-4" />
          <p className="text-[#64748B]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">لوحة بيانات الإيرادات</h1>
              <p className="text-xs text-[#64748B]">تحليل الأداء المالي والإيرادات</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-6">
          {/* Section 1: Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <Card className="border-emerald-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                  </div>
                </div>
                <p className="text-lg font-bold text-emerald-600">{formatOMR(stats.monthlyRevenue)}</p>
                <p className="text-xs text-gray-500">الإيراد الشهري</p>
              </CardContent>
            </Card>
            <Card className="border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                    <BarChart3 className="w-4 h-4 text-blue-600" />
                  </div>
                </div>
                <p className="text-lg font-bold text-blue-600">{formatOMR(stats.annualRevenue)}</p>
                <p className="text-xs text-gray-500">الإيراد السنوي المتوقع</p>
              </CardContent>
            </Card>
            <Card className={retentionRate >= 70 ? 'border-green-200' : 'border-amber-200'}>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg ${retentionRate >= 70 ? 'bg-green-100' : 'bg-amber-100'} flex items-center justify-center`}>
                    <Users className={`w-4 h-4 ${retentionRate >= 70 ? 'text-green-600' : 'text-amber-600'}`} />
                  </div>
                </div>
                <p className={`text-lg font-bold ${retentionRate >= 70 ? 'text-green-600' : 'text-amber-600'}`}>{retentionRate}%</p>
                <p className="text-xs text-gray-500">معدل الاحتفاظ</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-lg font-bold text-gray-700">{activeClients}</p>
                <p className="text-xs text-gray-500 mt-1">عملاء نشطون</p>
              </CardContent>
            </Card>
            <Card className="border-purple-200">
              <CardContent className="p-4">
                <p className="text-lg font-bold text-purple-600">{formatOMR(avgContractValue)}</p>
                <p className="text-xs text-gray-500 mt-1">متوسط قيمة العقد</p>
              </CardContent>
            </Card>
            <Card className={revenueGrowth >= 0 ? 'border-green-200' : 'border-red-200'}>
              <CardContent className="p-4">
                <div className="flex items-center gap-1">
                  {revenueGrowth >= 0 ? (
                    <ArrowUpRight className="w-4 h-4 text-green-600" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-600" />
                  )}
                  <p className={`text-lg font-bold ${revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {revenueGrowth > 0 ? '+' : ''}{revenueGrowth}%
                  </p>
                </div>
                <p className="text-xs text-gray-500 mt-1">نمو الإيراد</p>
              </CardContent>
            </Card>
          </div>

          {/* Section 2: Monthly Revenue Trend (CSS bar chart) */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                الإيراد الشهري (آخر 12 شهراً)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2 h-48">
                {monthlyTrend.map((t, idx) => {
                  const height = maxRevenue > 0 ? (t.revenue / maxRevenue) * 100 : 0;
                  return (
                    <div key={t.month} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-[10px] text-gray-500">{formatOMR(t.revenue)}</span>
                      <div
                        className="w-full bg-blue-500 rounded-t-sm transition-all hover:bg-blue-600"
                        style={{ height: `${Math.max(height, 2)}%` }}
                        title={`${getShortMonth(t.month)}: ${formatOMR(t.revenue)}`}
                      />
                      <span className="text-[10px] text-gray-400">{getShortMonth(t.month)}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Section 3: Revenue by Service Type */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">توزيع الإيراد حسب نوع الخدمة</CardTitle>
              </CardHeader>
              <CardContent>
                {serviceDistribution.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4">لا توجد بيانات</p>
                ) : (
                  <div className="space-y-3">
                    {serviceDistribution.map((s, idx) => {
                      const pct = totalServiceRevenue > 0 ? Math.round((s.totalRevenue / totalServiceRevenue) * 100) : 0;
                      return (
                        <div key={s.serviceType}>
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }} />
                              <span className="text-sm">{s.serviceType}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="text-xs">{s.contractCount} عقد</Badge>
                              <span className="text-sm font-medium">{formatOMR(s.totalRevenue)}</span>
                              <span className="text-xs text-gray-400">({pct}%)</span>
                            </div>
                          </div>
                          <div className="w-full bg-gray-100 rounded-full h-2">
                            <div
                              className="h-2 rounded-full transition-all"
                              style={{ width: `${pct}%`, backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Section 4: Contract Trend */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">العقود الجديدة مقابل التجديدات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4 text-xs">
                  <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-emerald-500" /> جديدة</div>
                  <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-blue-500" /> تجديدات</div>
                  <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-purple-500" /> زيادات</div>
                </div>
                <div className="space-y-2">
                  {contractTrend.map((t) => {
                    const total = t.newContracts + t.renewals + t.upsells;
                    return (
                      <div key={t.month} className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 w-14 shrink-0">{getShortMonth(t.month)}</span>
                        <div className="flex-1 flex gap-0.5 h-5">
                          {t.newContracts > 0 && (
                            <div className="bg-emerald-500 rounded-sm flex items-center justify-center text-white text-[10px]"
                              style={{ width: `${total > 0 ? (t.newContracts / Math.max(total, 1)) * 100 : 0}%`, minWidth: t.newContracts > 0 ? '20px' : '0' }}>
                              {t.newContracts}
                            </div>
                          )}
                          {t.renewals > 0 && (
                            <div className="bg-blue-500 rounded-sm flex items-center justify-center text-white text-[10px]"
                              style={{ width: `${total > 0 ? (t.renewals / Math.max(total, 1)) * 100 : 0}%`, minWidth: t.renewals > 0 ? '20px' : '0' }}>
                              {t.renewals}
                            </div>
                          )}
                          {t.upsells > 0 && (
                            <div className="bg-purple-500 rounded-sm flex items-center justify-center text-white text-[10px]"
                              style={{ width: `${total > 0 ? (t.upsells / Math.max(total, 1)) * 100 : 0}%`, minWidth: t.upsells > 0 ? '20px' : '0' }}>
                              {t.upsells}
                            </div>
                          )}
                          {total === 0 && <div className="bg-gray-100 rounded-sm flex-1" />}
                        </div>
                        <span className="text-xs text-gray-400 w-6 text-left">{total}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Section 5: Top Clients */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-500" />
                أفضل 10 عملاء
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-right p-3 font-medium">#</th>
                      <th className="text-right p-3 font-medium">العميل</th>
                      <th className="text-right p-3 font-medium">عدد العقود</th>
                      <th className="text-right p-3 font-medium">القيمة السنوية</th>
                      <th className="text-right p-3 font-medium">الحالة</th>
                      <th className="text-right p-3 font-medium">منذ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topClients.length === 0 ? (
                      <tr><td colSpan={6} className="text-center py-8 text-gray-400">لا توجد بيانات</td></tr>
                    ) : (
                      topClients.map((c, idx) => (
                        <tr key={c.clientName} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                              idx === 0 ? 'bg-yellow-500' : idx === 1 ? 'bg-gray-400' : idx === 2 ? 'bg-amber-700' : 'bg-gray-300'
                            }`}>
                              {idx + 1}
                            </div>
                          </td>
                          <td className="p-3 font-medium">{c.clientName}</td>
                          <td className="p-3">{c.contractCount}</td>
                          <td className="p-3 font-medium text-emerald-600">{formatOMR(c.totalAnnualRevenue)}</td>
                          <td className="p-3">
                            <Badge className={
                              c.latestStatus === 'active' ? 'bg-emerald-100 text-emerald-700' :
                              c.latestStatus === 'pending_renewal' ? 'bg-amber-100 text-amber-700' :
                              'bg-gray-100 text-gray-600'
                            }>
                              {CONTRACT_STATUS_LABELS[c.latestStatus] || c.latestStatus}
                            </Badge>
                          </td>
                          <td className="p-3 text-xs text-gray-500">{c.firstContractDate}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}