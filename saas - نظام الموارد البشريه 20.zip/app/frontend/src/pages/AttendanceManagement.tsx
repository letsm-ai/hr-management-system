import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CalendarDays, Clock, CalendarRange, Users, AlertTriangle, Timer, Menu, Receipt } from 'lucide-react';
import { Sidebar } from './Index';
import { useHRData } from '@/lib/hr-data-context';
import { getCurrentMonth } from '@/lib/hr-api';
import { useAuth } from '@/lib/auth-context';
import Attendance from './Attendance';
import Overtime from './Overtime';
import LeaveBalance from './LeaveBalance';
import SalaryReport from './SalaryReport';

export default function AttendanceManagement() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('attendance');
  const { user, loading: authLoading, login } = useAuth();
  const { attendance, overtime, loading: dataLoading } = useHRData();
  const currentMonth = getCurrentMonth();

  const monthAttendance = attendance.filter(a => a.date?.startsWith(currentMonth));
  const presentDays = monthAttendance.filter(a => a.status === 'حاضر' || a.dayStatus === 'حاضر').length;
  const absentDays = monthAttendance.filter(a => a.status === 'غائب' || a.dayStatus === 'غائب').length;
  const lateDays = monthAttendance.filter(a => (a.lateMinutes || 0) > 0).length;
  const totalOvertimeHours = overtime.reduce((sum, o) => sum + (o.hours || o.overtimeHours || 0), 0);

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card><CardContent className="p-8 text-center">
          <CalendarDays className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
          <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
        </CardContent></Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <CalendarDays className="w-6 h-6 text-emerald-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">إدارة الدوام</h1>
              <p className="text-xs text-[#64748B]">الحضور والعمل الإضافي والإجازات</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-100">
                  <Users className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-emerald-600 font-medium">أيام الحضور</p>
                  <p className="text-lg font-bold text-emerald-800">{presentDays}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-red-200 bg-red-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-100">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-xs text-red-600 font-medium">أيام الغياب</p>
                  <p className="text-lg font-bold text-red-800">{absentDays}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-100">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-xs text-amber-600 font-medium">أيام التأخير</p>
                  <p className="text-lg font-bold text-amber-800">{lateDays}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-indigo-200 bg-indigo-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-indigo-100">
                  <Timer className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <p className="text-xs text-indigo-600 font-medium">ساعات إضافية</p>
                  <p className="text-lg font-bold text-indigo-800">{totalOvertimeHours}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 h-11">
              <TabsTrigger value="attendance" className="gap-1.5 text-xs sm:text-sm">
                <CalendarDays className="w-4 h-4" />
                الحضور
              </TabsTrigger>
              <TabsTrigger value="salary-report" className="gap-1.5 text-xs sm:text-sm">
                <Receipt className="w-4 h-4" />
                تقرير الرواتب
              </TabsTrigger>
              <TabsTrigger value="overtime" className="gap-1.5 text-xs sm:text-sm">
                <Timer className="w-4 h-4" />
                العمل الإضافي
              </TabsTrigger>
              <TabsTrigger value="leave" className="gap-1.5 text-xs sm:text-sm">
                <CalendarRange className="w-4 h-4" />
                الإجازات
              </TabsTrigger>
            </TabsList>

            <TabsContent value="attendance" className="mt-4 embedded-page">
              <Attendance embedded />
            </TabsContent>
            <TabsContent value="salary-report" className="mt-4 embedded-page">
              <SalaryReport />
            </TabsContent>
            <TabsContent value="overtime" className="mt-4 embedded-page">
              <Overtime />
            </TabsContent>
            <TabsContent value="leave" className="mt-4 embedded-page">
              <LeaveBalance />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}