import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, ClipboardList, Menu, Settings, Users, TrendingUp, Target } from 'lucide-react';
import { Sidebar } from './Index';
import { useHRData } from '@/lib/hr-data-context';
import { useAuth } from '@/lib/auth-context';
import MonthlyEvaluation from './MonthlyEvaluation';
import RewardSettings from './RewardSettings';

export default function EvaluationSync() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('evaluation');
  const { user, loading: authLoading, login } = useAuth();
  const { employees, performance, loading: dataLoading } = useHRData();

  const activeEmployees = employees.filter(e => e.status === 'نشط').length;
  const avgScore = performance.length > 0
    ? Math.round(performance.reduce((sum, p) => {
        const total = (p.workQuality || 0) + (p.punctuality || 0) + (p.customerSatisfaction || 0) +
          (p.teamwork || 0) + (p.initiative || 0) + (p.selfDevelopment || 0);
        return sum + Math.round((total / 6) * 10);
      }, 0) / performance.length)
    : 0;

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card><CardContent className="p-8 text-center">
          <BarChart3 className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
          <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
        </CardContent></Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <BarChart3 className="w-6 h-6 text-purple-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">التقييم والمزامنة</h1>
              <p className="text-xs text-[#64748B]">مزامنة ClickUp، تقييم الجودة، حساب الأداء، وإعدادات الأوزان</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-100">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-xs text-purple-600 font-medium">موظفين نشطين</p>
                  <p className="text-lg font-bold text-purple-800">{activeEmployees}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-100">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-emerald-600 font-medium">متوسط الأداء</p>
                  <p className="text-lg font-bold text-emerald-800">{avgScore}%</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <Target className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-blue-600 font-medium">تقييمات مسجلة</p>
                  <p className="text-lg font-bold text-blue-800">{performance.length}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 h-11">
              <TabsTrigger value="evaluation" className="gap-1.5 text-xs sm:text-sm">
                <ClipboardList className="w-4 h-4" />
                التقييم والمزامنة
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-1.5 text-xs sm:text-sm">
                <Settings className="w-4 h-4" />
                إعدادات الأوزان
              </TabsTrigger>
            </TabsList>

            <TabsContent value="evaluation" className="mt-4 embedded-page">
              <MonthlyEvaluation />
            </TabsContent>
            <TabsContent value="settings" className="mt-4 embedded-page">
              <RewardSettings />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}