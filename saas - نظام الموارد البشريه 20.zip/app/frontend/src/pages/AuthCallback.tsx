import { useEffect } from 'react';

export default function AuthCallback() {
  useEffect(() => {
    handleCallback();
  }, []);

  function handleCallback() {
    // The backend redirects here with token in query params:
    // /auth/callback?token=xxx&expires_at=xxx&token_type=Bearer
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    const expiresAt = params.get('expires_at');

    if (token) {
      // Store the token
      localStorage.setItem('token', token);
      localStorage.setItem('isLougOutManual', 'false');
      if (expiresAt) {
        localStorage.setItem('token_expires_at', expiresAt);
      }
      // Redirect to home page (clean URL)
      window.location.href = '/';
      return;
    }

    // If no token in query params, check if this is an error
    const msg = params.get('msg');
    if (msg) {
      console.error('Auth callback error:', msg);
      // Store error for display and redirect to home
      sessionStorage.setItem('auth_error', msg);
      window.location.href = '/';
      return;
    }

    // No token and no error - might be an intermediate redirect
    // Check if there's already a token in localStorage (SDK might have handled it)
    const existingToken = localStorage.getItem('token');
    if (existingToken) {
      window.location.href = '/';
      return;
    }

    // Nothing worked - redirect to home and let the auth context handle it
    window.location.href = '/';
  }

  return (
    <div className="min-h-screen flex items-center justify-center" dir="rtl">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">جاري معالجة تسجيل الدخول...</p>
      </div>
    </div>
  );
}