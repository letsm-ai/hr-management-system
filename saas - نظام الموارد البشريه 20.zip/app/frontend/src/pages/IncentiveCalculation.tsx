import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  Calculator, ListChecks, Settings, Menu, Play, CheckCheck, ChevronDown, ChevronUp,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import {
  ClientContract, IncentiveRecord, IncentiveSetting, EmployeeIncentiveResult,
  IncentiveCalculationResult,
  fetchAllClientContracts, fetchIncentiveRecords, fetchIncentiveSettings,
  createIncentiveRecord, updateIncentiveRecord,
  calculateMonthlyIncentives, formatOMR, baisaToOmr,
  INCENTIVE_TYPE_LABELS, INCENTIVE_STATUS_LABELS, CONTRACT_TYPE_LABELS,
  parseSettingJSON, getSettingByKey, updateIncentiveSetting,
} from '@/lib/incentive-api';
import { fetchPerformanceKpis, PerformanceKpiRecord } from '@/lib/hr-api';
import { Sidebar } from './Index';

export default function IncentiveCalculation() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, loading: authLoading } = useAuth();
  const { employees, attendance, ideas, violations, overtime, loading: dataLoading } = useHRData();

  const [contracts, setContracts] = useState<ClientContract[]>([]);
  const [incentiveRecords, setIncentiveRecords] = useState<IncentiveRecord[]>([]);
  const [settings, setSettings] = useState<IncentiveSetting[]>([]);
  const [kpis, setKpis] = useState<PerformanceKpiRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('calculate');

  // Calculate tab
  const [calcMonth, setCalcMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [calcResult, setCalcResult] = useState<IncentiveCalculationResult | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [expandedEmployee, setExpandedEmployee] = useState<string | null>(null);

  // History tab
  const [historyMonth, setHistoryMonth] = useState('all');
  const [historyStatus, setHistoryStatus] = useState('all');

  // Settings tab
  const [editSettings, setEditSettings] = useState<Record<string, string>>({});
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    const [c, ir, s, k] = await Promise.all([
      fetchAllClientContracts(),
      fetchIncentiveRecords(),
      fetchIncentiveSettings(),
      fetchPerformanceKpis(),
    ]);
    setContracts(c);
    setIncentiveRecords(ir);
    setSettings(s);
    setKpis(k);

    // Initialize edit settings
    const es: Record<string, string> = {};
    for (const setting of s) {
      es[setting.settingKey] = setting.settingValue;
    }
    setEditSettings(es);
    setLoading(false);
  }

  async function handleCalculate() {
    setCalculating(true);
    const result = calculateMonthlyIncentives(
      calcMonth, contracts, employees, attendance, kpis, ideas, violations, overtime, settings
    );
    setCalcResult(result);
    setCalculating(false);
  }

  async function handleSaveIncentives() {
    if (!calcResult) return;
    for (const emp of calcResult.employees) {
      if (emp.adjustedAmount <= 0 && emp.totalContractBonus <= 0 && emp.poolShare <= 0) continue;

      // Save contract bonuses
      if (emp.newContractBonus > 0) {
        for (const cd of emp.contractDetails.filter((d) => d.type === 'new')) {
          await createIncentiveRecord({
            employeeId: emp.employeeId,
            contractId: cd.contractId,
            month: calcMonth,
            incentiveType: 'new_contract',
            baseAmount: cd.amount,
            performanceMultiplier: emp.performanceMultiplier,
            finalAmount: Math.round(cd.amount * emp.performanceMultiplier),
            status: 'calculated',
            calculationDetails: JSON.stringify(cd),
            approvedBy: '',
            paidAt: '',
          });
        }
      }
      if (emp.renewalBonus > 0) {
        for (const cd of emp.contractDetails.filter((d) => d.type === 'renewal')) {
          await createIncentiveRecord({
            employeeId: emp.employeeId,
            contractId: cd.contractId,
            month: calcMonth,
            incentiveType: 'renewal',
            baseAmount: cd.amount,
            performanceMultiplier: emp.performanceMultiplier,
            finalAmount: Math.round(cd.amount * emp.performanceMultiplier),
            status: 'calculated',
            calculationDetails: JSON.stringify(cd),
            approvedBy: '',
            paidAt: '',
          });
        }
      }
      if (emp.upsellBonus > 0) {
        for (const cd of emp.contractDetails.filter((d) => d.type === 'upsell')) {
          await createIncentiveRecord({
            employeeId: emp.employeeId,
            contractId: cd.contractId,
            month: calcMonth,
            incentiveType: 'upsell',
            baseAmount: cd.amount,
            performanceMultiplier: emp.performanceMultiplier,
            finalAmount: Math.round(cd.amount * emp.performanceMultiplier),
            status: 'calculated',
            calculationDetails: JSON.stringify(cd),
            approvedBy: '',
            paidAt: '',
          });
        }
      }
      if (emp.poolShare > 0) {
        await createIncentiveRecord({
          employeeId: emp.employeeId,
          contractId: '',
          month: calcMonth,
          incentiveType: 'monthly_pool',
          baseAmount: emp.poolShare,
          performanceMultiplier: emp.performanceMultiplier,
          finalAmount: Math.round(emp.poolShare * emp.performanceMultiplier),
          status: 'calculated',
          calculationDetails: JSON.stringify({ poolShare: emp.poolShare }),
          approvedBy: '',
          paidAt: '',
        });
      }
    }
    await loadData();
  }

  async function handleApproveAll() {
    const monthRecords = filteredHistory.filter((r) => r.status === 'calculated');
    for (const r of monthRecords) {
      await updateIncentiveRecord(r.id, { status: 'approved' });
    }
    await loadData();
  }

  async function handleStatusChange(id: string, newStatus: string) {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const updates: Partial<IncentiveRecord> = { status: newStatus };
    if (newStatus === 'paid') updates.paidAt = now;
    await updateIncentiveRecord(id, updates);
    await loadData();
  }

  async function handleSaveSettings() {
    setSavingSettings(true);
    for (const setting of settings) {
      const newVal = editSettings[setting.settingKey];
      if (newVal !== undefined && newVal !== setting.settingValue) {
        await updateIncentiveSetting(setting.id, newVal);
      }
    }
    await loadData();
    setSavingSettings(false);
  }

  // Filtered history
  const filteredHistory = incentiveRecords.filter((r) => {
    if (historyMonth !== 'all' && r.month !== historyMonth) return false;
    if (historyStatus !== 'all' && r.status !== historyStatus) return false;
    return true;
  });

  function getEmployeeName(id: string) {
    const emp = employees.find((e) => e.id === id);
    return emp ? emp.fullName : '—';
  }

  function getStatusBadge(status: string) {
    const colors: Record<string, string> = {
      calculated: 'bg-yellow-100 text-yellow-700',
      approved: 'bg-blue-100 text-blue-700',
      paid: 'bg-emerald-100 text-emerald-700',
      cancelled: 'bg-red-100 text-red-700',
    };
    return <Badge className={colors[status] || 'bg-gray-100'}>{INCENTIVE_STATUS_LABELS[status] || status}</Badge>;
  }

  const months = [];
  for (let m = 1; m <= 12; m++) {
    months.push(`2026-${String(m).padStart(2, '0')}`);
  }
  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  if (authLoading || dataLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E3A5F] mx-auto mb-4" />
          <p className="text-[#64748B]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">حساب الحوافز</h1>
              <p className="text-xs text-[#64748B]">حساب المكافآت تلقائياً بناءً على العقود والأداء</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="calculate" className="gap-1"><Calculator className="w-4 h-4" /> حساب الحوافز</TabsTrigger>
              <TabsTrigger value="history" className="gap-1"><ListChecks className="w-4 h-4" /> سجل الحوافز</TabsTrigger>
              <TabsTrigger value="settings" className="gap-1"><Settings className="w-4 h-4" /> إعدادات النسب</TabsTrigger>
            </TabsList>

            {/* TAB 1: Calculate */}
            <TabsContent value="calculate">
              <Card className="mb-6">
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-end gap-4">
                    <div>
                      <Label>الشهر</Label>
                      <Select value={calcMonth} onValueChange={setCalcMonth}>
                        <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {months.map((m) => (
                            <SelectItem key={m} value={m}>{monthNames[m.split('-')[1]]} {m.split('-')[0]}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCalculate} disabled={calculating} className="bg-[#1E3A5F] hover:bg-[#15304F] text-white gap-2">
                      <Play className="w-4 h-4" />
                      {calculating ? 'جاري الحساب...' : 'حساب الحوافز'}
                    </Button>
                    {calcResult && (
                      <Button onClick={handleSaveIncentives} variant="outline" className="gap-2">
                        <CheckCheck className="w-4 h-4" />
                        حفظ النتائج
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {calcResult && (
                <>
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
                    <Card><CardContent className="p-3 text-center">
                      <p className="text-lg font-bold text-emerald-600">{formatOMR(calcResult.summary.totalIncentives)}</p>
                      <p className="text-xs text-gray-500">إجمالي الحوافز</p>
                    </CardContent></Card>
                    <Card><CardContent className="p-3 text-center">
                      <p className="text-lg font-bold text-blue-600">{formatOMR(calcResult.summary.monthlyRevenue)}</p>
                      <p className="text-xs text-gray-500">الإيراد الشهري</p>
                    </CardContent></Card>
                    <Card><CardContent className="p-3 text-center">
                      <p className="text-lg font-bold text-amber-600">{formatOMR(calcResult.summary.monthlyCap)}</p>
                      <p className="text-xs text-gray-500">الحد الأقصى (8%)</p>
                    </CardContent></Card>
                    <Card><CardContent className="p-3 text-center">
                      <p className="text-lg font-bold text-purple-600">{formatOMR(calcResult.summary.poolAmount)}</p>
                      <p className="text-xs text-gray-500">صندوق الفريق</p>
                    </CardContent></Card>
                    <Card><CardContent className="p-3 text-center">
                      <p className="text-lg font-bold text-indigo-600">{calcResult.summary.eligibleCount}</p>
                      <p className="text-xs text-gray-500">موظفون مؤهلون</p>
                    </CardContent></Card>
                    <Card><CardContent className="p-3 text-center">
                      <p className={`text-lg font-bold ${calcResult.summary.isCapApplied ? 'text-red-600' : 'text-green-600'}`}>
                        {calcResult.summary.isCapApplied ? 'نعم' : 'لا'}
                      </p>
                      <p className="text-xs text-gray-500">تم تطبيق السقف؟</p>
                    </CardContent></Card>
                  </div>

                  {/* Results Table */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">نتائج الحساب</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b bg-gray-50">
                              <th className="text-right p-2 font-medium"></th>
                              <th className="text-right p-2 font-medium">الموظف</th>
                              <th className="text-right p-2 font-medium">الوظيفة</th>
                              <th className="text-right p-2 font-medium">عقود جديدة</th>
                              <th className="text-right p-2 font-medium">تجديدات</th>
                              <th className="text-right p-2 font-medium">زيادة قيمة</th>
                              <th className="text-right p-2 font-medium">حصة الصندوق</th>
                              <th className="text-right p-2 font-medium">مُعامل الأداء</th>
                              <th className="text-right p-2 font-medium">المُضاعف</th>
                              <th className="text-right p-2 font-medium">المكافأة النهائية</th>
                            </tr>
                          </thead>
                          <tbody>
                            {calcResult.employees.map((emp) => (
                              <>
                                <tr key={emp.employeeId} className="border-b hover:bg-gray-50 cursor-pointer"
                                  onClick={() => setExpandedEmployee(expandedEmployee === emp.employeeId ? null : emp.employeeId)}>
                                  <td className="p-2">
                                    {expandedEmployee === emp.employeeId ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                  </td>
                                  <td className="p-2 font-medium">{emp.employeeName}</td>
                                  <td className="p-2 text-xs">{emp.jobTitle}</td>
                                  <td className="p-2">{emp.newContractBonus > 0 ? formatOMR(emp.newContractBonus) : '—'}</td>
                                  <td className="p-2">{emp.renewalBonus > 0 ? formatOMR(emp.renewalBonus) : '—'}</td>
                                  <td className="p-2">{emp.upsellBonus > 0 ? formatOMR(emp.upsellBonus) : '—'}</td>
                                  <td className="p-2">{emp.poolShare > 0 ? formatOMR(emp.poolShare) : '—'}</td>
                                  <td className="p-2">
                                    <Badge className={
                                      emp.performanceScore >= 90 ? 'bg-emerald-100 text-emerald-700' :
                                      emp.performanceScore >= 75 ? 'bg-green-100 text-green-700' :
                                      emp.performanceScore >= 60 ? 'bg-yellow-100 text-yellow-700' :
                                      'bg-red-100 text-red-700'
                                    }>
                                      {emp.performanceScore}% — {emp.performanceLabel}
                                    </Badge>
                                  </td>
                                  <td className="p-2 font-medium">×{emp.performanceMultiplier}</td>
                                  <td className="p-2 font-bold text-emerald-600">{formatOMR(emp.adjustedAmount)}</td>
                                </tr>
                                {expandedEmployee === emp.employeeId && (
                                  <tr key={`${emp.employeeId}-details`}>
                                    <td colSpan={10} className="p-4 bg-gray-50">
                                      <div className="grid md:grid-cols-2 gap-4">
                                        {/* Contract Details */}
                                        {emp.contractDetails.length > 0 && (
                                          <div>
                                            <h4 className="font-medium text-sm mb-2">تفاصيل مكافآت العقود</h4>
                                            <div className="space-y-2">
                                              {emp.contractDetails.map((cd, idx) => (
                                                <div key={idx} className="p-2 bg-white rounded border text-xs">
                                                  <p className="font-medium">{cd.clientName}</p>
                                                  <p>النوع: {CONTRACT_TYPE_LABELS[cd.type]} | القيمة: {formatOMR(cd.value)} | النسبة: {(cd.rate * 100).toFixed(0)}% | المبلغ: {formatOMR(cd.amount)}</p>
                                                </div>
                                              ))}
                                            </div>
                                          </div>
                                        )}
                                        {/* Performance Details */}
                                        <div>
                                          <h4 className="font-medium text-sm mb-2">تفاصيل مُعامل الأداء</h4>
                                          <div className="space-y-1 text-xs">
                                            <div className="flex justify-between p-1.5 bg-white rounded border">
                                              <span>الحضور (20%)</span>
                                              <span className="font-medium">{emp.performanceDetails.attendanceScore}%</span>
                                            </div>
                                            <div className="flex justify-between p-1.5 bg-white rounded border">
                                              <span>مؤشرات الأداء KPI (25%)</span>
                                              <span className="font-medium">{emp.performanceDetails.kpiScore}%</span>
                                            </div>
                                            <div className="flex justify-between p-1.5 bg-white rounded border">
                                              <span>ClickUp (30%)</span>
                                              <span className="font-medium">{emp.performanceDetails.clickupScore}%</span>
                                            </div>
                                            <div className="flex justify-between p-1.5 bg-white rounded border">
                                              <span>الأفكار (10%)</span>
                                              <span className="font-medium">{emp.performanceDetails.ideasScore}%</span>
                                            </div>
                                            <div className="flex justify-between p-1.5 bg-white rounded border">
                                              <span>الانضباط (15%)</span>
                                              <span className="font-medium">{emp.performanceDetails.disciplineScore}%</span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                )}
                              </>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>

            {/* TAB 2: History */}
            <TabsContent value="history">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <Select value={historyMonth} onValueChange={setHistoryMonth}>
                      <SelectTrigger className="w-[180px]"><SelectValue placeholder="الشهر" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع الأشهر</SelectItem>
                        {months.map((m) => (
                          <SelectItem key={m} value={m}>{monthNames[m.split('-')[1]]} {m.split('-')[0]}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={historyStatus} onValueChange={setHistoryStatus}>
                      <SelectTrigger className="w-[150px]"><SelectValue placeholder="الحالة" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">الكل</SelectItem>
                        <SelectItem value="calculated">محسوبة</SelectItem>
                        <SelectItem value="approved">معتمدة</SelectItem>
                        <SelectItem value="paid">مصروفة</SelectItem>
                        <SelectItem value="cancelled">ملغاة</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm" onClick={handleApproveAll} className="gap-1">
                      <CheckCheck className="w-4 h-4" /> اعتماد الكل
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="text-right p-2 font-medium">الموظف</th>
                          <th className="text-right p-2 font-medium">الشهر</th>
                          <th className="text-right p-2 font-medium">النوع</th>
                          <th className="text-right p-2 font-medium">المبلغ الأساسي</th>
                          <th className="text-right p-2 font-medium">المُضاعف</th>
                          <th className="text-right p-2 font-medium">المبلغ النهائي</th>
                          <th className="text-right p-2 font-medium">الحالة</th>
                          <th className="text-right p-2 font-medium">إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredHistory.length === 0 ? (
                          <tr><td colSpan={8} className="text-center py-8 text-gray-400">لا توجد سجلات</td></tr>
                        ) : (
                          filteredHistory.map((r) => (
                            <tr key={r.id} className="border-b hover:bg-gray-50">
                              <td className="p-2 font-medium">{getEmployeeName(r.employeeId)}</td>
                              <td className="p-2 text-xs">{r.month}</td>
                              <td className="p-2">
                                <Badge variant="secondary">{INCENTIVE_TYPE_LABELS[r.incentiveType] || r.incentiveType}</Badge>
                              </td>
                              <td className="p-2">{formatOMR(r.baseAmount)}</td>
                              <td className="p-2">×{r.performanceMultiplier}</td>
                              <td className="p-2 font-medium">{formatOMR(r.finalAmount)}</td>
                              <td className="p-2">{getStatusBadge(r.status)}</td>
                              <td className="p-2">
                                <Select value={r.status} onValueChange={(v) => handleStatusChange(r.id, v)}>
                                  <SelectTrigger className="h-7 text-xs w-[100px]"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="calculated">محسوبة</SelectItem>
                                    <SelectItem value="approved">معتمدة</SelectItem>
                                    <SelectItem value="paid">مصروفة</SelectItem>
                                    <SelectItem value="cancelled">ملغاة</SelectItem>
                                  </SelectContent>
                                </Select>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* TAB 3: Settings */}
            <TabsContent value="settings">
              <div className="space-y-6">
                {/* New Contract Tiers */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">شرائح عمولة العقد الجديد</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-gray-500 mb-3">النسب المطبقة على القيمة السنوية للعقود الجديدة (القيم بالبيسة)</p>
                    <textarea
                      className="w-full h-24 p-3 border rounded-lg text-xs font-mono"
                      value={editSettings['new_contract_tiers'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, new_contract_tiers: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Renewal Rates */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">نسب مكافأة التجديد</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <textarea
                      className="w-full h-16 p-3 border rounded-lg text-xs font-mono"
                      value={editSettings['renewal_rates'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, renewal_rates: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Upsell Rate */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">نسبة مكافأة زيادة القيمة (Upsell)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Input
                      type="number"
                      step="0.01"
                      className="w-48"
                      value={editSettings['upsell_rate'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, upsell_rate: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Monthly Pool Tiers */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">شرائح صندوق المكافأة الشهرية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <textarea
                      className="w-full h-24 p-3 border rounded-lg text-xs font-mono"
                      value={editSettings['monthly_pool_tiers'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, monthly_pool_tiers: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Max Cap */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">الحد الأقصى للحوافز (نسبة من الإيراد)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Input
                      type="number"
                      step="0.01"
                      className="w-48"
                      value={editSettings['max_incentive_cap'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, max_incentive_cap: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Performance Weights */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">أوزان مُعامل الأداء</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-gray-500 mb-3">المجموع يجب أن يساوي 1.00 (100%)</p>
                    <textarea
                      className="w-full h-16 p-3 border rounded-lg text-xs font-mono"
                      value={editSettings['performance_weights'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, performance_weights: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Performance Multipliers */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">مُضاعفات الأداء</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <textarea
                      className="w-full h-16 p-3 border rounded-lg text-xs font-mono"
                      value={editSettings['performance_multipliers'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, performance_multipliers: e.target.value })}
                    />
                  </CardContent>
                </Card>

                {/* Eligibility */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">الحد الأدنى لأشهر العمل للأهلية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Input
                      type="number"
                      className="w-48"
                      value={editSettings['eligibility_min_months'] || ''}
                      onChange={(e) => setEditSettings({ ...editSettings, eligibility_min_months: e.target.value })}
                    />
                  </CardContent>
                </Card>

                <Button onClick={handleSaveSettings} disabled={savingSettings} className="bg-[#1E3A5F] hover:bg-[#15304F] text-white">
                  {savingSettings ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}