import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ClipboardCheck, CheckCircle2, Clock, Loader2, Users, TrendingUp, CalendarCheck, Zap } from 'lucide-react';
import { apiGet, apiPost } from '@/lib/api-client';

interface EmployeeEvalStatus {
  id: number;
  full_name: string;
  department: string;
  job_title: string;
  is_evaluated: boolean;
  attendance_score: number | null;
  productivity_score: number | null;
  tasks_assigned: number | null;
  tasks_completed: number | null;
  quality_score: number | null;
  quality_output: number | null;
  quality_initiative: number | null;
  quality_teamwork: number | null;
  quality_client_satisfaction: number | null;
  quality_notes: string | null;
  final_score: number | null;
  grade: string | null;
}

interface EvalFormData {
  quality_output: number;
  quality_initiative: number;
  quality_teamwork: number;
  quality_client_satisfaction: number;
  quality_notes: string;
}

interface Weights {
  attendance: number;
  productivity: number;
  quality: number;
}

function getScoreLabel(value: number): string {
  if (value <= 2) return 'ضعيف جداً';
  if (value <= 4) return 'ضعيف';
  if (value <= 5) return 'متوسط';
  if (value <= 7) return 'جيد';
  if (value <= 9) return 'جيد جداً';
  return 'ممتاز';
}

function getScoreColor(value: number): string {
  if (value <= 3) return 'text-red-600';
  if (value <= 5) return 'text-amber-600';
  if (value <= 7) return 'text-blue-600';
  return 'text-green-600';
}

function getPercentColor(score: number | null): string {
  if (score === null) return 'text-gray-400';
  const pct = score * 100;
  if (pct >= 85) return 'text-green-600';
  if (pct >= 70) return 'text-blue-600';
  if (pct >= 55) return 'text-amber-600';
  return 'text-red-600';
}

function getGradeColor(grade: string | null): string {
  if (!grade) return 'bg-gray-100 text-gray-600';
  if (grade === 'ممتاز') return 'bg-green-100 text-green-700';
  if (grade === 'جيد جداً') return 'bg-blue-100 text-blue-700';
  if (grade === 'جيد') return 'bg-amber-100 text-amber-700';
  return 'bg-red-100 text-red-700';
}

export default function MonthlyEvaluation() {
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [employees, setEmployees] = useState<EmployeeEvalStatus[]>([]);
  const [loading, setLoading] = useState(false);
  const [computing, setComputing] = useState(false);
  const [evalDialogOpen, setEvalDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<EmployeeEvalStatus | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState<EvalFormData>({
    quality_output: 5,
    quality_initiative: 5,
    quality_teamwork: 5,
    quality_client_satisfaction: 5,
    quality_notes: '',
  });
  const [weights, setWeights] = useState<Weights>({ attendance: 0.30, productivity: 0.45, quality: 0.25 });

  const [evaluatedCount, setEvaluatedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    if (selectedMonth) {
      autoComputeAndLoad();
    }
  }, [selectedMonth]);

  async function autoComputeAndLoad() {
    setComputing(true);
    try {
      await apiPost('/api/v1/rewards/auto-compute', { month: selectedMonth });
    } catch (err) {
      console.warn('Auto-compute failed (non-critical):', err);
    } finally {
      setComputing(false);
    }
    await loadEmployees();
  }

  async function loadEmployees() {
    setLoading(true);
    try {
      const res = await apiGet('/api/v1/rewards/employees-evaluation-status', { month: selectedMonth });
      if (res.ok && res.data) {
        setEmployees(res.data.employees || []);
        setEvaluatedCount(res.data.evaluated || 0);
        setTotalCount(res.data.total || 0);
        if (res.data.weights) {
          setWeights(res.data.weights);
        }
      } else {
        setEmployees([]);
      }
    } catch (err) {
      console.error('Failed to load employees:', err);
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  }

  function openEvalDialog(emp: EmployeeEvalStatus) {
    setSelectedEmployee(emp);
    setFormData({
      quality_output: emp.quality_output || 5,
      quality_initiative: emp.quality_initiative || 5,
      quality_teamwork: emp.quality_teamwork || 5,
      quality_client_satisfaction: emp.quality_client_satisfaction || 5,
      quality_notes: emp.quality_notes || '',
    });
    setEvalDialogOpen(true);
  }

  async function handleSubmitEval() {
    if (!selectedEmployee) return;
    setSubmitting(true);
    try {
      const res = await apiPost('/api/v1/rewards/evaluate', {
        employee_id: selectedEmployee.id,
        month: selectedMonth,
        quality_output: formData.quality_output,
        quality_initiative: formData.quality_initiative,
        quality_teamwork: formData.quality_teamwork,
        quality_client_satisfaction: formData.quality_client_satisfaction,
        quality_notes: formData.quality_notes || null,
      });
      if (res.ok && res.data) {
        toast.success(`تم تقييم ${selectedEmployee.full_name} بنجاح (${(res.data.quality_score * 100).toFixed(1)}%)`);
        setEvalDialogOpen(false);
        await autoComputeAndLoad();
      }
    } catch (err: any) {
      console.error('Evaluation failed:', err);
      toast.error(err?.data?.detail || err?.message || 'فشل في حفظ التقييم');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSyncClickUp() {
    setComputing(true);
    try {
      const res = await apiPost('/api/v1/rewards/sync-clickup', { month: selectedMonth });
      if (res.ok && res.data) {
        toast.success(`تم مزامنة ClickUp بنجاح - ${res.data.employees_processed} موظف`);
        await loadEmployees();
      }
    } catch (err: any) {
      console.error('ClickUp sync failed:', err);
      toast.error(err?.data?.detail || err?.message || 'فشل في مزامنة بيانات الإنتاجية');
    } finally {
      setComputing(false);
    }
  }

  const monthOptions = Array.from({ length: 12 }, (_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const label = d.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long' });
    return { value, label };
  });

  const computedScore = (
    (formData.quality_output * 0.35) +
    (formData.quality_initiative * 0.25) +
    (formData.quality_teamwork * 0.20) +
    (formData.quality_client_satisfaction * 0.20)
  ) / 10;

  const withAttendance = employees.filter(e => e.attendance_score !== null).length;
  const withProductivity = employees.filter(e => e.productivity_score !== null).length;

  return (
    <div className="space-y-6" dir="rtl">
      {/* Month Selector & Stats */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="اختر الشهر" />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSyncClickUp}
                disabled={computing}
                className="text-xs"
              >
                {computing ? <Loader2 className="w-3 h-3 animate-spin ml-1" /> : <Zap className="w-3 h-3 ml-1" />}
                مزامنة ClickUp
              </Button>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary" className="text-xs px-2 py-1">
                <CalendarCheck className="w-3 h-3 ml-1" />
                انضباط: {withAttendance}/{totalCount}
              </Badge>
              <Badge variant="secondary" className="text-xs px-2 py-1">
                <TrendingUp className="w-3 h-3 ml-1" />
                إنتاجية: {withProductivity}/{totalCount}
              </Badge>
              <Badge variant="secondary" className="text-xs px-2 py-1">
                <Users className="w-3 h-3 ml-1" />
                جودة: {evaluatedCount}/{totalCount}
              </Badge>
              {evaluatedCount === totalCount && totalCount > 0 && (
                <Badge className="bg-green-600 text-xs px-2 py-1">
                  <CheckCircle2 className="w-3 h-3 ml-1" />
                  مكتمل
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weights Info */}
      <Card className="border-blue-200 bg-blue-50/30">
        <CardContent className="pt-4 pb-3">
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <span className="font-medium text-blue-700">أوزان التقييم:</span>
            <Badge variant="outline" className="border-green-300 text-green-700">
              الانضباط {(weights.attendance * 100).toFixed(0)}%
            </Badge>
            <Badge variant="outline" className="border-blue-300 text-blue-700">
              الإنتاجية {(weights.productivity * 100).toFixed(0)}%
            </Badge>
            <Badge variant="outline" className="border-purple-300 text-purple-700">
              الجودة {(weights.quality * 100).toFixed(0)}%
            </Badge>
            <span className="text-xs text-gray-500">
              النتيجة = (انضباط × {(weights.attendance * 100).toFixed(0)}%) + (إنتاجية × {(weights.productivity * 100).toFixed(0)}%) + (جودة × {(weights.quality * 100).toFixed(0)}%)
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Employees Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-purple-600" />
            قائمة الموظفين - النتائج التلقائية
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading || computing ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
              <span className="mr-2 text-gray-500">
                {computing ? 'جاري حساب الدرجات...' : 'جاري التحميل...'}
              </span>
            </div>
          ) : employees.length === 0 ? (
            <p className="text-center text-gray-500 py-8">لا يوجد موظفون</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="text-right p-3 font-medium text-gray-600">#</th>
                    <th className="text-right p-3 font-medium text-gray-600">الموظف</th>
                    <th className="text-right p-3 font-medium text-gray-600">القسم</th>
                    <th className="text-center p-3 font-medium text-green-700">
                      <div className="flex flex-col items-center">
                        <CalendarCheck className="w-4 h-4 mb-0.5" />
                        <span>الانضباط</span>
                        <span className="text-[10px] text-gray-400">تلقائي</span>
                      </div>
                    </th>
                    <th className="text-center p-3 font-medium text-blue-700">
                      <div className="flex flex-col items-center">
                        <TrendingUp className="w-4 h-4 mb-0.5" />
                        <span>الإنتاجية</span>
                        <span className="text-[10px] text-gray-400">تلقائي</span>
                      </div>
                    </th>
                    <th className="text-center p-3 font-medium text-purple-700">
                      <div className="flex flex-col items-center">
                        <ClipboardCheck className="w-4 h-4 mb-0.5" />
                        <span>الجودة</span>
                        <span className="text-[10px] text-gray-400">يدوي</span>
                      </div>
                    </th>
                    <th className="text-center p-3 font-medium text-gray-700">النتيجة</th>
                    <th className="text-center p-3 font-medium text-gray-700">التصنيف</th>
                    <th className="text-center p-3 font-medium text-gray-600">إجراء</th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map((emp, idx) => (
                    <tr key={emp.id} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="p-3 text-gray-500">{idx + 1}</td>
                      <td className="p-3 font-medium">{emp.full_name}</td>
                      <td className="p-3 text-gray-600">{emp.department || '-'}</td>
                      <td className="p-3 text-center">
                        {emp.attendance_score !== null ? (
                          <span className={`font-semibold ${getPercentColor(emp.attendance_score)}`}>
                            {(emp.attendance_score * 100).toFixed(0)}%
                          </span>
                        ) : (
                          <span className="text-gray-400 text-xs">لا توجد بيانات</span>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        {emp.productivity_score !== null ? (
                          <div className="flex flex-col items-center">
                            <span className={`font-semibold ${getPercentColor(emp.productivity_score)}`}>
                              {(emp.productivity_score * 100).toFixed(0)}%
                            </span>
                            {emp.tasks_assigned !== null && (
                              <span className="text-[10px] text-gray-400">
                                {emp.tasks_completed}/{emp.tasks_assigned} مهمة
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400 text-xs">لا توجد بيانات</span>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        {emp.quality_score !== null ? (
                          <span className={`font-semibold ${getPercentColor(emp.quality_score)}`}>
                            {(emp.quality_score * 100).toFixed(0)}%
                          </span>
                        ) : (
                          <Badge variant="outline" className="text-amber-600 border-amber-300 text-[10px]">
                            <Clock className="w-3 h-3 ml-0.5" />
                            بانتظار
                          </Badge>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        {emp.final_score !== null ? (
                          <span className={`font-bold ${getPercentColor(emp.final_score)}`}>
                            {(emp.final_score * 100).toFixed(1)}%
                          </span>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        {emp.grade ? (
                          <Badge className={`${getGradeColor(emp.grade)} text-xs`}>
                            {emp.grade}
                          </Badge>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        <Button
                          size="sm"
                          variant={emp.is_evaluated ? 'outline' : 'default'}
                          onClick={() => openEvalDialog(emp)}
                          className={emp.is_evaluated ? '' : 'bg-purple-600 hover:bg-purple-700 text-white'}
                        >
                          {emp.is_evaluated ? 'تعديل' : 'تقييم الجودة'}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Evaluation Dialog - Quality Only */}
      <Dialog open={evalDialogOpen} onOpenChange={setEvalDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-lg">
              تقييم الجودة: {selectedEmployee?.full_name}
            </DialogTitle>
            <p className="text-sm text-gray-500">{selectedEmployee?.department} • {selectedEmployee?.job_title}</p>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Auto-computed scores display (read-only) */}
            {selectedEmployee && (selectedEmployee.attendance_score !== null || selectedEmployee.productivity_score !== null) && (
              <div className="p-4 bg-gray-50 rounded-lg border space-y-2">
                <p className="text-xs font-medium text-gray-600 mb-2">الدرجات المحسوبة تلقائياً:</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center justify-between bg-white p-2 rounded border">
                    <span className="text-xs text-gray-600 flex items-center gap-1">
                      <CalendarCheck className="w-3 h-3 text-green-600" />
                      الانضباط
                    </span>
                    <span className={`text-sm font-bold ${getPercentColor(selectedEmployee.attendance_score)}`}>
                      {selectedEmployee.attendance_score !== null
                        ? `${(selectedEmployee.attendance_score * 100).toFixed(0)}%`
                        : 'غير متوفر'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-white p-2 rounded border">
                    <span className="text-xs text-gray-600 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-blue-600" />
                      الإنتاجية
                    </span>
                    <span className={`text-sm font-bold ${getPercentColor(selectedEmployee.productivity_score)}`}>
                      {selectedEmployee.productivity_score !== null
                        ? `${(selectedEmployee.productivity_score * 100).toFixed(0)}%`
                        : 'غير متوفر'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Quality Output */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">جودة المخرجات (35%)</label>
                <span className={`text-sm font-bold ${getScoreColor(formData.quality_output)}`}>
                  {formData.quality_output} - {getScoreLabel(formData.quality_output)}
                </span>
              </div>
              <Slider
                value={[formData.quality_output]}
                onValueChange={([v]) => setFormData(prev => ({ ...prev, quality_output: v }))}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-gray-500">
                هل المخرجات تحتاج تعديلات كثيرة؟ هل الجودة عالية من أول مرة؟
              </p>
            </div>

            {/* Initiative */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">المبادرة والابتكار (25%)</label>
                <span className={`text-sm font-bold ${getScoreColor(formData.quality_initiative)}`}>
                  {formData.quality_initiative} - {getScoreLabel(formData.quality_initiative)}
                </span>
              </div>
              <Slider
                value={[formData.quality_initiative]}
                onValueChange={([v]) => setFormData(prev => ({ ...prev, quality_initiative: v }))}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-gray-500">
                هل يقترح أفكار جديدة؟ هل يحل مشاكل بنفسه بدون ما يُطلب منه؟
              </p>
            </div>

            {/* Teamwork */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">التعاون مع الفريق (20%)</label>
                <span className={`text-sm font-bold ${getScoreColor(formData.quality_teamwork)}`}>
                  {formData.quality_teamwork} - {getScoreLabel(formData.quality_teamwork)}
                </span>
              </div>
              <Slider
                value={[formData.quality_teamwork]}
                onValueChange={([v]) => setFormData(prev => ({ ...prev, quality_teamwork: v }))}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-gray-500">
                هل يساعد زملاءه؟ هل يتواصل بفعالية؟ هل يعمل بروح الفريق؟
              </p>
            </div>

            {/* Client Satisfaction */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">رضا العملاء (20%)</label>
                <span className={`text-sm font-bold ${getScoreColor(formData.quality_client_satisfaction)}`}>
                  {formData.quality_client_satisfaction} - {getScoreLabel(formData.quality_client_satisfaction)}
                </span>
              </div>
              <Slider
                value={[formData.quality_client_satisfaction]}
                onValueChange={([v]) => setFormData(prev => ({ ...prev, quality_client_satisfaction: v }))}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-gray-500">
                هل العملاء راضون عن عمله؟ هل يتلقى شكاوى أو إشادات؟
              </p>
            </div>

            {/* Computed Score Preview */}
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-purple-700">درجة الجودة المحسوبة:</span>
                <span className="text-lg font-bold text-purple-700">
                  {(computedScore * 100).toFixed(1)}%
                </span>
              </div>
              <p className="text-xs text-purple-600 mt-1">
                = ({formData.quality_output}×0.35 + {formData.quality_initiative}×0.25 + {formData.quality_teamwork}×0.20 + {formData.quality_client_satisfaction}×0.20) ÷ 10
              </p>
              {/* Show projected final score if attendance and productivity are available */}
              {selectedEmployee?.attendance_score !== null && selectedEmployee?.productivity_score !== null && (
                <div className="mt-3 pt-3 border-t border-purple-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-purple-600">النتيجة النهائية المتوقعة:</span>
                    <span className="text-sm font-bold text-purple-800">
                      {(
                        ((selectedEmployee?.attendance_score || 0) * weights.attendance +
                        (selectedEmployee?.productivity_score || 0) * weights.productivity +
                        computedScore * weights.quality) * 100
                      ).toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-[10px] text-purple-500 mt-0.5">
                    = ({((selectedEmployee?.attendance_score || 0) * 100).toFixed(0)}% × {(weights.attendance * 100).toFixed(0)}%) + ({((selectedEmployee?.productivity_score || 0) * 100).toFixed(0)}% × {(weights.productivity * 100).toFixed(0)}%) + ({(computedScore * 100).toFixed(0)}% × {(weights.quality * 100).toFixed(0)}%)
                  </p>
                </div>
              )}
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <label className="text-sm font-medium">ملاحظات (اختياري)</label>
              <Textarea
                value={formData.quality_notes}
                onChange={(e) => setFormData(prev => ({ ...prev, quality_notes: e.target.value }))}
                placeholder="ملاحظات المدير للموظف..."
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEvalDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleSubmitEval}
              disabled={submitting}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                'حفظ تقييم الجودة'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}