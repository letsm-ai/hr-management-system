import { useState, useEffect } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Link2, Menu, Settings, BarChart3, History, Users, CheckCircle2,
  AlertTriangle, Loader2, RefreshCw, Zap, Save, Eye, EyeOff,
  Shield, Clock, CalendarClock, Bell, BellOff, Play, ArrowDownUp,
} from 'lucide-react';
import { Sidebar } from './Index';
import {
  fetchClickUpWorkspaces, fetchClickUpSummary,
  type ClickUpWorkspace, type ClickUpMember, type ClickUpSummary,
  type Employee, getEmployeeNameFromList, getEmployeeByIdFromList,
  formatCurrency, getCurrentMonth, calculateKpiAchievementRate,
  calculateKpiBonus, getKpiRating, createPerformanceKpi, updatePerformanceKpi,
} from '@/lib/hr-api';
import {
  fetchClickUpSettings, saveClickUpSettings, fetchClickUpSpaces,
  fetchClickUpSyncHistory, triggerManualSync, testClickUpConnection,
  fetchMemberMapping, saveMemberMapping, recordSyncOperation,
  type ClickUpSettings, type ClickUpSpace, type SyncHistoryRecord,
} from '@/lib/clickup-api';
import {
  autoMatchMembers, getMatchMethodLabel, getConfidenceBadgeClass,
} from '@/lib/member-matching';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import { toast } from 'sonner';

const DAYS_OF_WEEK = [
  { value: '0', label: 'الأحد' },
  { value: '1', label: 'الاثنين' },
  { value: '2', label: 'الثلاثاء' },
  { value: '3', label: 'الأربعاء' },
  { value: '4', label: 'الخميس' },
  { value: '5', label: 'الجمعة' },
  { value: '6', label: 'السبت' },
];

const HOURS = Array.from({ length: 24 }, (_, i) => ({
  value: String(i),
  label: `${String(i).padStart(2, '0')}:00`,
}));

const MONTH_DAYS = Array.from({ length: 28 }, (_, i) => ({
  value: String(i + 1),
  label: String(i + 1),
}));

function getFrequencyLabel(freq: string) {
  switch (freq) {
    case 'weekly': return 'أسبوعياً';
    case 'biweekly': return 'كل أسبوعين';
    case 'monthly': return 'شهرياً';
    default: return freq;
  }
}

function getDayLabel(freq: string, day: number) {
  if (freq === 'monthly') return `يوم ${day} من كل شهر`;
  return DAYS_OF_WEEK.find((d) => d.value === String(day))?.label ?? `يوم ${day}`;
}

export default function ClickUpIntegrationPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, loading: authLoading, login, refreshAuth } = useAuth();
  const { employees, performanceKpis, loading: dataLoading, refreshPerformanceKpis } = useHRData();

  const [activeTab, setActiveTab] = useState('settings');

  // Settings state
  const [settings, setSettings] = useState<ClickUpSettings>({
    api_token: '',
    default_workspace_id: '',
    default_workspace_name: '',
    auto_sync_enabled: false,
    sync_frequency: 'monthly',
    sync_day: 1,
    sync_hour: 9,
    auto_sync_notify: true,
  });
  const [settingsLoading, setSettingsLoading] = useState(true);
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  // Workspace & spaces
  const [workspaces, setWorkspaces] = useState<ClickUpWorkspace[]>([]);
  const [loadingWorkspaces, setLoadingWorkspaces] = useState(false);

  // Dashboard / KPI state
  const [month, setMonth] = useState(getCurrentMonth());
  const [summary, setSummary] = useState<ClickUpSummary | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);

  // Sync state
  const [syncHistory, setSyncHistory] = useState<SyncHistoryRecord[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);

  // Member mapping
  const [memberMapping, setMemberMapping] = useState<Record<string, string>>({});

  // Sync dialog
  const [syncDialogOpen, setSyncDialogOpen] = useState(false);
  const [syncStep, setSyncStep] = useState<'mapping' | 'syncing' | 'done'>('mapping');
  const [syncStats, setSyncStats] = useState({ total: 0, synced: 0, skipped: 0, failed: 0 });

  // Auto-sync form state
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(false);
  const [autoSyncFrequency, setAutoSyncFrequency] = useState<'weekly' | 'biweekly' | 'monthly'>('monthly');
  const [autoSyncDay, setAutoSyncDay] = useState(1);
  const [autoSyncHour, setAutoSyncHour] = useState(9);
  const [autoSyncNotify, setAutoSyncNotify] = useState(true);
  const [savingAutoSync, setSavingAutoSync] = useState(false);
  const [forceSyncing, setForceSyncing] = useState(false);

  // Load settings on mount
  useEffect(() => {
    if (user) {
      loadSettingsAndWorkspaces();
      loadSyncHistory();
      loadSavedMapping();
    }
  }, [user]);

  // Populate auto-sync form from settings
  useEffect(() => {
    setAutoSyncEnabled(settings.auto_sync_enabled ?? false);
    setAutoSyncFrequency(settings.sync_frequency ?? 'monthly');
    setAutoSyncDay(settings.sync_day ?? 1);
    setAutoSyncHour(settings.sync_hour ?? 9);
    setAutoSyncNotify(settings.auto_sync_notify ?? true);
  }, [settings]);

  async function loadSettingsAndWorkspaces() {
    setSettingsLoading(true);
    try {
      const s = await fetchClickUpSettings();
      if (s) {
        setSettings(s);
        if (s.api_token) {
          // Token exists in settings - try to verify by fetching workspaces
          try {
            const ws = await fetchClickUpWorkspaces();
            if (ws.length > 0) {
              setConnectionStatus('success');
              setWorkspaces(ws);
              if (!s.default_workspace_id) {
                const updatedSettings = {
                  ...s,
                  default_workspace_id: ws[0].id,
                  default_workspace_name: ws[0].name,
                };
                setSettings(updatedSettings);
                await saveClickUpSettings(updatedSettings);
              }
            } else {
              // Token might be valid but no workspaces found
              setConnectionStatus('success');
            }
          } catch (err: any) {
            const detail = err?.response?.data?.detail || err?.message || '';
            
            // Check if it's a session/auth error (user's login expired, NOT ClickUp token)
            if (err?.isAuthError || detail === 'SESSION_EXPIRED' || err?.response?.status === 401) {
              // User's login session expired - try to refresh auth
              toast.error('انتهت جلسة تسجيل الدخول. جاري إعادة المصادقة...');
              await refreshAuth();
              setConnectionStatus('idle');
              return;
            }
            
            if (detail === 'TOKEN_NOT_CONFIGURED') {
              // Token in settings but not saved to DB yet - user needs to re-test
              setConnectionStatus('idle');
            } else if (detail.includes('غير صالح') || detail.includes('منتهي')) {
              // ClickUp token is invalid/expired - user needs to update
              setConnectionStatus('error');
              toast.error('توكن ClickUp غير صالح أو منتهي الصلاحية. يرجى إدخال توكن جديد واختبار الاتصال.');
            } else {
              // Network or other error - might be temporary
              setConnectionStatus('idle');
            }
          }
        } else {
          setConnectionStatus('idle');
        }
      }
    } catch (err: any) {
      // Check if settings fetch itself failed due to auth
      if (err?.response?.status === 401) {
        toast.error('انتهت جلسة تسجيل الدخول. يرجى إعادة تسجيل الدخول.');
        await refreshAuth();
        return;
      }
      // Settings not configured yet
      setConnectionStatus('idle');
    } finally {
      setSettingsLoading(false);
    }
  }

  async function loadSavedMapping() {
    try {
      const saved = await fetchMemberMapping();
      if (saved && Object.keys(saved).length > 0) {
        setMemberMapping(saved);
      }
    } catch {
      // No saved mapping yet
    }
  }

  async function loadSyncHistory() {
    setLoadingHistory(true);
    try {
      const history = await fetchClickUpSyncHistory();
      setSyncHistory(history);
    } catch {
      // No history yet
    } finally {
      setLoadingHistory(false);
    }
  }

  async function handleTestConnection() {
    if (!settings.api_token || !settings.api_token.trim()) {
      toast.error('يرجى إدخال ClickUp API Token أولاً');
      return;
    }
    setConnectionStatus('testing');
    try {
      const result = await testClickUpConnection(settings.api_token.trim());
      if (result.success) {
        setConnectionStatus('success');
        const ws = result.workspaces || [];
        setWorkspaces(ws);
        
        // Auto-select first workspace if none selected
        let updatedSettings = { ...settings };
        if (ws.length > 0 && !settings.default_workspace_id) {
          updatedSettings = {
            ...updatedSettings,
            default_workspace_id: ws[0].id,
            default_workspace_name: ws[0].name,
          };
        }
        setSettings(updatedSettings);
        
        toast.success(`تم الاتصال بنجاح! تم العثور على ${ws.length} مساحة عمل`);
        
        // Backend auto-saves token on successful test.
        // Also save full settings (workspace selection, etc.) explicitly.
        try {
          await saveClickUpSettings(updatedSettings);
        } catch {
          // Non-critical: token already saved by backend
        }
      } else {
        setConnectionStatus('error');
        const errorMsg = result.error || 'فشل الاتصال بـ ClickUp. تأكد من صحة التوكن.';
        toast.error(errorMsg);
      }
    } catch {
      setConnectionStatus('error');
      toast.error('فشل الاتصال بـ ClickUp. تحقق من اتصال الإنترنت.');
    }
  }

  async function handleSaveSettings() {
    setSettingsSaving(true);
    try {
      await saveClickUpSettings(settings);
      toast.success('تم حفظ الإعدادات بنجاح');
    } catch {
      toast.error('فشل في حفظ الإعدادات');
    } finally {
      setSettingsSaving(false);
    }
  }

  async function handleLoadWorkspaces() {
    setLoadingWorkspaces(true);
    try {
      const ws = await fetchClickUpWorkspaces();
      setWorkspaces(ws);
      if (ws.length === 0) {
        toast.error('لم يتم العثور على مساحات عمل');
      } else {
        setConnectionStatus('success');
      }
    } catch (err: any) {
      const detail = err?.response?.data?.detail || err?.message || '';
      
      // Session expired (user's login, NOT ClickUp token)
      if (err?.isAuthError || detail === 'SESSION_EXPIRED' || err?.response?.status === 401) {
        toast.error('انتهت جلسة تسجيل الدخول. يرجى إعادة تسجيل الدخول.');
        await refreshAuth();
        return;
      }
      
      if (detail === 'TOKEN_NOT_CONFIGURED') {
        toast.error('توكن ClickUp غير محفوظ. يرجى إدخال التوكن واختبار الاتصال أولاً.');
        setConnectionStatus('idle');
      } else if (detail.includes('غير صالح') || detail.includes('منتهي')) {
        toast.error('توكن ClickUp غير صالح أو منتهي الصلاحية. يرجى إدخال توكن جديد واختبار الاتصال.');
        setConnectionStatus('error');
      } else {
        toast.error('فشل في جلب مساحات العمل. تحقق من الاتصال بالإنترنت.');
      }
    } finally {
      setLoadingWorkspaces(false);
    }
  }

  async function handleFetchDashboard() {
    let workspaceId = settings.default_workspace_id;
    if (!workspaceId) {
      try {
        const ws = await fetchClickUpWorkspaces();
        setWorkspaces(ws);
        if (ws.length > 0) {
          workspaceId = ws[0].id;
          const updatedSettings = {
            ...settings,
            default_workspace_id: ws[0].id,
            default_workspace_name: ws[0].name,
          };
          setSettings(updatedSettings);
          await saveClickUpSettings(updatedSettings);
        } else {
          toast.error('لم يتم العثور على مساحات عمل. يرجى التحقق من إعدادات التوكن.');
          return;
        }
      } catch (err: any) {
        if (err?.isAuthError || err?.response?.status === 401) {
          toast.error('انتهت جلسة تسجيل الدخول. يرجى إعادة تسجيل الدخول.');
          await refreshAuth();
          return;
        }
        toast.error('يرجى تحديد مساحة العمل في الإعدادات أولاً');
        return;
      }
    }
    setLoadingSummary(true);
    try {
      const [yearStr, monthStr] = month.split('-');
      const year = parseInt(yearStr);
      const mon = parseInt(monthStr);
      const dateFrom = `${year}-${monthStr}-01`;
      const lastDay = new Date(year, mon, 0).getDate();
      const dateTo = `${year}-${monthStr}-${String(lastDay).padStart(2, '0')}`;

      const s = await fetchClickUpSummary(workspaceId, dateFrom, dateTo);
      if (s) {
        setSummary(s);
        // Load saved mapping, then use improved auto-matching
        const savedMapping = await fetchMemberMapping();
        const memberInfos = s.members.map((m) => ({
          clickup_id: m.clickup_id,
          username: m.username || '',
          email: m.email || '',
        }));
        const { mapping: mergedMapping, stats: matchStats } = autoMatchMembers(
          memberInfos,
          employees,
          savedMapping,
        );
        setMemberMapping(mergedMapping);
        const autoMsg = matchStats.autoMatched > 0 ? ` (${matchStats.autoMatched} تطابق تلقائي جديد)` : '';
        toast.success(`تم جلب بيانات ${s.members.length} عضو و ${s.total_tasks} مهمة${autoMsg}`);
      } else {
        toast.error('لم يتم العثور على بيانات');
      }
    } catch {
      toast.error('فشل في جلب بيانات المهام');
    } finally {
      setLoadingSummary(false);
    }
  }

  function openSyncDialog() {
    if (!summary || summary.members.length === 0) {
      toast.error('يرجى جلب بيانات المهام أولاً');
      return;
    }
    setSyncStep('mapping');
    setSyncProgress(0);
    setSyncStats({ total: 0, synced: 0, skipped: 0, failed: 0 });
    setSyncDialogOpen(true);
  }

  async function handleSync() {
    if (!summary) return;
    setSyncStep('syncing');
    setSyncProgress(0);

    const monthKpis = performanceKpis.filter((k) => k.month === month);
    const membersToSync = summary.members.filter(
      (m) => memberMapping[m.clickup_id] && m.total_tasks > 0
    );
    const total = membersToSync.length;
    let synced = 0;
    let failed = 0;

    setSyncStats({ total, synced: 0, skipped: 0, failed: 0 });

    for (let i = 0; i < membersToSync.length; i++) {
      const member = membersToSync[i];
      const employeeId = memberMapping[member.clickup_id];
      const emp = getEmployeeByIdFromList(employees, employeeId);
      const existingKpi = monthKpis.find((k) => k.employeeId === employeeId);

      try {
        const achievementRate = calculateKpiAchievementRate(member.completed_tasks, member.total_tasks);
        const kpiBonus = emp ? calculateKpiBonus(achievementRate, emp.basicSalary) : 0;
        const overallRating = getKpiRating(achievementRate);

        if (existingKpi) {
          await updatePerformanceKpi(existingKpi.id, {
            tasksTarget: member.total_tasks,
            tasksCompleted: member.completed_tasks,
            achievementRate,
            kpiBonus,
            overallRating,
            managerNotes: `${existingKpi.managerNotes ? existingKpi.managerNotes + '\n' : ''}تم التحديث من ClickUp - ${new Date().toLocaleDateString('ar-SA')}`,
          });
          synced++;
        } else {
          await createPerformanceKpi({
            employeeId,
            month,
            tasksTarget: member.total_tasks,
            tasksCompleted: member.completed_tasks,
            achievementRate,
            kpiBonus,
            qualityScore: 7,
            timelinessScore: 7,
            collaborationScore: 7,
            innovationScore: 7,
            overallRating,
            managerNotes: `تم الاستيراد من ClickUp - ${new Date().toLocaleDateString('ar-SA')}`,
            employeeGoals: '',
          });
          synced++;
        }
      } catch {
        failed++;
      }

      setSyncProgress(Math.round(((i + 1) / total) * 100));
      setSyncStats({ total, synced, skipped: 0, failed });
    }

    const unmappedWithTasks = summary.members.filter(
      (m) => !memberMapping[m.clickup_id] && m.total_tasks > 0
    ).length;
    setSyncStats({ total: total + unmappedWithTasks, synced, skipped: unmappedWithTasks, failed });

    setSyncStep('done');
    await saveMemberMapping(memberMapping);
    // Record sync in history
    const syncStatus = failed === 0 ? 'success' : synced > 0 ? 'partial' : 'failed';
    await recordSyncOperation({
      month,
      sync_type: 'manual',
      status: syncStatus,
      synced_count: synced,
      skipped_count: unmappedWithTasks,
      failed_count: failed,
    });
    await refreshPerformanceKpis();
    await loadSyncHistory();
    if (synced > 0) {
      toast.success(`تم مزامنة بيانات ${synced} موظف من ClickUp بنجاح`);
    }
  }

  async function handleSaveAutoSync() {
    setSavingAutoSync(true);
    try {
      const updatedSettings: ClickUpSettings = {
        ...settings,
        auto_sync_enabled: autoSyncEnabled,
        sync_frequency: autoSyncFrequency,
        sync_day: autoSyncDay,
        sync_hour: autoSyncHour,
        auto_sync_notify: autoSyncNotify,
      };
      await saveClickUpSettings(updatedSettings);
      setSettings(updatedSettings);
      toast.success(autoSyncEnabled ? 'تم تفعيل المزامنة التلقائية' : 'تم إيقاف المزامنة التلقائية');
    } catch {
      toast.error('فشل في حفظ إعدادات الجدولة');
    } finally {
      setSavingAutoSync(false);
    }
  }

  async function handleForceSync() {
    if (!settings.default_workspace_id) {
      toast.error('يرجى تحديد مساحة العمل أولاً');
      return;
    }
    setForceSyncing(true);
    try {
      // Fetch data and sync
      await handleFetchDashboard();
      // If we have summary data, auto-sync mapped members
      if (summary && summary.members.length > 0) {
        const monthKpis = performanceKpis.filter((k) => k.month === month);
        const membersToSync = summary.members.filter(
          (m) => memberMapping[m.clickup_id] && m.total_tasks > 0
        );
        let synced = 0;
        let failed = 0;
        for (const member of membersToSync) {
          const employeeId = memberMapping[member.clickup_id];
          const emp = getEmployeeByIdFromList(employees, employeeId);
          const existingKpi = monthKpis.find((k) => k.employeeId === employeeId);
          try {
            const achievementRate = calculateKpiAchievementRate(member.completed_tasks, member.total_tasks);
            const kpiBonus = emp ? calculateKpiBonus(achievementRate, emp.basicSalary) : 0;
            const overallRating = getKpiRating(achievementRate);
            if (existingKpi) {
              await updatePerformanceKpi(existingKpi.id, {
                tasksTarget: member.total_tasks,
                tasksCompleted: member.completed_tasks,
                achievementRate,
                kpiBonus,
                overallRating,
                managerNotes: `${existingKpi.managerNotes ? existingKpi.managerNotes + '\n' : ''}مزامنة فورية - ${new Date().toLocaleDateString('ar-SA')}`,
              });
              synced++;
            } else {
              await createPerformanceKpi({
                employeeId,
                month,
                tasksTarget: member.total_tasks,
                tasksCompleted: member.completed_tasks,
                achievementRate,
                kpiBonus,
                qualityScore: 7,
                timelinessScore: 7,
                collaborationScore: 7,
                innovationScore: 7,
                overallRating,
                managerNotes: `مزامنة فورية من ClickUp - ${new Date().toLocaleDateString('ar-SA')}`,
                employeeGoals: '',
              });
              synced++;
            }
          } catch {
            failed++;
          }
        }
        const syncStatus = failed === 0 ? 'success' : synced > 0 ? 'partial' : 'failed';
        await recordSyncOperation({
          month,
          sync_type: 'manual',
          status: syncStatus,
          synced_count: synced,
          skipped_count: 0,
          failed_count: failed,
        });
        await refreshPerformanceKpis();
        await loadSyncHistory();
        toast.success(`تمت المزامنة الفورية: تم معالجة ${synced} موظف`);
      }
    } catch {
      toast.error('فشل في المزامنة الفورية');
    } finally {
      setForceSyncing(false);
    }
  }

  const mappedCount = summary
    ? summary.members.filter((m) => memberMapping[m.clickup_id] && m.total_tasks > 0).length
    : 0;

  const months: string[] = [];
  for (let m = 1; m <= 12; m++) months.push(`2026-${String(m).padStart(2, '0')}`);

  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  // Count mapped employees (from saved mapping + summary)
  const totalMappedEmployees = Object.keys(memberMapping).length;

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <Link2 className="w-12 h-12 text-purple-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى تكامل ClickUp</p>
            <Button onClick={login} className="bg-purple-600 hover:bg-purple-700">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <Link2 className="w-5 h-5 text-purple-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">تكامل ClickUp</h1>
              <p className="text-xs text-[#64748B]">ربط مهام ClickUp بمؤشرات الأداء تلقائياً</p>
            </div>
            <div className="mr-auto flex items-center gap-2">
              {connectionStatus === 'success' && (
                <Badge className="bg-emerald-100 text-emerald-700 border-0 gap-1">
                  <CheckCircle2 className="w-3 h-3" /> متصل
                </Badge>
              )}
              {connectionStatus === 'error' && (
                <Badge className="bg-red-100 text-red-700 border-0 gap-1">
                  <AlertTriangle className="w-3 h-3" /> غير متصل
                </Badge>
              )}
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {settingsLoading || dataLoading ? (
            <div className="text-center py-20 text-gray-400">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3" />
              جاري التحميل...
            </div>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList className="grid grid-cols-5 w-full max-w-2xl">
                <TabsTrigger value="settings" className="gap-1.5">
                  <Settings className="w-4 h-4" /> الإعدادات
                </TabsTrigger>
                <TabsTrigger value="mapping" className="gap-1.5">
                  <Users className="w-4 h-4" /> ربط الموظفين
                </TabsTrigger>
                <TabsTrigger value="schedule" className="gap-1.5">
                  <CalendarClock className="w-4 h-4" /> الجدولة
                </TabsTrigger>
                <TabsTrigger value="kpis" className="gap-1.5">
                  <BarChart3 className="w-4 h-4" /> مؤشرات الأداء
                </TabsTrigger>
                <TabsTrigger value="logs" className="gap-1.5">
                  <History className="w-4 h-4" /> السجل
                </TabsTrigger>
              </TabsList>

              {/* ===== TAB 1: SETTINGS ===== */}
              <TabsContent value="settings" className="space-y-4">
                {/* Connection Settings */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Shield className="w-4 h-4 text-purple-600" />
                      إعدادات الاتصال
                    </CardTitle>
                    <CardDescription>أدخل مفتاح API للاتصال بـ ClickUp واختر مساحة العمل</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* API Token */}
                    <div>
                      <Label className="text-xs mb-1 block">ClickUp API Token *</Label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Input
                            type={showToken ? 'text' : 'password'}
                            value={settings.api_token}
                            onChange={(e) => setSettings({ ...settings, api_token: e.target.value })}
                            placeholder="pk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                            className="pl-10"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-7"
                            onClick={() => setShowToken(!showToken)}
                          >
                            {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                        </div>
                        <Button
                          onClick={handleTestConnection}
                          disabled={connectionStatus === 'testing' || !settings.api_token}
                          variant="outline"
                          className="gap-2 border-purple-300 text-purple-700 hover:bg-purple-50"
                        >
                          {connectionStatus === 'testing' ? (
                            <><Loader2 className="w-4 h-4 animate-spin" /> اختبار...</>
                          ) : (
                            <><Zap className="w-4 h-4" /> اختبار الاتصال</>
                          )}
                        </Button>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-1">
                        يمكنك الحصول على التوكن من: ClickUp → Settings → Apps → API Token
                      </p>
                      {connectionStatus === 'success' && (
                        <div className="flex items-center gap-1 mt-1 text-xs text-emerald-600">
                          <CheckCircle2 className="w-3 h-3" /> تم التحقق من الاتصال بنجاح
                        </div>
                      )}
                      {connectionStatus === 'error' && (
                        <div className="flex items-center gap-1 mt-1 text-xs text-red-600">
                          <AlertTriangle className="w-3 h-3" /> فشل الاتصال - تأكد من صحة التوكن
                        </div>
                      )}
                    </div>

                    {/* Workspace Selection */}
                    <div>
                      <Label className="text-xs mb-1 block">مساحة العمل الافتراضية</Label>
                      {!connectionStatus || connectionStatus === 'idle' || connectionStatus === 'error' ? (
                        <div className="text-center py-6 text-gray-400 border rounded-lg">
                          <Link2 className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                          <p className="text-sm">أدخل التوكن واختبر الاتصال أولاً</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {workspaces.map((ws) => (
                            <div
                              key={ws.id}
                              className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                                settings.default_workspace_id === ws.id
                                  ? 'border-purple-500 bg-purple-50'
                                  : 'hover:border-purple-300'
                              }`}
                              onClick={() => {
                                setSettings({
                                  ...settings,
                                  default_workspace_id: ws.id,
                                  default_workspace_name: ws.name,
                                });
                              }}
                            >
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium text-sm">{ws.name}</p>
                                  <p className="text-xs text-gray-500">ID: {ws.id}</p>
                                </div>
                                {settings.default_workspace_id === ws.id && (
                                  <CheckCircle2 className="w-5 h-5 text-purple-600" />
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="flex justify-end pt-2 border-t">
                      <Button
                        onClick={handleSaveSettings}
                        disabled={settingsSaving}
                        className="bg-[#1E3A5F] hover:bg-[#2a4f7a] gap-2"
                      >
                        {settingsSaving ? (
                          <><Loader2 className="w-4 h-4 animate-spin" /> جاري الحفظ...</>
                        ) : (
                          <><Save className="w-4 h-4" /> حفظ الإعدادات</>
                        )}
                      </Button>
                    </div>

                    {settings.last_sync_at && (
                      <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-600">
                        <strong>مساحة العمل النشطة:</strong> {settings.default_workspace_name}
                        <br />
                        <strong>آخر مزامنة:</strong> {settings.last_sync_at ? new Date(settings.last_sync_at).toLocaleString('ar-OM') : 'لم تتم المزامنة بعد'}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ===== TAB 2: MAPPING ===== */}
              <TabsContent value="mapping" className="space-y-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Users className="w-4 h-4 text-purple-600" />
                      ربط الموظفين بحسابات ClickUp
                    </CardTitle>
                    <CardDescription>اربط كل موظف بحسابه في ClickUp لحساب مؤشرات الأداء تلقائياً. اضغط "جلب الأعضاء" أولاً.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!settings.default_workspace_id ? (
                      <div className="text-center py-8 text-gray-400">
                        <Link2 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p className="font-medium">يرجى اختيار مساحة عمل أولاً من تبويب الإعدادات</p>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-purple-700 border-purple-300">
                              {settings.default_workspace_name}
                            </Badge>
                            <Badge className="bg-emerald-100 text-emerald-700 border-0">
                              {totalMappedEmployees} مربوط
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              onClick={handleFetchDashboard}
                              disabled={loadingSummary}
                              variant="outline"
                              className="gap-2"
                              size="sm"
                            >
                              {loadingSummary ? (
                                <><Loader2 className="w-4 h-4 animate-spin" /> جاري الجلب...</>
                              ) : (
                                <><RefreshCw className="w-4 h-4" /> جلب الأعضاء</>
                              )}
                            </Button>
                            <Button
                              onClick={async () => {
                                const ok = await saveMemberMapping(memberMapping);
                                if (ok) toast.success('تم حفظ الربط بنجاح!');
                                else toast.error('فشل في حفظ الربط');
                              }}
                              variant="outline"
                              className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50"
                              size="sm"
                            >
                              <Save className="w-4 h-4" /> حفظ الربط
                            </Button>
                          </div>
                        </div>

                        {summary && summary.members.length > 0 ? (
                          <div className="space-y-2 max-h-[500px] overflow-y-auto">
                            {summary.members
                              .sort((a, b) => b.total_tasks - a.total_tasks)
                              .map((member) => {
                                const isMapped = !!memberMapping[member.clickup_id];
                                const mappedEmp = isMapped
                                  ? getEmployeeByIdFromList(employees, memberMapping[member.clickup_id])
                                  : null;
                                return (
                                  <div
                                    key={member.clickup_id}
                                    className={`flex items-center gap-4 border rounded-lg p-3 ${
                                      isMapped ? 'border-emerald-200 bg-emerald-50/50' : 'border-gray-200'
                                    }`}
                                  >
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2">
                                        {isMapped ? (
                                          <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                                        ) : (
                                          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                                        )}
                                        <div>
                                          <p className="text-sm font-medium">{member.username || member.email || 'بدون اسم'}</p>
                                          <p className="text-[10px] text-gray-500">{member.email}</p>
                                        </div>
                                      </div>
                                      <div className="flex gap-3 mt-1 text-[10px] text-gray-500 mr-6">
                                        <span>المهام: <strong className="text-gray-700">{member.total_tasks}</strong></span>
                                        <span>المكتملة: <strong className="text-emerald-600">{member.completed_tasks}</strong></span>
                                        <span>الإنجاز: <strong className="text-blue-600">{member.completion_rate}%</strong></span>
                                      </div>
                                    </div>
                                    <div className="w-[220px]">
                                      <Select
                                        value={memberMapping[member.clickup_id] || 'none'}
                                        onValueChange={(v) => {
                                          setMemberMapping((prev) => {
                                            const next = { ...prev };
                                            if (v === 'none') {
                                              delete next[member.clickup_id];
                                            } else {
                                              next[member.clickup_id] = v;
                                            }
                                            return next;
                                          });
                                        }}
                                      >
                                        <SelectTrigger className="h-8 text-xs">
                                          <SelectValue placeholder="اختر الموظف" />
                                        </SelectTrigger>
                                        <SelectContent position="popper" className="z-[9999] max-h-[200px] overflow-y-auto">
                                          <SelectItem value="none">-- غير مربوط --</SelectItem>
                                          {employees.map((e) => (
                                            <SelectItem key={e.id} value={e.id}>
                                              {e.fullName} {e.department ? `- ${e.department}` : ''} ({e.email})
                                            </SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <div>
                                      {isMapped ? (
                                        <Badge className="bg-emerald-100 text-emerald-700 border-0 text-xs">
                                          مربوط
                                        </Badge>
                                      ) : (
                                        <Badge variant="secondary" className="text-xs">
                                          غير مربوط
                                        </Badge>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-400">
                            <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                            <p className="font-medium">اضغط "جلب الأعضاء" لعرض أعضاء ClickUp</p>
                            <p className="text-xs mt-1">سيتم جلب الأعضاء ومهامهم من مساحة العمل المحددة</p>
                            <p className="text-xs mt-2 text-purple-500">💡 المطابقة التلقائية تدعم: البريد الإلكتروني، الاسم الكامل، الاسم الجزئي، والتقاطعات</p>
                          </div>
                        )}
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ===== TAB 3: SCHEDULE ===== */}
              <TabsContent value="schedule" className="space-y-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <CalendarClock className="w-4 h-4 text-blue-600" />
                      المزامنة التلقائية
                    </CardTitle>
                    <CardDescription>
                      جدولة مزامنة تلقائية لجلب بيانات المهام من ClickUp وحساب مؤشرات الأداء
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {!settings.default_workspace_id ? (
                      <div className="text-center py-8 text-gray-400">
                        <Settings className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p className="font-medium">يرجى إعداد مساحة عمل ClickUp أولاً من تبويب الإعدادات</p>
                      </div>
                    ) : (
                      <>
                        {/* Enable/Disable Toggle */}
                        <div className="flex items-center justify-between border rounded-lg p-4">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full ${autoSyncEnabled ? 'bg-emerald-100' : 'bg-gray-100'}`}>
                              <Clock className={`w-5 h-5 ${autoSyncEnabled ? 'text-emerald-600' : 'text-gray-400'}`} />
                            </div>
                            <div>
                              <p className="text-sm font-medium">تفعيل المزامنة التلقائية</p>
                              <p className="text-xs text-gray-500">
                                {autoSyncEnabled ? 'المزامنة التلقائية مفعلة' : 'المزامنة التلقائية معطلة'}
                              </p>
                            </div>
                          </div>
                          <Switch
                            checked={autoSyncEnabled}
                            onCheckedChange={setAutoSyncEnabled}
                          />
                        </div>

                        {/* Schedule Settings */}
                        <div className={`space-y-4 transition-opacity ${autoSyncEnabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                              <Label className="text-xs mb-1 block">التكرار</Label>
                              <Select value={autoSyncFrequency} onValueChange={(v) => setAutoSyncFrequency(v as 'weekly' | 'biweekly' | 'monthly')}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="weekly">أسبوعياً</SelectItem>
                                  <SelectItem value="biweekly">كل أسبوعين</SelectItem>
                                  <SelectItem value="monthly">شهرياً</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label className="text-xs mb-1 block">
                                {autoSyncFrequency === 'monthly' ? 'يوم الشهر' : 'يوم الأسبوع'}
                              </Label>
                              <Select value={String(autoSyncDay)} onValueChange={(v) => setAutoSyncDay(parseInt(v))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {autoSyncFrequency === 'monthly' ? (
                                    MONTH_DAYS.map((d) => (
                                      <SelectItem key={d.value} value={d.value}>يوم {d.label}</SelectItem>
                                    ))
                                  ) : (
                                    DAYS_OF_WEEK.map((d) => (
                                      <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                                    ))
                                  )}
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label className="text-xs mb-1 block">الساعة</Label>
                              <Select value={String(autoSyncHour)} onValueChange={(v) => setAutoSyncHour(parseInt(v))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {HOURS.map((h) => (
                                    <SelectItem key={h.value} value={h.value}>{h.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          {/* Notifications */}
                          <div className="flex items-center justify-between border rounded-lg p-4">
                            <div className="flex items-center gap-3">
                              {autoSyncNotify ? (
                                <Bell className="w-5 h-5 text-blue-600" />
                              ) : (
                                <BellOff className="w-5 h-5 text-gray-400" />
                              )}
                              <div>
                                <p className="text-sm font-medium">إشعار بعد المزامنة</p>
                                <p className="text-xs text-gray-500">إرسال إشعار للمدير بنتيجة المزامنة التلقائية</p>
                              </div>
                            </div>
                            <Switch
                              checked={autoSyncNotify}
                              onCheckedChange={setAutoSyncNotify}
                            />
                          </div>

                          {/* Schedule Summary */}
                          {autoSyncEnabled && (
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                              <p className="text-sm font-medium text-blue-800">ملخص الجدولة</p>
                              <p className="text-sm text-blue-700 mt-1">
                                ستتم المزامنة <strong>{getFrequencyLabel(autoSyncFrequency)}</strong> في{' '}
                                <strong>{getDayLabel(autoSyncFrequency, autoSyncDay)}</strong> الساعة{' '}
                                <strong>{String(autoSyncHour).padStart(2, '0')}:00</strong>
                                {autoSyncNotify && ' مع إرسال إشعار بالنتيجة'}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-3 pt-2 border-t">
                          <Button
                            onClick={handleSaveAutoSync}
                            disabled={savingAutoSync}
                            className="bg-[#1E3A5F] hover:bg-[#2a4f7a] gap-2"
                          >
                            {savingAutoSync ? (
                              <><Loader2 className="w-4 h-4 animate-spin" /> جاري الحفظ...</>
                            ) : (
                              <><CalendarClock className="w-4 h-4" /> حفظ إعدادات الجدولة</>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            onClick={handleForceSync}
                            disabled={forceSyncing}
                            className="gap-2"
                          >
                            {forceSyncing ? (
                              <><Loader2 className="w-4 h-4 animate-spin" /> جاري المزامنة...</>
                            ) : (
                              <><Play className="w-4 h-4" /> تشغيل المزامنة الآن</>
                            )}
                          </Button>
                        </div>

                        {/* Current Status */}
                        <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                          <p className="text-sm font-medium">حالة المزامنة التلقائية</p>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">الحالة: </span>
                              {settings.auto_sync_enabled ? (
                                <Badge className="bg-emerald-100 text-emerald-700 border-0">مفعلة</Badge>
                              ) : (
                                <Badge variant="secondary">معطلة</Badge>
                              )}
                            </div>
                            <div>
                              <span className="text-gray-500">التكرار: </span>
                              <span>{getFrequencyLabel(settings.sync_frequency ?? 'monthly')}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">آخر مزامنة: </span>
                              <span>
                                {settings.last_sync_at
                                  ? new Date(settings.last_sync_at).toLocaleString('ar-OM')
                                  : 'لم تتم بعد'}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500">المزامنة التالية: </span>
                              <span>
                                {settings.next_auto_sync_at
                                  ? new Date(settings.next_auto_sync_at).toLocaleString('ar-OM')
                                  : 'غير محددة'}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Frequency Guide */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="font-semibold text-blue-700">أسبوعي</p>
                            <p className="text-gray-600">مناسب للفرق ذات المهام السريعة والمشاريع القصيرة</p>
                          </div>
                          <div className="p-3 bg-purple-50 rounded-lg">
                            <p className="font-semibold text-purple-700">نصف شهري</p>
                            <p className="text-gray-600">مناسب للمتابعة المنتظمة مع مرونة كافية</p>
                          </div>
                          <div className="p-3 bg-emerald-50 rounded-lg">
                            <p className="font-semibold text-emerald-700">شهري</p>
                            <p className="text-gray-600">مناسب لتقييم الأداء الشهري وحساب KPI</p>
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ===== TAB 4: KPIs ===== */}
              <TabsContent value="kpis" className="space-y-4">
                {/* Controls */}
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    <Select value={month} onValueChange={setMonth}>
                      <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {months.map((m) => (
                          <SelectItem key={m} value={m}>
                            {monthNames[m.split('-')[1]]} {m.split('-')[0]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {settings.default_workspace_name && (
                      <Badge variant="outline" className="text-purple-700 border-purple-300">
                        {settings.default_workspace_name}
                      </Badge>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleFetchDashboard}
                      disabled={loadingSummary || !settings.api_token}
                      className="bg-purple-600 hover:bg-purple-700 gap-2"
                    >
                      {loadingSummary ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> جاري الجلب...</>
                      ) : (
                        <><RefreshCw className="w-4 h-4" /> جلب البيانات</>
                      )}
                    </Button>
                    <Button
                      onClick={openSyncDialog}
                      disabled={!summary || summary.members.length === 0}
                      variant="outline"
                      className="gap-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                    >
                      <Zap className="w-4 h-4" /> مزامنة مع KPI
                    </Button>
                  </div>
                </div>

                {!settings.api_token ? (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Settings className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">لم يتم تكوين الاتصال</h3>
                      <p className="text-sm text-gray-500 mb-4">يرجى الانتقال إلى تبويب "الإعدادات" لإدخال ClickUp API Token أولاً</p>
                    </CardContent>
                  </Card>
                ) : !summary ? (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <BarChart3 className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">اضغط "جلب البيانات" لعرض المهام</h3>
                      <p className="text-sm text-gray-500">سيتم جلب بيانات المهام من ClickUp لشهر {monthNames[month.split('-')[1]]}</p>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Users className="w-6 h-6 text-purple-500 mx-auto mb-1" />
                          <p className="text-2xl font-bold text-purple-600">{summary.members.length}</p>
                          <p className="text-xs text-gray-500">أعضاء الفريق</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <BarChart3 className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                          <p className="text-2xl font-bold text-blue-600">{summary.total_tasks}</p>
                          <p className="text-xs text-gray-500">إجمالي المهام</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                          <p className="text-2xl font-bold text-emerald-600">{summary.total_completed}</p>
                          <p className="text-xs text-gray-500">المهام المكتملة</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <ArrowDownUp className="w-6 h-6 text-amber-500 mx-auto mb-1" />
                          <p className="text-2xl font-bold text-amber-600">
                            {summary.total_tasks > 0 ? Math.round((summary.total_completed / summary.total_tasks) * 100) : 0}%
                          </p>
                          <p className="text-xs text-gray-500">نسبة الإنجاز</p>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Members Table */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <Users className="w-4 h-4 text-purple-600" />
                          أعضاء الفريق ومهامهم
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <ScrollArea className="w-full">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-gray-50">
                                <TableHead className="text-right">العضو</TableHead>
                                <TableHead className="text-right">البريد الإلكتروني</TableHead>
                                <TableHead className="text-center">إجمالي المهام</TableHead>
                                <TableHead className="text-center">المكتملة</TableHead>
                                <TableHead className="text-center">قيد التنفيذ</TableHead>
                                <TableHead className="text-center">نسبة الإنجاز</TableHead>
                                <TableHead className="text-right">الموظف المرتبط</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {summary.members
                                .sort((a, b) => b.total_tasks - a.total_tasks)
                                .map((member) => {
                                  const mappedEmpId = memberMapping[member.clickup_id];
                                  const mappedEmp = mappedEmpId ? getEmployeeByIdFromList(employees, mappedEmpId) : null;
                                  return (
                                    <TableRow key={member.clickup_id} className="hover:bg-gray-50">
                                      <TableCell className="font-medium text-sm">
                                        {member.username || 'بدون اسم'}
                                      </TableCell>
                                      <TableCell className="text-xs text-gray-500">{member.email}</TableCell>
                                      <TableCell className="text-center font-semibold">{member.total_tasks}</TableCell>
                                      <TableCell className="text-center text-emerald-600 font-semibold">{member.completed_tasks}</TableCell>
                                      <TableCell className="text-center text-blue-600">{member.in_progress_tasks}</TableCell>
                                      <TableCell>
                                        <div className="flex items-center justify-center gap-2">
                                          <Progress value={member.completion_rate} className="h-2 w-16" />
                                          <span className="text-xs font-semibold">{member.completion_rate}%</span>
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        {mappedEmp ? (
                                          <Badge className="bg-emerald-100 text-emerald-700 border-0 text-xs">
                                            {mappedEmp.fullName}
                                          </Badge>
                                        ) : (
                                          <Badge variant="outline" className="text-gray-400 text-xs">
                                            غير مرتبط
                                          </Badge>
                                        )}
                                      </TableCell>
                                    </TableRow>
                                  );
                                })}
                            </TableBody>
                          </Table>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  </>
                )}
              </TabsContent>

              {/* ===== TAB 5: LOGS ===== */}
              <TabsContent value="logs" className="space-y-4">
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <History className="w-4 h-4 text-blue-600" />
                        سجل عمليات المزامنة
                      </CardTitle>
                      <CardDescription>آخر عمليات المزامنة مع ClickUp (يدوية وتلقائية)</CardDescription>
                      <Button variant="outline" size="sm" onClick={loadSyncHistory} disabled={loadingHistory}>
                        <RefreshCw className={`w-4 h-4 ${loadingHistory ? 'animate-spin' : ''}`} />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {syncHistory.length === 0 ? (
                      <div className="text-center py-8">
                        <History className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                        <p className="text-sm text-gray-500">لا توجد عمليات مزامنة سابقة</p>
                        <p className="text-xs text-gray-400 mt-1">ستظهر هنا سجلات المزامنة بعد إجراء أول عملية</p>
                      </div>
                    ) : (
                      <ScrollArea className="max-h-[400px]">
                        <div className="space-y-2">
                          {syncHistory.map((record) => (
                            <div
                              key={record.id}
                              className={`flex items-center gap-3 border rounded-lg p-3 ${
                                record.status === 'success' ? 'border-emerald-200 bg-emerald-50/30' :
                                record.status === 'partial' ? 'border-amber-200 bg-amber-50/30' :
                                'border-red-200 bg-red-50/30'
                              }`}
                            >
                              {record.status === 'success' ? (
                                <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                              ) : record.status === 'partial' ? (
                                <ArrowDownUp className="w-5 h-5 text-amber-500 flex-shrink-0" />
                              ) : (
                                <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0" />
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-sm font-medium">
                                    {record.sync_type === 'manual' ? 'مزامنة يدوية' :
                                     record.sync_type === 'auto' ? 'مزامنة تلقائية' : record.sync_type}
                                  </span>
                                  {record.sync_type === 'auto' && (
                                    <Badge variant="outline" className="text-xs">
                                      <CalendarClock className="w-3 h-3 ml-1" /> تلقائي
                                    </Badge>
                                  )}
                                  <Badge variant={record.status === 'success' ? 'default' : record.status === 'partial' ? 'secondary' : 'destructive'}>
                                    {record.status === 'success' ? 'ناجح' : record.status === 'partial' ? 'جزئي' : 'فشل'}
                                  </Badge>
                                </div>
                                <div className="flex gap-4 text-xs text-gray-600">
                                  <span>{record.created_at}</span>
                                  <span>الشهر: <strong>{record.month}</strong></span>
                                  <span>تم مزامنته: <strong className="text-emerald-600">{record.synced_count}</strong></span>
                                  <span>تم تخطيه: <strong className="text-amber-600">{record.skipped_count}</strong></span>
                                  <span>فشل: <strong className="text-red-600">{record.failed_count}</strong></span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </main>
      </div>

      {/* Sync Dialog */}
      <Dialog open={syncDialogOpen} onOpenChange={(open) => { if (!open && syncStep !== 'syncing') setSyncDialogOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-emerald-600" />
              مزامنة بيانات ClickUp مع مؤشرات الأداء
            </DialogTitle>
          </DialogHeader>

          {/* Mapping Step */}
          {syncStep === 'mapping' && summary && (
            <div className="space-y-4 py-2">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <p className="text-xs text-purple-700">
                  🔗 ربط أعضاء ClickUp بالموظفين لشهر <strong>{monthNames[month.split('-')[1]]} {month.split('-')[0]}</strong>
                </p>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-purple-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-purple-600">{summary.members.length}</p>
                  <p className="text-xs text-gray-600">عضو</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-blue-600">{summary.total_tasks}</p>
                  <p className="text-xs text-gray-600">مهمة</p>
                </div>
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-emerald-600">{mappedCount}</p>
                  <p className="text-xs text-gray-600">سيتم مزامنتهم</p>
                </div>
              </div>

              <div className="max-h-[300px] overflow-y-auto space-y-2">
                {summary.members
                  .sort((a, b) => b.total_tasks - a.total_tasks)
                  .map((member) => {
                    const isMapped = !!memberMapping[member.clickup_id];
                    return (
                      <div
                        key={member.clickup_id}
                        className={`border rounded-lg p-3 ${isMapped ? 'border-emerald-200 bg-emerald-50/50' : 'border-gray-200'}`}
                      >
                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className="flex-1 min-w-[180px]">
                            <div className="flex items-center gap-2">
                              {isMapped ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                              ) : (
                                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                              )}
                              <div>
                                <p className="text-sm font-medium">{member.username || member.email}</p>
                                <p className="text-[10px] text-gray-500">{member.email}</p>
                              </div>
                            </div>
                            <div className="flex gap-3 mt-1 text-[10px] text-gray-500">
                              <span>المهام: <strong className="text-gray-700">{member.total_tasks}</strong></span>
                              <span>المكتملة: <strong className="text-emerald-600">{member.completed_tasks}</strong></span>
                              <span>الإنجاز: <strong className="text-blue-600">{member.completion_rate}%</strong></span>
                            </div>
                          </div>
                          <div className="w-[200px]">
                            <Select
                              value={memberMapping[member.clickup_id] || 'none'}
                              onValueChange={(v) => {
                                setMemberMapping((prev) => {
                                  const next = { ...prev };
                                  if (v === 'none') {
                                    delete next[member.clickup_id];
                                  } else {
                                    next[member.clickup_id] = v;
                                  }
                                  return next;
                                });
                              }}
                            >
                              <SelectTrigger className="h-8 text-xs">
                                <SelectValue placeholder="اختر الموظف" />
                              </SelectTrigger>
                              <SelectContent position="popper" className="z-[9999] max-h-[200px] overflow-y-auto">
                                <SelectItem value="none">-- غير مربوط --</SelectItem>
                                {employees.map((e) => (
                                  <SelectItem key={e.id} value={e.id}>
                                    {e.fullName} {e.department ? `- ${e.department}` : ''} ({e.email})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setSyncDialogOpen(false)}>إلغاء</Button>
                <Button
                  variant="outline"
                  onClick={async () => {
                    const ok = await saveMemberMapping(memberMapping);
                    if (ok) toast.success('تم حفظ الربط بنجاح! سيتم تذكره في المرات القادمة.');
                    else toast.error('فشل في حفظ الربط');
                  }}
                  className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50"
                >
                  <Save className="w-4 h-4" /> حفظ الربط
                </Button>
                <Button
                  onClick={handleSync}
                  disabled={mappedCount === 0}
                  className="bg-emerald-600 hover:bg-emerald-700 gap-2"
                >
                  <Zap className="w-4 h-4" /> مزامنة {mappedCount} موظف
                </Button>
              </DialogFooter>
            </div>
          )}

          {/* Syncing Step */}
          {syncStep === 'syncing' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <RefreshCw className="w-10 h-10 text-emerald-500 mx-auto mb-3 animate-spin" />
                <p className="font-medium text-gray-700">جاري مزامنة البيانات...</p>
              </div>
              <Progress value={syncProgress} className="h-3" />
              <p className="text-center text-sm text-gray-600">{syncProgress}%</p>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded p-2">
                  <p className="text-lg font-bold text-emerald-600">{syncStats.synced}</p>
                  <p className="text-xs text-gray-500">تم بنجاح</p>
                </div>
                <div className="bg-red-50 rounded p-2">
                  <p className="text-lg font-bold text-red-600">{syncStats.failed}</p>
                  <p className="text-xs text-gray-500">فشل</p>
                </div>
                <div className="bg-amber-50 rounded p-2">
                  <p className="text-lg font-bold text-amber-600">{syncStats.skipped}</p>
                  <p className="text-xs text-gray-500">تم تخطيه</p>
                </div>
              </div>
            </div>
          )}

          {/* Done Step */}
          {syncStep === 'done' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="font-bold text-lg text-gray-800">تمت المزامنة!</p>
                <p className="text-sm text-gray-500 mt-1">
                  تم تحديث مؤشرات الأداء من ClickUp لشهر {monthNames[month.split('-')[1]]}
                </p>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-emerald-600">{syncStats.synced}</p>
                  <p className="text-xs text-gray-600">تم مزامنته</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-red-600">{syncStats.failed}</p>
                  <p className="text-xs text-gray-600">فشل</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-amber-600">{syncStats.skipped}</p>
                  <p className="text-xs text-gray-600">غير مربوط</p>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => setSyncDialogOpen(false)} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                  إغلاق
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}