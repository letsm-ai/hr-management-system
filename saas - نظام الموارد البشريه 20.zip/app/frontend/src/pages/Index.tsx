import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Users, CalendarCheck, Clock, AlertTriangle, Award, TrendingDown,
  Lightbulb, Timer, LayoutDashboard, UserCog, CalendarDays,
  BarChart3, FileText, ChevronRight, Menu, X,
  LogIn, LogOut, UserCircle, Shield, ClipboardList, Link2,
  TrendingUp, Database,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  getDashboardStats, getCurrentMonth, formatCurrency,
} from '@/lib/hr-api';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import ContractAlertsBell from '@/components/ContractAlertsBell';

const NAV_ITEMS = [
  { path: '/', label: 'لوحة المعلومات', icon: LayoutDashboard },
  { path: '/employees', label: 'بيانات الموظفين', icon: UserCog },
  { path: '/attendance-management', label: 'إدارة الدوام', icon: CalendarDays },
  { path: '/contracts-management', label: 'إدارة العقود', icon: FileText },
  { path: '/evaluation-sync', label: 'التقييم والمزامنة', icon: BarChart3 },
  { path: '/financial-outputs', label: 'المخرجات المالية', icon: Award },
  { path: '/requests', label: 'إدارة الطلبات', icon: ClipboardList },
  { path: '/revenue-dashboard', label: 'لوحة الإيرادات', icon: TrendingUp },
  { path: '/clickup', label: 'تكامل ClickUp', icon: Link2 },
  { path: '/user-management', label: 'إدارة المستخدمين', icon: Shield },
  { path: '/data-sync', label: 'مزامنة البيانات', icon: Database },
];

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const location = useLocation();
  const { user, loading, login, logout } = useAuth();

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed top-0 right-0 z-50 h-full w-72 bg-[#1E3A5F] text-white transform transition-transform duration-300 lg:translate-x-0 ${
          open ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-sm">نظام إدارة الموارد البشرية</h1>
              <p className="text-xs text-white/60">الإصدار 2.0</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="lg:hidden text-white hover:bg-white/10" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <ScrollArea className="h-[calc(100vh-80px-72px)]">
          <nav className="p-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={onClose}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all ${
                    isActive
                      ? 'bg-white/20 text-white font-semibold'
                      : 'text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <item.icon className="w-5 h-5 shrink-0" />
                  <span>{item.label}</span>
                  {isActive && <ChevronRight className="w-4 h-4 mr-auto rotate-180" />}
                </Link>
              );
            })}
          </nav>

          <div className="p-4 mx-3 mt-4 rounded-lg bg-white/10">
            <p className="text-xs text-white/60 mb-1">قانون العمل العماني</p>
            <p className="text-xs text-white/80">إجازة سنوية: 30 يوم</p>
            <p className="text-xs text-white/80">إجازة مرضية: 15 يوم</p>
            <p className="text-xs text-white/80">ساعات العمل: 8 يومياً</p>
          </div>
        </ScrollArea>

        {/* Auth Section at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10 bg-[#1E3A5F]">
          {loading ? (
            <div className="flex items-center gap-3 px-2">
              <div className="w-8 h-8 rounded-full bg-white/20 animate-pulse" />
              <span className="text-xs text-white/50">جاري التحميل...</span>
            </div>
          ) : user ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-8 h-8 rounded-full bg-emerald-500/30 flex items-center justify-center shrink-0">
                  <UserCircle className="w-5 h-5 text-emerald-300" />
                </div>
                <span className="text-xs text-white/80 truncate">متصل</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-white/70 hover:text-white hover:bg-white/10 gap-1 text-xs shrink-0"
              >
                <LogOut className="w-4 h-4" />
                خروج
              </Button>
            </div>
          ) : (
            <Button
              onClick={login}
              className="w-full bg-white/20 hover:bg-white/30 text-white gap-2 text-sm"
            >
              <LogIn className="w-4 h-4" />
              تسجيل الدخول
            </Button>
          )}
        </div>
      </aside>
    </>
  );
}

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, ideas, overtime, violations, loading: dataLoading } = useHRData();

  const stats = getDashboardStats(selectedMonth, employees, attendance, ideas, overtime, violations);

  const months = [];
  for (let m = 1; m <= 12; m++) {
    months.push(`2026-${String(m).padStart(2, '0')}`);
  }

  const monthNames: Record<string, string> = {
    '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
    '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
    '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
  };

  if (authLoading || dataLoading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E3A5F] mx-auto mb-4" />
          <p className="text-[#64748B]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="lg:mr-72">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-lg font-bold text-[#1E293B]">لوحة المعلومات الرئيسية</h1>
                <p className="text-xs text-[#64748B]">نظرة عامة على أداء الشركة</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <ContractAlertsBell />
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map((m) => (
                    <SelectItem key={m} value={m}>
                      {monthNames[m.split('-')[1]]} {m.split('-')[0]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="p-4 lg:p-6 space-y-6">
          {/* Hero Banner */}
          <div className="relative rounded-2xl overflow-hidden h-40 lg:h-48">
            <img
              src="https://mgx-backend-cdn.metadl.com/generate/images/867866/2026-03-01/99e8dfe1-19a7-4fda-b30d-c98888effb36.png"
              alt="HR Dashboard"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-[#1E3A5F]/90 to-[#1E3A5F]/50 flex items-center">
              <div className="px-6 lg:px-10">
                <h2 className="text-2xl lg:text-3xl font-bold text-white mb-2">
                  مرحباً بك في نظام الموارد البشرية
                </h2>
                <p className="text-white/80 text-sm lg:text-base">
                  {monthNames[selectedMonth.split('-')[1]]} {selectedMonth.split('-')[0]} • {stats.activeEmployees} موظف نشط
                </p>
              </div>
            </div>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <KPICard title="إجمالي الموظفين" value={stats.totalEmployees} subtitle={`${stats.activeEmployees} نشط`} icon={<Users className="w-5 h-5" />} color="bg-blue-500" />
            <KPICard title="معدل الحضور" value={`${stats.attendanceRate}%`} subtitle={`${stats.presentCount} يوم حضور`} icon={<CalendarCheck className="w-5 h-5" />} color="bg-emerald-500" />
            <KPICard title="إجمالي التأخير" value={`${stats.totalTardiness}`} subtitle="دقيقة" icon={<Clock className="w-5 h-5" />} color="bg-amber-500" />
            <KPICard title="حالات الغياب" value={stats.absentCount} subtitle="يوم غياب" icon={<AlertTriangle className="w-5 h-5" />} color="bg-red-500" />
            <KPICard title="إجمالي المكافآت" value={formatCurrency(stats.totalRewards)} subtitle="هذا الشهر" icon={<Award className="w-5 h-5" />} color="bg-purple-500" />
            <KPICard title="إجمالي الخصومات" value={formatCurrency(stats.totalDeductions)} subtitle="هذا الشهر" icon={<TrendingDown className="w-5 h-5" />} color="bg-rose-500" />
            <KPICard title="الأفكار المقدمة" value={stats.totalIdeas} subtitle={`${stats.acceptedIdeas} مقبولة`} icon={<Lightbulb className="w-5 h-5" />} color="bg-yellow-500" />
            <KPICard title="ساعات العمل الإضافي" value={stats.totalOvertimeHours} subtitle="ساعة" icon={<Timer className="w-5 h-5" />} color="bg-indigo-500" />
          </div>

          {/* Charts & Tables Row */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Top 5 Attendance */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <CalendarCheck className="w-5 h-5 text-emerald-500" />
                  أفضل 5 موظفين من حيث الحضور
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stats.top5Attendance.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4">لا توجد بيانات</p>
                ) : (
                  <div className="space-y-3">
                    {stats.top5Attendance.map((emp, idx) => (
                      <div key={emp.id} className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                          idx === 0 ? 'bg-yellow-500' : idx === 1 ? 'bg-gray-400' : idx === 2 ? 'bg-amber-700' : 'bg-gray-300'
                        }`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{emp.fullName}</p>
                          <p className="text-xs text-gray-500">{emp.department}</p>
                        </div>
                        <div className="text-left w-24">
                          <p className="text-sm font-semibold text-emerald-600">
                            {Math.round(emp.attendanceRate)}%
                          </p>
                          <Progress value={emp.attendanceRate} className="h-1.5 mt-1" />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Department Stats */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-500" />
                  أداء الأقسام
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stats.deptStats.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4">لا توجد بيانات</p>
                ) : (
                  <div className="space-y-4">
                    {stats.deptStats.map((dept) => (
                      <div key={dept.department}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{dept.department}</span>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {dept.employeeCount} موظف
                            </Badge>
                            <span className="text-sm font-semibold">{dept.avgAttendance}%</span>
                          </div>
                        </div>
                        <Progress value={dept.avgAttendance} className="h-2" />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Alerts */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-amber-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2 text-amber-600">
                  <AlertTriangle className="w-5 h-5" />
                  تنبيهات الحضور (أقل من 90%)
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stats.lowAttendance.length === 0 ? (
                  <div className="text-center py-4">
                    <CalendarCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">جميع الموظفين ملتزمون بالحضور ✓</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {stats.lowAttendance.map((emp) => (
                      <div key={emp.id} className="flex items-center justify-between p-2 rounded-lg bg-amber-50">
                        <div>
                          <p className="text-sm font-medium">{emp.fullName}</p>
                          <p className="text-xs text-gray-500">{emp.department}</p>
                        </div>
                        <Badge variant="destructive" className="text-xs">
                          {Math.round(emp.attendanceRate)}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2 text-red-600">
                  <Clock className="w-5 h-5" />
                  تأخير متكرر (أكثر من 3 مرات)
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stats.repeatedTardiness.length === 0 ? (
                  <div className="text-center py-4">
                    <Clock className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">لا يوجد تأخير متكرر ✓</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {stats.repeatedTardiness.map((emp) => (
                      <div key={emp.id} className="flex items-center justify-between p-2 rounded-lg bg-red-50">
                        <div>
                          <p className="text-sm font-medium">{emp.fullName}</p>
                          <p className="text-xs text-gray-500">{emp.department}</p>
                        </div>
                        <div className="text-left">
                          <Badge variant="destructive" className="text-xs">
                            {emp.tardinessCount} مرات
                          </Badge>
                          <p className="text-xs text-gray-500 mt-0.5">
                            {emp.totalTardiness} دقيقة
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Summary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">ملخص سريع</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-3 rounded-lg bg-blue-50">
                  <p className="text-2xl font-bold text-blue-600">{stats.totalViolations}</p>
                  <p className="text-xs text-gray-600">مخالفات هذا الشهر</p>
                </div>
                <div className="p-3 rounded-lg bg-green-50">
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(stats.totalRewards - stats.totalDeductions)}</p>
                  <p className="text-xs text-gray-600">صافي المكافآت/الخصومات</p>
                </div>
                <div className="p-3 rounded-lg bg-purple-50">
                  <p className="text-2xl font-bold text-purple-600">{stats.acceptedIdeas}/{stats.totalIdeas}</p>
                  <p className="text-xs text-gray-600">أفكار مقبولة/إجمالي</p>
                </div>
                <div className="p-3 rounded-lg bg-indigo-50">
                  <p className="text-2xl font-bold text-indigo-600">{stats.totalOvertimeHours}h</p>
                  <p className="text-xs text-gray-600">ساعات عمل إضافي</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}

function KPICard({
  title,
  value,
  subtitle,
  icon,
  color,
}: {
  title: string;
  value: string | number;
  subtitle: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center text-white`}>
            {icon}
          </div>
        </div>
        <p className="text-2xl font-bold text-[#1E293B]">{value}</p>
        <p className="text-xs text-[#64748B] mt-1">{title}</p>
        <p className="text-xs text-[#94A3B8]">{subtitle}</p>
      </CardContent>
    </Card>
  );
}