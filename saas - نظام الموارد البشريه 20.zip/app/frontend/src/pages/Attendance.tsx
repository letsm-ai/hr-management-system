import { useState, useRef, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Plus, Pencil, Trash2, CalendarDays, Menu, Download, Upload, FileUp, CheckCircle2, XCircle, AlertTriangle, CalendarRange, Clock } from 'lucide-react';
import { Sidebar } from './Index';
import { toast } from 'sonner';
import {
  createAttendanceRecord, updateAttendanceRecord, deleteAttendanceRecord,
  createOvertimeRecord, createEmployee,
  getEmployeeNameFromList, getEmployeeByIdFromList,
  calculateTardiness, calculateEarlyDeparture, calculateActualHours,
  DAY_STATUSES, ABSENCE_TYPES, APPROVAL_STATUSES, getCurrentMonth,
  type Employee,
} from '@/lib/hr-api';
import { parseAttendanceFile, type ParsedAttendanceRow, type ParseResult } from '@/lib/attendance-file-parser';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

export default function AttendancePage({ embedded = false }: { embedded?: boolean }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [filterMonth, setFilterMonth] = useState(getCurrentMonth());
  const [filterEmployee, setFilterEmployee] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({
    date: '', employeeId: '', checkIn: '', checkOut: '',
    dayStatus: 'حاضر', absenceType: 'لا ينطبق', notes: '', approved: 'لا ينطبق',
  });
  const [saving, setSaving] = useState(false);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, overtime, loading: dataLoading, refreshAttendance, refreshOvertime, refreshEmployees } = useHRData();

  // Upload states
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [uploadStep, setUploadStep] = useState<'select' | 'preview' | 'importing' | 'done'>('select');
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [importProgress, setImportProgress] = useState(0);
  const [importStats, setImportStats] = useState({ success: 0, failed: 0, skipped: 0, created: 0 });
  const [importUnmatched, setImportUnmatched] = useState(true); // Auto-create unmatched employees
  const [employeeMapping, setEmployeeMapping] = useState<Record<string, string>>({}); // empCode/name -> employeeId manual mapping
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Bulk leave registration states
  const [bulkLeaveDialogOpen, setBulkLeaveDialogOpen] = useState(false);
  const [bulkLeaveStep, setBulkLeaveStep] = useState<'form' | 'creating' | 'done'>('form');
  const [bulkLeaveForm, setBulkLeaveForm] = useState({
    employeeId: '',
    startDate: '',
    endDate: '',
    leaveType: 'إجازة سنوية',
    absenceType: 'إجازة سنوية مدفوعة',
    approved: 'قيد المراجعة',
    notes: '',
  });
  const [bulkLeaveProgress, setBulkLeaveProgress] = useState(0);
  const [bulkLeaveStats, setBulkLeaveStats] = useState({ total: 0, success: 0, failed: 0, skipped: 0 });

  // Leave type mapping: dayStatus -> absenceType
  const LEAVE_TYPE_MAP: Record<string, string> = {
    'إجازة سنوية': 'إجازة سنوية مدفوعة',
    'إجازة مرضية': 'إجازة مرضية مدفوعة',
    'إجازة طارئة': 'إجازة طارئة مدفوعة',
    'إجازة بدون راتب': 'إجازة بدون راتب',
  };

  const LEAVE_TYPES = Object.keys(LEAVE_TYPE_MAP);

  // Calculate working days for bulk leave (skip Fri & Sat - Saudi weekends)
  const bulkLeaveDays = useMemo(() => {
    if (!bulkLeaveForm.startDate || !bulkLeaveForm.endDate) return [];
    const start = new Date(bulkLeaveForm.startDate);
    const end = new Date(bulkLeaveForm.endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) return [];
    const days: string[] = [];
    const current = new Date(start);
    while (current <= end) {
      const dow = current.getDay(); // 0=Sun, 5=Fri, 6=Sat
      if (dow !== 5 && dow !== 6) {
        days.push(current.toISOString().split('T')[0]);
      }
      current.setDate(current.getDate() + 1);
    }
    return days;
  }, [bulkLeaveForm.startDate, bulkLeaveForm.endDate]);

  // Check for existing records on the same dates for the same employee
  const existingDatesForBulk = useMemo(() => {
    if (!bulkLeaveForm.employeeId || bulkLeaveDays.length === 0) return new Set<string>();
    const empRecords = attendance.filter((a) => a.employeeId === bulkLeaveForm.employeeId);
    const existingDates = new Set(empRecords.map((a) => a.date));
    return new Set(bulkLeaveDays.filter((d) => existingDates.has(d)));
  }, [bulkLeaveForm.employeeId, bulkLeaveDays, attendance]);

  function openBulkLeave() {
    const today = new Date().toISOString().split('T')[0];
    setBulkLeaveForm({
      employeeId: employees[0]?.id || '',
      startDate: today,
      endDate: today,
      leaveType: 'إجازة سنوية',
      absenceType: 'إجازة سنوية مدفوعة',
      approved: 'قيد المراجعة',
      notes: '',
    });
    setBulkLeaveStep('form');
    setBulkLeaveProgress(0);
    setBulkLeaveStats({ total: 0, success: 0, failed: 0, skipped: 0 });
    setBulkLeaveDialogOpen(true);
  }

  async function handleBulkLeaveCreate() {
    if (!bulkLeaveForm.employeeId || bulkLeaveDays.length === 0) return;
    setBulkLeaveStep('creating');
    setBulkLeaveProgress(0);

    const emp = getEmployeeByIdFromList(employees, bulkLeaveForm.employeeId);
    const daysToCreate = bulkLeaveDays.filter((d) => !existingDatesForBulk.has(d));
    const total = daysToCreate.length;
    const skipped = bulkLeaveDays.length - daysToCreate.length;
    let success = 0;
    let failed = 0;

    setBulkLeaveStats({ total: bulkLeaveDays.length, success: 0, failed: 0, skipped });

    for (let i = 0; i < daysToCreate.length; i++) {
      try {
        await createAttendanceRecord({
          date: daysToCreate[i],
          employeeId: bulkLeaveForm.employeeId,
          checkIn: '',
          checkOut: '',
          actualHours: 0,
          requiredHours: emp?.dailyWorkHours || 8,
          tardiness: 0,
          earlyDeparture: 0,
          dayStatus: bulkLeaveForm.leaveType,
          absenceType: bulkLeaveForm.absenceType,
          notes: bulkLeaveForm.notes || `إجازة جماعية من ${bulkLeaveForm.startDate} إلى ${bulkLeaveForm.endDate}`,
          approved: bulkLeaveForm.approved,
        });
        success++;
      } catch {
        failed++;
      }
      setBulkLeaveProgress(Math.round(((i + 1) / total) * 100));
      setBulkLeaveStats({ total: bulkLeaveDays.length, success, failed, skipped });
    }

    // If all were skipped (no new days to create)
    if (total === 0) {
      setBulkLeaveProgress(100);
    }

    setBulkLeaveStep('done');
    await refreshAttendance();
    if (success > 0) {
      toast.success(`تم تسجيل ${success} يوم إجازة بنجاح`);
    }
  }

  // Normalize text for fuzzy matching (remove diacritics, extra spaces, lowercase)
  function normalizeText(text: string): string {
    return text
      .trim()
      .toLowerCase()
      .replace(/[\u064B-\u065F\u0670]/g, '') // Remove Arabic diacritics
      .replace(/[أإآ]/g, 'ا') // Normalize Alef variants
      .replace(/ة/g, 'ه') // Normalize Ta Marbuta
      .replace(/ى/g, 'ي') // Normalize Alef Maksura
      .replace(/\s+/g, ' '); // Normalize whitespace
  }

  function findEmployeeByCodeOrName(row: ParsedAttendanceRow, empList: Employee[]): Employee | undefined {
    // Match by emp_code first
    if (row.empCode) {
      const code = row.empCode.trim();
      const byCode = empList.find(e =>
        e.empCode.trim().toLowerCase() === code.toLowerCase() ||
        e.empCode.trim() === code
      );
      if (byCode) return byCode;
    }
    // Match by name (multiple strategies)
    if (row.empName) {
      const normalizedRowName = normalizeText(row.empName);
      // Exact match
      const byExact = empList.find(e => e.fullName === row.empName);
      if (byExact) return byExact;
      // Normalized exact match
      const byNormalized = empList.find(e => normalizeText(e.fullName) === normalizedRowName);
      if (byNormalized) return byNormalized;
      // Substring match (either direction)
      const bySubstring = empList.find(e =>
        normalizeText(e.fullName).includes(normalizedRowName) ||
        normalizedRowName.includes(normalizeText(e.fullName))
      );
      if (bySubstring) return bySubstring;
      // Word-based match: at least 2 words match
      const rowWords = normalizedRowName.split(' ').filter(w => w.length > 1);
      if (rowWords.length >= 2) {
        const byWords = empList.find(e => {
          const empWords = normalizeText(e.fullName).split(' ').filter(w => w.length > 1);
          const matchCount = rowWords.filter(rw => empWords.some(ew => ew === rw || ew.includes(rw) || rw.includes(ew))).length;
          return matchCount >= 2 || (matchCount >= 1 && rowWords.length <= 2);
        });
        if (byWords) return byWords;
      }
    }
    return undefined;
  }

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await parseAttendanceFile(file);
    setParseResult(result);
    setUploadStep(result.success ? 'preview' : 'select');
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  async function handleImport() {
    if (!parseResult || !parseResult.data.length) return;
    setUploadStep('importing');
    setImportProgress(0);
    setImportStats({ success: 0, failed: 0, skipped: 0, created: 0 });

    const total = parseResult.data.length;
    let success = 0;
    let failed = 0;
    let skipped = 0;
    let created = 0;

    // Cache for newly created employees during this import
    const createdEmployees: Record<string, Employee> = {};
    // Refresh employees list to get latest
    const currentEmployees = [...employees];

    for (let i = 0; i < total; i++) {
      const row = parseResult.data[i];
      const empKey = row.empCode || row.empName;

      // Check manual mapping first
      let emp: Employee | undefined;
      if (employeeMapping[empKey]) {
        emp = currentEmployees.find(e => e.id === employeeMapping[empKey]);
      }
      // Then try automatic matching
      if (!emp) {
        emp = findEmployeeByCodeOrName(row, currentEmployees);
      }
      // Check if we already created this employee in this session
      if (!emp && createdEmployees[empKey]) {
        emp = createdEmployees[empKey];
      }

      if (!emp) {
        if (importUnmatched && row.empName) {
          // Auto-create employee from fingerprint data
          try {
            const newEmp = await createEmployee({
              empCode: row.empCode || '',
              fullName: row.empName,
              department: 'غير محدد',
              jobTitle: 'غير محدد',
              hireDate: new Date().toISOString().split('T')[0],
              basicSalary: 0,
              housingAllowance: 0,
              transportAllowance: 0,
              otherAllowances: 0,
              dailyWorkHours: 8,
              status: 'نشط',
              phone: '',
              email: '',
              nationality: '',
              idNumber: '',
              bankName: '',
              bankAccount: '',
            });
            if (newEmp) {
              emp = newEmp;
              createdEmployees[empKey] = newEmp;
              currentEmployees.push(newEmp);
              created++;
            }
          } catch {
            // If creation fails, skip
          }
        }

        if (!emp) {
          skipped++;
          setImportProgress(Math.round(((i + 1) / total) * 100));
          setImportStats({ success, failed, skipped, created });
          continue;
        }
      }

      try {
        const tardiness = row.checkIn ? calculateTardiness(row.checkIn) : 0;
        const earlyDeparture = row.checkOut ? calculateEarlyDeparture(row.checkOut) : 0;
        const actualHours = row.checkIn && row.checkOut ? calculateActualHours(row.checkIn, row.checkOut) : 0;
        const dayStatus = (!row.checkIn && !row.checkOut) ? 'غائب' : 'حاضر';

        await createAttendanceRecord({
          date: row.date,
          employeeId: emp.id,
          checkIn: row.checkIn || '',
          checkOut: row.checkOut || '',
          actualHours: Math.round(actualHours * 100) / 100,
          requiredHours: emp.dailyWorkHours || 8,
          tardiness,
          earlyDeparture,
          dayStatus,
          absenceType: dayStatus === 'غائب' ? 'غياب بدون إذن' : 'لا ينطبق',
          notes: 'تم الاستيراد من ملف البصمة',
          approved: 'لا ينطبق',
        });
        success++;
      } catch {
        failed++;
      }

      setImportProgress(Math.round(((i + 1) / total) * 100));
      setImportStats({ success, failed, skipped, created });
    }

    setUploadStep('done');
    await refreshAttendance();
    // Refresh employees if new ones were created
    if (created > 0) {
      await refreshEmployees();
    }
  }

  function resetUpload() {
    setUploadStep('select');
    setParseResult(null);
    setImportProgress(0);
    setImportStats({ success: 0, failed: 0, skipped: 0, created: 0 });
    setImportUnmatched(true);
    setEmployeeMapping({});
  }

  function handleExport() {
    exportToCSV(
      filtered.map((r) => ({
        date: r.date,
        employee: getEmployeeNameFromList(employees, r.employeeId),
        checkIn: r.checkIn || '-',
        checkOut: r.checkOut || '-',
        actualHours: r.actualHours > 0 ? r.actualHours : '-',
        tardiness: r.tardiness > 0 ? r.tardiness : 0,
        dayStatus: r.dayStatus,
        absenceType: r.absenceType,
        approved: r.approved,
      })),
      [
        { key: 'date', label: 'التاريخ' },
        { key: 'employee', label: 'الموظف' },
        { key: 'checkIn', label: 'وقت الدخول' },
        { key: 'checkOut', label: 'وقت الخروج' },
        { key: 'actualHours', label: 'ساعات العمل' },
        { key: 'tardiness', label: 'التأخير (دقيقة)' },
        { key: 'dayStatus', label: 'الحالة' },
        { key: 'absenceType', label: 'نوع الغياب' },
        { key: 'approved', label: 'الموافقة' },
      ],
      `تقرير_الحضور_${filterMonth}`
    );
  }

  if (!embedded && !authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <CalendarDays className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى سجلات الحضور</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filtered = attendance.filter((r) => {
    const matchMonth = r.date.startsWith(filterMonth);
    const matchEmp = filterEmployee === 'all' || r.employeeId === filterEmployee;
    return matchMonth && matchEmp;
  }).sort((a, b) => b.date.localeCompare(a.date) || a.employeeId.localeCompare(b.employeeId));

  function openAdd() {
    setEditingId(null);
    const today = new Date().toISOString().split('T')[0];
    setForm({
      date: today, employeeId: employees[0]?.id || '', checkIn: '09:00', checkOut: '17:00',
      dayStatus: 'حاضر', absenceType: 'لا ينطبق', notes: '', approved: 'لا ينطبق',
    });
    setDialogOpen(true);
  }

  function openEdit(rec: typeof attendance[0]) {
    setEditingId(rec.id);
    setForm({
      date: rec.date, employeeId: rec.employeeId, checkIn: rec.checkIn, checkOut: rec.checkOut,
      dayStatus: rec.dayStatus, absenceType: rec.absenceType, notes: rec.notes, approved: rec.approved,
    });
    setDialogOpen(true);
  }

  async function handleSave() {
    if (!form.date || !form.employeeId) return;
    setSaving(true);
    try {
      const emp = getEmployeeByIdFromList(employees, form.employeeId);
      const tardiness = form.dayStatus === 'حاضر' ? calculateTardiness(form.checkIn) : 0;
      const earlyDeparture = form.dayStatus === 'حاضر' ? calculateEarlyDeparture(form.checkOut) : 0;
      const actualHours = form.dayStatus === 'حاضر' ? calculateActualHours(form.checkIn, form.checkOut) : 0;

      const record = {
        date: form.date,
        employeeId: form.employeeId,
        checkIn: form.checkIn,
        checkOut: form.checkOut,
        actualHours: Math.round(actualHours * 100) / 100,
        requiredHours: emp?.dailyWorkHours || 8,
        tardiness,
        earlyDeparture,
        dayStatus: form.dayStatus,
        absenceType: form.absenceType,
        notes: form.notes,
        approved: form.approved,
      };

      if (editingId) {
        await updateAttendanceRecord(editingId, record);
      } else {
        await createAttendanceRecord(record);
      }
      setDialogOpen(false);
      await refreshAttendance();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (confirm('هل أنت متأكد من حذف هذا السجل؟')) {
      await deleteAttendanceRecord(id);
      await refreshAttendance();
    }
  }

  // Check if overtime already exists for a given employee on a date
  function hasOvertimeRecord(employeeId: string, date: string): boolean {
    return overtime.some((o) => o.employeeId === employeeId && o.date === date);
  }

  // Create overtime record from attendance extra hours
  async function handleSuggestOvertime(rec: typeof attendance[0]) {
    const extraHours = Math.round((rec.actualHours - rec.requiredHours) * 100) / 100;
    if (extraHours <= 0) return;

    try {
      await createOvertimeRecord({
        date: rec.date,
        employeeId: rec.employeeId,
        dayType: 'يوم عمل',
        overtimeHours: extraHours,
        compensationMethod: 'مالي',
        approved: 'قيد المراجعة',
      });
      await refreshOvertime();
      toast.success(`تم إنشاء سجل عمل إضافي (${extraHours} ساعة) لـ ${getEmployeeNameFromList(employees, rec.employeeId)}`);
    } catch {
      toast.error('فشل في إنشاء سجل العمل الإضافي');
    }
  }

  const statusColors: Record<string, string> = {
    'حاضر': 'bg-emerald-100 text-emerald-700',
    'غائب': 'bg-red-100 text-red-700',
    'إجازة سنوية': 'bg-blue-100 text-blue-700',
    'إجازة مرضية': 'bg-purple-100 text-purple-700',
    'إجازة طارئة': 'bg-orange-100 text-orange-700',
    'إجازة بدون راتب': 'bg-gray-100 text-gray-700',
    'يوم عطلة رسمية': 'bg-cyan-100 text-cyan-700',
    'يوم راحة أسبوعية': 'bg-teal-100 text-teal-700',
  };

  const tardinessColor = (mins: number) => {
    if (mins === 0) return 'text-emerald-600';
    if (mins <= 15) return 'text-yellow-600';
    if (mins <= 30) return 'text-orange-600';
    return 'text-red-600';
  };

  const months = [];
  for (let m = 1; m <= 12; m++) {
    months.push(`2026-${String(m).padStart(2, '0')}`);
  }

  // Content that is shared between embedded and standalone modes
  const mainContent = (
    <div className={embedded ? "space-y-4" : "p-4 lg:p-6 space-y-4"}>
      {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              <Card>
                <CardContent className="p-4">
                  <div className="flex flex-wrap gap-3 items-end">
                    <div className="w-[180px]">
                      <Label className="text-xs mb-1 block">الشهر</Label>
                      <Select value={filterMonth} onValueChange={setFilterMonth}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {months.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-[200px]">
                      <Label className="text-xs mb-1 block">الموظف</Label>
                      <Select value={filterEmployee} onValueChange={setFilterEmployee}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الموظفين</SelectItem>
                          {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex gap-2 mr-auto flex-wrap">
                      <Button onClick={handleExport} variant="outline" className="gap-2">
                        <Download className="w-4 h-4" />
                        تصدير CSV
                      </Button>
                      <Button onClick={() => { resetUpload(); setUploadDialogOpen(true); }} variant="outline" className="gap-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50">
                        <Upload className="w-4 h-4" />
                        رفع ملف البصمة
                      </Button>
                      <Button onClick={openBulkLeave} variant="outline" className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50">
                        <CalendarRange className="w-4 h-4" />
                        إجازة جماعية
                      </Button>
                      <Button onClick={openAdd} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                        <Plus className="w-4 h-4 ml-2" />
                        تسجيل حضور
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">التاريخ</TableHead>
                          <TableHead className="text-right">الموظف</TableHead>
                          <TableHead className="text-right">الدخول</TableHead>
                          <TableHead className="text-right">الخروج</TableHead>
                          <TableHead className="text-right">ساعات العمل</TableHead>
                          <TableHead className="text-right">التأخير (دقيقة)</TableHead>
                          <TableHead className="text-right">الحالة</TableHead>
                          <TableHead className="text-right">الموافقة</TableHead>
                          <TableHead className="text-right">عمل إضافي</TableHead>
                          <TableHead className="text-right">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filtered.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={10} className="text-center py-8 text-gray-400">لا توجد سجلات</TableCell>
                          </TableRow>
                        ) : (
                          filtered.slice(0, 100).map((rec) => (
                            <TableRow key={rec.id} className="hover:bg-gray-50">
                              <TableCell className="text-sm">{rec.date}</TableCell>
                              <TableCell className="text-sm font-medium">{getEmployeeNameFromList(employees, rec.employeeId)}</TableCell>
                              <TableCell className="text-sm font-mono">{rec.checkIn || '-'}</TableCell>
                              <TableCell className="text-sm font-mono">{rec.checkOut || '-'}</TableCell>
                              <TableCell className="text-sm">{rec.actualHours > 0 ? `${rec.actualHours}h` : '-'}</TableCell>
                              <TableCell className={`text-sm font-semibold ${tardinessColor(rec.tardiness)}`}>
                                {rec.tardiness > 0 ? rec.tardiness : '-'}
                              </TableCell>
                              <TableCell>
                                <Badge className={`${statusColors[rec.dayStatus] || 'bg-gray-100 text-gray-700'} border-0 text-xs`}>
                                  {rec.dayStatus}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-xs">{rec.approved}</TableCell>
                              <TableCell>
                                {rec.actualHours > rec.requiredHours && rec.dayStatus === 'حاضر' ? (
                                  hasOvertimeRecord(rec.employeeId, rec.date) ? (
                                    <Badge className="bg-emerald-100 text-emerald-700 border-0 text-[10px]">مسجّل</Badge>
                                  ) : (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-7 px-2 text-[10px] text-indigo-700 hover:bg-indigo-50 gap-1"
                                      onClick={() => handleSuggestOvertime(rec)}
                                      title={`${Math.round((rec.actualHours - rec.requiredHours) * 100) / 100} ساعة إضافية`}
                                    >
                                      <Clock className="w-3 h-3" />
                                      +{Math.round((rec.actualHours - rec.requiredHours) * 10) / 10}h
                                    </Button>
                                  )
                                ) : (
                                  <span className="text-gray-300 text-xs">-</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button variant="ghost" size="icon" onClick={() => openEdit(rec)}>
                                    <Pencil className="w-4 h-4 text-blue-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(rec.id)}>
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
              <p className="text-xs text-gray-400 text-center">عرض {Math.min(filtered.length, 100)} من {filtered.length} سجل</p>
            </>
          )}
      </div>
  );

  // Dialogs (shared between embedded and standalone)
  const dialogs = (
    <>
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingId ? 'تعديل سجل الحضور' : 'تسجيل حضور جديد'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">التاريخ *</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">الموظف *</Label>
                <Select value={form.employeeId} onValueChange={(v) => setForm({ ...form, employeeId: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">وقت الدخول</Label>
                <Input type="time" value={form.checkIn} onChange={(e) => setForm({ ...form, checkIn: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">وقت الخروج</Label>
                <Input type="time" value={form.checkOut} onChange={(e) => setForm({ ...form, checkOut: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">حالة اليوم</Label>
                <Select value={form.dayStatus} onValueChange={(v) => setForm({ ...form, dayStatus: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DAY_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">نوع الغياب/الإجازة</Label>
                <Select value={form.absenceType} onValueChange={(v) => setForm({ ...form, absenceType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ABSENCE_TYPES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">الموافقة</Label>
              <Select value={form.approved} onValueChange={(v) => setForm({ ...form, approved: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {APPROVAL_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">ملاحظات</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload Fingerprint File Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={(open) => { if (!open && uploadStep !== 'importing') { setUploadDialogOpen(false); } }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileUp className="w-5 h-5 text-emerald-600" />
              رفع ملف بيانات البصمة
            </DialogTitle>
          </DialogHeader>

          {uploadStep === 'select' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-emerald-400 transition-colors">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-700 mb-1">اختر ملف بيانات الحضور من جهاز البصمة</p>
                <p className="text-xs text-gray-500 mb-4">الصيغ المدعومة: Excel (.xlsx, .xls) • CSV • نص (.txt)</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv,.txt"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="attendance-file"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-emerald-600 hover:bg-emerald-700 gap-2"
                >
                  <FileUp className="w-4 h-4" />
                  اختيار ملف
                </Button>
              </div>

              {parseResult && !parseResult.success && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <XCircle className="w-5 h-5 text-red-500" />
                    <p className="font-medium text-red-700">خطأ في قراءة الملف</p>
                  </div>
                  <ul className="text-sm text-red-600 space-y-1 list-disc list-inside">
                    {parseResult.errors.map((err, i) => <li key={i}>{err}</li>)}
                  </ul>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm font-medium text-blue-700 mb-2">📋 تنسيق الملف المطلوب:</p>
                <p className="text-xs text-blue-600 mb-2">يجب أن يحتوي الملف على صف عناوين (Header) يتضمن الأعمدة التالية:</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-blue-600">
                  <div>• <strong>رقم الموظف</strong> (أو Employee ID, AC-No)</div>
                  <div>• <strong>التاريخ</strong> (أو Date)</div>
                  <div>• <strong>وقت الحضور</strong> (أو Check In, On Duty)</div>
                  <div>• <strong>وقت الانصراف</strong> (أو Check Out, Off Duty)</div>
                </div>
                <p className="text-xs text-blue-500 mt-2">💡 يتم مطابقة الموظفين تلقائياً عبر رمز الموظف أو الاسم</p>
              </div>
            </div>
          )}

          {uploadStep === 'preview' && parseResult && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-emerald-50 rounded-lg p-3 text-center">
                  <p className="text-xl font-bold text-emerald-600">{parseResult.parsedRows}</p>
                  <p className="text-xs text-gray-600">سجل صالح</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3 text-center">
                  <p className="text-xl font-bold text-amber-600">{parseResult.skippedRows}</p>
                  <p className="text-xs text-gray-600">سجل تم تخطيه</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3 text-center">
                  <p className="text-xl font-bold text-blue-600">{parseResult.totalRows}</p>
                  <p className="text-xs text-gray-600">إجمالي الصفوف</p>
                </div>
              </div>

              {/* Preview of matched/unmatched employees */}
              {(() => {
                const matched: { row: ParsedAttendanceRow; emp: Employee }[] = [];
                const unmatched: ParsedAttendanceRow[] = [];
                const seen = new Set<string>();
                parseResult.data.forEach(row => {
                  const key = row.empCode || row.empName;
                  if (seen.has(key)) return;
                  seen.add(key);
                  const empKey = row.empCode || row.empName;
                  // Check manual mapping first
                  let emp: Employee | undefined;
                  if (employeeMapping[empKey]) {
                    emp = employees.find(e => e.id === employeeMapping[empKey]);
                  }
                  if (!emp) {
                    emp = findEmployeeByCodeOrName(row, employees);
                  }
                  if (emp) matched.push({ row, emp });
                  else unmatched.push(row);
                });
                return (
                  <div className="space-y-3">
                    {matched.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-emerald-700 mb-2 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" /> موظفون تم مطابقتهم ({matched.length})
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {matched.map(({ row, emp }) => (
                            <Badge key={row.empCode || row.empName} variant="secondary" className="bg-emerald-50 text-emerald-700 text-xs">
                              {row.empCode ? `${row.empCode} - ` : ''}{row.empName} → {emp.fullName}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {unmatched.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-amber-700 mb-2 flex items-center gap-1">
                          <AlertTriangle className="w-4 h-4" /> موظفون لم يتم مطابقتهم ({unmatched.length})
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {unmatched.map((row) => (
                            <div key={row.empCode || row.empName} className="flex items-center gap-1">
                              <Badge variant="secondary" className="bg-amber-50 text-amber-700 text-xs">
                                {row.empCode ? `${row.empCode} - ` : ''}{row.empName || 'غير معروف'}
                              </Badge>
                              {/* Manual mapping dropdown */}
                              <Select
                                value={employeeMapping[row.empCode || row.empName] || '_none'}
                                onValueChange={(v) => {
                                  const key = row.empCode || row.empName;
                                  setEmployeeMapping(prev => {
                                    if (v === '_none') {
                                      const next = { ...prev };
                                      delete next[key];
                                      return next;
                                    }
                                    return { ...prev, [key]: v };
                                  });
                                }}
                              >
                                <SelectTrigger className="h-7 w-[140px] text-[10px]">
                                  <SelectValue placeholder="ربط يدوي" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="_none">-- بدون ربط --</SelectItem>
                                  {employees.map(e => (
                                    <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          ))}
                        </div>
                        {/* Auto-create toggle */}
                        <div className="mt-3 bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={importUnmatched}
                              onChange={(e) => setImportUnmatched(e.target.checked)}
                              className="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                            />
                            <span className="text-sm text-blue-800 font-medium">
                              إنشاء موظفين جدد تلقائياً للأسماء غير المطابقة
                            </span>
                          </label>
                          <p className="text-xs text-blue-600 mt-1 mr-6">
                            سيتم إنشاء سجل موظف جديد بالاسم الموجود في ملف البصمة مع رمز الموظف من الجهاز
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Preview table */}
              <div>
                <p className="text-sm font-medium mb-2">معاينة البيانات (أول 10 سجلات):</p>
                <ScrollArea className="w-full max-h-[200px]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="text-right text-xs">رمز الموظف</TableHead>
                        <TableHead className="text-right text-xs">الاسم</TableHead>
                        <TableHead className="text-right text-xs">التاريخ</TableHead>
                        <TableHead className="text-right text-xs">الحضور</TableHead>
                        <TableHead className="text-right text-xs">الانصراف</TableHead>
                        <TableHead className="text-right text-xs">الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {parseResult.data.slice(0, 10).map((row, i) => {
                        const emp = findEmployeeByCodeOrName(row, employees);
                        return (
                          <TableRow key={i}>
                            <TableCell className="text-xs">{row.empCode || '-'}</TableCell>
                            <TableCell className="text-xs">{row.empName || '-'}</TableCell>
                            <TableCell className="text-xs font-mono">{row.date}</TableCell>
                            <TableCell className="text-xs font-mono">{row.checkIn || '-'}</TableCell>
                            <TableCell className="text-xs font-mono">{row.checkOut || '-'}</TableCell>
                            <TableCell>
                              {emp ? (
                                <Badge className="bg-emerald-100 text-emerald-700 border-0 text-[10px]">✓ {emp.fullName}</Badge>
                              ) : (
                                <Badge className="bg-amber-100 text-amber-700 border-0 text-[10px]">✗ غير مطابق</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => { resetUpload(); }}>رجوع</Button>
                <Button onClick={handleImport} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                  <Upload className="w-4 h-4" />
                  استيراد البيانات
                </Button>
              </DialogFooter>
            </div>
          )}

          {uploadStep === 'importing' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <Upload className="w-10 h-10 text-emerald-500 mx-auto mb-3 animate-pulse" />
                <p className="font-medium text-gray-700">جاري استيراد البيانات...</p>
                <p className="text-sm text-gray-500 mt-1">يرجى عدم إغلاق النافذة</p>
              </div>
              <Progress value={importProgress} className="h-3" />
              <p className="text-center text-sm text-gray-600">{importProgress}%</p>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-emerald-50 rounded p-2">
                  <p className="text-lg font-bold text-emerald-600">{importStats.success}</p>
                  <p className="text-xs text-gray-500">تم بنجاح</p>
                </div>
                <div className="bg-blue-50 rounded p-2">
                  <p className="text-lg font-bold text-blue-600">{importStats.created}</p>
                  <p className="text-xs text-gray-500">موظف جديد</p>
                </div>
                <div className="bg-red-50 rounded p-2">
                  <p className="text-lg font-bold text-red-600">{importStats.failed}</p>
                  <p className="text-xs text-gray-500">فشل</p>
                </div>
                <div className="bg-amber-50 rounded p-2">
                  <p className="text-lg font-bold text-amber-600">{importStats.skipped}</p>
                  <p className="text-xs text-gray-500">تم تخطيه</p>
                </div>
              </div>
            </div>
          )}

          {uploadStep === 'done' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="font-bold text-lg text-gray-800">تم الاستيراد بنجاح!</p>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-emerald-600">{importStats.success}</p>
                  <p className="text-xs text-gray-600">سجل تم إضافته</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-blue-600">{importStats.created}</p>
                  <p className="text-xs text-gray-600">موظف جديد</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-red-600">{importStats.failed}</p>
                  <p className="text-xs text-gray-600">سجل فشل</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-amber-600">{importStats.skipped}</p>
                  <p className="text-xs text-gray-600">سجل تم تخطيه</p>
                </div>
              </div>
              {importStats.created > 0 && (
                <p className="text-xs text-blue-600 text-center">
                  ✨ تم إنشاء {importStats.created} موظف جديد تلقائياً من بيانات ملف البصمة
                </p>
              )}
              {importStats.skipped > 0 && (
                <p className="text-xs text-amber-600 text-center">
                  💡 السجلات المتخطاة: لم يتم العثور على موظف مطابق ولم يتم تفعيل الإنشاء التلقائي.
                </p>
              )}
              <DialogFooter>
                <Button onClick={() => setUploadDialogOpen(false)} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                  إغلاق
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Bulk Leave Registration Dialog */}
      <Dialog open={bulkLeaveDialogOpen} onOpenChange={(open) => { if (!open && bulkLeaveStep !== 'creating') setBulkLeaveDialogOpen(false); }}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarRange className="w-5 h-5 text-blue-600" />
              تسجيل إجازة جماعية (من - إلى)
            </DialogTitle>
          </DialogHeader>

          {bulkLeaveStep === 'form' && (
            <div className="space-y-4 py-2">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-700">💡 حدد الموظف وفترة الإجازة ونوعها، وسيتم إنشاء سجل حضور لكل يوم عمل تلقائياً (مع تخطي الجمعة والسبت).</p>
              </div>

              <div>
                <Label className="text-xs">الموظف *</Label>
                <Select value={bulkLeaveForm.employeeId} onValueChange={(v) => setBulkLeaveForm({ ...bulkLeaveForm, employeeId: v })}>
                  <SelectTrigger><SelectValue placeholder="اختر الموظف" /></SelectTrigger>
                  <SelectContent>
                    {employees.filter(e => e.status === 'نشط').map((e) => (
                      <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">تاريخ البداية *</Label>
                  <Input type="date" value={bulkLeaveForm.startDate} onChange={(e) => setBulkLeaveForm({ ...bulkLeaveForm, startDate: e.target.value })} />
                </div>
                <div>
                  <Label className="text-xs">تاريخ النهاية *</Label>
                  <Input type="date" value={bulkLeaveForm.endDate} onChange={(e) => setBulkLeaveForm({ ...bulkLeaveForm, endDate: e.target.value })} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">نوع الإجازة *</Label>
                  <Select value={bulkLeaveForm.leaveType} onValueChange={(v) => setBulkLeaveForm({ ...bulkLeaveForm, leaveType: v, absenceType: LEAVE_TYPE_MAP[v] || v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {LEAVE_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">حالة الموافقة</Label>
                  <Select value={bulkLeaveForm.approved} onValueChange={(v) => setBulkLeaveForm({ ...bulkLeaveForm, approved: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {APPROVAL_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-xs">ملاحظات</Label>
                <Textarea
                  value={bulkLeaveForm.notes}
                  onChange={(e) => setBulkLeaveForm({ ...bulkLeaveForm, notes: e.target.value })}
                  rows={2}
                  placeholder="ملاحظات اختيارية..."
                />
              </div>

              {/* Preview summary */}
              {bulkLeaveForm.startDate && bulkLeaveForm.endDate && bulkLeaveForm.employeeId && (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-3">
                  <p className="text-sm font-semibold text-gray-700">📊 ملخص الإجازة</p>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="bg-blue-50 rounded-lg p-2">
                      <p className="text-xl font-bold text-blue-600">{bulkLeaveDays.length}</p>
                      <p className="text-[10px] text-gray-600">يوم عمل</p>
                    </div>
                    <div className="bg-amber-50 rounded-lg p-2">
                      <p className="text-xl font-bold text-amber-600">{existingDatesForBulk.size}</p>
                      <p className="text-[10px] text-gray-600">مسجل مسبقاً</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-2">
                      <p className="text-xl font-bold text-emerald-600">{bulkLeaveDays.length - existingDatesForBulk.size}</p>
                      <p className="text-[10px] text-gray-600">سيتم إنشاؤه</p>
                    </div>
                  </div>
                  {existingDatesForBulk.size > 0 && (
                    <p className="text-xs text-amber-600">⚠️ سيتم تخطي الأيام المسجلة مسبقاً تلقائياً</p>
                  )}
                  {bulkLeaveDays.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-500 mb-1">الأيام:</p>
                      <div className="flex flex-wrap gap-1 max-h-[80px] overflow-y-auto">
                        {bulkLeaveDays.map((d) => (
                          <Badge
                            key={d}
                            variant="secondary"
                            className={`text-[10px] ${existingDatesForBulk.has(d) ? 'bg-amber-100 text-amber-600 line-through' : 'bg-blue-100 text-blue-700'}`}
                          >
                            {d}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setBulkLeaveDialogOpen(false)}>إلغاء</Button>
                <Button
                  onClick={handleBulkLeaveCreate}
                  disabled={!bulkLeaveForm.employeeId || bulkLeaveDays.length === 0 || (bulkLeaveDays.length - existingDatesForBulk.size) === 0}
                  className="bg-blue-600 hover:bg-blue-700 gap-2"
                >
                  <CalendarRange className="w-4 h-4" />
                  تسجيل {bulkLeaveDays.length - existingDatesForBulk.size} يوم إجازة
                </Button>
              </DialogFooter>
            </div>
          )}

          {bulkLeaveStep === 'creating' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <CalendarRange className="w-10 h-10 text-blue-500 mx-auto mb-3 animate-pulse" />
                <p className="font-medium text-gray-700">جاري تسجيل الإجازات...</p>
                <p className="text-sm text-gray-500 mt-1">يرجى عدم إغلاق النافذة</p>
              </div>
              <Progress value={bulkLeaveProgress} className="h-3" />
              <p className="text-center text-sm text-gray-600">{bulkLeaveProgress}%</p>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded p-2">
                  <p className="text-lg font-bold text-emerald-600">{bulkLeaveStats.success}</p>
                  <p className="text-xs text-gray-500">تم بنجاح</p>
                </div>
                <div className="bg-red-50 rounded p-2">
                  <p className="text-lg font-bold text-red-600">{bulkLeaveStats.failed}</p>
                  <p className="text-xs text-gray-500">فشل</p>
                </div>
                <div className="bg-amber-50 rounded p-2">
                  <p className="text-lg font-bold text-amber-600">{bulkLeaveStats.skipped}</p>
                  <p className="text-xs text-gray-500">تم تخطيه</p>
                </div>
              </div>
            </div>
          )}

          {bulkLeaveStep === 'done' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="font-bold text-lg text-gray-800">تم تسجيل الإجازة بنجاح!</p>
                <p className="text-sm text-gray-500 mt-1">
                  {getEmployeeNameFromList(employees, bulkLeaveForm.employeeId)} - {bulkLeaveForm.leaveType}
                </p>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-emerald-600">{bulkLeaveStats.success}</p>
                  <p className="text-xs text-gray-600">يوم تم تسجيله</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-red-600">{bulkLeaveStats.failed}</p>
                  <p className="text-xs text-gray-600">فشل</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-amber-600">{bulkLeaveStats.skipped}</p>
                  <p className="text-xs text-gray-600">تم تخطيه (مسجل مسبقاً)</p>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => setBulkLeaveDialogOpen(false)} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                  إغلاق
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );

  // Embedded mode: just content + dialogs, no sidebar/header
  if (embedded) {
    return (
      <div dir="rtl">
        {mainContent}
        {dialogs}
      </div>
    );
  }

  // Standalone mode: full layout with sidebar and header
  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <CalendarDays className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">الحضور اليومي</h1>
              <p className="text-xs text-[#64748B]">تسجيل ومتابعة الحضور والغياب</p>
            </div>
          </div>
        </header>
        <main className="p-4 lg:p-6 space-y-4">
          {mainContent}
        </main>
      </div>
      {dialogs}
    </div>
  );
}