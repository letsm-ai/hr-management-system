import { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Briefcase, Menu, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { Sidebar } from './Index';
import { useHRData } from '@/lib/hr-data-context';
import { useAuth } from '@/lib/auth-context';
import Contracts from './Contracts';
import ClientContracts from './ClientContracts';

export default function ContractsManagement() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('employee');
  const { user, loading: authLoading, login } = useAuth();
  const { contracts, loading: dataLoading } = useHRData();

  // Contract stats
  const activeContracts = contracts.filter(c => c.status === 'نشط');
  const expiringContracts = contracts.filter(c => {
    if (!c.endDate) return false;
    const end = new Date(c.endDate);
    const now = new Date();
    const daysLeft = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysLeft > 0 && daysLeft <= 30;
  });
  const expiredContracts = contracts.filter(c => {
    if (!c.endDate) return false;
    return new Date(c.endDate) < new Date();
  });

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card><CardContent className="p-8 text-center">
          <FileText className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
          <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
        </CardContent></Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <FileText className="w-6 h-6 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">إدارة العقود</h1>
              <p className="text-xs text-[#64748B]">عقود الموظفين والعملاء</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-100">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-emerald-600 font-medium">عقود نشطة</p>
                  <p className="text-lg font-bold text-emerald-800">{activeContracts.length}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-100">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-xs text-amber-600 font-medium">تنتهي قريباً</p>
                  <p className="text-lg font-bold text-amber-800">{expiringContracts.length}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-red-200 bg-red-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-100">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-xs text-red-600 font-medium">منتهية</p>
                  <p className="text-lg font-bold text-red-800">{expiredContracts.length}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-blue-600 font-medium">إجمالي العقود</p>
                  <p className="text-lg font-bold text-blue-800">{contracts.length}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Expiring contracts alert */}
          {expiringContracts.length > 0 && (
            <Card className="border-amber-300 bg-amber-50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 text-amber-700">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    تنبيه: {expiringContracts.length} عقد(عقود) تنتهي خلال 30 يوم
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 h-11">
              <TabsTrigger value="employee" className="gap-1.5 text-xs sm:text-sm">
                <FileText className="w-4 h-4" />
                عقود الموظفين
              </TabsTrigger>
              <TabsTrigger value="client" className="gap-1.5 text-xs sm:text-sm">
                <Briefcase className="w-4 h-4" />
                عقود العملاء
              </TabsTrigger>
            </TabsList>

            <TabsContent value="employee" className="mt-4 embedded-page">
              <Contracts />
            </TabsContent>
            <TabsContent value="client" className="mt-4 embedded-page">
              <ClientContracts />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}