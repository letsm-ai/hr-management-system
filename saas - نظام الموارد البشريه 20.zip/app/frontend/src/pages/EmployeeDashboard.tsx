import { useState, useEffect, useCallback, useRef } from 'react';
import { useRole } from '@/lib/role-context';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  LogOut, User, BarChart3, CalendarDays, AlertTriangle, Send,
  TrendingUp, Clock, CheckCircle, XCircle, Lightbulb, Timer,
  Target, DollarSign, FileText, PlusCircle, Bell, BellRing,
  CheckCheck, Eye,
} from 'lucide-react';
import {
  ViolationRecord, NotificationRecord,
  calculatePerformanceScore, getPerformanceRating, getRatingColor,
  getMonthlyAttendanceStats, getCurrentMonth, formatCurrency,
  calculateMonthlyRewards, calculateOvertimeAmount,
  ABSENCE_TYPES, IDEA_CLASSIFICATIONS, IMPACT_LEVELS,
  getKpiRating, getKpiRatingColor,
  createAttendanceRecord, updateViolation, createIdea,
  fetchNotifications, fetchUnreadCount, markNotificationRead,
  markAllNotificationsRead, getNotificationIcon, getNotificationTypeLabel,
} from '@/lib/hr-api';

export default function EmployeeDashboard() {
  const { logout } = useAuth();
  const { employeeId } = useRole();
  const {
    employees, attendance, performance, ideas, overtime, violations,
    performanceKpis, refreshAll, refreshIdeas,
  } = useHRData();

  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [leaveDialogOpen, setLeaveDialogOpen] = useState(false);
  const [grievanceDialogOpen, setGrievanceDialogOpen] = useState(false);
  const [ideaDialogOpen, setIdeaDialogOpen] = useState(false);
  const [selectedViolation, setSelectedViolation] = useState<ViolationRecord | null>(null);
  const [grievanceText, setGrievanceText] = useState('');
  const [leaveType, setLeaveType] = useState('');
  const [leaveDate, setLeaveDate] = useState('');
  const [leaveNotes, setLeaveNotes] = useState('');
  const [ideaTitle, setIdeaTitle] = useState('');
  const [ideaClassification, setIdeaClassification] = useState('');
  const [ideaImpact, setIdeaImpact] = useState('');
  const [ideaNotes, setIdeaNotes] = useState('');
  const [saving, setSaving] = useState(false);

  // Notification state
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifLoading, setNotifLoading] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const loadNotifications = useCallback(async () => {
    setNotifLoading(true);
    try {
      const [notifs, count] = await Promise.all([
        fetchNotifications(),
        fetchUnreadCount(),
      ]);
      setNotifications(notifs);
      setUnreadCount(count);
    } catch {
      // silent fail
    } finally {
      setNotifLoading(false);
    }
  }, []);

  // Poll notifications every 30 seconds
  useEffect(() => {
    loadNotifications();
    const interval = setInterval(() => {
      fetchUnreadCount().then(setUnreadCount).catch(() => {});
    }, 30000);
    return () => clearInterval(interval);
  }, [loadNotifications]);

  // Close notification panel on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    if (notifOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [notifOpen]);

  async function handleMarkRead(notifId: number) {
    await markNotificationRead(notifId);
    setNotifications((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, isRead: true } : n))
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
  }

  async function handleMarkAllRead() {
    await markAllNotificationsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
  }

  function formatTimeAgo(dateStr: string): string {
    if (!dateStr) return '';
    const now = new Date();
    const date = new Date(dateStr);
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return 'الآن';
    if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `منذ ${diffHr} ساعة`;
    const diffDay = Math.floor(diffHr / 24);
    if (diffDay < 7) return `منذ ${diffDay} يوم`;
    return date.toLocaleDateString('ar-SA');
  }

  const empIdStr = String(employeeId);
  const myEmployee = employees.find((e) => e.id === empIdStr);
  const myAttendance = attendance.filter((a) => a.employeeId === empIdStr);
  const myPerformance = performance.filter((p) => p.employeeId === empIdStr);
  const myViolations = violations.filter((v) => v.employeeId === empIdStr);
  const myIdeas = ideas.filter((i) => i.employeeId === empIdStr);
  const myOvertime = overtime.filter((o) => o.employeeId === empIdStr);
  const myKpis = performanceKpis.filter((k) => k.employeeId === empIdStr);

  // Filter by selected month
  const [yearStr, monthStr] = selectedMonth.split('-');
  const year = parseInt(yearStr);
  const mon = parseInt(monthStr);
  const startDate = new Date(year, mon - 1, 1);
  const endDate = new Date(year, mon, 0);

  const isInMonth = (dateStr: string) => {
    const d = new Date(dateStr);
    return d >= startDate && d <= endDate;
  };

  const monthAttendance = myAttendance.filter((a) => isInMonth(a.date));
  const monthLeaves = myAttendance.filter(
    (a) => isInMonth(a.date) && a.dayStatus !== 'حاضر' && a.absenceType !== 'لا ينطبق' && a.absenceType !== 'غياب بدون إذن'
  );
  const monthOvertime = myOvertime.filter((o) => isInMonth(o.date));
  const monthIdeas = myIdeas.filter((i) => i.month === selectedMonth);
  const monthKpi = myKpis.find((k) => k.month === selectedMonth);
  const monthViolations = myViolations.filter((v) => isInMonth(v.date));

  const monthStats = myEmployee
    ? getMonthlyAttendanceStats(empIdStr, selectedMonth, attendance)
    : null;

  const currentPerf = myPerformance.find((p) => p.month === selectedMonth);
  const perfScore = currentPerf
    ? calculatePerformanceScore(currentPerf, myIdeas.filter((i) => i.month === selectedMonth))
    : null;

  const rewards = myEmployee
    ? calculateMonthlyRewards(empIdStr, selectedMonth, employees, attendance, ideas, overtime, violations)
    : null;

  const months: string[] = [];
  for (let i = 0; i < 12; i++) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }

  async function handleLeaveRequest() {
    if (!leaveType || !leaveDate) {
      toast.error('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }
    setSaving(true);
    try {
      await createAttendanceRecord({
        date: leaveDate,
        employeeId: empIdStr,
        checkIn: '',
        checkOut: '',
        actualHours: 0,
        requiredHours: 8,
        tardiness: 0,
        earlyDeparture: 0,
        dayStatus: 'إجازة سنوية',
        absenceType: leaveType,
        notes: leaveNotes || 'طلب إجازة من الموظف',
        approved: 'قيد المراجعة',
      });
      toast.success('تم تقديم طلب الإجازة بنجاح');
      setLeaveDialogOpen(false);
      setLeaveType('');
      setLeaveDate('');
      setLeaveNotes('');
      refreshAll();
    } catch {
      toast.error('فشل في تقديم طلب الإجازة');
    } finally {
      setSaving(false);
    }
  }

  async function handleIdeaSubmit() {
    if (!ideaTitle || !ideaClassification || !ideaImpact) {
      toast.error('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }
    setSaving(true);
    try {
      await createIdea({
        month: selectedMonth,
        employeeId: empIdStr,
        title: ideaTitle,
        status: 'قيد المراجعة',
        classification: ideaClassification,
        expectedImpact: ideaImpact,
        submissionDate: new Date().toISOString().split('T')[0],
        decisionDate: '',
        revenueGenerated: 0,
        notes: ideaNotes,
      });
      toast.success('تم تقديم الفكرة بنجاح');
      setIdeaDialogOpen(false);
      setIdeaTitle('');
      setIdeaClassification('');
      setIdeaImpact('');
      setIdeaNotes('');
      refreshIdeas();
    } catch {
      toast.error('فشل في تقديم الفكرة');
    } finally {
      setSaving(false);
    }
  }

  async function handleGrievance() {
    if (!selectedViolation || !grievanceText) {
      toast.error('يرجى كتابة نص التظلم');
      return;
    }
    setSaving(true);
    try {
      await updateViolation(selectedViolation.id, {
        grievanceStatus: 'تظلم قيد المراجعة',
        notes: `${selectedViolation.notes ? selectedViolation.notes + ' | ' : ''}تظلم الموظف: ${grievanceText}`,
      });
      toast.success('تم تقديم التظلم بنجاح');
      setGrievanceDialogOpen(false);
      setSelectedViolation(null);
      setGrievanceText('');
      refreshAll();
    } catch {
      toast.error('فشل في تقديم التظلم');
    } finally {
      setSaving(false);
    }
  }

  function getApprovalBadge(status: string) {
    switch (status) {
      case 'نعم': return <Badge className="bg-green-100 text-green-700 border-0">موافق عليه</Badge>;
      case 'لا': return <Badge className="bg-red-100 text-red-700 border-0">مرفوض</Badge>;
      case 'قيد المراجعة': return <Badge className="bg-yellow-100 text-yellow-700 border-0">قيد المراجعة</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  }

  function getIdeaStatusBadge(status: string) {
    switch (status) {
      case 'مقبولة': return <Badge className="bg-green-100 text-green-700 border-0">{status}</Badge>;
      case 'منفذة': return <Badge className="bg-emerald-100 text-emerald-700 border-0">{status}</Badge>;
      case 'مرفوضة': return <Badge className="bg-red-100 text-red-700 border-0">{status}</Badge>;
      case 'قيد المراجعة': return <Badge className="bg-yellow-100 text-yellow-700 border-0">{status}</Badge>;
      case 'قيد التنفيذ': return <Badge className="bg-blue-100 text-blue-700 border-0">{status}</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  }

  if (!myEmployee) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center" dir="rtl">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <User className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-bold mb-2">لم يتم ربط حسابك بموظف</h2>
            <p className="text-gray-500 mb-4">يرجى التواصل مع الإدارة لربط حسابك بملف الموظف الخاص بك</p>
            <Button variant="outline" onClick={logout}>
              <LogOut className="h-4 w-4 ml-2" />
              تسجيل الخروج
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold">
              {myEmployee.fullName.charAt(0)}
            </div>
            <div>
              <h1 className="font-bold text-lg">{myEmployee.fullName}</h1>
              <p className="text-sm text-gray-500">{myEmployee.jobTitle} - {myEmployee.department}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Notification Bell */}
            <div className="relative" ref={notifRef}>
              <Button
                variant="ghost"
                size="sm"
                className="relative p-2"
                onClick={() => {
                  setNotifOpen(!notifOpen);
                  if (!notifOpen) loadNotifications();
                }}
              >
                {unreadCount > 0 ? (
                  <BellRing className="h-5 w-5 text-orange-500 animate-pulse" />
                ) : (
                  <Bell className="h-5 w-5 text-gray-500" />
                )}
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Button>

              {/* Notification Dropdown Panel */}
              {notifOpen && (
                <div className="absolute left-0 top-full mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-2xl border z-[100] overflow-hidden">
                  {/* Header */}
                  <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-l from-blue-50 to-white border-b">
                    <h3 className="font-bold text-sm flex items-center gap-2">
                      <Bell className="h-4 w-4 text-blue-600" />
                      الإشعارات
                      {unreadCount > 0 && (
                        <Badge className="bg-red-500 text-white text-xs px-1.5 py-0">{unreadCount}</Badge>
                      )}
                    </h3>
                    {unreadCount > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs text-blue-600 hover:text-blue-800 h-auto py-1 px-2"
                        onClick={handleMarkAllRead}
                      >
                        <CheckCheck className="h-3 w-3 ml-1" />
                        قراءة الكل
                      </Button>
                    )}
                  </div>

                  {/* Notification List */}
                  <ScrollArea className="max-h-80">
                    {notifLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600" />
                      </div>
                    ) : notifications.length > 0 ? (
                      <div className="divide-y">
                        {notifications.map((notif) => (
                          <div
                            key={notif.id}
                            className={`px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer ${
                              !notif.isRead ? 'bg-blue-50/50' : ''
                            }`}
                            onClick={() => {
                              if (!notif.isRead) handleMarkRead(notif.id);
                            }}
                          >
                            <div className="flex items-start gap-3">
                              <span className="text-lg mt-0.5">{getNotificationIcon(notif.type)}</span>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-0.5">
                                  <Badge
                                    variant="outline"
                                    className={`text-[10px] px-1.5 py-0 ${
                                      !notif.isRead ? 'border-blue-300 text-blue-700 bg-blue-50' : ''
                                    }`}
                                  >
                                    {getNotificationTypeLabel(notif.type)}
                                  </Badge>
                                  {!notif.isRead && (
                                    <span className="h-2 w-2 rounded-full bg-blue-500 flex-shrink-0" />
                                  )}
                                </div>
                                <p className="text-sm font-medium text-gray-900 truncate">{notif.title}</p>
                                <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{notif.message}</p>
                                <p className="text-[10px] text-gray-400 mt-1">{formatTimeAgo(notif.createdAt)}</p>
                              </div>
                              {!notif.isRead && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0 text-gray-400 hover:text-blue-600 flex-shrink-0"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleMarkRead(notif.id);
                                  }}
                                >
                                  <Eye className="h-3.5 w-3.5" />
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-10 text-gray-400">
                        <Bell className="h-10 w-10 mb-2 opacity-30" />
                        <p className="text-sm">لا توجد إشعارات</p>
                      </div>
                    )}
                  </ScrollArea>
                </div>
              )}
            </div>

            <Button variant="outline" size="sm" onClick={logout}>
              <LogOut className="h-4 w-4 ml-2" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Month Selector & Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-6">
          <div className="flex items-center gap-2">
            <Label className="text-sm font-medium">الشهر:</Label>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((m) => (
                  <SelectItem key={m} value={m}>{m}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 mr-auto flex-wrap">
            {/* Leave Request Button */}
            <Dialog open={leaveDialogOpen} onOpenChange={setLeaveDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700 text-white" size="sm">
                  <CalendarDays className="h-4 w-4 ml-1" />
                  طلب إجازة
                </Button>
              </DialogTrigger>
              <DialogContent dir="rtl">
                <DialogHeader>
                  <DialogTitle>طلب إجازة</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>نوع الإجازة *</Label>
                    <Select value={leaveType} onValueChange={setLeaveType}>
                      <SelectTrigger><SelectValue placeholder="اختر نوع الإجازة" /></SelectTrigger>
                      <SelectContent>
                        {ABSENCE_TYPES.filter((t) => t !== 'لا ينطبق' && t !== 'غياب بإذن' && t !== 'غياب بدون إذن').map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>التاريخ *</Label>
                    <Input type="date" value={leaveDate} onChange={(e) => setLeaveDate(e.target.value)} />
                  </div>
                  <div>
                    <Label>ملاحظات (اختياري)</Label>
                    <Textarea value={leaveNotes} onChange={(e) => setLeaveNotes(e.target.value)} placeholder="سبب الإجازة..." />
                  </div>
                  <Button onClick={handleLeaveRequest} disabled={saving} className="w-full bg-green-600 hover:bg-green-700 text-white">
                    <Send className="h-4 w-4 ml-2" />
                    {saving ? 'جاري الإرسال...' : 'تقديم الطلب'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Idea Submit Button */}
            <Dialog open={ideaDialogOpen} onOpenChange={setIdeaDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white" size="sm">
                  <Lightbulb className="h-4 w-4 ml-1" />
                  تقديم فكرة
                </Button>
              </DialogTrigger>
              <DialogContent dir="rtl">
                <DialogHeader>
                  <DialogTitle>تقديم فكرة إبداعية</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>عنوان الفكرة *</Label>
                    <Input value={ideaTitle} onChange={(e) => setIdeaTitle(e.target.value)} placeholder="عنوان الفكرة الإبداعية..." />
                  </div>
                  <div>
                    <Label>تصنيف الفكرة *</Label>
                    <Select value={ideaClassification} onValueChange={setIdeaClassification}>
                      <SelectTrigger><SelectValue placeholder="اختر التصنيف" /></SelectTrigger>
                      <SelectContent>
                        {IDEA_CLASSIFICATIONS.map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>الأثر المتوقع *</Label>
                    <Select value={ideaImpact} onValueChange={setIdeaImpact}>
                      <SelectTrigger><SelectValue placeholder="اختر مستوى الأثر" /></SelectTrigger>
                      <SelectContent>
                        {IMPACT_LEVELS.map((l) => (
                          <SelectItem key={l} value={l}>{l}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>تفاصيل الفكرة (اختياري)</Label>
                    <Textarea value={ideaNotes} onChange={(e) => setIdeaNotes(e.target.value)} placeholder="اشرح فكرتك بالتفصيل..." rows={3} />
                  </div>
                  <Button onClick={handleIdeaSubmit} disabled={saving} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                    <Send className="h-4 w-4 ml-2" />
                    {saving ? 'جاري الإرسال...' : 'تقديم الفكرة'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Quick Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-blue-100 p-2.5 rounded-lg">
                <CheckCircle className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">أيام الحضور</p>
                <p className="text-2xl font-bold">{monthStats?.presentDays || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-red-100 p-2.5 rounded-lg">
                <XCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">أيام الغياب</p>
                <p className="text-2xl font-bold">{monthStats?.absentDays || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-yellow-100 p-2.5 rounded-lg">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">دقائق التأخير</p>
                <p className="text-2xl font-bold">{monthStats?.totalTardiness || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-green-100 p-2.5 rounded-lg">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">نسبة الحضور</p>
                <p className="text-2xl font-bold">{monthStats?.attendanceRate?.toFixed(0) || 0}%</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="kpi" className="space-y-4">
          <TabsList className="flex flex-wrap h-auto gap-1 bg-white border p-1">
            <TabsTrigger value="kpi" className="text-xs gap-1">
              <Target className="h-3.5 w-3.5" />
              مؤشر الأداء
            </TabsTrigger>
            <TabsTrigger value="performance" className="text-xs gap-1">
              <BarChart3 className="h-3.5 w-3.5" />
              تقييم الأداء
            </TabsTrigger>
            <TabsTrigger value="salary" className="text-xs gap-1">
              <DollarSign className="h-3.5 w-3.5" />
              الراتب والعلاوات
            </TabsTrigger>
            <TabsTrigger value="leaves" className="text-xs gap-1">
              <CalendarDays className="h-3.5 w-3.5" />
              الإجازات
            </TabsTrigger>
            <TabsTrigger value="overtime" className="text-xs gap-1">
              <Timer className="h-3.5 w-3.5" />
              العمل الإضافي
            </TabsTrigger>
            <TabsTrigger value="ideas" className="text-xs gap-1">
              <Lightbulb className="h-3.5 w-3.5" />
              الأفكار
            </TabsTrigger>
            <TabsTrigger value="violations" className="text-xs gap-1">
              <AlertTriangle className="h-3.5 w-3.5" />
              المخالفات
            </TabsTrigger>
          </TabsList>

          {/* ===== KPI Tab ===== */}
          <TabsContent value="kpi">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-blue-600" />
                  مؤشرات الأداء الرئيسية - {selectedMonth}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {monthKpi ? (
                  <div className="space-y-6">
                    {/* Achievement Overview */}
                    <div className="text-center">
                      <div className={`inline-block px-8 py-4 rounded-2xl text-lg font-bold ${getKpiRatingColor(monthKpi.achievementRate)}`}>
                        {monthKpi.overallRating || getKpiRating(monthKpi.achievementRate)}
                      </div>
                    </div>

                    {/* Tasks Progress */}
                    <div className="bg-blue-50 rounded-xl p-5">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">نسبة إنجاز المهام</span>
                        <span className="text-2xl font-bold text-blue-700">{monthKpi.achievementRate}%</span>
                      </div>
                      <Progress value={Math.min(monthKpi.achievementRate, 100)} className="h-3 mb-3" />
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>المهام المستهدفة: <strong>{monthKpi.tasksTarget}</strong></span>
                        <span>المهام المنجزة: <strong>{monthKpi.tasksCompleted}</strong></span>
                      </div>
                    </div>

                    {/* Scores Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { label: 'جودة العمل', value: monthKpi.qualityScore, color: 'blue' },
                        { label: 'الالتزام بالمواعيد', value: monthKpi.timelinessScore, color: 'green' },
                        { label: 'التعاون', value: monthKpi.collaborationScore, color: 'purple' },
                        { label: 'الابتكار', value: monthKpi.innovationScore, color: 'orange' },
                      ].map((item) => (
                        <div key={item.label} className="bg-gray-50 rounded-lg p-3 text-center">
                          <p className="text-xs text-gray-500 mb-1">{item.label}</p>
                          <p className="text-xl font-bold">{item.value}<span className="text-sm text-gray-400">/10</span></p>
                          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                            <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: `${item.value * 10}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* KPI Bonus */}
                    {monthKpi.kpiBonus > 0 && (
                      <div className="bg-emerald-50 rounded-lg p-4 text-center">
                        <p className="text-sm text-emerald-600 mb-1">مكافأة الأداء</p>
                        <p className="text-2xl font-bold text-emerald-700">{formatCurrency(monthKpi.kpiBonus)}</p>
                      </div>
                    )}

                    {/* Manager Notes & Goals */}
                    {(monthKpi.managerNotes || monthKpi.employeeGoals) && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {monthKpi.managerNotes && (
                          <div className="bg-gray-50 rounded-lg p-4">
                            <p className="text-xs text-gray-500 mb-1 font-medium">ملاحظات المدير</p>
                            <p className="text-sm">{monthKpi.managerNotes}</p>
                          </div>
                        )}
                        {monthKpi.employeeGoals && (
                          <div className="bg-gray-50 rounded-lg p-4">
                            <p className="text-xs text-gray-500 mb-1 font-medium">أهداف الفترة القادمة</p>
                            <p className="text-sm">{monthKpi.employeeGoals}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Target className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                    <p className="text-gray-500">لا توجد مؤشرات أداء لهذا الشهر</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Performance Tab ===== */}
          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  تقرير تقييم الأداء - {selectedMonth}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {currentPerf && perfScore !== null ? (
                  <div className="space-y-6">
                    <div className="text-center">
                      <div className={`inline-block px-6 py-3 rounded-full text-lg font-bold ${getRatingColor(perfScore)}`}>
                        {perfScore.toFixed(1)} / 10 - {getPerformanceRating(perfScore)}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {[
                        { label: 'جودة العمل', value: currentPerf.workQuality, weight: '25%' },
                        { label: 'الانضباط', value: currentPerf.punctuality, weight: '15%' },
                        { label: 'رضا العملاء', value: currentPerf.customerSatisfaction, weight: '15%' },
                        { label: 'العمل الجماعي', value: currentPerf.teamwork, weight: '10%' },
                        { label: 'المبادرة', value: currentPerf.initiative, weight: '10%' },
                        { label: 'التطوير الذاتي', value: currentPerf.selfDevelopment, weight: '5%' },
                      ].map((item) => (
                        <div key={item.label} className="bg-gray-50 rounded-lg p-3">
                          <p className="text-sm text-gray-500">{item.label} ({item.weight})</p>
                          <p className="text-xl font-bold">{item.value}/10</p>
                          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${item.value * 10}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BarChart3 className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                    <p className="text-gray-500">لا يوجد تقييم أداء لهذا الشهر</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Salary & Commissions Tab ===== */}
          <TabsContent value="salary">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  تقرير الراتب والعلاوات - {selectedMonth}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {rewards ? (
                  <div className="space-y-4">
                    {/* Basic Salary */}
                    <div className="bg-blue-50 rounded-lg p-4 text-center">
                      <p className="text-sm text-gray-500">الراتب الأساسي</p>
                      <p className="text-3xl font-bold text-blue-700">{formatCurrency(rewards.basicSalary)}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Rewards */}
                      <div className="bg-green-50 rounded-lg p-4">
                        <h3 className="font-bold text-green-700 mb-3 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          المكافآت والعلاوات
                        </h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>مكافأة العمل الإضافي</span>
                            <span className="text-green-600 font-medium">+{formatCurrency(rewards.overtimeReward)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>مكافأة الأفكار ({rewards.acceptedIdeas} مقبولة)</span>
                            <span className="text-green-600 font-medium">+{formatCurrency(rewards.ideaReward)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>عمولة الإيرادات</span>
                            <span className="text-green-600 font-medium">+{formatCurrency(rewards.commission)}</span>
                          </div>
                          {rewards.ideaRevenue > 0 && (
                            <div className="flex justify-between text-xs text-gray-500 pt-1">
                              <span>إجمالي الإيرادات من الأفكار</span>
                              <span>{formatCurrency(rewards.ideaRevenue)}</span>
                            </div>
                          )}
                          <div className="flex justify-between font-bold border-t border-green-200 pt-2 mt-2">
                            <span>إجمالي المكافآت</span>
                            <span className="text-green-700">+{formatCurrency(rewards.totalRewards)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Deductions */}
                      <div className="bg-red-50 rounded-lg p-4">
                        <h3 className="font-bold text-red-700 mb-3 flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4" />
                          الخصومات
                        </h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>خصم الغياب</span>
                            <span className="text-red-600 font-medium">-{formatCurrency(rewards.absenceDeduction)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>خصم التأخير ({rewards.tardinessMinutes} دقيقة)</span>
                            <span className="text-red-600 font-medium">-{formatCurrency(rewards.tardinessDeduction)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>خصم المخالفات</span>
                            <span className="text-red-600 font-medium">-{formatCurrency(rewards.violationDeduction)}</span>
                          </div>
                          <div className="flex justify-between font-bold border-t border-red-200 pt-2 mt-2">
                            <span>إجمالي الخصومات</span>
                            <span className="text-red-700">-{formatCurrency(rewards.totalDeductions)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Net Salary */}
                    <div className="bg-gray-900 text-white rounded-lg p-5 text-center">
                      <p className="text-sm text-gray-300 mb-1">صافي الراتب</p>
                      <p className="text-3xl font-bold">{formatCurrency(rewards.finalSalary)}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        ({rewards.netAmount >= 0 ? '+' : ''}{formatCurrency(rewards.netAmount)} عن الراتب الأساسي)
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <DollarSign className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                    <p className="text-gray-500">لا تتوفر بيانات الراتب</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Leaves Tab ===== */}
          <TabsContent value="leaves">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-green-600" />
                    طلبات الإجازات - {selectedMonth}
                  </div>
                  <Badge variant="outline">{monthLeaves.length} طلب</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Leave Balance Summary */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  {(() => {
                    const allLeaves = myAttendance.filter((a) => a.absenceType !== 'لا ينطبق' && a.absenceType !== 'غياب بدون إذن' && a.absenceType !== 'غياب بإذن');
                    const annualUsed = allLeaves.filter((a) => a.absenceType === 'إجازة سنوية مدفوعة').length;
                    const sickUsed = allLeaves.filter((a) => a.absenceType === 'إجازة مرضية مدفوعة').length;
                    const emergencyUsed = allLeaves.filter((a) => a.absenceType === 'إجازة طارئة مدفوعة').length;
                    const unpaidUsed = allLeaves.filter((a) => a.absenceType === 'إجازة بدون راتب').length;
                    return (
                      <>
                        <div className="bg-blue-50 rounded-lg p-3 text-center">
                          <p className="text-xs text-gray-500">سنوية (مستخدمة/الرصيد)</p>
                          <p className="text-lg font-bold text-blue-700">{annualUsed}/{myEmployee.annualLeaveBalance}</p>
                        </div>
                        <div className="bg-orange-50 rounded-lg p-3 text-center">
                          <p className="text-xs text-gray-500">مرضية (مستخدمة/15)</p>
                          <p className="text-lg font-bold text-orange-700">{sickUsed}/15</p>
                        </div>
                        <div className="bg-purple-50 rounded-lg p-3 text-center">
                          <p className="text-xs text-gray-500">طارئة</p>
                          <p className="text-lg font-bold text-purple-700">{emergencyUsed}</p>
                        </div>
                        <div className="bg-gray-100 rounded-lg p-3 text-center">
                          <p className="text-xs text-gray-500">بدون راتب</p>
                          <p className="text-lg font-bold text-gray-700">{unpaidUsed}</p>
                        </div>
                      </>
                    );
                  })()}
                </div>

                {/* Leave Requests Table */}
                {monthLeaves.length > 0 ? (
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">التاريخ</TableHead>
                          <TableHead className="text-right">نوع الإجازة</TableHead>
                          <TableHead className="text-right">الحالة</TableHead>
                          <TableHead className="text-right">ملاحظات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monthLeaves.map((leave) => (
                          <TableRow key={leave.id}>
                            <TableCell className="text-sm">{leave.date}</TableCell>
                            <TableCell className="text-sm">{leave.absenceType}</TableCell>
                            <TableCell>{getApprovalBadge(leave.approved)}</TableCell>
                            <TableCell className="text-sm text-gray-500">{leave.notes || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-8">
                    <CalendarDays className="h-10 w-10 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500 text-sm">لا توجد طلبات إجازة لهذا الشهر</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Overtime Tab ===== */}
          <TabsContent value="overtime">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Timer className="h-5 w-5 text-indigo-600" />
                    سجلات العمل الإضافي - {selectedMonth}
                  </div>
                  <Badge variant="outline">{monthOvertime.length} سجل</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Overtime Summary */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="bg-indigo-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">إجمالي الساعات</p>
                    <p className="text-xl font-bold text-indigo-700">
                      {monthOvertime.reduce((s, o) => s + o.overtimeHours, 0).toFixed(1)}
                    </p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">المعتمدة</p>
                    <p className="text-xl font-bold text-green-700">
                      {monthOvertime.filter((o) => o.approved === 'نعم').length}
                    </p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">المكافأة المتوقعة</p>
                    <p className="text-xl font-bold text-emerald-700">
                      {myEmployee ? formatCurrency(
                        monthOvertime
                          .filter((o) => o.approved === 'نعم')
                          .reduce((s, o) => s + calculateOvertimeAmount(myEmployee.basicSalary, o.overtimeHours, o.dayType), 0)
                      ) : '-'}
                    </p>
                  </div>
                </div>

                {/* Overtime Table */}
                {monthOvertime.length > 0 ? (
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">التاريخ</TableHead>
                          <TableHead className="text-right">نوع اليوم</TableHead>
                          <TableHead className="text-right">الساعات</TableHead>
                          <TableHead className="text-right">طريقة التعويض</TableHead>
                          <TableHead className="text-right">الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monthOvertime.map((ot) => (
                          <TableRow key={ot.id}>
                            <TableCell className="text-sm">{ot.date}</TableCell>
                            <TableCell className="text-sm">{ot.dayType}</TableCell>
                            <TableCell className="text-sm font-medium">{ot.overtimeHours} ساعة</TableCell>
                            <TableCell className="text-sm">{ot.compensationMethod}</TableCell>
                            <TableCell>{getApprovalBadge(ot.approved)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-8">
                    <Timer className="h-10 w-10 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500 text-sm">لا توجد سجلات عمل إضافي لهذا الشهر</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Ideas Tab ===== */}
          <TabsContent value="ideas">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-purple-600" />
                    الأفكار الإبداعية المقدمة - {selectedMonth}
                  </div>
                  <Badge variant="outline">{monthIdeas.length} فكرة</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Ideas Summary */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  <div className="bg-purple-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">إجمالي الأفكار</p>
                    <p className="text-xl font-bold text-purple-700">{monthIdeas.length}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">مقبولة</p>
                    <p className="text-xl font-bold text-green-700">
                      {monthIdeas.filter((i) => i.status === 'مقبولة' || i.status === 'منفذة').length}
                    </p>
                  </div>
                  <div className="bg-yellow-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">قيد المراجعة</p>
                    <p className="text-xl font-bold text-yellow-700">
                      {monthIdeas.filter((i) => i.status === 'قيد المراجعة' || i.status === 'قيد التنفيذ').length}
                    </p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-500">الإيرادات المحققة</p>
                    <p className="text-xl font-bold text-emerald-700">
                      {formatCurrency(monthIdeas.reduce((s, i) => s + (i.revenueGenerated || 0), 0))}
                    </p>
                  </div>
                </div>

                {/* Ideas List */}
                {monthIdeas.length > 0 ? (
                  <div className="space-y-3">
                    {monthIdeas.map((idea) => (
                      <div key={idea.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              {getIdeaStatusBadge(idea.status)}
                              <Badge variant="outline" className="text-xs">{idea.classification}</Badge>
                            </div>
                            <h4 className="font-bold text-sm">{idea.title}</h4>
                            <div className="flex gap-4 mt-2 text-xs text-gray-500">
                              <span>تاريخ التقديم: {idea.submissionDate}</span>
                              <span>الأثر المتوقع: {idea.expectedImpact}</span>
                              {idea.revenueGenerated > 0 && (
                                <span className="text-emerald-600 font-medium">
                                  إيرادات: {formatCurrency(idea.revenueGenerated)}
                                </span>
                              )}
                            </div>
                            {idea.notes && <p className="text-xs text-gray-500 mt-1">{idea.notes}</p>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Lightbulb className="h-10 w-10 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500 text-sm mb-3">لا توجد أفكار مقدمة لهذا الشهر</p>
                    <Button
                      size="sm"
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                      onClick={() => setIdeaDialogOpen(true)}
                    >
                      <PlusCircle className="h-4 w-4 ml-1" />
                      قدّم فكرتك الأولى
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== Violations Tab ===== */}
          <TabsContent value="violations">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    المخالفات
                  </div>
                  <Badge variant="outline">{myViolations.length} مخالفة</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {myViolations.length > 0 ? (
                  <div className="space-y-3">
                    {myViolations.map((v) => (
                      <div key={v.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge
                                variant={v.severity === 'خطير' || v.severity === 'خطير جداً' ? 'destructive' : 'secondary'}
                              >
                                {v.severity}
                              </Badge>
                              <span className="text-sm text-gray-500">{v.date}</span>
                            </div>
                            <h4 className="font-bold text-sm">{v.violationType}</h4>
                            {v.details && <p className="text-sm text-gray-600 mt-1">{v.details}</p>}
                            <div className="flex gap-4 mt-2 text-sm">
                              <span>العقوبة: <strong>{v.penalty}</strong></span>
                              {v.deductionAmount > 0 && (
                                <span className="text-red-600">خصم: {formatCurrency(v.deductionAmount)}</span>
                              )}
                            </div>
                            <div className="mt-1">
                              <Badge variant="outline">{v.grievanceStatus}</Badge>
                            </div>
                          </div>
                          {v.grievanceStatus === 'لا يوجد تظلم' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-orange-600 border-orange-300 hover:bg-orange-50"
                              onClick={() => {
                                setSelectedViolation(v);
                                setGrievanceDialogOpen(true);
                              }}
                            >
                              <AlertTriangle className="h-4 w-4 ml-1" />
                              تقديم تظلم
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="h-10 w-10 mx-auto text-green-300 mb-2" />
                    <p className="text-gray-500 text-sm">لا توجد مخالفات مسجلة 🎉</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Grievance Dialog */}
      <Dialog open={grievanceDialogOpen} onOpenChange={setGrievanceDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تقديم تظلم</DialogTitle>
          </DialogHeader>
          {selectedViolation && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm text-gray-500">المخالفة:</p>
                <p className="font-bold">{selectedViolation.violationType}</p>
                <p className="text-sm text-gray-500 mt-1">التاريخ: {selectedViolation.date}</p>
                <p className="text-sm text-gray-500">العقوبة: {selectedViolation.penalty}</p>
              </div>
              <div>
                <Label>نص التظلم *</Label>
                <Textarea
                  value={grievanceText}
                  onChange={(e) => setGrievanceText(e.target.value)}
                  placeholder="اكتب سبب التظلم وأي توضيحات..."
                  rows={4}
                />
              </div>
              <Button onClick={handleGrievance} disabled={saving} className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                <Send className="h-4 w-4 ml-2" />
                {saving ? 'جاري الإرسال...' : 'تقديم التظلم'}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}