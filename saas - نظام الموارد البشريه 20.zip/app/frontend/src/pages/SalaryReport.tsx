import { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Upload, FileText, Printer, Download, Loader2, AlertCircle,
  CheckCircle, Clock, XCircle, AlertTriangle, Save, Edit2,
} from 'lucide-react';
import { client } from '@/lib/api';

// ============ TYPES ============

interface DailyRecord {
  day: number;
  date: string;
  weekday: string;
  status: string;
  check_in: string | null;
  check_out: string | null;
  work_hours: number | null;
  tardiness_minutes: number;
}

interface EmployeeReport {
  employee_name: string;
  employee_id: string;
  department: string;
  basic_salary: number;
  overtime_amount: number;
  daily_salary: number;
  total_attendance_days: number;
  full_punch_days: number;
  single_punch_days: number;
  absence_days: number;
  total_work_hours: number;
  tardiness_count: number;
  total_tardiness_minutes: number;
  tardiness_deduction_days: number;
  total_deduction_days: number;
  deduction_amount: number;
  final_salary: number;
  daily_records: DailyRecord[];
  single_punch_records: DailyRecord[];
  absence_records: DailyRecord[];
  tardiness_records: DailyRecord[];
  on_paid_leave: boolean;
}

interface SalaryReportData {
  success: boolean;
  message: string;
  month: string;
  year: number;
  employees: EmployeeReport[];
  total_basic_salaries: number;
  total_overtime: number;
  total_deductions: number;
  total_final_salaries: number;
}

// ============ CONSTANTS ============
const WORK_START_HOUR = 8;
const WORK_START_MINUTE = 30;
const DAILY_WORK_MINUTES = 480;
const WORK_DAYS_PER_MONTH = 22;
const SALARY_DIVISOR = 30;

// ============ HELPERS ============

function formatCurrency(amount: number): string {
  return `${amount.toFixed(3)} ر.ع`;
}

function getStatusIcon(status: string) {
  switch (status) {
    case 'present':
      return <CheckCircle className="w-4 h-4 text-green-600" />;
    case 'single_punch':
      return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    case 'absent':
      return <XCircle className="w-4 h-4 text-red-500" />;
    default:
      return null;
  }
}

function getStatusLabel(status: string): string {
  switch (status) {
    case 'present': return '✅ حاضر';
    case 'single_punch': return '⚠️ بصمة واحدة';
    case 'absent': return '❌ غائب';
    default: return status;
  }
}

function parseTimeStr(timeStr: string | null): { hour: number; minute: number } | null {
  if (!timeStr || !timeStr.trim()) return null;
  const parts = timeStr.trim().split(':');
  if (parts.length >= 2) {
    const h = parseInt(parts[0]);
    const m = parseInt(parts[1]);
    if (!isNaN(h) && !isNaN(m) && h >= 0 && h <= 23 && m >= 0 && m <= 59) {
      return { hour: h, minute: m };
    }
  }
  return null;
}

function calculateTardiness(checkInStr: string | null): number {
  const t = parseTimeStr(checkInStr);
  if (!t) return 0;
  const startMinutes = WORK_START_HOUR * 60 + WORK_START_MINUTE;
  const inMinutes = t.hour * 60 + t.minute;
  return Math.max(0, inMinutes - startMinutes);
}

function calculateWorkHours(checkIn: string | null, checkOut: string | null): number | null {
  const inT = parseTimeStr(checkIn);
  const outT = parseTimeStr(checkOut);
  if (!inT || !outT) return null;
  const inMin = inT.hour * 60 + inT.minute;
  const outMin = outT.hour * 60 + outT.minute;
  const diff = outMin - inMin;
  if (diff <= 0) return 0;
  return Math.round((diff / 60) * 100) / 100;
}

/** Recalculate an employee's deductions and final salary based on daily_records */
function recalcEmployeeReport(emp: EmployeeReport): EmployeeReport {
  let fullPunchDays = 0;
  let singlePunchDays = 0;
  let absenceDays = 0;
  let totalWorkHours = 0;
  let tardinessCount = 0;
  let totalTardinessMinutes = 0;

  const singlePunchRecords: DailyRecord[] = [];
  const absenceRecords: DailyRecord[] = [];
  const tardinessRecords: DailyRecord[] = [];

  const updatedRecords = emp.daily_records.map(rec => {
    const hasIn = !!(rec.check_in && rec.check_in.trim());
    const hasOut = !!(rec.check_out && rec.check_out.trim());

    let status = rec.status;
    let workHours = rec.work_hours;
    let tardMins = rec.tardiness_minutes;

    if (hasIn && hasOut) {
      status = 'present';
      fullPunchDays++;
      workHours = calculateWorkHours(rec.check_in, rec.check_out);
      if (workHours != null) totalWorkHours += workHours;
      tardMins = calculateTardiness(rec.check_in);
      if (tardMins > 0) {
        tardinessCount++;
        totalTardinessMinutes += tardMins;
      }
    } else if (hasIn || hasOut) {
      status = 'single_punch';
      singlePunchDays++;
      workHours = null;
      tardMins = 0;
    } else {
      status = 'absent';
      absenceDays++;
      workHours = null;
      tardMins = 0;
    }

    const updated: DailyRecord = { ...rec, status, work_hours: workHours, tardiness_minutes: tardMins };

    if (status === 'single_punch') singlePunchRecords.push(updated);
    if (status === 'absent') absenceRecords.push(updated);
    if (status === 'present' && tardMins > 0) tardinessRecords.push(updated);

    return updated;
  });

  const totalAttendanceDays = fullPunchDays + singlePunchDays;
  const absenceDeductionDays = emp.on_paid_leave ? 0 : Math.max(0, WORK_DAYS_PER_MONTH - totalAttendanceDays);
  const tardinessDeductionDays = Math.round((totalTardinessMinutes / DAILY_WORK_MINUTES) * 10000) / 10000;
  const totalDeductionDays = absenceDeductionDays + tardinessDeductionDays;
  const dailySalary = emp.basic_salary > 0 ? emp.basic_salary / SALARY_DIVISOR : 0;
  const deductionAmount = Math.round(totalDeductionDays * dailySalary * 1000) / 1000;
  const finalSalary = Math.round((emp.basic_salary + emp.overtime_amount - deductionAmount) * 1000) / 1000;

  return {
    ...emp,
    daily_records: updatedRecords,
    single_punch_records: singlePunchRecords,
    absence_records: absenceRecords,
    tardiness_records: tardinessRecords,
    full_punch_days: fullPunchDays,
    single_punch_days: singlePunchDays,
    absence_days: absenceDeductionDays,
    total_attendance_days: totalAttendanceDays,
    total_work_hours: Math.round(totalWorkHours * 100) / 100,
    tardiness_count: tardinessCount,
    total_tardiness_minutes: totalTardinessMinutes,
    tardiness_deduction_days: tardinessDeductionDays,
    total_deduction_days: totalDeductionDays,
    daily_salary: Math.round(dailySalary * 1000) / 1000,
    deduction_amount: deductionAmount,
    final_salary: finalSalary,
  };
}

/** Recalculate report totals */
function recalcReportTotals(report: SalaryReportData): SalaryReportData {
  const totalBasic = report.employees.reduce((s, e) => s + e.basic_salary, 0);
  const totalOvertime = report.employees.reduce((s, e) => s + e.overtime_amount, 0);
  const totalDeductions = report.employees.reduce((s, e) => s + e.deduction_amount, 0);
  const totalFinal = report.employees.reduce((s, e) => s + e.final_salary, 0);
  return {
    ...report,
    total_basic_salaries: Math.round(totalBasic * 1000) / 1000,
    total_overtime: Math.round(totalOvertime * 1000) / 1000,
    total_deductions: Math.round(totalDeductions * 1000) / 1000,
    total_final_salaries: Math.round(totalFinal * 1000) / 1000,
  };
}

// ============ COMPONENT ============

export default function SalaryReport() {
  const [loading, setLoading] = useState(false);
  const [loadingReport, setLoadingReport] = useState(false);
  const [saving, setSaving] = useState(false);
  const [report, setReport] = useState<SalaryReportData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [savingNote, setSavingNote] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const printRef = useRef<HTMLDivElement>(null);

  // Load saved report when month changes
  useEffect(() => {
    loadSavedReport(selectedMonth);
  }, [selectedMonth]);

  // Load saved report from DB
  const loadSavedReport = async (month: string) => {
    setLoadingReport(true);
    setError(null);
    try {
      const res = await client.apiCall.invoke({
        url: `/api/v1/salary-report/load/${month}`,
        method: 'GET',
      });
      const data = res.data as { success: boolean; report: SalaryReportData | null; updated_at?: string };
      if (data?.success && data.report) {
        setReport(data.report as SalaryReportData);
        setSavedAt(data.updated_at || null);
        setHasUnsavedChanges(false);
        // Load notes
        await loadNotes(month);
      } else {
        setReport(null);
        setSavedAt(null);
      }
    } catch {
      // No saved report - that's fine
      setReport(null);
      setSavedAt(null);
    } finally {
      setLoadingReport(false);
    }
  };

  // Save report to DB
  const saveReportToDB = async () => {
    if (!report) return;
    setSaving(true);
    try {
      await client.apiCall.invoke({
        url: '/api/v1/salary-report/save',
        method: 'POST',
        data: {
          month: report.month,
          year: report.year,
          report_data: report,
        },
      });
      setSavedAt(new Date().toLocaleString('ar-SA'));
      setHasUnsavedChanges(false);
    } catch (err: any) {
      const msg = err?.response?.data?.detail || err?.data?.detail || err?.message || 'خطأ في حفظ التقرير';
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  // Upload and generate report
  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);
    setReport(null);

    try {
      const [yearStr, monthStr] = selectedMonth.split('-');
      const formData = new FormData();
      formData.append('file', file);

      const res = await client.apiCall.invoke({
        url: `/api/v1/salary-report/generate?year=${yearStr}&month=${parseInt(monthStr)}`,
        method: 'POST',
        data: formData,
        options: {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        },
      });

      const data = res.data as SalaryReportData;
      if (data?.success) {
        setReport(data);
        setHasUnsavedChanges(true);
        // Auto-save after generation
        try {
          await client.apiCall.invoke({
            url: '/api/v1/salary-report/save',
            method: 'POST',
            data: {
              month: data.month,
              year: data.year,
              report_data: data,
            },
          });
          setSavedAt(new Date().toLocaleString('ar-SA'));
          setHasUnsavedChanges(false);
        } catch {
          // Save failed but report is still shown
        }
        // Load notes for this month
        await loadNotes(data.month);
      } else {
        setError('فشل في إنشاء التقرير');
      }
    } catch (err: any) {
      const msg = err?.response?.data?.detail || err?.data?.detail || err?.message || 'خطأ في رفع الملف';
      setError(msg);
    } finally {
      setLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }, [selectedMonth]);

  // Handle time edit for a specific employee and day
  const handleTimeEdit = (employeeId: string, dayIndex: number, field: 'check_in' | 'check_out', value: string) => {
    if (!report) return;

    const updatedEmployees = report.employees.map(emp => {
      if (emp.employee_id !== employeeId) return emp;

      const updatedRecords = emp.daily_records.map((rec, idx) => {
        if (idx !== dayIndex) return rec;
        return { ...rec, [field]: value || null };
      });

      const updatedEmp = recalcEmployeeReport({ ...emp, daily_records: updatedRecords });
      return updatedEmp;
    });

    const updatedReport = recalcReportTotals({ ...report, employees: updatedEmployees });
    setReport(updatedReport);
    setHasUnsavedChanges(true);
  };

  // Load notes
  const loadNotes = async (month: string) => {
    try {
      const res = await client.apiCall.invoke({
        url: `/api/v1/salary-report/notes/${month}`,
        method: 'GET',
      });
      const data = res.data as { success: boolean; notes: Record<string, string> };
      if (data?.notes) {
        setNotes(data.notes);
      }
    } catch {
      // Notes are optional
    }
  };

  // Save note
  const saveNote = async (employeeId: string, date: string, noteType: string, note: string) => {
    if (!report) return;
    const key = `${employeeId}|${date}|${noteType}`;
    setSavingNote(key);
    try {
      await client.apiCall.invoke({
        url: '/api/v1/salary-report/notes',
        method: 'POST',
        data: {
          report_month: report.month,
          employee_id: employeeId,
          date,
          note_type: noteType,
          note,
        },
      });
      setNotes(prev => ({ ...prev, [key]: note }));
    } catch {
      // Silently fail
    } finally {
      setSavingNote(null);
    }
  };

  // Print
  const handlePrint = () => {
    window.print();
  };

  // Export PDF (uses print dialog)
  const handleExportPDF = () => {
    window.print();
  };

  // Export Excel (summary only)
  const handleExportExcel = () => {
    if (!report) return;

    const headers = ['#', 'الموظف', 'الراتب', 'إضافي', 'حضور', 'بصمة واحدة', 'غياب', 'تأخير (يوم)', 'مبلغ الخصم', 'الراتب النهائي'];
    const rows = report.employees.map((emp, idx) => [
      idx + 1,
      emp.employee_name,
      emp.basic_salary,
      emp.overtime_amount,
      emp.total_attendance_days,
      emp.single_punch_days,
      emp.absence_days,
      emp.total_deduction_days.toFixed(4),
      emp.deduction_amount.toFixed(3),
      emp.final_salary.toFixed(3),
    ]);

    // Add totals row
    rows.push([
      '',
      'المجموع',
      report.total_basic_salaries,
      report.total_overtime,
      '',
      '',
      '',
      '',
      report.total_deductions.toFixed(3),
      report.total_final_salaries.toFixed(3),
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(',')),
    ].join('\n');

    // Add BOM for Arabic support in Excel
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `salary_report_${report.month}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Month options
  const monthOptions = [];
  const now = new Date();
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const val = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const label = d.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long' });
    monthOptions.push({ value: val, label });
  }

  return (
    <div className="bg-gray-50 p-4 lg:p-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">تقرير الرواتب الشهري</h1>
          <p className="text-gray-500 text-sm mt-1">رفع ملف الحضور وإصدار تقرير الرواتب الشامل</p>
          {savedAt && (
            <p className="text-xs text-green-600 mt-1">
              <CheckCircle className="w-3 h-3 inline ml-1" />
              آخر حفظ: {savedAt}
            </p>
          )}
        </div>

        {report && (
          <div className="flex gap-2 flex-wrap">
            {hasUnsavedChanges && (
              <Button variant="default" size="sm" onClick={saveReportToDB} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white">
                {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
                حفظ التغييرات
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={handlePrint}>
              <Printer className="w-4 h-4 ml-1" />
              طباعة
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportPDF}>
              <FileText className="w-4 h-4 ml-1" />
              PDF
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportExcel}>
              <Download className="w-4 h-4 ml-1" />
              Excel
            </Button>
          </div>
        )}
      </div>

      {/* Upload Section */}
      <Card className="mb-6 print:hidden">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-end gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium text-gray-700 mb-2 block">الشهر</label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium text-gray-700 mb-2 block">ملف الحضور (XLS/XLSX)</label>
              <Input
                ref={fileInputRef}
                type="file"
                accept=".xls,.xlsx"
                onChange={handleFileUpload}
                disabled={loading}
                className="cursor-pointer"
              />
            </div>
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 ml-1 animate-spin" />
              ) : (
                <Upload className="w-4 h-4 ml-1" />
              )}
              رفع وإنشاء التقرير
            </Button>
          </div>
          {report && !hasUnsavedChanges && savedAt && (
            <p className="text-xs text-gray-500 mt-3">
              💡 التقرير محفوظ. يمكنك رفع ملف جديد لتحديثه أو تعديل الأوقات يدوياً.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Error */}
      {error && (
        <Card className="mb-6 border-red-200 bg-red-50 print:hidden">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <p className="text-red-700">{error}</p>
          </CardContent>
        </Card>
      )}

      {/* Loading */}
      {(loading || loadingReport) && (
        <Card className="mb-6">
          <CardContent className="p-8 text-center">
            <Loader2 className="w-10 h-10 animate-spin mx-auto text-blue-600 mb-3" />
            <p className="text-gray-600">
              {loading ? 'جاري معالجة الملف وإنشاء التقرير...' : 'جاري تحميل التقرير المحفوظ...'}
            </p>
          </CardContent>
        </Card>
      )}

      {/* No report message */}
      {!loading && !loadingReport && !report && !error && (
        <Card className="mb-6 print:hidden">
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500">لا يوجد تقرير محفوظ لهذا الشهر</p>
            <p className="text-gray-400 text-sm mt-1">قم برفع ملف الحضور لإنشاء التقرير</p>
          </CardContent>
        </Card>
      )}

      {/* Report Content */}
      {report && !loading && !loadingReport && (
        <div ref={printRef}>
          {/* Print Header */}
          <div className="hidden print:block text-center mb-6">
            <h1 className="text-xl font-bold">تقرير الرواتب الشهري</h1>
            <p className="text-gray-600">
              {new Date(report.year, parseInt(report.month.split('-')[1]) - 1).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long' })}
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 print:grid-cols-4">
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">إجمالي الرواتب</p>
                <p className="text-lg font-bold text-blue-700">{formatCurrency(report.total_basic_salaries)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">إجمالي الإضافي</p>
                <p className="text-lg font-bold text-green-700">{formatCurrency(report.total_overtime)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">إجمالي الخصومات</p>
                <p className="text-lg font-bold text-red-700">{formatCurrency(report.total_deductions)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-gray-500 mb-1">صافي الرواتب</p>
                <p className="text-lg font-bold text-emerald-700">{formatCurrency(report.total_final_salaries)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Section 1: Summary Table */}
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">القسم الأول: جدول الملخص</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-100">
                      <TableHead className="text-right w-10">#</TableHead>
                      <TableHead className="text-right">الموظف</TableHead>
                      <TableHead className="text-right">الراتب</TableHead>
                      <TableHead className="text-right">إضافي</TableHead>
                      <TableHead className="text-right">حضور</TableHead>
                      <TableHead className="text-right">بصمة واحدة</TableHead>
                      <TableHead className="text-right">غياب</TableHead>
                      <TableHead className="text-right">تأخير (يوم)</TableHead>
                      <TableHead className="text-right">مبلغ الخصم</TableHead>
                      <TableHead className="text-right">الراتب النهائي</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {report.employees.map((emp, idx) => (
                      <TableRow key={emp.employee_id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">{idx + 1}</TableCell>
                        <TableCell className="font-medium">{emp.employee_name}</TableCell>
                        <TableCell>{formatCurrency(emp.basic_salary)}</TableCell>
                        <TableCell className="text-green-700">{formatCurrency(emp.overtime_amount)}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {emp.total_attendance_days}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {emp.single_punch_days > 0 ? (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700">
                              {emp.single_punch_days}
                            </Badge>
                          ) : '0'}
                        </TableCell>
                        <TableCell>
                          {emp.absence_days > 0 ? (
                            <Badge variant="outline" className="bg-red-50 text-red-700">
                              {emp.absence_days}
                            </Badge>
                          ) : '0'}
                        </TableCell>
                        <TableCell>{emp.total_deduction_days.toFixed(2)}</TableCell>
                        <TableCell className="text-red-600 font-medium">{formatCurrency(emp.deduction_amount)}</TableCell>
                        <TableCell className="font-bold text-emerald-700">{formatCurrency(emp.final_salary)}</TableCell>
                      </TableRow>
                    ))}
                    {/* Totals Row */}
                    <TableRow className="bg-gray-100 font-bold border-t-2">
                      <TableCell></TableCell>
                      <TableCell>المجموع</TableCell>
                      <TableCell>{formatCurrency(report.total_basic_salaries)}</TableCell>
                      <TableCell className="text-green-700">{formatCurrency(report.total_overtime)}</TableCell>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                      <TableCell className="text-red-600">{formatCurrency(report.total_deductions)}</TableCell>
                      <TableCell className="text-emerald-700">{formatCurrency(report.total_final_salaries)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Employee Details */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">القسم الثاني: تفاصيل الموظفين</CardTitle>
                <div className="flex items-center gap-2 text-xs text-gray-500 print:hidden">
                  <Edit2 className="w-3 h-3" />
                  <span>انقر على وقت الدخول/الخروج لتعديله</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" className="space-y-3">
                {report.employees.map((emp) => (
                  <AccordionItem key={emp.employee_id} value={emp.employee_id} className="border rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline py-3">
                      <div className="flex items-center gap-3 text-right w-full">
                        <span className="font-bold text-gray-800">{emp.employee_name}</span>
                        <Badge variant="outline" className="text-xs">{emp.department}</Badge>
                        <span className="mr-auto text-sm text-emerald-700 font-bold">
                          {formatCurrency(emp.final_salary)}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pt-2 pb-4">
                      <EmployeeDetailSection
                        emp={emp}
                        notes={notes}
                        savingNote={savingNote}
                        onSaveNote={saveNote}
                        reportMonth={report.month}
                        onTimeEdit={handleTimeEdit}
                      />
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>

          {/* Floating save button */}
          {hasUnsavedChanges && (
            <div className="fixed bottom-6 left-6 z-50 print:hidden">
              <Button
                onClick={saveReportToDB}
                disabled={saving}
                className="bg-green-600 hover:bg-green-700 text-white shadow-lg rounded-full px-6 py-3 h-auto"
              >
                {saving ? <Loader2 className="w-5 h-5 ml-2 animate-spin" /> : <Save className="w-5 h-5 ml-2" />}
                حفظ التغييرات
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============ EMPLOYEE DETAIL SECTION ============

function EmployeeDetailSection({
  emp,
  notes,
  savingNote,
  onSaveNote,
  reportMonth,
  onTimeEdit,
}: {
  emp: EmployeeReport;
  notes: Record<string, string>;
  savingNote: string | null;
  onSaveNote: (empId: string, date: string, type: string, note: string) => void;
  reportMonth: string;
  onTimeEdit: (employeeId: string, dayIndex: number, field: 'check_in' | 'check_out', value: string) => void;
}) {
  return (
    <div className="space-y-6">
      {/* A) Basic Data Table */}
      <div>
        <h4 className="font-bold text-gray-700 mb-2">البيانات الأساسية</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1 bg-gray-50 rounded-lg p-4 text-sm">
          <InfoRow label="الراتب الأساسي" value={formatCurrency(emp.basic_salary)} />
          <InfoRow label="الراتب اليومي (÷30)" value={formatCurrency(emp.daily_salary)} />
          <InfoRow label="مبلغ العمل الإضافي" value={formatCurrency(emp.overtime_amount)} />
          <InfoRow label="أيام العمل في الشهر" value="22 يوم" />
          <InfoRow label="أيام الحضور (إجمالي)" value={`${emp.total_attendance_days} يوم`} />
          <InfoRow label="أيام ببصمتين كاملتين" value={`${emp.full_punch_days} يوم`} />
          <InfoRow label="أيام ببصمة واحدة" value={`${emp.single_punch_days} يوم`} />
          <InfoRow label="أيام الغياب (تُخصم)" value={`${emp.absence_days} يوم`} highlight={emp.absence_days > 0 ? 'red' : undefined} />
          <InfoRow label="إجمالي ساعات العمل المحسوبة" value={`${emp.total_work_hours} ساعة`} />
          <InfoRow label="عدد مرات التأخير" value={`${emp.tardiness_count} مرة`} />
          <InfoRow label="إجمالي دقائق التأخير" value={`${emp.total_tardiness_minutes} دقيقة`} />
          <InfoRow label="خصم التأخير (بالأيام)" value={`${emp.tardiness_deduction_days.toFixed(4)} يوم`} />
          <InfoRow label="إجمالي أيام الخصم" value={`${emp.total_deduction_days.toFixed(4)} يوم`} highlight="red" />
          <InfoRow label="مبلغ الخصم" value={formatCurrency(emp.deduction_amount)} highlight="red" />
          <InfoRow label="الراتب النهائي" value={formatCurrency(emp.final_salary)} highlight="green" />
        </div>
      </div>

      {/* B) Single Punch Days */}
      {emp.single_punch_records.length > 0 && (
        <div>
          <h4 className="font-bold text-amber-700 mb-2">⚠️ أيام البصمة الواحدة (يحتاج تفسير)</h4>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-amber-50">
                  <TableHead className="text-right">اليوم</TableHead>
                  <TableHead className="text-right">التاريخ</TableHead>
                  <TableHead className="text-right">البصمة المسجلة</TableHead>
                  <TableHead className="text-right w-64">الملاحظة / تفسير الموظف</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emp.single_punch_records.map(rec => {
                  const noteKey = `${emp.employee_id}|${rec.date}|single_punch`;
                  return (
                    <TableRow key={rec.date}>
                      <TableCell>{rec.weekday}</TableCell>
                      <TableCell>{rec.date}</TableCell>
                      <TableCell>
                        {rec.check_in ? `دخول: ${rec.check_in}` : ''}
                        {rec.check_out ? `خروج: ${rec.check_out}` : ''}
                      </TableCell>
                      <TableCell>
                        <NoteCell
                          noteKey={noteKey}
                          currentNote={notes[noteKey] || ''}
                          saving={savingNote === noteKey}
                          onSave={(note) => onSaveNote(emp.employee_id, rec.date, 'single_punch', note)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* C) Absence Days */}
      {emp.absence_records.length > 0 && (
        <div>
          <h4 className="font-bold text-red-700 mb-2">❌ أيام الغياب</h4>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-red-50">
                  <TableHead className="text-right">اليوم</TableHead>
                  <TableHead className="text-right">التاريخ</TableHead>
                  <TableHead className="text-right w-64">الملاحظة / تفسير الموظف</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emp.absence_records.map(rec => {
                  const noteKey = `${emp.employee_id}|${rec.date}|absence`;
                  return (
                    <TableRow key={rec.date}>
                      <TableCell>{rec.weekday}</TableCell>
                      <TableCell>{rec.date}</TableCell>
                      <TableCell>
                        <NoteCell
                          noteKey={noteKey}
                          currentNote={notes[noteKey] || ''}
                          saving={savingNote === noteKey}
                          onSave={(note) => onSaveNote(emp.employee_id, rec.date, 'absence', note)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* D) Tardiness Details */}
      {emp.tardiness_records.length > 0 && (
        <div>
          <h4 className="font-bold text-orange-700 mb-2">🕐 تفاصيل التأخير</h4>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-orange-50">
                  <TableHead className="text-right">اليوم</TableHead>
                  <TableHead className="text-right">التاريخ</TableHead>
                  <TableHead className="text-right">وقت الدخول</TableHead>
                  <TableHead className="text-right">التأخير (دقيقة)</TableHead>
                  <TableHead className="text-right w-64">الملاحظة / تفسير الموظف</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emp.tardiness_records.map(rec => {
                  const noteKey = `${emp.employee_id}|${rec.date}|tardiness`;
                  return (
                    <TableRow key={rec.date}>
                      <TableCell>{rec.weekday}</TableCell>
                      <TableCell>{rec.date}</TableCell>
                      <TableCell>{rec.check_in}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-orange-50 text-orange-700">
                          {rec.tardiness_minutes} دقيقة
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <NoteCell
                          noteKey={noteKey}
                          currentNote={notes[noteKey] || ''}
                          saving={savingNote === noteKey}
                          onSave={(note) => onSaveNote(emp.employee_id, rec.date, 'tardiness', note)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* E) Full Attendance Log with Inline Edit */}
      <div>
        <h4 className="font-bold text-gray-700 mb-2">
          📋 سجل الحضور الكامل
          <span className="text-xs font-normal text-gray-400 mr-2 print:hidden">(انقر على الوقت لتعديله)</span>
        </h4>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-100">
                <TableHead className="text-right">اليوم</TableHead>
                <TableHead className="text-right">يوم الأسبوع</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">الدخول</TableHead>
                <TableHead className="text-right">الخروج</TableHead>
                <TableHead className="text-right">الساعات</TableHead>
                <TableHead className="text-right">التأخير</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {emp.daily_records.map((rec, idx) => (
                <TableRow key={rec.date} className={
                  rec.status === 'absent' ? 'bg-red-50/50' :
                  rec.status === 'single_punch' ? 'bg-amber-50/50' : ''
                }>
                  <TableCell>{rec.day}</TableCell>
                  <TableCell>{rec.weekday}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(rec.status)}
                      <span className="text-xs">{getStatusLabel(rec.status)}</span>
                    </div>
                  </TableCell>
                  <TableCell className="print:hidden p-1">
                    <EditableTimeCell
                      value={rec.check_in}
                      onChange={(val) => onTimeEdit(emp.employee_id, idx, 'check_in', val)}
                    />
                  </TableCell>
                  <TableCell className="hidden print:table-cell">{rec.check_in || '-'}</TableCell>
                  <TableCell className="print:hidden p-1">
                    <EditableTimeCell
                      value={rec.check_out}
                      onChange={(val) => onTimeEdit(emp.employee_id, idx, 'check_out', val)}
                    />
                  </TableCell>
                  <TableCell className="hidden print:table-cell">{rec.check_out || '-'}</TableCell>
                  <TableCell>{rec.work_hours != null ? `${rec.work_hours.toFixed(1)}` : '-'}</TableCell>
                  <TableCell>
                    {rec.tardiness_minutes > 0 ? (
                      <Badge variant="outline" className="bg-orange-50 text-orange-700 text-xs">
                        {rec.tardiness_minutes} د
                      </Badge>
                    ) : '-'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* F) Final Calculation Formula */}
      <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
        <h4 className="font-bold text-blue-800 mb-2">معادلة الحساب النهائية</h4>
        <p className="text-lg font-mono text-center text-blue-900">
          {formatCurrency(emp.basic_salary)} + {formatCurrency(emp.overtime_amount)} - {formatCurrency(emp.deduction_amount)} = <strong>{formatCurrency(emp.final_salary)}</strong>
        </p>
        <p className="text-xs text-center text-blue-600 mt-1">
          الراتب + الإضافي - الخصم = الراتب النهائي
        </p>
      </div>

      <Separator />
    </div>
  );
}

// ============ EDITABLE TIME CELL ============

function EditableTimeCell({
  value,
  onChange,
}: {
  value: string | null;
  onChange: (val: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value || '');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    setLocalValue(value || '');
    setEditing(true);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const handleBlur = () => {
    setEditing(false);
    const trimmed = localValue.trim();
    if (trimmed !== (value || '')) {
      onChange(trimmed);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      (e.target as HTMLInputElement).blur();
    }
    if (e.key === 'Escape') {
      setLocalValue(value || '');
      setEditing(false);
    }
  };

  if (editing) {
    return (
      <Input
        ref={inputRef}
        type="text"
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className="h-7 text-xs w-20 text-center px-1"
        placeholder="HH:MM"
      />
    );
  }

  return (
    <div
      className="cursor-pointer hover:bg-blue-50 rounded px-2 py-1 text-xs min-w-[3rem] text-center border border-transparent hover:border-blue-200 transition-colors"
      onClick={handleClick}
      title="انقر للتعديل"
    >
      {value || <span className="text-gray-300">-</span>}
    </div>
  );
}

// ============ HELPER COMPONENTS ============

function InfoRow({ label, value, highlight }: { label: string; value: string; highlight?: 'red' | 'green' }) {
  const valueClass = highlight === 'red' ? 'text-red-600 font-bold' :
    highlight === 'green' ? 'text-emerald-700 font-bold' : 'text-gray-800';

  return (
    <div className="flex justify-between py-1 border-b border-gray-200 last:border-0">
      <span className="text-gray-600">{label}</span>
      <span className={valueClass}>{value}</span>
    </div>
  );
}

function NoteCell({
  noteKey,
  currentNote,
  saving,
  onSave,
}: {
  noteKey: string;
  currentNote: string;
  saving: boolean;
  onSave: (note: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [localNote, setLocalNote] = useState(currentNote);

  const handleSave = () => {
    onSave(localNote);
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="flex items-center gap-2">
        <Textarea
          value={localNote}
          onChange={(e) => setLocalNote(e.target.value)}
          className="text-xs h-16 resize-none"
          placeholder="أدخل الملاحظة..."
        />
        <div className="flex flex-col gap-1">
          <Button size="sm" variant="default" onClick={handleSave} disabled={saving} className="text-xs px-2 py-1 h-auto">
            {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : 'حفظ'}
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="text-xs px-2 py-1 h-auto">
            إلغاء
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="cursor-pointer text-xs text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded p-1 min-h-[2rem] flex items-center"
      onClick={() => { setLocalNote(currentNote); setEditing(true); }}
    >
      {currentNote || <span className="italic">انقر لإضافة ملاحظة...</span>}
    </div>
  );
}