import { useState, useMemo, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  Menu, ClipboardList, CalendarDays, Lightbulb, AlertTriangle,
  CheckCircle, XCircle, Clock, Eye, MessageSquare, Search,
  Download, FileSpreadsheet, FileText,
} from 'lucide-react';
import { Sidebar } from './Index';
import {
  AttendanceRecord, IdeaRecord, ViolationRecord, Employee,
  getEmployeeNameFromList, updateAttendanceRecord, updateIdea, updateViolation,
  createNotification, IDEA_STATUSES, APPROVAL_STATUSES,
} from '@/lib/hr-api';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

const LEAVE_DAY_KEYWORDS = ['إجازة'];

function isLeaveRecord(r: AttendanceRecord): boolean {
  return LEAVE_DAY_KEYWORDS.some((k) => r.dayStatus.includes(k) || r.absenceType.includes(k));
}

function getLeaveType(r: AttendanceRecord): string {
  if (r.dayStatus !== 'حاضر' && r.dayStatus !== 'غائب' && r.dayStatus.includes('إجازة')) return r.dayStatus;
  if (r.absenceType.includes('إجازة')) return r.absenceType;
  return r.dayStatus || r.absenceType;
}

// CSV export helper
function downloadCSV(filename: string, headers: string[], rows: string[][]) {
  const BOM = '\uFEFF';
  const csv = BOM + [headers.join(','), ...rows.map((r) => r.map((c) => `"${(c || '').replace(/"/g, '""')}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Simple HTML table export for print/PDF
function downloadHTMLReport(title: string, headers: string[], rows: string[][]) {
  const tableRows = rows.map((r) => `<tr>${r.map((c) => `<td style="border:1px solid #ddd;padding:8px;text-align:right">${c || '-'}</td>`).join('')}</tr>`).join('');
  const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${title}</title>
<style>body{font-family:Arial,sans-serif;padding:20px;direction:rtl}table{border-collapse:collapse;width:100%;margin-top:20px}
th{background:#1E3A5F;color:white;padding:10px;border:1px solid #ddd;text-align:right}
td{padding:8px;border:1px solid #ddd}h1{color:#1E3A5F}@media print{body{padding:0}}</style></head>
<body><h1>${title}</h1><p>تاريخ التصدير: ${new Date().toLocaleDateString('ar-SA')}</p>
<table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${tableRows}</tbody></table>
<script>window.print()</script></body></html>`;
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  window.open(url, '_blank');
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

type LeaveFilter = 'all' | 'pending' | 'approved' | 'rejected';
type IdeaFilter = 'all' | 'pending' | 'accepted' | 'rejected' | 'implementing' | 'implemented';
type GrievanceFilter = 'all' | 'pending' | 'accepted' | 'rejected';

export default function RequestsManagement() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tab, setTab] = useState('leaves');
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, ideas, violations, loading, refreshAttendance, refreshIdeas, refreshViolations } = useHRData();

  // Filters
  const [leaveSearch, setLeaveSearch] = useState('');
  const [leaveFilter, setLeaveFilter] = useState<LeaveFilter>('all');
  const [ideaSearch, setIdeaSearch] = useState('');
  const [ideaFilter, setIdeaFilter] = useState<IdeaFilter>('all');
  const [grievanceSearch, setGrievanceSearch] = useState('');
  const [grievanceFilter, setGrievanceFilter] = useState<GrievanceFilter>('all');

  // Leave dialog
  const [leaveDialog, setLeaveDialog] = useState(false);
  const [selectedLeave, setSelectedLeave] = useState<AttendanceRecord | null>(null);
  const [leaveNewStatus, setLeaveNewStatus] = useState('');
  const [leaveResponse, setLeaveResponse] = useState('');

  // Idea dialog
  const [ideaDialog, setIdeaDialog] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<IdeaRecord | null>(null);
  const [ideaNewStatus, setIdeaNewStatus] = useState('');
  const [ideaResponse, setIdeaResponse] = useState('');

  // Grievance dialog
  const [grievanceDialog, setGrievanceDialog] = useState(false);
  const [selectedGrievance, setSelectedGrievance] = useState<ViolationRecord | null>(null);
  const [grievanceNewStatus, setGrievanceNewStatus] = useState('');
  const [grievanceResponse, setGrievanceResponse] = useState('');

  const [saving, setSaving] = useState(false);

  // ============ DATA FILTERING ============

  const leaveRequests = useMemo(() => {
    return attendance.filter(isLeaveRecord).sort((a, b) => b.date.localeCompare(a.date));
  }, [attendance]);

  const filteredLeaves = useMemo(() => {
    let result = leaveRequests;
    if (leaveFilter === 'pending') result = result.filter((r) => r.approved === 'قيد المراجعة' || r.approved === 'لا ينطبق');
    else if (leaveFilter === 'approved') result = result.filter((r) => r.approved === 'نعم');
    else if (leaveFilter === 'rejected') result = result.filter((r) => r.approved === 'لا');
    if (leaveSearch.trim()) {
      const q = leaveSearch.trim().toLowerCase();
      result = result.filter((r) => {
        const name = getEmployeeNameFromList(employees, r.employeeId).toLowerCase();
        return name.includes(q) || r.date.includes(q) || r.dayStatus.includes(q) || r.absenceType.includes(q) || (r.notes || '').includes(q);
      });
    }
    return result;
  }, [leaveRequests, leaveFilter, leaveSearch, employees]);

  const pendingLeavesCount = useMemo(() => leaveRequests.filter((r) => r.approved === 'قيد المراجعة' || r.approved === 'لا ينطبق').length, [leaveRequests]);

  const allIdeasSorted = useMemo(() => [...ideas].sort((a, b) => b.submissionDate.localeCompare(a.submissionDate)), [ideas]);

  const filteredIdeas = useMemo(() => {
    let result = allIdeasSorted;
    if (ideaFilter === 'pending') result = result.filter((i) => i.status === 'قيد المراجعة');
    else if (ideaFilter === 'accepted') result = result.filter((i) => i.status === 'مقبولة');
    else if (ideaFilter === 'rejected') result = result.filter((i) => i.status === 'مرفوضة');
    else if (ideaFilter === 'implementing') result = result.filter((i) => i.status === 'قيد التنفيذ');
    else if (ideaFilter === 'implemented') result = result.filter((i) => i.status === 'منفذة');
    if (ideaSearch.trim()) {
      const q = ideaSearch.trim().toLowerCase();
      result = result.filter((i) => {
        const name = getEmployeeNameFromList(employees, i.employeeId).toLowerCase();
        return name.includes(q) || i.title.toLowerCase().includes(q) || i.classification.includes(q) || (i.notes || '').includes(q);
      });
    }
    return result;
  }, [allIdeasSorted, ideaFilter, ideaSearch, employees]);

  const pendingIdeasCount = useMemo(() => ideas.filter((i) => i.status === 'قيد المراجعة').length, [ideas]);

  const grievances = useMemo(() => {
    return violations.filter((v) =>
      v.grievanceStatus && v.grievanceStatus !== 'لا يوجد تظلم' && v.grievanceStatus.trim() !== ''
    ).sort((a, b) => b.date.localeCompare(a.date));
  }, [violations]);

  const filteredGrievances = useMemo(() => {
    let result = grievances;
    if (grievanceFilter === 'pending') result = result.filter((g) => g.grievanceStatus === 'تظلم قيد المراجعة');
    else if (grievanceFilter === 'accepted') result = result.filter((g) => g.grievanceStatus === 'تم قبول التظلم');
    else if (grievanceFilter === 'rejected') result = result.filter((g) => g.grievanceStatus === 'تم رفض التظلم');
    if (grievanceSearch.trim()) {
      const q = grievanceSearch.trim().toLowerCase();
      result = result.filter((v) => {
        const name = getEmployeeNameFromList(employees, v.employeeId).toLowerCase();
        return name.includes(q) || v.violationType.includes(q) || v.details.includes(q) || (v.notes || '').includes(q);
      });
    }
    return result;
  }, [grievances, grievanceFilter, grievanceSearch, employees]);

  const pendingGrievancesCount = useMemo(() => grievances.filter((g) => g.grievanceStatus === 'تظلم قيد المراجعة').length, [grievances]);

  // ============ NOTIFICATION HELPERS ============

  const sendLeaveNotification = useCallback(async (record: AttendanceRecord, action: string, response: string) => {
    const empIdNum = parseInt(record.employeeId, 10);
    if (isNaN(empIdNum)) return;
    const type = action === 'نعم' ? 'leave_approved' : 'leave_rejected';
    const title = action === 'نعم' ? 'تمت الموافقة على طلب إجازتك' : 'تم رفض طلب إجازتك';
    const leaveType = getLeaveType(record);
    let message = `${title} - ${leaveType} بتاريخ ${record.date}`;
    if (response.trim()) message += ` | رد المدير: ${response}`;
    await createNotification(empIdNum, type, title, message);
  }, []);

  const sendIdeaNotification = useCallback(async (idea: IdeaRecord, newStatus: string, response: string) => {
    const empIdNum = parseInt(idea.employeeId, 10);
    if (isNaN(empIdNum)) return;
    const type = newStatus === 'مقبولة' ? 'idea_accepted' : newStatus === 'مرفوضة' ? 'idea_rejected' : 'idea_status_change';
    const title = newStatus === 'مقبولة' ? 'تم قبول فكرتك' : newStatus === 'مرفوضة' ? 'تم رفض فكرتك' : `تم تحديث حالة فكرتك إلى: ${newStatus}`;
    let message = `${title} - "${idea.title}"`;
    if (response.trim()) message += ` | رد المدير: ${response}`;
    await createNotification(empIdNum, type, title, message);
  }, []);

  const sendGrievanceNotification = useCallback(async (violation: ViolationRecord, newStatus: string, response: string) => {
    const empIdNum = parseInt(violation.employeeId, 10);
    if (isNaN(empIdNum)) return;
    const type = 'grievance_response';
    const title = newStatus === 'تم قبول التظلم' ? 'تم قبول تظلمك' : newStatus === 'تم رفض التظلم' ? 'تم رفض تظلمك' : 'تم تحديث حالة تظلمك';
    let message = `${title} - بخصوص مخالفة: ${violation.violationType} بتاريخ ${violation.date}`;
    if (response.trim()) message += ` | رد المدير: ${response}`;
    await createNotification(empIdNum, type, title, message);
  }, []);

  // ============ ACTIONS ============

  async function handleLeaveAction() {
    if (!selectedLeave || !leaveNewStatus) return;
    setSaving(true);
    try {
      const notesUpdate = leaveResponse.trim()
        ? `${selectedLeave.notes ? selectedLeave.notes + ' | ' : ''}رد المدير: ${leaveResponse.trim()}`
        : selectedLeave.notes;
      await updateAttendanceRecord(selectedLeave.id, { approved: leaveNewStatus, notes: notesUpdate });
      await sendLeaveNotification(selectedLeave, leaveNewStatus, leaveResponse.trim());
      toast.success(leaveNewStatus === 'نعم' ? 'تمت الموافقة على الإجازة وتم إشعار الموظف' : leaveNewStatus === 'لا' ? 'تم رفض الإجازة وتم إشعار الموظف' : 'تم تحديث حالة الطلب');
      setLeaveDialog(false);
      setSelectedLeave(null);
      setLeaveResponse('');
      setLeaveNewStatus('');
      await refreshAttendance();
    } catch {
      toast.error('فشل في تحديث الطلب');
    } finally {
      setSaving(false);
    }
  }

  async function handleQuickLeaveAction(record: AttendanceRecord, action: 'نعم' | 'لا') {
    setSaving(true);
    try {
      await updateAttendanceRecord(record.id, { approved: action });
      await sendLeaveNotification(record, action, '');
      toast.success(action === 'نعم' ? 'تمت الموافقة وتم إشعار الموظف' : 'تم الرفض وتم إشعار الموظف');
      await refreshAttendance();
    } catch {
      toast.error('فشل في تحديث الطلب');
    } finally {
      setSaving(false);
    }
  }

  async function handleIdeaAction() {
    if (!selectedIdea || !ideaNewStatus) return;
    setSaving(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const notesUpdate = ideaResponse.trim()
        ? `${selectedIdea.notes ? selectedIdea.notes + ' | ' : ''}رد المدير: ${ideaResponse.trim()}`
        : selectedIdea.notes;
      await updateIdea(selectedIdea.id, { status: ideaNewStatus, decisionDate: today, notes: notesUpdate });
      await sendIdeaNotification(selectedIdea, ideaNewStatus, ideaResponse.trim());
      toast.success('تم تحديث حالة الفكرة وتم إشعار الموظف');
      setIdeaDialog(false);
      setSelectedIdea(null);
      setIdeaNewStatus('');
      setIdeaResponse('');
      await refreshIdeas();
    } catch {
      toast.error('فشل في تحديث الفكرة');
    } finally {
      setSaving(false);
    }
  }

  async function handleQuickIdeaAction(idea: IdeaRecord, action: 'مقبولة' | 'مرفوضة') {
    setSaving(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      await updateIdea(idea.id, { status: action, decisionDate: today });
      await sendIdeaNotification(idea, action, '');
      toast.success(action === 'مقبولة' ? 'تم قبول الفكرة وتم إشعار الموظف' : 'تم رفض الفكرة وتم إشعار الموظف');
      await refreshIdeas();
    } catch {
      toast.error('فشل');
    } finally {
      setSaving(false);
    }
  }

  async function handleGrievanceAction() {
    if (!selectedGrievance || !grievanceNewStatus) return;
    setSaving(true);
    try {
      const notesUpdate = grievanceResponse.trim()
        ? `${selectedGrievance.notes ? selectedGrievance.notes + ' | ' : ''}رد المدير على التظلم: ${grievanceResponse.trim()}`
        : selectedGrievance.notes;
      await updateViolation(selectedGrievance.id, { grievanceStatus: grievanceNewStatus, notes: notesUpdate });
      await sendGrievanceNotification(selectedGrievance, grievanceNewStatus, grievanceResponse.trim());
      toast.success('تم تحديث حالة التظلم وتم إشعار الموظف');
      setGrievanceDialog(false);
      setSelectedGrievance(null);
      setGrievanceResponse('');
      setGrievanceNewStatus('');
      await refreshViolations();
    } catch {
      toast.error('فشل في تحديث التظلم');
    } finally {
      setSaving(false);
    }
  }

  async function handleQuickGrievanceAction(v: ViolationRecord, action: 'تم قبول التظلم' | 'تم رفض التظلم') {
    setSaving(true);
    try {
      await updateViolation(v.id, { grievanceStatus: action });
      await sendGrievanceNotification(v, action, '');
      toast.success(action === 'تم قبول التظلم' ? 'تم قبول التظلم وتم إشعار الموظف' : 'تم رفض التظلم وتم إشعار الموظف');
      await refreshViolations();
    } catch {
      toast.error('فشل');
    } finally {
      setSaving(false);
    }
  }

  // ============ EXPORT ============

  function exportLeavesCSV() {
    const headers = ['الموظف', 'التاريخ', 'نوع الإجازة', 'الحالة', 'ملاحظات'];
    const rows = filteredLeaves.map((r) => [
      getEmployeeNameFromList(employees, r.employeeId),
      r.date,
      getLeaveType(r),
      r.approved === 'نعم' ? 'موافق عليها' : r.approved === 'لا' ? 'مرفوضة' : r.approved === 'قيد المراجعة' ? 'قيد المراجعة' : 'بانتظار المراجعة',
      r.notes || '',
    ]);
    downloadCSV('طلبات_الإجازة.csv', headers, rows);
    toast.success('تم تصدير البيانات بنجاح');
  }

  function exportLeavesPDF() {
    const headers = ['الموظف', 'التاريخ', 'نوع الإجازة', 'الحالة', 'ملاحظات'];
    const rows = filteredLeaves.map((r) => [
      getEmployeeNameFromList(employees, r.employeeId),
      r.date,
      getLeaveType(r),
      r.approved === 'نعم' ? 'موافق عليها' : r.approved === 'لا' ? 'مرفوضة' : r.approved === 'قيد المراجعة' ? 'قيد المراجعة' : 'بانتظار المراجعة',
      r.notes || '',
    ]);
    downloadHTMLReport('تقرير طلبات الإجازة', headers, rows);
  }

  function exportIdeasCSV() {
    const headers = ['الموظف', 'عنوان الفكرة', 'التصنيف', 'الأثر المتوقع', 'تاريخ التقديم', 'الحالة', 'ملاحظات'];
    const rows = filteredIdeas.map((i) => [
      getEmployeeNameFromList(employees, i.employeeId),
      i.title, i.classification, i.expectedImpact, i.submissionDate, i.status, i.notes || '',
    ]);
    downloadCSV('الأفكار_الإبداعية.csv', headers, rows);
    toast.success('تم تصدير البيانات بنجاح');
  }

  function exportIdeasPDF() {
    const headers = ['الموظف', 'عنوان الفكرة', 'التصنيف', 'الأثر المتوقع', 'تاريخ التقديم', 'الحالة', 'ملاحظات'];
    const rows = filteredIdeas.map((i) => [
      getEmployeeNameFromList(employees, i.employeeId),
      i.title, i.classification, i.expectedImpact, i.submissionDate, i.status, i.notes || '',
    ]);
    downloadHTMLReport('تقرير الأفكار الإبداعية', headers, rows);
  }

  function exportGrievancesCSV() {
    const headers = ['الموظف', 'التاريخ', 'نوع المخالفة', 'الشدة', 'العقوبة', 'حالة التظلم', 'ملاحظات'];
    const rows = filteredGrievances.map((v) => [
      getEmployeeNameFromList(employees, v.employeeId),
      v.date, v.violationType, v.severity, v.penalty, v.grievanceStatus, v.notes || '',
    ]);
    downloadCSV('التظلمات.csv', headers, rows);
    toast.success('تم تصدير البيانات بنجاح');
  }

  function exportGrievancesPDF() {
    const headers = ['الموظف', 'التاريخ', 'نوع المخالفة', 'الشدة', 'العقوبة', 'حالة التظلم', 'ملاحظات'];
    const rows = filteredGrievances.map((v) => [
      getEmployeeNameFromList(employees, v.employeeId),
      v.date, v.violationType, v.severity, v.penalty, v.grievanceStatus, v.notes || '',
    ]);
    downloadHTMLReport('تقرير التظلمات', headers, rows);
  }

  // ============ BADGES ============

  const approvalBadge = (status: string) => {
    switch (status) {
      case 'نعم': return <Badge className="bg-emerald-100 text-emerald-700 border-0">موافق عليها</Badge>;
      case 'لا': return <Badge className="bg-red-100 text-red-700 border-0">مرفوضة</Badge>;
      case 'قيد المراجعة': return <Badge className="bg-amber-100 text-amber-700 border-0">قيد المراجعة</Badge>;
      default: return <Badge className="bg-gray-100 text-gray-700 border-0">بانتظار المراجعة</Badge>;
    }
  };

  const ideaStatusBadge = (status: string) => {
    switch (status) {
      case 'مقبولة': return <Badge className="bg-emerald-100 text-emerald-700 border-0">مقبولة</Badge>;
      case 'مرفوضة': return <Badge className="bg-red-100 text-red-700 border-0">مرفوضة</Badge>;
      case 'قيد التنفيذ': return <Badge className="bg-blue-100 text-blue-700 border-0">قيد التنفيذ</Badge>;
      case 'منفذة': return <Badge className="bg-purple-100 text-purple-700 border-0">منفذة</Badge>;
      default: return <Badge className="bg-amber-100 text-amber-700 border-0">قيد المراجعة</Badge>;
    }
  };

  const grievanceBadge = (status: string) => {
    switch (status) {
      case 'تظلم قيد المراجعة': return <Badge className="bg-amber-100 text-amber-700 border-0">قيد المراجعة</Badge>;
      case 'تم قبول التظلم': return <Badge className="bg-emerald-100 text-emerald-700 border-0">تم القبول</Badge>;
      case 'تم رفض التظلم': return <Badge className="bg-red-100 text-red-700 border-0">تم الرفض</Badge>;
      default: return <Badge className="bg-gray-100 text-gray-700 border-0">{status}</Badge>;
    }
  };

  const isPending = (approved: string) => approved === 'قيد المراجعة' || approved === 'لا ينطبق';

  // ============ RENDER ============

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <ClipboardList className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى إدارة الطلبات</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a] text-white">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <ClipboardList className="w-5 h-5 text-indigo-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">إدارة الطلبات</h1>
              <p className="text-xs text-[#64748B]">مراجعة والرد على طلبات الإجازة والأفكار والتظلمات</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {loading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-r-4 border-r-amber-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setTab('leaves')}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="bg-amber-100 rounded-full p-3"><CalendarDays className="w-6 h-6 text-amber-600" /></div>
                    <div>
                      <p className="text-2xl font-bold text-amber-600">{pendingLeavesCount}</p>
                      <p className="text-sm text-gray-600">طلبات إجازة معلقة</p>
                      <p className="text-xs text-gray-400">إجمالي: {leaveRequests.length}</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-r-4 border-r-blue-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setTab('ideas')}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="bg-blue-100 rounded-full p-3"><Lightbulb className="w-6 h-6 text-blue-600" /></div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">{pendingIdeasCount}</p>
                      <p className="text-sm text-gray-600">أفكار بانتظار المراجعة</p>
                      <p className="text-xs text-gray-400">إجمالي: {ideas.length}</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-r-4 border-r-red-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setTab('grievances')}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="bg-red-100 rounded-full p-3"><AlertTriangle className="w-6 h-6 text-red-600" /></div>
                    <div>
                      <p className="text-2xl font-bold text-red-600">{pendingGrievancesCount}</p>
                      <p className="text-sm text-gray-600">تظلمات بانتظار الرد</p>
                      <p className="text-xs text-gray-400">إجمالي: {grievances.length}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Tabs */}
              <Tabs value={tab} onValueChange={setTab}>
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="leaves" className="gap-1 text-xs sm:text-sm">
                    <CalendarDays className="w-4 h-4" />
                    <span className="hidden sm:inline">طلبات</span> الإجازة
                    {pendingLeavesCount > 0 && <Badge className="bg-amber-500 text-white border-0 text-xs mr-1">{pendingLeavesCount}</Badge>}
                  </TabsTrigger>
                  <TabsTrigger value="ideas" className="gap-1 text-xs sm:text-sm">
                    <Lightbulb className="w-4 h-4" />
                    الأفكار
                    {pendingIdeasCount > 0 && <Badge className="bg-blue-500 text-white border-0 text-xs mr-1">{pendingIdeasCount}</Badge>}
                  </TabsTrigger>
                  <TabsTrigger value="grievances" className="gap-1 text-xs sm:text-sm">
                    <AlertTriangle className="w-4 h-4" />
                    التظلمات
                    {pendingGrievancesCount > 0 && <Badge className="bg-red-500 text-white border-0 text-xs mr-1">{pendingGrievancesCount}</Badge>}
                  </TabsTrigger>
                </TabsList>

                {/* ============ LEAVES TAB ============ */}
                <TabsContent value="leaves" className="space-y-4">
                  <Card>
                    <CardContent className="p-4 space-y-4">
                      {/* Search & Filter Bar */}
                      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                        <div className="flex gap-2 flex-1 w-full sm:w-auto">
                          <div className="relative flex-1 max-w-sm">
                            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input
                              placeholder="بحث بالاسم أو التاريخ..."
                              value={leaveSearch}
                              onChange={(e) => setLeaveSearch(e.target.value)}
                              className="pr-10"
                            />
                          </div>
                          <Select value={leaveFilter} onValueChange={(v) => setLeaveFilter(v as LeaveFilter)}>
                            <SelectTrigger className="w-40"><SelectValue placeholder="الحالة" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">الكل</SelectItem>
                              <SelectItem value="pending">معلقة</SelectItem>
                              <SelectItem value="approved">موافق عليها</SelectItem>
                              <SelectItem value="rejected">مرفوضة</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={exportLeavesCSV} className="gap-1">
                            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
                          </Button>
                          <Button size="sm" variant="outline" onClick={exportLeavesPDF} className="gap-1">
                            <FileText className="w-3.5 h-3.5" /> PDF
                          </Button>
                        </div>
                      </div>

                      <p className="text-sm text-gray-500">عرض {filteredLeaves.length} من {leaveRequests.length} طلب</p>

                      <ScrollArea className="w-full max-h-[500px]">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">التاريخ</TableHead>
                              <TableHead className="text-right">نوع الإجازة</TableHead>
                              <TableHead className="text-right">ملاحظات</TableHead>
                              <TableHead className="text-right">الحالة</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredLeaves.length === 0 ? (
                              <TableRow><TableCell colSpan={6} className="text-center py-8 text-gray-400">لا توجد نتائج</TableCell></TableRow>
                            ) : (
                              filteredLeaves.map((rec) => (
                                <TableRow key={rec.id} className={`hover:bg-gray-50 ${isPending(rec.approved) ? 'bg-amber-50/30' : ''}`}>
                                  <TableCell className="font-medium">{getEmployeeNameFromList(employees, rec.employeeId)}</TableCell>
                                  <TableCell className="font-mono text-sm">{rec.date}</TableCell>
                                  <TableCell><Badge className="bg-blue-100 text-blue-700 border-0 text-xs">{getLeaveType(rec)}</Badge></TableCell>
                                  <TableCell className="text-sm text-gray-600 max-w-[200px] truncate">{rec.notes || '-'}</TableCell>
                                  <TableCell>{approvalBadge(rec.approved)}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-1">
                                      {isPending(rec.approved) && (
                                        <>
                                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 px-2 text-xs" onClick={() => handleQuickLeaveAction(rec, 'نعم')} disabled={saving}>
                                            <CheckCircle className="w-3 h-3 ml-1" />موافقة
                                          </Button>
                                          <Button size="sm" variant="outline" className="border-red-300 text-red-600 hover:bg-red-50 h-7 px-2 text-xs" onClick={() => handleQuickLeaveAction(rec, 'لا')} disabled={saving}>
                                            <XCircle className="w-3 h-3 ml-1" />رفض
                                          </Button>
                                        </>
                                      )}
                                      <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => { setSelectedLeave(rec); setLeaveNewStatus(rec.approved); setLeaveResponse(''); setLeaveDialog(true); }}>
                                        <MessageSquare className="w-3.5 h-3.5" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* ============ IDEAS TAB ============ */}
                <TabsContent value="ideas" className="space-y-4">
                  <Card>
                    <CardContent className="p-4 space-y-4">
                      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                        <div className="flex gap-2 flex-1 w-full sm:w-auto">
                          <div className="relative flex-1 max-w-sm">
                            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input placeholder="بحث بالاسم أو العنوان..." value={ideaSearch} onChange={(e) => setIdeaSearch(e.target.value)} className="pr-10" />
                          </div>
                          <Select value={ideaFilter} onValueChange={(v) => setIdeaFilter(v as IdeaFilter)}>
                            <SelectTrigger className="w-40"><SelectValue placeholder="الحالة" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">الكل</SelectItem>
                              <SelectItem value="pending">قيد المراجعة</SelectItem>
                              <SelectItem value="accepted">مقبولة</SelectItem>
                              <SelectItem value="rejected">مرفوضة</SelectItem>
                              <SelectItem value="implementing">قيد التنفيذ</SelectItem>
                              <SelectItem value="implemented">منفذة</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={exportIdeasCSV} className="gap-1">
                            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
                          </Button>
                          <Button size="sm" variant="outline" onClick={exportIdeasPDF} className="gap-1">
                            <FileText className="w-3.5 h-3.5" /> PDF
                          </Button>
                        </div>
                      </div>

                      <p className="text-sm text-gray-500">عرض {filteredIdeas.length} من {allIdeasSorted.length} فكرة</p>

                      <ScrollArea className="w-full max-h-[500px]">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">عنوان الفكرة</TableHead>
                              <TableHead className="text-right">التصنيف</TableHead>
                              <TableHead className="text-right">الأثر المتوقع</TableHead>
                              <TableHead className="text-right">تاريخ التقديم</TableHead>
                              <TableHead className="text-right">الحالة</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredIdeas.length === 0 ? (
                              <TableRow><TableCell colSpan={7} className="text-center py-8 text-gray-400">لا توجد نتائج</TableCell></TableRow>
                            ) : (
                              filteredIdeas.map((idea) => (
                                <TableRow key={idea.id} className={`hover:bg-gray-50 ${idea.status === 'قيد المراجعة' ? 'bg-blue-50/30' : ''}`}>
                                  <TableCell className="font-medium">{getEmployeeNameFromList(employees, idea.employeeId)}</TableCell>
                                  <TableCell className="text-sm max-w-[180px] truncate">{idea.title}</TableCell>
                                  <TableCell className="text-sm">{idea.classification}</TableCell>
                                  <TableCell className="text-sm">{idea.expectedImpact}</TableCell>
                                  <TableCell className="font-mono text-sm">{idea.submissionDate}</TableCell>
                                  <TableCell>{ideaStatusBadge(idea.status)}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-1">
                                      {idea.status === 'قيد المراجعة' && (
                                        <>
                                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 px-2 text-xs" onClick={() => handleQuickIdeaAction(idea, 'مقبولة')} disabled={saving}>
                                            <CheckCircle className="w-3 h-3 ml-1" />قبول
                                          </Button>
                                          <Button size="sm" variant="outline" className="border-red-300 text-red-600 hover:bg-red-50 h-7 px-2 text-xs" onClick={() => handleQuickIdeaAction(idea, 'مرفوضة')} disabled={saving}>
                                            <XCircle className="w-3 h-3 ml-1" />رفض
                                          </Button>
                                        </>
                                      )}
                                      <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => { setSelectedIdea(idea); setIdeaNewStatus(idea.status); setIdeaResponse(''); setIdeaDialog(true); }}>
                                        <MessageSquare className="w-3.5 h-3.5" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* ============ GRIEVANCES TAB ============ */}
                <TabsContent value="grievances" className="space-y-4">
                  <Card>
                    <CardContent className="p-4 space-y-4">
                      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                        <div className="flex gap-2 flex-1 w-full sm:w-auto">
                          <div className="relative flex-1 max-w-sm">
                            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input placeholder="بحث بالاسم أو النوع..." value={grievanceSearch} onChange={(e) => setGrievanceSearch(e.target.value)} className="pr-10" />
                          </div>
                          <Select value={grievanceFilter} onValueChange={(v) => setGrievanceFilter(v as GrievanceFilter)}>
                            <SelectTrigger className="w-40"><SelectValue placeholder="الحالة" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">الكل</SelectItem>
                              <SelectItem value="pending">قيد المراجعة</SelectItem>
                              <SelectItem value="accepted">تم القبول</SelectItem>
                              <SelectItem value="rejected">تم الرفض</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={exportGrievancesCSV} className="gap-1">
                            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
                          </Button>
                          <Button size="sm" variant="outline" onClick={exportGrievancesPDF} className="gap-1">
                            <FileText className="w-3.5 h-3.5" /> PDF
                          </Button>
                        </div>
                      </div>

                      <p className="text-sm text-gray-500">عرض {filteredGrievances.length} من {grievances.length} تظلم</p>

                      <ScrollArea className="w-full max-h-[500px]">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">التاريخ</TableHead>
                              <TableHead className="text-right">نوع المخالفة</TableHead>
                              <TableHead className="text-right">التفاصيل</TableHead>
                              <TableHead className="text-right">الشدة</TableHead>
                              <TableHead className="text-right">حالة التظلم</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredGrievances.length === 0 ? (
                              <TableRow><TableCell colSpan={7} className="text-center py-8 text-gray-400">لا توجد نتائج</TableCell></TableRow>
                            ) : (
                              filteredGrievances.map((v) => (
                                <TableRow key={v.id} className={`hover:bg-gray-50 ${v.grievanceStatus === 'تظلم قيد المراجعة' ? 'bg-red-50/30' : ''}`}>
                                  <TableCell className="font-medium">{getEmployeeNameFromList(employees, v.employeeId)}</TableCell>
                                  <TableCell className="font-mono text-sm">{v.date}</TableCell>
                                  <TableCell className="text-sm">{v.violationType}</TableCell>
                                  <TableCell className="text-sm text-gray-600 max-w-[180px] truncate">{v.details}</TableCell>
                                  <TableCell className="text-sm">{v.severity}</TableCell>
                                  <TableCell>{grievanceBadge(v.grievanceStatus)}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-1">
                                      {v.grievanceStatus === 'تظلم قيد المراجعة' && (
                                        <>
                                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 px-2 text-xs" onClick={() => handleQuickGrievanceAction(v, 'تم قبول التظلم')} disabled={saving}>
                                            <CheckCircle className="w-3 h-3 ml-1" />قبول
                                          </Button>
                                          <Button size="sm" variant="outline" className="border-red-300 text-red-600 hover:bg-red-50 h-7 px-2 text-xs" onClick={() => handleQuickGrievanceAction(v, 'تم رفض التظلم')} disabled={saving}>
                                            <XCircle className="w-3 h-3 ml-1" />رفض
                                          </Button>
                                        </>
                                      )}
                                      <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => { setSelectedGrievance(v); setGrievanceNewStatus(v.grievanceStatus); setGrievanceResponse(''); setGrievanceDialog(true); }}>
                                        <MessageSquare className="w-3.5 h-3.5" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </main>
      </div>

      {/* ============ LEAVE DETAIL / REPLY DIALOG ============ */}
      <Dialog open={leaveDialog} onOpenChange={setLeaveDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarDays className="w-5 h-5 text-blue-600" />
              تفاصيل طلب الإجازة والرد عليه
            </DialogTitle>
          </DialogHeader>
          {selectedLeave && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الموظف</p>
                  <p className="font-semibold">{getEmployeeNameFromList(employees, selectedLeave.employeeId)}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">التاريخ</p>
                  <p className="font-semibold font-mono">{selectedLeave.date}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">نوع الإجازة</p>
                  <p className="font-semibold">{getLeaveType(selectedLeave)}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الحالة الحالية</p>
                  {approvalBadge(selectedLeave.approved)}
                </div>
              </div>
              {selectedLeave.notes && (
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">ملاحظات الموظف</p>
                  <p className="text-sm">{selectedLeave.notes}</p>
                </div>
              )}
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-semibold text-sm text-[#1E3A5F]">تحديث الطلب والرد</h4>
                <div>
                  <Label className="text-xs font-medium">تغيير الحالة</Label>
                  <Select value={leaveNewStatus} onValueChange={setLeaveNewStatus}>
                    <SelectTrigger><SelectValue placeholder="اختر الحالة" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="نعم">✅ موافقة</SelectItem>
                      <SelectItem value="لا">❌ رفض</SelectItem>
                      <SelectItem value="قيد المراجعة">⏳ قيد المراجعة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-medium">رد المدير</Label>
                  <Textarea
                    value={leaveResponse}
                    onChange={(e) => setLeaveResponse(e.target.value)}
                    placeholder="اكتب ردك أو ملاحظاتك هنا... (سيتم إرسال إشعار للموظف)"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setLeaveDialog(false)}>إغلاق</Button>
            <Button
              className="bg-[#1E3A5F] hover:bg-[#2a4f7a] text-white"
              onClick={handleLeaveAction}
              disabled={saving || !leaveNewStatus}
            >
              {saving ? 'جاري الحفظ...' : '💾 حفظ وإرسال إشعار'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ IDEA DETAIL / REPLY DIALOG ============ */}
      <Dialog open={ideaDialog} onOpenChange={setIdeaDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-blue-600" />
              تفاصيل الفكرة والرد عليها
            </DialogTitle>
          </DialogHeader>
          {selectedIdea && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الموظف</p>
                  <p className="font-semibold">{getEmployeeNameFromList(employees, selectedIdea.employeeId)}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">تاريخ التقديم</p>
                  <p className="font-semibold font-mono">{selectedIdea.submissionDate}</p>
                </div>
                <div className="bg-gray-50 rounded p-3 col-span-2">
                  <p className="text-gray-500 text-xs mb-1">عنوان الفكرة</p>
                  <p className="font-semibold">{selectedIdea.title}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">التصنيف</p>
                  <p className="font-semibold">{selectedIdea.classification}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الأثر المتوقع</p>
                  <p className="font-semibold">{selectedIdea.expectedImpact}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الحالة الحالية</p>
                  {ideaStatusBadge(selectedIdea.status)}
                </div>
                {selectedIdea.decisionDate && (
                  <div className="bg-gray-50 rounded p-3">
                    <p className="text-gray-500 text-xs mb-1">تاريخ القرار</p>
                    <p className="font-semibold font-mono">{selectedIdea.decisionDate}</p>
                  </div>
                )}
              </div>
              {selectedIdea.notes && (
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">ملاحظات</p>
                  <p className="text-sm">{selectedIdea.notes}</p>
                </div>
              )}
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-semibold text-sm text-[#1E3A5F]">تحديث الفكرة والرد</h4>
                <div>
                  <Label className="text-xs font-medium">تغيير الحالة</Label>
                  <Select value={ideaNewStatus} onValueChange={setIdeaNewStatus}>
                    <SelectTrigger><SelectValue placeholder="اختر الحالة" /></SelectTrigger>
                    <SelectContent>
                      {IDEA_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-medium">رد المدير</Label>
                  <Textarea
                    value={ideaResponse}
                    onChange={(e) => setIdeaResponse(e.target.value)}
                    placeholder="اكتب ردك أو تعليقك على الفكرة... (سيتم إرسال إشعار للموظف)"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIdeaDialog(false)}>إغلاق</Button>
            <Button
              className="bg-[#1E3A5F] hover:bg-[#2a4f7a] text-white"
              onClick={handleIdeaAction}
              disabled={saving || !ideaNewStatus}
            >
              {saving ? 'جاري الحفظ...' : '💾 حفظ وإرسال إشعار'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ GRIEVANCE DETAIL / REPLY DIALOG ============ */}
      <Dialog open={grievanceDialog} onOpenChange={setGrievanceDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              تفاصيل التظلم والرد عليه
            </DialogTitle>
          </DialogHeader>
          {selectedGrievance && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الموظف</p>
                  <p className="font-semibold">{getEmployeeNameFromList(employees, selectedGrievance.employeeId)}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">التاريخ</p>
                  <p className="font-semibold font-mono">{selectedGrievance.date}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">نوع المخالفة</p>
                  <p className="font-semibold">{selectedGrievance.violationType}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">الشدة</p>
                  <p className="font-semibold">{selectedGrievance.severity}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">العقوبة</p>
                  <p className="font-semibold">{selectedGrievance.penalty}</p>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">حالة التظلم</p>
                  {grievanceBadge(selectedGrievance.grievanceStatus)}
                </div>
              </div>
              <div className="bg-gray-50 rounded p-3">
                <p className="text-gray-500 text-xs mb-1">تفاصيل المخالفة</p>
                <p className="text-sm">{selectedGrievance.details}</p>
              </div>
              {selectedGrievance.notes && (
                <div className="bg-gray-50 rounded p-3">
                  <p className="text-gray-500 text-xs mb-1">ملاحظات سابقة</p>
                  <p className="text-sm">{selectedGrievance.notes}</p>
                </div>
              )}
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-semibold text-sm text-[#1E3A5F]">تحديث التظلم والرد</h4>
                <div>
                  <Label className="text-xs font-medium">تغيير حالة التظلم</Label>
                  <Select value={grievanceNewStatus} onValueChange={setGrievanceNewStatus}>
                    <SelectTrigger><SelectValue placeholder="اختر الحالة" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="تظلم قيد المراجعة">⏳ قيد المراجعة</SelectItem>
                      <SelectItem value="تم قبول التظلم">✅ قبول التظلم</SelectItem>
                      <SelectItem value="تم رفض التظلم">❌ رفض التظلم</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-medium">رد المدير على التظلم</Label>
                  <Textarea
                    value={grievanceResponse}
                    onChange={(e) => setGrievanceResponse(e.target.value)}
                    placeholder="اكتب ردك على التظلم هنا... (سيتم إرسال إشعار للموظف)"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setGrievanceDialog(false)}>إغلاق</Button>
            <Button
              className="bg-[#1E3A5F] hover:bg-[#2a4f7a] text-white"
              onClick={handleGrievanceAction}
              disabled={saving || !grievanceNewStatus}
            >
              {saving ? 'جاري الحفظ...' : '💾 حفظ وإرسال إشعار'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}