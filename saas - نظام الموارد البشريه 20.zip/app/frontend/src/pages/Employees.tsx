import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Pencil, Trash2, Search, UserCog, Menu, Download } from 'lucide-react';
import { Sidebar } from './Index';
import {
  Employee, createEmployee, updateEmployee, deleteEmployee,
  DEPARTMENTS, EMPLOYEE_STATUSES, JOB_TITLES, formatCurrency
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

const EMPTY_FORM: Omit<Employee, 'id'> = {
  empCode: '', fullName: '', department: DEPARTMENTS[0], jobTitle: JOB_TITLES[0], hireDate: '',
  basicSalary: 0, email: '', status: 'نشط', annualLeaveBalance: 30, dailyWorkHours: 8,
};

export default function EmployeesPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [filterDept, setFilterDept] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, loading: dataLoading, refreshEmployees } = useHRData();

  function handleExport() {
    exportToCSV(
      filtered.map((e) => ({
        empCode: e.empCode,
        fullName: e.fullName,
        department: e.department,
        jobTitle: e.jobTitle,
        hireDate: e.hireDate,
        basicSalary: e.basicSalary,
        email: e.email,
        status: e.status,
        annualLeaveBalance: e.annualLeaveBalance,
      })),
      [
        { key: 'empCode', label: 'رمز الموظف' },
        { key: 'fullName', label: 'الاسم الكامل' },
        { key: 'department', label: 'القسم' },
        { key: 'jobTitle', label: 'المسمى الوظيفي' },
        { key: 'hireDate', label: 'تاريخ التعيين' },
        { key: 'basicSalary', label: 'الراتب الأساسي' },
        { key: 'email', label: 'البريد الإلكتروني' },
        { key: 'status', label: 'الحالة' },
        { key: 'annualLeaveBalance', label: 'رصيد الإجازات' },
      ],
      'تقرير_الموظفين'
    );
  }

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <UserCog className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى بيانات الموظفين</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filtered = employees.filter((e) => {
    const matchSearch = e.fullName.includes(search) || e.empCode.includes(search) || e.email.includes(search);
    const matchDept = filterDept === 'all' || e.department === filterDept;
    const matchStatus = filterStatus === 'all' || e.status === filterStatus;
    return matchSearch && matchDept && matchStatus;
  });

  function openAdd() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEdit(emp: Employee) {
    setEditingId(emp.id);
    setForm({
      empCode: emp.empCode, fullName: emp.fullName, department: emp.department, jobTitle: emp.jobTitle,
      hireDate: emp.hireDate, basicSalary: emp.basicSalary, email: emp.email,
      status: emp.status, annualLeaveBalance: emp.annualLeaveBalance, dailyWorkHours: emp.dailyWorkHours,
    });
    setDialogOpen(true);
  }

  async function handleSave() {
    if (!form.empCode || !form.fullName || !form.jobTitle || !form.hireDate) return;
    setSaving(true);
    try {
      if (editingId) {
        await updateEmployee(editingId, form);
      } else {
        await createEmployee(form);
      }
      setDialogOpen(false);
      await refreshEmployees();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (confirm('هل أنت متأكد من حذف هذا الموظف؟')) {
      await deleteEmployee(id);
      await refreshEmployees();
    }
  }

  const statusColor: Record<string, string> = {
    'نشط': 'bg-emerald-100 text-emerald-700',
    'إجازة': 'bg-blue-100 text-blue-700',
    'متوقف مؤقتاً': 'bg-amber-100 text-amber-700',
    'منتهي الخدمة': 'bg-red-100 text-red-700',
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <UserCog className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">بيانات الموظفين</h1>
              <p className="text-xs text-[#64748B]">إدارة معلومات الموظفين الأساسية</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              {/* Filters */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex flex-wrap gap-3 items-end">
                    <div className="flex-1 min-w-[200px]">
                      <Label className="text-xs mb-1 block">بحث</Label>
                      <div className="relative">
                        <Search className="absolute right-3 top-2.5 w-4 h-4 text-gray-400" />
                        <Input placeholder="اسم، رقم، أو بريد..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-9" />
                      </div>
                    </div>
                    <div className="w-[180px]">
                      <Label className="text-xs mb-1 block">القسم</Label>
                      <Select value={filterDept} onValueChange={setFilterDept}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الأقسام</SelectItem>
                          {DEPARTMENTS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-[160px]">
                      <Label className="text-xs mb-1 block">الحالة</Label>
                      <Select value={filterStatus} onValueChange={setFilterStatus}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الحالات</SelectItem>
                          {EMPLOYEE_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleExport} variant="outline" className="gap-2">
                      <Download className="w-4 h-4" />
                      تصدير CSV
                    </Button>
                    <Button onClick={openAdd} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                      <Plus className="w-4 h-4 ml-2" />
                      إضافة موظف
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Table */}
              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="w-full">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-right">الرقم</TableHead>
                          <TableHead className="text-right">الاسم</TableHead>
                          <TableHead className="text-right">القسم</TableHead>
                          <TableHead className="text-right">المسمى الوظيفي</TableHead>
                          <TableHead className="text-right">تاريخ التعيين</TableHead>
                          <TableHead className="text-right">الراتب</TableHead>
                          <TableHead className="text-right">الحالة</TableHead>
                          <TableHead className="text-right">رصيد الإجازات</TableHead>
                          <TableHead className="text-right">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filtered.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8 text-gray-400">لا توجد بيانات</TableCell>
                          </TableRow>
                        ) : (
                          filtered.map((emp) => (
                            <TableRow key={emp.id} className="hover:bg-gray-50">
                              <TableCell className="font-mono text-sm">{emp.empCode}</TableCell>
                              <TableCell className="font-medium">{emp.fullName}</TableCell>
                              <TableCell className="text-sm">{emp.department}</TableCell>
                              <TableCell className="text-sm">{emp.jobTitle}</TableCell>
                              <TableCell className="text-sm">{emp.hireDate}</TableCell>
                              <TableCell className="text-sm font-medium">{formatCurrency(emp.basicSalary)}</TableCell>
                              <TableCell>
                                <Badge className={`${statusColor[emp.status] || 'bg-gray-100 text-gray-700'} border-0`}>
                                  {emp.status}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm">{emp.annualLeaveBalance} يوم</TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button variant="ghost" size="icon" onClick={() => openEdit(emp)}>
                                    <Pencil className="w-4 h-4 text-blue-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(emp.id)}>
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>

              <p className="text-xs text-gray-400 text-center">إجمالي: {filtered.length} موظف</p>
            </>
          )}
        </main>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingId ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div>
              <Label className="text-xs">رمز الموظف * (مثال: EMP007)</Label>
              <Input value={form.empCode} onChange={(e) => setForm({ ...form, empCode: e.target.value })} placeholder="EMP007" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">الاسم الكامل *</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">المسمى الوظيفي *</Label>
                <Select value={form.jobTitle} onValueChange={(v) => setForm({ ...form, jobTitle: v })}>
                  <SelectTrigger><SelectValue placeholder="اختر المسمى الوظيفي" /></SelectTrigger>
                  <SelectContent>
                    {JOB_TITLES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">القسم</Label>
                <Select value={form.department} onValueChange={(v) => setForm({ ...form, department: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">الحالة</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EMPLOYEE_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">تاريخ التعيين *</Label>
                <Input type="date" value={form.hireDate} onChange={(e) => setForm({ ...form, hireDate: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">الراتب الأساسي (ر.ع)</Label>
                <Input type="number" value={form.basicSalary} onChange={(e) => setForm({ ...form, basicSalary: Number(e.target.value) })} />
              </div>
            </div>
            <div>
              <Label className="text-xs">البريد الإلكتروني</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">رصيد الإجازات السنوية</Label>
                <Input type="number" value={form.annualLeaveBalance} onChange={(e) => setForm({ ...form, annualLeaveBalance: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-xs">ساعات العمل اليومية</Label>
                <Input type="number" value={form.dailyWorkHours} onChange={(e) => setForm({ ...form, dailyWorkHours: Number(e.target.value) })} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
              {saving ? 'جاري الحفظ...' : editingId ? 'حفظ التعديلات' : 'إضافة'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}