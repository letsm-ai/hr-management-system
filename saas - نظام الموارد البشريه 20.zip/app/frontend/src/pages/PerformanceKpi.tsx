import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus, Pencil, Trash2, Target, Menu, Download, TrendingUp, Award, BarChart3,
  RefreshCw, Link2, CheckCircle2, AlertTriangle, Loader2, ClipboardList,
} from 'lucide-react';
import { Sidebar } from './Index';
import {
  PerformanceKpiRecord, PerformanceRecord,
  createPerformanceKpi, updatePerformanceKpi, deletePerformanceKpi,
  getEmployeeNameFromList, getEmployeeByIdFromList, formatCurrency, getCurrentMonth,
  calculateKpiAchievementRate, calculateKpiBonus, getKpiRating, getKpiRatingColor,
  fetchClickUpWorkspaces, fetchClickUpSummary,
  calculatePerformanceScore, getPerformanceRating, getRatingColor, getMonthlyAttendanceStats,
  type ClickUpWorkspace, type ClickUpSummary, type Employee,
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import {
  autoMatchMembers, getMatchMethodLabel, getConfidenceBadgeClass,
} from '@/lib/member-matching';
import { fetchMemberMapping } from '@/lib/clickup-api';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';
import { toast } from 'sonner';

const defaultForm = {
  employeeId: '',
  tasksTarget: 10,
  tasksCompleted: 0,
  qualityScore: 7,
  timelinessScore: 7,
  collaborationScore: 7,
  innovationScore: 7,
  managerNotes: '',
  employeeGoals: '',
};

export default function PerformanceKpiPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [month, setMonth] = useState(getCurrentMonth());
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);
  const [activeTab, setActiveTab] = useState('kpi');
  const { user, loading: authLoading, login } = useAuth();
  const { employees, attendance, ideas: allIdeas, performanceKpis, performance: allPerf, loading: dataLoading, refreshPerformanceKpis } = useHRData();

  // ClickUp integration states
  const [clickupDialogOpen, setClickupDialogOpen] = useState(false);
  const [clickupStep, setClickupStep] = useState<'workspace' | 'mapping' | 'syncing' | 'done'>('workspace');
  const [workspaces, setWorkspaces] = useState<ClickUpWorkspace[]>([]);
  const [selectedWorkspace, setSelectedWorkspace] = useState('');
  const [loadingWorkspaces, setLoadingWorkspaces] = useState(false);
  const [clickupSummary, setClickupSummary] = useState<ClickUpSummary | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [memberMapping, setMemberMapping] = useState<Record<string, string>>({});
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStats, setSyncStats] = useState({ total: 0, synced: 0, skipped: 0, failed: 0 });

  const monthKpis = useMemo(() => {
    return performanceKpis.filter((k) => k.month === month);
  }, [performanceKpis, month]);

  // Traditional performance records for the comprehensive tab
  const perfRecords = useMemo(() => {
    return allPerf.filter((r) => r.month === month);
  }, [allPerf, month]);

  const stats = useMemo(() => {
    if (monthKpis.length === 0) return { avgAchievement: 0, totalBonus: 0, excellentCount: 0, needsImprovement: 0 };
    const avgAchievement = Math.round(monthKpis.reduce((s, k) => s + k.achievementRate, 0) / monthKpis.length);
    const totalBonus = monthKpis.reduce((s, k) => s + k.kpiBonus, 0);
    const excellentCount = monthKpis.filter((k) => k.achievementRate >= 100).length;
    const needsImprovement = monthKpis.filter((k) => k.achievementRate < 75).length;
    return { avgAchievement, totalBonus, excellentCount, needsImprovement };
  }, [monthKpis]);

  // Combined performance score (KPI + Traditional)
  const combinedScores = useMemo(() => {
    return employees.filter(e => e.status === 'نشط').map(emp => {
      const kpi = monthKpis.find(k => k.employeeId === emp.id);
      const perf = perfRecords.find(r => r.employeeId === emp.id);
      const empIdeas = allIdeas.filter(i => i.employeeId === emp.id && i.month === month);

      const kpiScore = kpi ? kpi.achievementRate : 0;
      const traditionalScore = perf ? calculatePerformanceScore(perf, empIdeas) * 10 : 0; // scale to 100
      
      // Combined: 60% KPI + 40% Traditional
      const hasKpi = !!kpi;
      const hasPerf = !!perf;
      let combinedScore = 0;
      if (hasKpi && hasPerf) {
        combinedScore = kpiScore * 0.6 + traditionalScore * 0.4;
      } else if (hasKpi) {
        combinedScore = kpiScore;
      } else if (hasPerf) {
        combinedScore = traditionalScore;
      }

      return {
        employeeId: emp.id,
        employeeName: emp.fullName,
        kpiScore: hasKpi ? kpiScore : null,
        traditionalScore: hasPerf ? traditionalScore : null,
        combinedScore: (hasKpi || hasPerf) ? Math.round(combinedScore) : null,
        kpiBonus: kpi?.kpiBonus || 0,
        overallRating: kpi?.overallRating || (perf ? getPerformanceRating(calculatePerformanceScore(perf, empIdeas)) : '-'),
      };
    }).filter(s => s.combinedScore !== null);
  }, [employees, monthKpis, perfRecords, allIdeas, month]);

  // ---- ClickUp Functions ----

  async function openClickupSync() {
    setClickupStep('workspace');
    setSelectedWorkspace('');
    setClickupSummary(null);
    setMemberMapping({});
    setSyncProgress(0);
    setSyncStats({ total: 0, synced: 0, skipped: 0, failed: 0 });
    setClickupDialogOpen(true);

    // Load workspaces
    setLoadingWorkspaces(true);
    try {
      const ws = await fetchClickUpWorkspaces();
      setWorkspaces(ws);
      if (ws.length === 1) {
        setSelectedWorkspace(ws[0].id);
      }
    } catch {
      toast.error('فشل في الاتصال بـ ClickUp. تأكد من صحة التوكن.');
    } finally {
      setLoadingWorkspaces(false);
    }
  }

  async function handleFetchSummary() {
    if (!selectedWorkspace) return;
    setLoadingSummary(true);

    const [yearStr, monthStr] = month.split('-');
    const year = parseInt(yearStr);
    const mon = parseInt(monthStr);
    const dateFrom = `${year}-${monthStr}-01`;
    const lastDay = new Date(year, mon, 0).getDate();
    const dateTo = `${year}-${monthStr}-${String(lastDay).padStart(2, '0')}`;

    try {
      const summary = await fetchClickUpSummary(selectedWorkspace, dateFrom, dateTo);
      if (summary) {
        setClickupSummary(summary);

        let savedMapping: Record<string, string> = {};
        try {
          savedMapping = await fetchMemberMapping();
        } catch {
          // No saved mapping
        }
        const memberInfos = summary.members.map((m) => ({
          clickup_id: m.clickup_id,
          username: m.username || '',
          email: m.email || '',
        }));
        const { mapping: autoMapping, stats: matchStats } = autoMatchMembers(
          memberInfos,
          employees,
          savedMapping,
        );
        setMemberMapping(autoMapping);
        if (matchStats.autoMatched > 0) {
          toast.info(`تم مطابقة ${matchStats.autoMatched} عضو تلقائياً (${matchStats.savedKept} محفوظ مسبقاً)`);
        }
        setClickupStep('mapping');
      } else {
        toast.error('لم يتم العثور على بيانات من ClickUp');
      }
    } catch {
      toast.error('فشل في جلب بيانات المهام من ClickUp');
    } finally {
      setLoadingSummary(false);
    }
  }

  async function handleClickupSync() {
    if (!clickupSummary) return;
    setClickupStep('syncing');
    setSyncProgress(0);

    const membersToSync = clickupSummary.members.filter(
      (m) => memberMapping[m.clickup_id] && m.total_tasks > 0
    );
    const total = membersToSync.length;
    let synced = 0;
    let skipped = 0;
    let failed = 0;

    setSyncStats({ total, synced: 0, skipped: 0, failed: 0 });

    for (let i = 0; i < membersToSync.length; i++) {
      const member = membersToSync[i];
      const employeeId = memberMapping[member.clickup_id];
      const emp = getEmployeeByIdFromList(employees, employeeId);

      const existingKpi = monthKpis.find((k) => k.employeeId === employeeId);

      try {
        const achievementRate = calculateKpiAchievementRate(member.completed_tasks, member.total_tasks);
        const kpiBonus = emp ? calculateKpiBonus(achievementRate, emp.basicSalary) : 0;
        const overallRating = getKpiRating(achievementRate);

        if (existingKpi) {
          await updatePerformanceKpi(existingKpi.id, {
            tasksTarget: member.total_tasks,
            tasksCompleted: member.completed_tasks,
            achievementRate,
            kpiBonus,
            overallRating,
            managerNotes: `${existingKpi.managerNotes ? existingKpi.managerNotes + '\n' : ''}تم التحديث من ClickUp - ${new Date().toLocaleDateString('ar-SA')}`,
          });
          synced++;
        } else {
          await createPerformanceKpi({
            employeeId,
            month,
            tasksTarget: member.total_tasks,
            tasksCompleted: member.completed_tasks,
            achievementRate,
            kpiBonus,
            qualityScore: 7,
            timelinessScore: 7,
            collaborationScore: 7,
            innovationScore: 7,
            overallRating,
            managerNotes: `تم الاستيراد من ClickUp - ${new Date().toLocaleDateString('ar-SA')}`,
            employeeGoals: '',
          });
          synced++;
        }
      } catch {
        failed++;
      }

      setSyncProgress(Math.round(((i + 1) / total) * 100));
      setSyncStats({ total, synced, skipped, failed });
    }

    const unmappedWithTasks = clickupSummary.members.filter(
      (m) => !memberMapping[m.clickup_id] && m.total_tasks > 0
    ).length;
    skipped = unmappedWithTasks;
    setSyncStats({ total: total + skipped, synced, skipped, failed });

    setClickupStep('done');
    await refreshPerformanceKpis();
    if (synced > 0) {
      toast.success(`تم مزامنة بيانات ${synced} موظف من ClickUp بنجاح`);
    }
  }

  function openAdd() {
    setEditId(null);
    setForm({ ...defaultForm, employeeId: employees[0]?.id || '' });
    setDialogOpen(true);
  }

  function openEdit(kpi: PerformanceKpiRecord) {
    setEditId(kpi.id);
    setForm({
      employeeId: kpi.employeeId,
      tasksTarget: kpi.tasksTarget,
      tasksCompleted: kpi.tasksCompleted,
      qualityScore: kpi.qualityScore,
      timelinessScore: kpi.timelinessScore,
      collaborationScore: kpi.collaborationScore,
      innovationScore: kpi.innovationScore,
      managerNotes: kpi.managerNotes,
      employeeGoals: kpi.employeeGoals,
    });
    setDialogOpen(true);
  }

  async function handleSave() {
    if (!form.employeeId) return;
    setSaving(true);
    try {
      const achievementRate = calculateKpiAchievementRate(form.tasksCompleted, form.tasksTarget);
      const emp = getEmployeeByIdFromList(employees, form.employeeId);
      const kpiBonus = emp ? calculateKpiBonus(achievementRate, emp.basicSalary) : 0;
      const overallRating = getKpiRating(achievementRate);

      const data: Omit<PerformanceKpiRecord, 'id'> = {
        ...form,
        month,
        achievementRate,
        kpiBonus,
        overallRating,
      };

      if (editId) {
        await updatePerformanceKpi(editId, data);
      } else {
        await createPerformanceKpi(data);
      }
      setDialogOpen(false);
      await refreshPerformanceKpis();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await deletePerformanceKpi(id);
    await refreshPerformanceKpis();
  }

  function handleExport() {
    exportToCSV(
      monthKpis.map((k) => ({
        employee: getEmployeeNameFromList(employees, k.employeeId),
        tasksTarget: k.tasksTarget,
        tasksCompleted: k.tasksCompleted,
        achievementRate: `${k.achievementRate}%`,
        kpiBonus: k.kpiBonus,
        qualityScore: k.qualityScore,
        timelinessScore: k.timelinessScore,
        collaborationScore: k.collaborationScore,
        innovationScore: k.innovationScore,
        overallRating: k.overallRating,
      })),
      [
        { key: 'employee', label: 'الموظف' },
        { key: 'tasksTarget', label: 'المهام المستهدفة' },
        { key: 'tasksCompleted', label: 'المهام المنجزة' },
        { key: 'achievementRate', label: 'نسبة الإنجاز' },
        { key: 'kpiBonus', label: 'مكافأة الأداء' },
        { key: 'qualityScore', label: 'الجودة' },
        { key: 'timelinessScore', label: 'الالتزام بالوقت' },
        { key: 'collaborationScore', label: 'التعاون' },
        { key: 'innovationScore', label: 'الابتكار' },
        { key: 'overallRating', label: 'التقييم العام' },
      ],
      `تقرير_مؤشرات_الأداء_${month}`
    );
  }

  // Preview calculations
  const previewAchievement = calculateKpiAchievementRate(form.tasksCompleted, form.tasksTarget);
  const previewEmp = getEmployeeByIdFromList(employees, form.employeeId);
  const previewBonus = previewEmp ? calculateKpiBonus(previewAchievement, previewEmp.basicSalary) : 0;
  const previewRating = getKpiRating(previewAchievement);

  const months: string[] = [];
  for (let m = 1; m <= 12; m++) months.push(`2026-${String(m).padStart(2, '0')}`);

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <Target className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى مؤشرات الأداء</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  function ScoreInput({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
    return (
      <div>
        <div className="flex items-center justify-between mb-1">
          <Label className="text-xs">{label}</Label>
          <span className="text-xs font-bold text-blue-600">{value}/10</span>
        </div>
        <input
          type="range" min={1} max={10} value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
        />
      </div>
    );
  }

  const mappedCount = clickupSummary
    ? clickupSummary.members.filter((m) => memberMapping[m.clickup_id] && m.total_tasks > 0).length
    : 0;

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <Target className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">مؤشرات الأداء الرئيسية (KPI)</h1>
              <p className="text-xs text-[#64748B]">تقييم أداء الموظفين بناءً على المهام المنجزة والمعايير الشاملة</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              {/* Month Selector & Actions */}
              <div className="flex items-center justify-between flex-wrap gap-3">
                <Select value={month} onValueChange={setMonth}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {months.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
                <div className="flex gap-2 flex-wrap">
                  <Button onClick={openClickupSync} variant="outline" className="gap-2 border-purple-300 text-purple-700 hover:bg-purple-50">
                    <Link2 className="w-4 h-4" />
                    مزامنة من ClickUp
                  </Button>
                  <Button onClick={handleExport} variant="outline" className="gap-2">
                    <Download className="w-4 h-4" /> تصدير
                  </Button>
                  <Button onClick={openAdd} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                    <Plus className="w-4 h-4 ml-2" /> إضافة تقييم KPI
                  </Button>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Card>
                  <CardContent className="p-4 text-center">
                    <BarChart3 className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-blue-600">{stats.avgAchievement}%</p>
                    <p className="text-xs text-gray-500">متوسط الإنجاز</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <Award className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.totalBonus)}</p>
                    <p className="text-xs text-gray-500">إجمالي المكافآت</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="w-6 h-6 text-purple-500 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-purple-600">{stats.excellentCount}</p>
                    <p className="text-xs text-gray-500">تجاوزوا المستهدف</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <Target className="w-6 h-6 text-orange-500 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-orange-600">{stats.needsImprovement}</p>
                    <p className="text-xs text-gray-500">يحتاجون تحسين</p>
                  </CardContent>
                </Card>
              </div>

              {/* Tabs: KPI + Comprehensive */}
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="kpi" className="gap-2">
                    <Target className="w-4 h-4" /> مؤشرات KPI
                  </TabsTrigger>
                  <TabsTrigger value="comprehensive" className="gap-2">
                    <ClipboardList className="w-4 h-4" /> التقييم الشامل
                  </TabsTrigger>
                </TabsList>

                {/* KPI Tab */}
                <TabsContent value="kpi" className="space-y-4">
                  <Card>
                    <CardContent className="p-0">
                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">المستهدف</TableHead>
                              <TableHead className="text-right">المنجز</TableHead>
                              <TableHead className="text-right">نسبة الإنجاز</TableHead>
                              <TableHead className="text-right">الجودة</TableHead>
                              <TableHead className="text-right">الالتزام</TableHead>
                              <TableHead className="text-right">التعاون</TableHead>
                              <TableHead className="text-right">الابتكار</TableHead>
                              <TableHead className="text-right">المكافأة</TableHead>
                              <TableHead className="text-right">التقييم</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monthKpis.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={11} className="text-center py-8 text-gray-400">لا توجد تقييمات لهذا الشهر</TableCell>
                              </TableRow>
                            ) : (
                              monthKpis.map((kpi) => (
                                <TableRow key={kpi.id} className="hover:bg-gray-50">
                                  <TableCell className="font-medium text-sm">{getEmployeeNameFromList(employees, kpi.employeeId)}</TableCell>
                                  <TableCell className="text-sm text-center">{kpi.tasksTarget}</TableCell>
                                  <TableCell className="text-sm text-center">{kpi.tasksCompleted}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Progress value={Math.min(kpi.achievementRate, 100)} className="h-2 w-16" />
                                      <span className="text-sm font-semibold">{kpi.achievementRate}%</span>
                                    </div>
                                  </TableCell>
                                  <TableCell className="text-sm text-center">{kpi.qualityScore}/10</TableCell>
                                  <TableCell className="text-sm text-center">{kpi.timelinessScore}/10</TableCell>
                                  <TableCell className="text-sm text-center">{kpi.collaborationScore}/10</TableCell>
                                  <TableCell className="text-sm text-center">{kpi.innovationScore}/10</TableCell>
                                  <TableCell className="text-sm font-semibold text-emerald-600">
                                    {kpi.kpiBonus > 0 ? formatCurrency(kpi.kpiBonus) : '-'}
                                  </TableCell>
                                  <TableCell>
                                    <Badge className={`${getKpiRatingColor(kpi.achievementRate)} border-0 text-xs`}>
                                      {kpi.overallRating || getKpiRating(kpi.achievementRate)}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex gap-1">
                                      <Button variant="ghost" size="icon" onClick={() => openEdit(kpi)}>
                                        <Pencil className="w-4 h-4 text-blue-600" />
                                      </Button>
                                      <Button variant="ghost" size="icon" onClick={() => handleDelete(kpi.id)}>
                                        <Trash2 className="w-4 h-4 text-red-500" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  {/* KPI Bonus Guide */}
                  <Card>
                    <CardHeader className="pb-2"><CardTitle className="text-sm">دليل مكافآت الأداء</CardTitle></CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                        <div className="p-3 bg-emerald-50 rounded-lg">
                          <p className="font-semibold text-emerald-700">إنجاز ≥ 100%</p>
                          <p className="text-gray-600">مكافأة = 10% من الراتب الشهري</p>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg">
                          <p className="font-semibold text-green-700">إنجاز ≥ 90%</p>
                          <p className="text-gray-600">مكافأة = 5% من الراتب الشهري</p>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <p className="font-semibold text-gray-700">إنجاز &lt; 90%</p>
                          <p className="text-gray-600">لا توجد مكافأة</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Comprehensive Evaluation Tab */}
                <TabsContent value="comprehensive" className="space-y-4">
                  <Card className="border-blue-200 bg-blue-50/50">
                    <CardContent className="p-4">
                      <p className="text-sm text-blue-800">
                        <strong>التقييم الشامل:</strong> يجمع بين مؤشرات KPI (60%) والتقييم التقليدي (40%) لإعطاء صورة كاملة عن أداء الموظف. يُستخدم هذا التقييم المدمج في حساب الحوافز.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-0">
                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">نسبة KPI</TableHead>
                              <TableHead className="text-right">التقييم التقليدي</TableHead>
                              <TableHead className="text-right">الدرجة المدمجة</TableHead>
                              <TableHead className="text-right">مكافأة KPI</TableHead>
                              <TableHead className="text-right">التقييم</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {combinedScores.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={6} className="text-center py-8 text-gray-400">لا توجد تقييمات لهذا الشهر</TableCell>
                              </TableRow>
                            ) : (
                              combinedScores.map((s) => (
                                <TableRow key={s.employeeId} className="hover:bg-gray-50">
                                  <TableCell className="font-medium text-sm">{s.employeeName}</TableCell>
                                  <TableCell className="text-sm">
                                    {s.kpiScore !== null ? (
                                      <div className="flex items-center gap-2">
                                        <Progress value={Math.min(s.kpiScore, 100)} className="h-2 w-12" />
                                        <span className="font-semibold">{s.kpiScore}%</span>
                                      </div>
                                    ) : <span className="text-gray-400">-</span>}
                                  </TableCell>
                                  <TableCell className="text-sm">
                                    {s.traditionalScore !== null ? (
                                      <span className="font-semibold">{s.traditionalScore.toFixed(0)}%</span>
                                    ) : <span className="text-gray-400">-</span>}
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Progress value={Math.min(s.combinedScore!, 100)} className="h-2 w-16" />
                                      <span className="text-sm font-bold">{s.combinedScore}%</span>
                                    </div>
                                  </TableCell>
                                  <TableCell className="text-sm font-semibold text-emerald-600">
                                    {s.kpiBonus > 0 ? formatCurrency(s.kpiBonus) : '-'}
                                  </TableCell>
                                  <TableCell>
                                    <Badge className={`${getKpiRatingColor(s.combinedScore!)} border-0 text-xs`}>
                                      {s.overallRating}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2"><CardTitle className="text-sm">معايير التقييم الشامل</CardTitle></CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs font-semibold text-blue-700 mb-2">مؤشرات KPI (60%)</p>
                          <div className="space-y-1 text-xs text-gray-600">
                            <p>• المهام المنجزة vs المستهدفة</p>
                            <p>• جودة العمل والالتزام بالوقت</p>
                            <p>• التعاون والابتكار</p>
                          </div>
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-purple-700 mb-2">التقييم التقليدي (40%)</p>
                          <div className="space-y-1 text-xs text-gray-600">
                            <p>• جودة العمل (25%) • الالتزام (15%)</p>
                            <p>• رضا العملاء (15%) • التعاون (10%)</p>
                            <p>• المبادرة (10%) • التطوير (5%)</p>
                            <p>• الأفكار المقدمة (10%) • معدل القبول (10%)</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </main>
      </div>

      {/* KPI Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editId ? 'تعديل تقييم KPI' : 'إضافة تقييم KPI جديد'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div>
              <Label className="text-xs">الموظف *</Label>
              <Select value={form.employeeId} onValueChange={(v) => setForm({ ...form, employeeId: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">المهام المستهدفة *</Label>
                <Input type="number" min={1} value={form.tasksTarget} onChange={(e) => setForm({ ...form, tasksTarget: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-xs">المهام المنجزة *</Label>
                <Input type="number" min={0} value={form.tasksCompleted} onChange={(e) => setForm({ ...form, tasksCompleted: Number(e.target.value) })} />
              </div>
            </div>

            <div className="p-3 bg-blue-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">نسبة الإنجاز:</span>
                <div className="flex items-center gap-2">
                  <Progress value={Math.min(previewAchievement, 100)} className="h-2 w-20" />
                  <span className="text-sm font-bold text-blue-700">{previewAchievement}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">المكافأة:</span>
                <span className="text-sm font-bold text-emerald-600">{formatCurrency(previewBonus)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">التقييم:</span>
                <Badge className={`${getKpiRatingColor(previewAchievement)} border-0 text-xs`}>{previewRating}</Badge>
              </div>
            </div>

            <ScoreInput label="جودة العمل" value={form.qualityScore} onChange={(v) => setForm({ ...form, qualityScore: v })} />
            <ScoreInput label="الالتزام بالمواعيد" value={form.timelinessScore} onChange={(v) => setForm({ ...form, timelinessScore: v })} />
            <ScoreInput label="التعاون مع الفريق" value={form.collaborationScore} onChange={(v) => setForm({ ...form, collaborationScore: v })} />
            <ScoreInput label="الابتكار والمبادرة" value={form.innovationScore} onChange={(v) => setForm({ ...form, innovationScore: v })} />

            <div>
              <Label className="text-xs">ملاحظات المدير</Label>
              <Textarea value={form.managerNotes} onChange={(e) => setForm({ ...form, managerNotes: e.target.value })} rows={2} />
            </div>
            <div>
              <Label className="text-xs">أهداف الفترة القادمة</Label>
              <Textarea value={form.employeeGoals} onChange={(e) => setForm({ ...form, employeeGoals: e.target.value })} rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ClickUp Sync Dialog */}
      <Dialog open={clickupDialogOpen} onOpenChange={(open) => { if (!open && clickupStep !== 'syncing') setClickupDialogOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Link2 className="w-5 h-5 text-purple-600" />
              مزامنة مؤشرات الأداء من ClickUp
            </DialogTitle>
          </DialogHeader>

          {clickupStep === 'workspace' && (
            <div className="space-y-4 py-2">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <p className="text-xs text-purple-700">
                  💡 سيتم جلب بيانات المهام من ClickUp لشهر <strong>{month}</strong> ومطابقتها مع الموظفين عبر البريد الإلكتروني.
                </p>
              </div>

              {loadingWorkspaces ? (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 text-purple-500 mx-auto mb-3 animate-spin" />
                  <p className="text-sm text-gray-600">جاري الاتصال بـ ClickUp...</p>
                </div>
              ) : workspaces.length === 0 ? (
                <div className="text-center py-8">
                  <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-3" />
                  <p className="text-sm text-gray-700 font-medium">لم يتم العثور على مساحات عمل</p>
                  <p className="text-xs text-gray-500 mt-1">تأكد من صحة ClickUp API Token</p>
                </div>
              ) : (
                <>
                  <div>
                    <Label className="text-xs mb-1 block">مساحة العمل (Workspace) *</Label>
                    <Select value={selectedWorkspace} onValueChange={setSelectedWorkspace}>
                      <SelectTrigger><SelectValue placeholder="اختر مساحة العمل" /></SelectTrigger>
                      <SelectContent>
                        {workspaces.map((ws) => (
                          <SelectItem key={ws.id} value={ws.id}>{ws.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <DialogFooter className="gap-2">
                    <Button variant="outline" onClick={() => setClickupDialogOpen(false)}>إلغاء</Button>
                    <Button
                      onClick={handleFetchSummary}
                      disabled={!selectedWorkspace || loadingSummary}
                      className="bg-purple-600 hover:bg-purple-700 gap-2"
                    >
                      {loadingSummary ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> جاري الجلب...</>
                      ) : (
                        <><RefreshCw className="w-4 h-4" /> جلب بيانات المهام</>
                      )}
                    </Button>
                  </DialogFooter>
                </>
              )}
            </div>
          )}

          {clickupStep === 'mapping' && clickupSummary && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-purple-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-purple-600">{clickupSummary.members.length}</p>
                  <p className="text-xs text-gray-600">عضو في ClickUp</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-blue-600">{clickupSummary.total_tasks}</p>
                  <p className="text-xs text-gray-600">إجمالي المهام</p>
                </div>
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-xl font-bold text-emerald-600">{clickupSummary.total_completed}</p>
                  <p className="text-xs text-gray-600">المهام المكتملة</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">🔗 ربط أعضاء ClickUp بالموظفين</p>
                <p className="text-xs text-gray-500 mb-3">تم المطابقة التلقائية عبر البريد الإلكتروني. يمكنك تعديل الربط يدوياً.</p>

                <div className="max-h-[300px] overflow-y-auto space-y-2">
                    {clickupSummary.members
                      .sort((a, b) => b.total_tasks - a.total_tasks)
                      .map((member) => {
                        const isMapped = !!memberMapping[member.clickup_id];
                        return (
                          <div
                            key={member.clickup_id}
                            className={`border rounded-lg p-3 ${isMapped ? 'border-emerald-200 bg-emerald-50/50' : 'border-gray-200'}`}
                          >
                            <div className="flex items-center justify-between gap-3 flex-wrap">
                              <div className="flex-1 min-w-[180px]">
                                <div className="flex items-center gap-2">
                                  {isMapped ? (
                                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                                  ) : (
                                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                                  )}
                                  <div>
                                    <p className="text-sm font-medium">{member.username || member.email}</p>
                                    <p className="text-[10px] text-gray-500">{member.email}</p>
                                  </div>
                                </div>
                                <div className="flex gap-3 mt-1 text-[10px] text-gray-500">
                                  <span>المهام: <strong className="text-gray-700">{member.total_tasks}</strong></span>
                                  <span>المكتملة: <strong className="text-emerald-600">{member.completed_tasks}</strong></span>
                                  <span>الإنجاز: <strong className="text-blue-600">{member.completion_rate}%</strong></span>
                                </div>
                              </div>
                              <div className="w-[200px]">
                                <Select
                                  value={memberMapping[member.clickup_id] || 'none'}
                                  onValueChange={(v) => {
                                    setMemberMapping((prev) => {
                                      const next = { ...prev };
                                      if (v === 'none') {
                                        delete next[member.clickup_id];
                                      } else {
                                        next[member.clickup_id] = v;
                                      }
                                      return next;
                                    });
                                  }}
                                >
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue placeholder="اختر الموظف" />
                                  </SelectTrigger>
                                  <SelectContent position="popper" className="z-[9999] max-h-[200px] overflow-y-auto">
                                    <SelectItem value="none">-- غير مربوط --</SelectItem>
                                    {employees.map((e) => (
                                      <SelectItem key={e.id} value={e.id}>
                                        {e.fullName} ({e.email})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                </div>
              </div>

              <div className="bg-gray-50 border rounded-lg p-3 text-center">
                <p className="text-sm">
                  <strong className="text-emerald-600">{mappedCount}</strong> موظف سيتم مزامنة بياناتهم
                </p>
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setClickupStep('workspace')}>رجوع</Button>
                <Button
                  onClick={handleClickupSync}
                  disabled={mappedCount === 0}
                  className="bg-purple-600 hover:bg-purple-700 gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  مزامنة {mappedCount} موظف
                </Button>
              </DialogFooter>
            </div>
          )}

          {clickupStep === 'syncing' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <RefreshCw className="w-10 h-10 text-purple-500 mx-auto mb-3 animate-spin" />
                <p className="font-medium text-gray-700">جاري مزامنة البيانات من ClickUp...</p>
                <p className="text-sm text-gray-500 mt-1">يرجى عدم إغلاق النافذة</p>
              </div>
              <Progress value={syncProgress} className="h-3" />
              <p className="text-center text-sm text-gray-600">{syncProgress}%</p>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded p-2">
                  <p className="text-lg font-bold text-emerald-600">{syncStats.synced}</p>
                  <p className="text-xs text-gray-500">تم بنجاح</p>
                </div>
                <div className="bg-red-50 rounded p-2">
                  <p className="text-lg font-bold text-red-600">{syncStats.failed}</p>
                  <p className="text-xs text-gray-500">فشل</p>
                </div>
                <div className="bg-amber-50 rounded p-2">
                  <p className="text-lg font-bold text-amber-600">{syncStats.skipped}</p>
                  <p className="text-xs text-gray-500">تم تخطيه</p>
                </div>
              </div>
            </div>
          )}

          {clickupStep === 'done' && (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="font-bold text-lg text-gray-800">تمت المزامنة بنجاح!</p>
                <p className="text-sm text-gray-500 mt-1">تم تحديث مؤشرات الأداء من ClickUp لشهر {month}</p>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-emerald-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-emerald-600">{syncStats.synced}</p>
                  <p className="text-xs text-gray-600">تم مزامنته</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-red-600">{syncStats.failed}</p>
                  <p className="text-xs text-gray-600">فشل</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3">
                  <p className="text-2xl font-bold text-amber-600">{syncStats.skipped}</p>
                  <p className="text-xs text-gray-600">غير مربوط</p>
                </div>
              </div>
              {syncStats.skipped > 0 && (
                <p className="text-xs text-amber-600 text-center">
                  💡 بعض الأعضاء في ClickUp لم يتم ربطهم بموظفين في النظام. تأكد من تطابق البريد الإلكتروني.
                </p>
              )}
              <DialogFooter>
                <Button onClick={() => setClickupDialogOpen(false)} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">
                  إغلاق
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}