import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Pencil, Trash2, Zap, AlertOctagon, Menu, Download } from 'lucide-react';
import { Sidebar } from './Index';
import {
  createOvertimeRecord, updateOvertimeRecord, deleteOvertimeRecord as apiDeleteOt,
  createViolation, updateViolation, deleteViolation as apiDeleteVio,
  getEmployeeNameFromList, getEmployeeByIdFromList,
  calculateOvertimeAmount, formatCurrency, getCurrentMonth,
  DAY_TYPES, COMPENSATION_METHODS, APPROVAL_STATUSES,
  VIOLATION_TYPES, SEVERITY_LEVELS, RECURRENCE_OPTIONS, PENALTY_TYPES, GRIEVANCE_STATUSES
} from '@/lib/hr-api';
import { exportToCSV } from '@/lib/export-utils';
import { useAuth } from '@/lib/auth-context';
import { useHRData } from '@/lib/hr-data-context';

export default function OvertimePage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tab, setTab] = useState('overtime');
  const [month, setMonth] = useState(getCurrentMonth());
  const [saving, setSaving] = useState(false);
  const { user, loading: authLoading, login } = useAuth();
  const { employees, overtime: allOvertime, violations: allViolations, loading: dataLoading, refreshOvertime, refreshViolations } = useHRData();

  const [y, m] = month.split('-').map(Number);
  const start = new Date(y, m - 1, 1);
  const end = new Date(y, m, 0);

  const overtimeRecs = allOvertime.filter((r) => { const d = new Date(r.date); return d >= start && d <= end; });
  const violations = allViolations.filter((v) => { const d = new Date(v.date); return d >= start && d <= end; });

  const [otDialogOpen, setOtDialogOpen] = useState(false);
  const [otEditId, setOtEditId] = useState<string | null>(null);
  const [otForm, setOtForm] = useState({
    date: '', employeeId: '', dayType: 'يوم عادي', overtimeHours: 0,
    compensationMethod: 'مكافأة مالية', approved: 'قيد المراجعة',
  });

  const [vioDialogOpen, setVioDialogOpen] = useState(false);
  const [vioEditId, setVioEditId] = useState<string | null>(null);
  const [vioForm, setVioForm] = useState({
    date: '', employeeId: '', violationType: VIOLATION_TYPES[0], details: '',
    severity: 'بسيط', isRepeated: 'المرة الأولى', penalty: 'إنذار شفهي',
    deductionAmount: 0, deductionDays: 0, notificationDate: '',
    grievanceStatus: 'لا يوجد تظلم', notes: '',
  });

  function handleExportOvertime() {
    exportToCSV(
      overtimeRecs.map((rec) => {
        const emp = getEmployeeByIdFromList(employees, rec.employeeId);
        const amount = emp ? calculateOvertimeAmount(emp.basicSalary, rec.overtimeHours, rec.dayType) : 0;
        return {
          date: rec.date, employee: getEmployeeNameFromList(employees, rec.employeeId),
          dayType: rec.dayType, hours: rec.overtimeHours,
          rate: rec.dayType === 'يوم عادي' ? '125%' : '150%',
          amount: Math.round(amount * 100) / 100,
          compensation: rec.compensationMethod, approved: rec.approved,
        };
      }),
      [
        { key: 'date', label: 'التاريخ' }, { key: 'employee', label: 'الموظف' },
        { key: 'dayType', label: 'نوع اليوم' }, { key: 'hours', label: 'الساعات' },
        { key: 'rate', label: 'النسبة' }, { key: 'amount', label: 'المستحق (ر.ع)' },
        { key: 'compensation', label: 'التعويض' }, { key: 'approved', label: 'الموافقة' },
      ],
      `تقرير_العمل_الإضافي_${month}`
    );
  }

  function handleExportViolations() {
    exportToCSV(
      violations.map((v) => ({
        date: v.date, employee: getEmployeeNameFromList(employees, v.employeeId),
        type: v.violationType, severity: v.severity, repeated: v.isRepeated,
        penalty: v.penalty, deduction: v.deductionAmount, grievance: v.grievanceStatus,
      })),
      [
        { key: 'date', label: 'التاريخ' }, { key: 'employee', label: 'الموظف' },
        { key: 'type', label: 'نوع المخالفة' }, { key: 'severity', label: 'الخطورة' },
        { key: 'repeated', label: 'التكرار' }, { key: 'penalty', label: 'الجزاء' },
        { key: 'deduction', label: 'الخصم (ر.ع)' }, { key: 'grievance', label: 'التظلم' },
      ],
      `تقرير_المخالفات_${month}`
    );
  }

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center" dir="rtl">
        <Card>
          <CardContent className="p-8 text-center">
            <Zap className="w-12 h-12 text-[#1E3A5F] mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">للوصول إلى سجلات العمل الإضافي والمخالفات</p>
            <Button onClick={login} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">تسجيل الدخول</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const months: string[] = [];
  for (let mo = 1; mo <= 12; mo++) months.push(`2026-${String(mo).padStart(2, '0')}`);

  function openAddOt() {
    setOtEditId(null);
    const today = new Date().toISOString().split('T')[0];
    setOtForm({ date: today, employeeId: employees[0]?.id || '', dayType: 'يوم عادي', overtimeHours: 0, compensationMethod: 'مكافأة مالية', approved: 'قيد المراجعة' });
    setOtDialogOpen(true);
  }

  function openEditOt(rec: typeof overtimeRecs[0]) {
    setOtEditId(rec.id);
    setOtForm({ date: rec.date, employeeId: rec.employeeId, dayType: rec.dayType, overtimeHours: rec.overtimeHours, compensationMethod: rec.compensationMethod, approved: rec.approved });
    setOtDialogOpen(true);
  }

  async function saveOt() {
    if (!otForm.date || !otForm.employeeId) return;
    setSaving(true);
    try {
      if (otEditId) await updateOvertimeRecord(otEditId, otForm);
      else await createOvertimeRecord(otForm);
      setOtDialogOpen(false);
      await refreshOvertime();
    } finally {
      setSaving(false);
    }
  }

  function openAddVio() {
    setVioEditId(null);
    const today = new Date().toISOString().split('T')[0];
    setVioForm({ date: today, employeeId: employees[0]?.id || '', violationType: VIOLATION_TYPES[0], details: '', severity: 'بسيط', isRepeated: 'المرة الأولى', penalty: 'إنذار شفهي', deductionAmount: 0, deductionDays: 0, notificationDate: today, grievanceStatus: 'لا يوجد تظلم', notes: '' });
    setVioDialogOpen(true);
  }

  function openEditVio(rec: typeof violations[0]) {
    setVioEditId(rec.id);
    setVioForm({ date: rec.date, employeeId: rec.employeeId, violationType: rec.violationType, details: rec.details, severity: rec.severity, isRepeated: rec.isRepeated, penalty: rec.penalty, deductionAmount: rec.deductionAmount, deductionDays: rec.deductionDays, notificationDate: rec.notificationDate, grievanceStatus: rec.grievanceStatus, notes: rec.notes });
    setVioDialogOpen(true);
  }

  async function saveVio() {
    if (!vioForm.date || !vioForm.employeeId) return;
    setSaving(true);
    try {
      if (vioEditId) await updateViolation(vioEditId, vioForm);
      else await createViolation(vioForm);
      setVioDialogOpen(false);
      await refreshViolations();
    } finally {
      setSaving(false);
    }
  }

  const severityColors: Record<string, string> = {
    'بسيط': 'bg-green-100 text-green-700', 'متوسط': 'bg-yellow-100 text-yellow-700',
    'خطير': 'bg-orange-100 text-orange-700', 'خطير جداً': 'bg-red-100 text-red-700',
  };

  const approvalColors: Record<string, string> = {
    'نعم': 'bg-emerald-100 text-emerald-700', 'لا': 'bg-red-100 text-red-700',
    'قيد المراجعة': 'bg-yellow-100 text-yellow-700',
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]" dir="rtl">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:mr-72">
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <Zap className="w-5 h-5 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold text-[#1E293B]">العمل الإضافي والمخالفات</h1>
              <p className="text-xs text-[#64748B]">تسجيل ساعات العمل الإضافي وسجل المخالفات</p>
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 space-y-4">
          {dataLoading ? (
            <div className="text-center py-20 text-gray-400">جاري التحميل...</div>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Select value={month} onValueChange={setMonth}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {months.map((mo) => <SelectItem key={mo} value={mo}>{mo}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <Tabs value={tab} onValueChange={setTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="overtime" className="gap-2"><Zap className="w-4 h-4" /> العمل الإضافي</TabsTrigger>
                  <TabsTrigger value="violations" className="gap-2"><AlertOctagon className="w-4 h-4" /> سجل المخالفات</TabsTrigger>
                </TabsList>

                <TabsContent value="overtime" className="space-y-4">
                  <div className="flex justify-end gap-2">
                    <Button onClick={handleExportOvertime} variant="outline" className="gap-2"><Download className="w-4 h-4" /> تصدير CSV</Button>
                    <Button onClick={openAddOt} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]"><Plus className="w-4 h-4 ml-2" /> تسجيل عمل إضافي</Button>
                  </div>
                  <Card>
                    <CardContent className="p-0">
                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">التاريخ</TableHead>
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">نوع اليوم</TableHead>
                              <TableHead className="text-right">الساعات</TableHead>
                              <TableHead className="text-right">النسبة</TableHead>
                              <TableHead className="text-right">المستحق (ر.ع)</TableHead>
                              <TableHead className="text-right">التعويض</TableHead>
                              <TableHead className="text-right">الموافقة</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {overtimeRecs.length === 0 ? (
                              <TableRow><TableCell colSpan={9} className="text-center py-8 text-gray-400">لا توجد سجلات</TableCell></TableRow>
                            ) : (
                              overtimeRecs.map((rec) => {
                                const emp = getEmployeeByIdFromList(employees, rec.employeeId);
                                const amount = emp ? calculateOvertimeAmount(emp.basicSalary, rec.overtimeHours, rec.dayType) : 0;
                                const rate = rec.dayType === 'يوم عادي' ? '125%' : '150%';
                                return (
                                  <TableRow key={rec.id} className="hover:bg-gray-50">
                                    <TableCell className="text-sm">{rec.date}</TableCell>
                                    <TableCell className="text-sm font-medium">{getEmployeeNameFromList(employees, rec.employeeId)}</TableCell>
                                    <TableCell className="text-sm">{rec.dayType}</TableCell>
                                    <TableCell className="text-sm font-semibold">{rec.overtimeHours}h</TableCell>
                                    <TableCell className="text-sm">{rate}</TableCell>
                                    <TableCell className="text-sm font-semibold text-emerald-600">{formatCurrency(Math.round(amount * 100) / 100)}</TableCell>
                                    <TableCell className="text-xs">{rec.compensationMethod}</TableCell>
                                    <TableCell><Badge className={`${approvalColors[rec.approved] || 'bg-gray-100'} border-0 text-xs`}>{rec.approved}</Badge></TableCell>
                                    <TableCell>
                                      <div className="flex gap-1">
                                        <Button variant="ghost" size="icon" onClick={() => openEditOt(rec)}><Pencil className="w-4 h-4 text-blue-600" /></Button>
                                        <Button variant="ghost" size="icon" onClick={async () => { await apiDeleteOt(rec.id); await refreshOvertime(); }}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                );
                              })
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-500">
                        <strong>قانون العمل العماني:</strong> العمل الإضافي في الأيام العادية بنسبة 125% • في الإجازات والعطل بنسبة 150% • أجر الساعة = الراتب الأساسي ÷ 176
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="violations" className="space-y-4">
                  <div className="flex justify-end gap-2">
                    <Button onClick={handleExportViolations} variant="outline" className="gap-2"><Download className="w-4 h-4" /> تصدير CSV</Button>
                    <Button onClick={openAddVio} className="bg-red-600 hover:bg-red-700 text-white"><Plus className="w-4 h-4 ml-2" /> تسجيل مخالفة</Button>
                  </div>
                  <Card>
                    <CardContent className="p-0">
                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="text-right">التاريخ</TableHead>
                              <TableHead className="text-right">الموظف</TableHead>
                              <TableHead className="text-right">نوع المخالفة</TableHead>
                              <TableHead className="text-right">الخطورة</TableHead>
                              <TableHead className="text-right">التكرار</TableHead>
                              <TableHead className="text-right">الجزاء</TableHead>
                              <TableHead className="text-right">الخصم (ر.ع)</TableHead>
                              <TableHead className="text-right">التظلم</TableHead>
                              <TableHead className="text-right">إجراءات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {violations.length === 0 ? (
                              <TableRow><TableCell colSpan={9} className="text-center py-8 text-gray-400">لا توجد مخالفات</TableCell></TableRow>
                            ) : (
                              violations.map((vio) => (
                                <TableRow key={vio.id} className="hover:bg-gray-50">
                                  <TableCell className="text-sm">{vio.date}</TableCell>
                                  <TableCell className="text-sm font-medium">{getEmployeeNameFromList(employees, vio.employeeId)}</TableCell>
                                  <TableCell className="text-xs">{vio.violationType}</TableCell>
                                  <TableCell><Badge className={`${severityColors[vio.severity] || 'bg-gray-100'} border-0 text-xs`}>{vio.severity}</Badge></TableCell>
                                  <TableCell className="text-xs">{vio.isRepeated}</TableCell>
                                  <TableCell className="text-xs">{vio.penalty}</TableCell>
                                  <TableCell className="text-sm font-semibold text-red-600">{vio.deductionAmount > 0 ? formatCurrency(vio.deductionAmount) : '-'}</TableCell>
                                  <TableCell className="text-xs">{vio.grievanceStatus}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-1">
                                      <Button variant="ghost" size="icon" onClick={() => openEditVio(vio)}><Pencil className="w-4 h-4 text-blue-600" /></Button>
                                      <Button variant="ghost" size="icon" onClick={async () => { await apiDeleteVio(vio.id); await refreshViolations(); }}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-500">
                        <strong>قانون العمل العماني:</strong> لا يجوز أن تتجاوز الخصومات 25% من الراتب الشهري • يجب إخطار الموظف قبل 3 أيام • حق التظلم خلال 3 أيام
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </main>
      </div>

      {/* Overtime Dialog */}
      <Dialog open={otDialogOpen} onOpenChange={setOtDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>{otEditId ? 'تعديل سجل العمل الإضافي' : 'تسجيل عمل إضافي'}</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">التاريخ *</Label><Input type="date" value={otForm.date} onChange={(e) => setOtForm({ ...otForm, date: e.target.value })} /></div>
              <div>
                <Label className="text-xs">الموظف *</Label>
                <Select value={otForm.employeeId} onValueChange={(v) => setOtForm({ ...otForm, employeeId: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">نوع اليوم</Label>
                <Select value={otForm.dayType} onValueChange={(v) => setOtForm({ ...otForm, dayType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DAY_TYPES.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">عدد الساعات</Label><Input type="number" min={0} step={0.5} value={otForm.overtimeHours} onChange={(e) => setOtForm({ ...otForm, overtimeHours: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">طريقة التعويض</Label>
                <Select value={otForm.compensationMethod} onValueChange={(v) => setOtForm({ ...otForm, compensationMethod: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{COMPENSATION_METHODS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">الموافقة</Label>
                <Select value={otForm.approved} onValueChange={(v) => setOtForm({ ...otForm, approved: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{APPROVAL_STATUSES.filter((s) => s !== 'لا ينطبق').map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOtDialogOpen(false)}>إلغاء</Button>
            <Button onClick={saveOt} disabled={saving} className="bg-[#1E3A5F] hover:bg-[#2a4f7a]">{saving ? 'جاري الحفظ...' : 'حفظ'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Violation Dialog */}
      <Dialog open={vioDialogOpen} onOpenChange={setVioDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>{vioEditId ? 'تعديل المخالفة' : 'تسجيل مخالفة جديدة'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2 max-h-[60vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">التاريخ *</Label><Input type="date" value={vioForm.date} onChange={(e) => setVioForm({ ...vioForm, date: e.target.value })} /></div>
              <div>
                <Label className="text-xs">الموظف *</Label>
                <Select value={vioForm.employeeId} onValueChange={(v) => setVioForm({ ...vioForm, employeeId: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">نوع المخالفة</Label>
              <Select value={vioForm.violationType} onValueChange={(v) => setVioForm({ ...vioForm, violationType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{VIOLATION_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label className="text-xs">التفاصيل</Label><Textarea value={vioForm.details} onChange={(e) => setVioForm({ ...vioForm, details: e.target.value })} rows={2} /></div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-xs">الخطورة</Label>
                <Select value={vioForm.severity} onValueChange={(v) => setVioForm({ ...vioForm, severity: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{SEVERITY_LEVELS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">التكرار</Label>
                <Select value={vioForm.isRepeated} onValueChange={(v) => setVioForm({ ...vioForm, isRepeated: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{RECURRENCE_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">الجزاء</Label>
                <Select value={vioForm.penalty} onValueChange={(v) => setVioForm({ ...vioForm, penalty: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PENALTY_TYPES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">قيمة الخصم (ر.ع)</Label><Input type="number" value={vioForm.deductionAmount} onChange={(e) => setVioForm({ ...vioForm, deductionAmount: Number(e.target.value) })} /></div>
              <div>
                <Label className="text-xs">حالة التظلم</Label>
                <Select value={vioForm.grievanceStatus} onValueChange={(v) => setVioForm({ ...vioForm, grievanceStatus: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{GRIEVANCE_STATUSES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVioDialogOpen(false)}>إلغاء</Button>
            <Button onClick={saveVio} disabled={saving} className="bg-red-600 hover:bg-red-700 text-white">{saving ? 'جاري الحفظ...' : 'حفظ'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}