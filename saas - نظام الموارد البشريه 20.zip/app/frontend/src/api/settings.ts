import { client } from '../lib/api';

export interface EnvVariable {
  key: string;
  value: string;
  description: string;
}

export interface EnvConfig {
  backend_vars: Record<string, EnvVariable>;
  frontend_vars: Record<string, EnvVariable>;
}

export interface EnvVariableUpdate {
  value: string;
}

async function sdkGet(url: string) {
  const res = await client.apiCall.invoke({ url, method: 'GET' });
  return res.data;
}

async function sdkPost(url: string, data?: any) {
  const res = await client.apiCall.invoke({ url, method: 'POST', data });
  return res.data;
}

async function sdkPut(url: string, data?: any) {
  const res = await client.apiCall.invoke({ url, method: 'PUT', data });
  return res.data;
}

async function sdkDelete(url: string) {
  const res = await client.apiCall.invoke({ url, method: 'DELETE' });
  return res.data;
}

export const settingsApi = {
  // Fetch all configurations
  async getConfig(): Promise<EnvConfig> {
    return sdkGet('/api/v1/admin/settings/') as Promise<EnvConfig>;
  },

  // Update backend configuration
  async updateBackendConfig(
    key: string,
    value: string
  ): Promise<{ message: string }> {
    return sdkPut(`/api/v1/admin/settings/backend/${key}`, { value }) as Promise<{ message: string }>;
  },

  // Update frontend configuration
  async updateFrontendConfig(
    key: string,
    value: string
  ): Promise<{ message: string }> {
    return sdkPut(`/api/v1/admin/settings/frontend/${key}`, { value }) as Promise<{ message: string }>;
  },

  // Add backend configuration
  async addBackendConfig(
    key: string,
    value: string
  ): Promise<{ message: string }> {
    return sdkPost(`/api/v1/admin/settings/backend/${key}`, { value }) as Promise<{ message: string }>;
  },

  // Add frontend configuration
  async addFrontendConfig(
    key: string,
    value: string
  ): Promise<{ message: string }> {
    return sdkPost(`/api/v1/admin/settings/frontend/${key}`, { value }) as Promise<{ message: string }>;
  },

  // Delete backend configuration
  async deleteBackendConfig(key: string): Promise<{ message: string }> {
    return sdkDelete(`/api/v1/admin/settings/backend/${key}`) as Promise<{ message: string }>;
  },

  // Delete frontend configuration
  async deleteFrontendConfig(key: string): Promise<{ message: string }> {
    return sdkDelete(`/api/v1/admin/settings/frontend/${key}`) as Promise<{ message: string }>;
  },
};